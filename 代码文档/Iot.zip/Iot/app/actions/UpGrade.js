import * as types from "../constants/ActionTypes";
//updateTaskList
export const getUpdateTasks = (currentPage, condition) => {
  return {
    type: types.XAHC_EQU_UPGRADE,
    payload: {
      currentPage,
      condition
    }
  };
};
//appid
export const getAppid = value => {
  return {
    type: types.XAHC_EQU_APPID,
    payload: {
      value
    }
  };
};

//getAccount
export const getAccount = (currentPage, condition) => {
  return {
    type: types.XAHC_EQU_ACCOUNT,
    payload: {
      currentPage,
      condition
    }
  };
};
//delete
export const deleteTask = key => {
  console.log("action-> deleteTask");
  return {
    type: types.XAHC_EQU_DELETE,
    payload: {
      key
    }
  };
};
//getDeviceType
export const getDeviceType = (value, appid) => {
  return {
    type: types.XAHC_EQU_TYPE,
    payload: {
      value,
      appid
    }
  };
};
//version
export const getVersion = (appId, deviceMode) => {
  console.log("action-> getVersion ");
  return {
    type: types.XAHC_EQU_VERSION,
    payload: {
      appId,
      deviceMode
    }
  };
};
//version in id
export const versionInId = (appId, deviceMode) => {
  console.log("action-> getVersion ");
  return {
    type: types.XAHC_EQU_VERSIONINID,
    payload: {
      appId,
      deviceMode
    }
  };
};
//updateByType
export const updateByType = data => {
  console.log("action->updateByType");
  return {
    type: types.XAHC_EQU_TYPEUPDATE,
    payload: {
      uid: data.uid,
      appid: data.appid,
      deviceMode: data.deviceMode,
      sourceVersion: data.sourceVersion,
      targetVersion: data.targetVersion,
      account: data.account,
      description: data.description
    }
  };
};
//updateById
export const updateById = data => {
  console.log("action->updateByType");
  return {
    type: types.XAHC_EQU_UPDATEBYID,
    payload: {
      deviceId: data.deviceId,
      appid: data.appId,
      account: data.account,
      description: data.description,
      targetVersion: data.targetVersion,
      sourceVersion: data.sourceVersion
    }
  };
};

//getDeviceApps
export const getDeviceApps = deviceId => {
  console.log("action-> getDeviceApps");
  return {
    type: types.XAHC_EQU_DEVID,
    payload: {
      deviceId
    }
  };
};

//forceUpdate
export const forceUpdate = key => {
  console.log("action-> forceUpdate");
  return {
    type: types.XAHC_EQU_FOUPDATE,
    payload: {
      key
    }
  };
};
//unforceUpdate
export const unforceUpdate = key => {
  console.log("action-> unforceUpdate");
  return {
    type: types.XAHC_EQU_UNFOUPDATE,
    payload: {
      key
    }
  };
};
