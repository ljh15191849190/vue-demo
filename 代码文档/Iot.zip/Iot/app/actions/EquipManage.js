import * as types from "../constants/ActionTypes";

export const getEquipList = currentPage => {
  return {
    type: types.XAHC_EQUIP_MANAGEMENT,
    payload: {
      currentPage
    }
  };
};
export const addNewEquip = data => {
  return {
    type: types.XAHC_ADD_NEW_EQUIPMENT,
    payload: {
      uid: data.uid,
      deviceId: data.deviceId
    }
  };
};
export const unBindEquipByDeviceId = deviceId => {
  return {
    type: types.XAHC_UNBIND_EQUIPMENT,
    payload: {
      deviceId
    }
  };
};
export const delEquipByDeviceId = deviceId => {
  return {
    type: types.XAHC_EQUIP_MANAGEMENT_DEL,
    payload: {
      deviceId
    }
  };
};
export const getEquipByDeviceId = deviceId => {
  return {
    type: types.XAHC_GET_EQUIP_MANAGEMENT,
    payload: {
      deviceId
    }
  };
};
