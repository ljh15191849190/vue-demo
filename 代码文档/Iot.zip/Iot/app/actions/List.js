import * as types from "../constants/ActionTypes";

export const getInfo = (currentPage, condition) => {
  console.log("action-> list");
  if (condition) {
    return {
      type: types.XAHC_INFO_LIST,
      payload: {
        currentPage,
        condition
      }
    };
  } else {
    return {
      type: types.XAHC_INFO_LIST,
      payload: {
        currentPage
      }
    };
  }
};
