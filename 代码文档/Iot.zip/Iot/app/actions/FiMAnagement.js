import * as types from "../constants/ActionTypes";

export const getFiManagement = (currentPage, condition) => {
  console.log("action-> FiManagement");
  return {
    type: types.XAHC_EQU_MANAGEMENT,
    payload: {
      currentPage,
      condition
    }
  };
};
export const addNewFireware = data => {
  console.log("action-> addNewFireware");
  return {
    type: types.XAHC_ADD_NEW_FIREWARE,
    payload: {
      data
    }
  };
};
//forbidden
export const forbidden = (id, online) => {
  console.log("action-> forbidden");
  return {
    type: types.XAHC_EQU_FORBIDDEN,
    payload: {
      id,
      online
    }
  };
};
//clear appid
export const clearAppId = () => {
  return {
    type: types.XAHC_CLEAR_APPID
  };
};
//clear typeData
export const clearTypeData = () => {
  return {
    type: types.XAHC_CLEAR_TYPE
  };
};
