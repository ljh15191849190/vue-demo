import * as types from "../constants/ActionTypes";

export const uploadFile = data => {
  return {
    type: types.XAHC_UPLOAD_FILE,
    payload: {
      data
    }
  };
};
export const clearUploadFile = () => {
  return {
    type: types.XAHC_CLEAR_UPLOAD_FILE
  };
};
