import * as types from "../constants/ActionTypes";

export const getControl = (currentPage, condition) => {
  console.log("action->EquipmentControl");
  return {
    type: types.XAHC_GET_CONTROL_LIST,
    payload: {
      currentPage,
      condition
    }
  };
};
export const getControlType = deviceId => {
  console.log("action->getControlType");
  return {
    type: types.XAHC_GET_CONTROL_TYPE,
    payload: {
      deviceId
    }
  };
};
export const toControlEquip = data => {
  console.log("action->toControlEquip");
  return {
    type: types.XAHC_TO_CONTROL_EQUIP,
    payload: {
      data
    }
  };
};
