import * as types from "../constants/ActionTypes";

export const register = (name, pass) => {
  console.log("action->Register");
  return {
    type: types.XAHC_REGISTER,
    payload: {
      name,
      pass
    }
  };
};
