import * as types from "../constants/ActionTypes";

export const getOperHistory = (currentPage, condition) => {
  console.log("action-> getOperHistory");
  if (condition) {
    return {
      type: types.XAHC_UPDATE_HISTORY,
      payload: {
        currentPage,
        condition
      }
    };
  } else {
    return {
      type: types.XAHC_UPDATE_HISTORY,
      payload: {
        currentPage
      }
    };
  }
};
