export const XAHC_LOGIN = "LOGIN";
export const XAHC_LOGOUT = "LOGOUT";
export const LOGIN_SAGA = "LOGIN_SAGA";
export const LOGOUT_SAGA = "LOGOUT_SAGA";

export const XAHC_REGISTER = "XAHC_REGISTER";
export const XAHC_REGISTER_SAGA = "XAHC_REGISTER_SAGA";
export const ERROR = "ERROR";
//设备信息管理
export const XAHC_INFO_LIST = "INFO_LIST";
export const XAHC_INFO_LIST_SAGA = "INFO_LIST_SAGA";

//update history
export const XAHC_UPDATE_HISTORY = "UPDATE_HISTORY";
export const XAHC_UPDATE_HISTORY_SAGA = "UPDATE_HISTORY_SAGA";

//EQU control
export const XAHC_GET_CONTROL_LIST = "GET_CONTROL_LIST";
export const XAHC_GET_CONTROL_LIST_SAGA = "GET_CONTROL_LIST_SAGA";
export const XAHC_GET_CONTROL_TYPE = "GET_CONTROL_TYPE";
export const XAHC_GET_CONTROL_TYPE_SAGA = "GET_CONTROL_TYPE_SAGA";
export const XAHC_TO_CONTROL_EQUIP = "TO_CONTROL_EQUIP";
export const XAHC_TO_CONTROL_EQUIP_SAGA = "TO_CONTROL_EQUIPE_SAGA";
//equipment update
export const XAHC_EQU_UPGRADE = "EQU_UPGRADE";
export const XAHC_EQU_UPGRADE_SAGA = "EQU_UPGRADE_SAGA";

//firmware management
export const XAHC_EQU_MANAGEMENT = "EQU_MANAGEMENT";
export const XAHC_EQU_MANAGEMENT_SAGA = "EQU_MANAGEMENT_SAGA";
export const XAHC_ADD_NEW_FIREWARE = "ADD_NEW_FIREWARE";
export const XAHC_ADD_NEW_FIREWARE_SAGA = "ADD_NEW_FIREWARE_SAGA";
export const XAHC_EQU_FORBIDDEN = "EQU_FORBIDDEN";
export const XAHC_EQU_FORBIDDEN_SAGA = "EQU_FORBIDDEN_SAGA";
//clear appid
export const XAHC_CLEAR_APPID = "CLEAR_APPID";
export const XAHC_CLEAR_APPID_SAGA = "CLEAR_APPID_SAGA";
//clear typeData
export const XAHC_CLEAR_TYPE = "CLEAR_TYPE";
export const XAHC_CLEAR_TYPE_SAGA = "CLEAR_TYPE_SAGA";
//app
export const XAHC_APP_MANAGE = "APP_MANAGE";
export const XAHC_APP_MANAGE_SAGA = "APP_MANAGE_SAGA";

export const XAHC_ADD_APP = "ADD_APP";
export const XAHC_ADD_APP_SAGA = "ADD_APP_SAGA";

//equipment update-appid
export const XAHC_EQU_APPID = "EQU_APPID";
export const XAHC_EQU_APPID_SAGA = "EQU_APPID_SAGA";

//appid details
export const XAHC_EQU_APPIDDETAILS = "EQU_APPIDDETAILS";
export const XAHC_EQU_APPIDDETAILS_SAGA = "EQU_APPIDDETAILS_SAGA";

//equipment update-version
export const XAHC_EQU_VERSION = "EQU_VERSION";
export const XAHC_EQU_VERSION_SAGA = "EQU_VERSION_SAGA";

//equipment IDupdate-version
export const XAHC_EQU_VERSIONINID = "EQU_VERSIONINID";
export const XAHC_EQU_VERSIONINID_SAGA = "EQU_VERSIONINID_SAGA";

//equipment management
export const XAHC_EQUIP_MANAGEMENT = "EQUIP_MANAGEMENT";
export const XAHC_EQUIP_MANAGEMENT_SAGA = "EQUIP_MANAGEMENT_SAGA";
export const XAHC_ADD_NEW_EQUIPMENT = "ADD_NEW_EQUIPMENT";
export const XAHC_ADD_NEW_EQUIPMENT_SAGA = "ADD_NEW_EQUIPMENT_SAGA";
export const XAHC_UNBIND_EQUIPMENT = "UNBIND_EQUIPMENT";
export const XAHC_UNBIND_EQUIPMENT_SAGA = "UNBIND_EQUIPMENT_SAGA";
export const XAHC_EQUIP_MANAGEMENT_DEL = "EQUIP_MANAGEMENT_DEL";
export const XAHC_EQUIP_MANAGEMENT_DEL_SAGA = "EQUIP_MANAGEMENT_DEL_SAGA";
export const XAHC_GET_EQUIP_MANAGEMENT = "GET_EQUIP_MANAGEMENT";
export const XAHC_GET_EQUIP_MANAGEMENT_SAGA = "GET_EQUIP_MANAGEMENT_SAGA";
//delete
export const XAHC_EQU_DELETE = "EQU_DELETE";
export const XAHC_EQU_DELETE_SAGA = "EQU_DELETE_SAGA";

//getAccount
export const XAHC_EQU_ACCOUNT = "EQU_ACCOUNT";
export const XAHC_EQU_ACCOUNT_SAGA = "EQU_ACCOUNT_SAGA";

//DeviceType
export const XAHC_EQU_TYPE = "EQU_TYPE";
export const XAHC_EQU_TYPE_SAGA = "EQU_TYPE_SAGA";

//getDeviceApps按设备id查询
export const XAHC_EQU_DEVID = "EQU_DEVID";
export const XAHC_EQU_DEVID_SAGA = "EQU_DEVID_SAGA";

//updateByType
export const XAHC_EQU_TYPEUPDATE = "EQU_TYPEUPDATE";
export const XAHC_EQU_TYPEUPDATE_SAGA = "EQU_TYPEUPDATE_SAGA";

//updateById
export const XAHC_EQU_UPDATEBYID = "EQU_UPDATEBYID";
export const XAHC_EQU_UPDATEBYID_SAGA = "EQU_UPDATEBYID_SAGA";

//forceUpdate
export const XAHC_EQU_FOUPDATE = "EQU_FOUPDATE";
export const XAHC_EQU_FOUPDATE_SAGA = "EQU_FOUPDATE_SAGA";

//unforceUpdate
export const XAHC_EQU_UNFOUPDATE = "EQU_UNFOUPDATE";
export const XAHC_EQU_UNFOUPDATE_SAGA = "EQU_UNFOUPDATE_SAGA";

//upload
export const XAHC_UPLOAD_FILE = "EQU_UPLOAD_FILE";
export const XAHC_UPLOAD_FILE_SAGA = "UPLOAD_FILE_SAGA";
export const XAHC_CLEAR_UPLOAD_FILE = "CLEAR_UPLOAD_FILE";
export const XAHC_CLEAR_UPLOAD_FILE_SAGA = "CLEAR_UPLOAD_FILE_SAGA";

/*
permission*/
export const XAHC_ADD = "XAHC_ADD";
export const SAGA_ADD = "SAGA_ADD";

export const XAHC_DEL = "XAHC_DEL";
export const SAGA_DEL = "SAGA_DEL";

export const XAHC_GET = "XAHC_GET";
export const SAGA_GET = "SAGA_GET";

export const XAHC_UPDATE = "XAHC_UPDATE";
export const SAGA_UPDATE = "SAGA_UPDATE";

export const XAHC_SEARCHGET = "XAHC_SEARCHGET";
export const SAGA_SEARCH = "SAGA_SEARCH";

export const XAHC_UPDATE_COMPANY_INFO = "XAHC_UPDATE_COMPANY_INFO";
export const SAGA_UPDATE_COMPANY_INFO = "SAGA_UPDATE_COMPANY_INFO";