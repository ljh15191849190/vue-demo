export default {
  login: "/user/login",
  logout: "/user/logout",
  register: "/user/register",
  //getEquInfo: "/webdeviceinfo/deviceInfo/findAllDeviceInfo",
  getEquInfo: "/webdeviceinfo/deviceInfo/all",
  getOperHistory: "/webupgradehistory/upgradeHistory/findCustomized",
  getUpdateTasks: "/webupgradetask/upgradeTask/findCustomized",
  getFiManagement: "/devicepackage/package/get",
  addNewFirmWare: "/devicepackage/package/add",
  getEquipControl: "/webdevicecontrol/deviceControl/findControlMsg",
  getEquipControlType: "/webdevicecontrol/deviceControl/findControlModeByDeviceId",
  toControlEquip: "/webdevicecontrol/deviceControl/send",
  getAppidInfo: "/webdeviceappinfo/deviceAppInfo/findAppInfo",
  getVersion: "/devicepackage/package/getVersionAll",
  getAppList: "/appinfo/app/getAppAll",
  addApp: "/appinfo/app/registe",
  appIdDetails: "/appinfo/app/getApp",
  deleteTask: "/webupgradetask/upgradeTask/modifyState",
  getAccount: "/webuserapplication/user-findnameanduid",
  getDeviceType: "/webdeviceappinfo/deviceAppInfo/findAllDeviceType",
  getAllEquipment: "/webdeviceappinfo/deviceAppInfo/findAllDeviceAppInfo",
  delEquipById: "/webdeviceinfo/deviceInfo/deleteDeviceInfo",
  getEquipById: "/webdeviceinfo/deviceInfo/findDeviceById",
  getDeviceApps: "/webdeviceappinfo/deviceAppInfo/getDeviceApps",
  updateByType: "/webupgradetask/upgradeTask/upgrade/mode",
  updateById: "/webupgradetask/upgradeTask/upgrade/deviceId",
  forceUpdate: "/webupgradetask/upgradeTask/upgrade/forced",
  unforceUpdate: "/webupgradetask/upgradeTask/upgrade/unforced",
  uploadFile: "/webfileupapplication/uploadFile",
  addNewEquipment: "/webdeviceappinfo/deviceAppInfo/addDeviceAppInfo",
  unbindEquipment: "/webdeviceappinfo/deviceAppInfo/deleteDeviceAppInfo",
  forbidden: "/devicepackage/package/change",
  getAppAll:"/appinfo/app/getAppList",

  companyGetOne: "/webuser/company/getOne",
  companyUpdate: "/webuser/company/update",
 
  // userList: "/webuser/permission/user-list",        
  // userFindone: "webuser/permission/user-findone",  
  // userUpdate: "/webuser/permission/user-update",
  // userSave: "webuser/permission/user-save",   //ADDUSER
  // userDelete: "webuser/permission/user-delete",
  // userAddsysrole: "webuser/permission/user-addsysrole",   //ADDSYSROLE

  // sysrolelist: "/webuser/permission/sysrole-list",
  // sysroleFind: "webuser/permission/sysrole-find",  
  // sysroleUpdate: "/webuser/permission/sysrole-update",
  // sysroleSave: "webuser/permission/sysrole-save",   //ADDsysrole
  // sysroleDelete: "webuser/permission/sysrole-delete",
  // sysroleAddsyspermission: "/webuser/permission/sysrole-addsyspermission",   //Addsyspermission

  // syspermissionlist: "/webuser/permission/syspermission-list",
  // syspermissionFind: "webuser/permission/syspermission-find-id",  
  // syspermissionUpdate: "/webuser/permission/syspermission-update",
  // syspermissionSave: "webuser/permission/syspermission-save",   //ADDsyspermission  http://192.168.100.107:7070
  // syspermissionDelete: "webuser/permission/syspermission-delete",

};
