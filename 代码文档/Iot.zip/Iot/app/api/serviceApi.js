import "whatwg-fetch";
import history from "../routes/history";
import URL from "./urlConfig";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";

let fetchApi = function(postData, url, resolve, obj) {
  let options = {
    method: "POST",
    credentials: "include",
    body: JSON.stringify(postData)
  };
  fetch(url, options)
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/iot/login");
        message.info("请登录！");
        // } else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        //   message.info("数据不存在");
      } else {
        resolve({ res: data, param: obj });
      }
    });
};

let fetchFileApi = function(postData, url, resolve, obj) {
  let options = {
    method: "POST",
    credentials: "include",
    body: postData
  };
  fetch(url, options)
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/iot/login");
        message.info("请登录！");
      } else {
        resolve({ res: data, param: obj });
      }
    });
};
let fetchApiGet = function(postData, url, resolve, obj) {
  let options = {
    method: "GET",
    credentials: "include"
  };
  fetch(url, options)
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/iot/login");
        message.info("请登录！");
      } else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.info("数据不存在");
      } else {
        resolve({ res: data, param: obj });
      }
    });
};

class ServiceApi {
  static login(payload) {
    return new Promise(resolve => {
      let url =
        URL.login + "?username=" + payload.name + "&pwd=" + payload.pass + "&equipmenttype=pc";
      let postdata = {};
      fetchApi(postdata, url, resolve);
    });
  }
  static register(payload) {
    console.log("serviceApi -> register");
    return new Promise(resolve => {
      let url = URL.register + "?name=" + payload.name + "&password=" + payload.pass;
      let postdata = {};
      fetchApi(postdata, url, resolve);
    });
  }
  static queryAppList() {
    console.log("serviceApi -> queryAppList");
    return new Promise(resolve => {
      let url = URL.getAppAll + "?uid=" + localStorage.getItem("uid");
      let postdata = {};
      fetchApiGet(postdata, url, resolve);
    });
  }
  static addAppRequest(payload) {
    return new Promise(resolve => {
      let url =
        URL.addApp +
        "?appName=" +
        payload.appName +
        "&pkgName=" +
        payload.pkgName +
        "&signName=" +
        payload.signName +
        "&describe=" +
        payload.describe +
        "&uid=" +
        localStorage.getItem("uid");

      let postdata = {};
      fetchApi(postdata, url, resolve);
    });
  }
  //appid details
  static appIdDetails(payload) {
    return new Promise(resolve => {
      let url = URL.appIdDetails + "?appId=" + payload.value;
      let reqParam = {
        conditions: []
      };
      fetchApiGet(reqParam, url, resolve);
    });
  }
  static getEquInfo(payload) {
    return new Promise(resolve => {
      let url = URL.getEquInfo + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {};
      if (payload.condition) {
        reqParam["conditions"] = [payload.condition];
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }
  //updateTask
  static getUpdateTasks(payload) {
    return new Promise(resolve => {
      let url = URL.getUpdateTasks + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //updateHistory
  static getOperHistory(payload) {
    return new Promise(resolve => {
      let url = URL.getOperHistory + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {};
      if (payload.condition) {
        reqParam["conditions"] = [payload.condition];
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }
  //fimanagement
  static getFiManagement(payload) {
    return new Promise(resolve => {
      let url = URL.getFiManagement + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  static addNewFirmWare(payload) {
    var uid = localStorage.getItem("uid");
    return new Promise(resolve => {
      let url =
        URL.addNewFirmWare +
        "?deviceMode=" +
        payload.type +
        "&uid=" +
        uid +
        "&appId=" +
        payload.appId +
        "&version=" +
        payload.version +
        "&url=" +
        payload.url +
        "&md5=" +
        payload.md5 +
        "&size=" +
        payload.size;
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //equipmentControl
  static getEquipControl(payload) {
    return new Promise(resolve => {
      let url = URL.getEquipControl + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //equipmentControl
  static getEquipControlType(payload) {
    return new Promise(resolve => {
      let url = URL.getEquipControlType + "?deviceId=" + payload.deviceId;
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  static toControlEquip(payload) {
    return new Promise(resolve => {
      let url = URL.toControlEquip;
      let reqParam = {
        deviceId: payload.deviceId,
        command: payload.command
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  //get all equipments
  static addAllEquips(payload) {
    console.log("serviceApi -> addAllEquips");
    return new Promise(resolve => {
      let url = URL.getAllEquipment + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //del equipment by id
  static delEquipByDeviceId(payload) {
    console.log("serviceApi -> delEquipByDeviceId");
    return new Promise(resolve => {
      let url = URL.delEquipById + "?deviceId=" + payload.deviceId;
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //get all equipment by id
  static getEquipByDeviceId(payload) {
    console.log("serviceApi -> getEquipByDeviceId");
    return new Promise(resolve => {
      let url = URL.getEquipById + "?deviceId=" + payload.deviceId;
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //add new equipment
  static addNewEquip(payload) {
    console.log("serviceApi -> addNewEquip");
    return new Promise(resolve => {
      let url = URL.addNewEquipment;
      let params = {
        uid: payload.uid,
        deviceId: payload.deviceId
      };
      fetchApi(params, url, resolve);
    });
  }
  //add new equipment
  static unBindEquip(payload) {
    console.log("serviceApi -> unBindEquip");
    return new Promise(resolve => {
      let url = URL.unbindEquipment;
      let params = {
        deviceId: payload.deviceId
      };
      fetchApi(params, url, resolve);
    });
  }
  //updateappid
  static getAppidInfo(payload) {
    return new Promise(resolve => {
      let url = URL.getAppidInfo + "?uid=" + payload.value;
      let reqParam = {
        conditions: []
      };
      fetchApiGet(reqParam, url, resolve);
    });
  }
  //updateVersion
  static getVersion(payload) {
    return new Promise(resolve => {
      let url = URL.getVersion + "?deviceMode=" + payload.deviceMode + "&appId=" + payload.appId;
      let reqData = {
        // deviceMode: payload.deviceMode,
        // appId: payload.appId
      };
      fetchApi(reqData, url, resolve);
    });
  }
  //version in id
  static versionInId(payload) {
    return new Promise(resolve => {
      let url = URL.getVersion + "?deviceMode=" + payload.deviceMode + "&appId=" + payload.appId;
      let reqData = {};
      fetchApi(reqData, url, resolve);
    });
  }
  //deleteTask
  static deleteTask(payload) {
    return new Promise(resolve => {
      let url = URL.deleteTask + "?id=" + payload.key;
      let delData = [];
      fetchApi(delData, url, resolve);
    });
  }
  //update account
  static getAccount(payload) {
    return new Promise(resolve => {
      let url = URL.getAccount;
      let accountdata = {};
      fetchApi(accountdata, url, resolve);
    });
  }
  //getDeviceType
  static getDeviceType(payload) {
    return new Promise(resolve => {
      let url = URL.getDeviceType + "?uid=" + payload.value + "&appid=" + payload.appid;
      let typeData = {};
      fetchApi(typeData, url, resolve);
    });
  }
  //getDeviceApps
  static getDeviceApps(payload) {
    return new Promise(resolve => {
      let url = URL.getDeviceApps + "?deviceId=" + payload.deviceId;
      let reqParam = {
        conditions: []
      };
      fetchApiGet(reqParam, url, resolve);
    });
  }
  //updateByType
  static updateByType(payload) {
    return new Promise(resolve => {
      let url = URL.updateByType;
      let updateData = {
        deviceMode: payload.deviceMode,
        appid: payload.appid,
        targetVersion: payload.targetVersion,
        account: payload.account,
        sourceVersion: payload.sourceVersion,
        description: payload.description,
        uid: payload.uid
      };
      fetchApi(updateData, url, resolve);
    });
  }
  //updateById
  static updateById(payload) {
    return new Promise(resolve => {
      let url = URL.updateById;
      let updateData = {
        deviceId: payload.deviceId,
        appid: payload.appid,
        targetVersion: payload.targetVersion,
        sourceVersion:payload.sourceVersion,
        account: payload.account,
        description: payload.description
      };
      fetchApi(updateData, url, resolve);
    });
  }
  //forceUpdate
  static forceUpdate(payload) {
    return new Promise(resolve => {
      let url = URL.forceUpdate + "?id=" + payload.key;
      let forceData = {};
      fetchApi(forceData, url, resolve);
    });
  }
  //unforceUpdate
  static unforceUpdate(payload) {
    return new Promise(resolve => {
      let url = URL.unforceUpdate + "?id=" + payload.key;
      let unforceData = {};
      fetchApi(unforceData, url, resolve);
    });
  }
  //upload file
  static uploadFile(payload) {
    return new Promise(resolve => {
      let url = URL.uploadFile;
      // let postData = payload;
      fetchFileApi(payload.data, url, resolve, payload.data);
    });
  }
  //forbidden
  static forbidden(payload) {
    console.log("serviceApi -> forbidden");
    return new Promise(resolve => {
      let url = URL.forbidden + "?id=" + payload.id + "&online=" + payload.online;
      let data = {
        id: payload.id,
        online: payload.online
      };
      fetchApi(data, url, resolve);
    });
  }

   //company add app
   static addAppRequest(payload) {
    return new Promise(resolve => {
      console.log("severceApi->addApp");
      let url =
        URL.addApp +
        "?appName=" +
        payload.appName +
        "&describe=" +
        payload.describe +
        "&companyId=" +
        payload.companyId;
      let postdata = {
        // appName: payload.appName,
        // describe: payload.describe,
        // companyId: payload.companyId
      };
      fetchApi(postdata, url, resolve);
    });
  }
  //company app list
  static getAppList(payload) {
    return new Promise(resolve => {
      let url = URL.appList + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //company staff info
  static getStaffInfo(payload) {
    return new Promise(resolve => {
      let url = URL.staffInfo + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
  //权限管理
  static add(param) {
    let that = this;
    let postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.usersave;
          break;
        case "roleManage":
          url = URL.sysrolesave;
          break;
        case "resManage":
          url = URL.addres;
          break;
        case "addrole":
          url = URL.useraddsysrole + postdata;
          postdata = {};
          break;
        case "addResource":
          url = URL.configRes + postdata;
          break;
        case "locationManage":
          url = URL.addlocation;
          break;
        case "carinfo":
          //url = URL.addlocation;
          break;
        case "gatedevice" || "videodevice" || "barrierdevice":
          url = URL.adddevice;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
  static del(param) {
    let url = "";
    let postdata = {};
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.userdelete + "?userId=" + param.id;
          break;
        case "roleManage":
          url = URL.sysroledelete + "?id=" + param.id;
          break;
        case "resManage":
          url = URL.delres + "?permissionId=" + param.id;
          break;
        case "gatedevice" || "videodevice" || "barrierdevice":
          url = URL.deldevice + "?id=" + param.id;
          break;
        case "locationManage":
          url = URL.dellocation + "?id=" + param.id;
          break;
        case "carinfo":
          //url = URL.dellocation + "?id=" + param.id;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
  static add(param) {
    let that = this;
    let postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.usersave;
          break;
        case "roleManage":
          url = URL.sysrolesave;
          break;
        case "resManage":
          url = URL.addres;
          break;
        case "addrole":
          url = URL.useraddsysrole + postdata;
          postdata = {};
          break;
        case "addResource":
          url = URL.configRes + postdata;
          break;
        case "locationManage":
          url = URL.addlocation;
          break;
        case "carinfo":
          //url = URL.addlocation;
          break;
        case "gatedevice" || "videodevice" || "barrierdevice":
          url = URL.adddevice;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
  static del(param) {
    let url = "";
    let postdata = {};
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.userdelete + "?userId=" + param.id;
          break;
        case "roleManage":
          url = URL.sysroledelete + "?id=" + param.id;
          break;
        case "resManage":
          url = URL.delres + "?permissionId=" + param.id;
          break;
        case "gatedevice" || "videodevice" || "barrierdevice":
          url = URL.deldevice + "?id=" + param.id;
          break;
        case "locationManage":
          url = URL.dellocation + "?id=" + param.id;
          break;
        case "carinfo":
          //url = URL.dellocation + "?id=" + param.id;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
  static get(param) {
    let url = "";
    let postdata = { conditions: [] };
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.syspermissionlist + "?size=10&page=" + param.page;
          break;
        case "roleManage":
          if (param.page == null) {
            //无分页查询
            url = URL.sysrolelist;
          } else {
            //有分页查询
            url = URL.sysrolelist + "?size=10&page=" + param.page;
          }
          break;
        case "companyGetOne":
          url = URL.companyGetOne;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }

  static update(param) {
    let postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.userupdate;
          break;
        case "roleManage":
          url = URL.sysroleupdate;
          break;
        case "resManage":
          url = URL.updateres;
          break;
        case "doordevice":
          url = URL.updatedoor;
          break;
        case "barrierdevice":
          url = URL.updatereading;
          break;
        case "gatedevice" || "videodevice":
          url = URL.updatedevice;
          break;
        case "locationManage":
          url = URL.updatelocation;
          break;
        case "carinfo":
          //url = URL.updatelocation;
          break;
        case "adddevice":
          url = URL.updatedevice;
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
  static search(param) {
    let url = "";
    let postdata = "";
    return new Promise(resolve => {
      console.log("searchparam", param);
      switch (param.from) {
        case "userManage":
          if (param.params.inputType && param.params.inputName) {
            // console.log("312");
            postdata = {
              conditions: [
                {
                  name: "name",
                  sopt: "cn",
                  value: param.params.inputName
                },
                {
                  name: "resourceType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            };
          } else if (param.params.inputType) {
            postdata = {
              conditions: [
                {
                  name: "resourceType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            };
          } else if (param.params.inputName) {
            postdata = {
              conditions: [
                {
                  name: "name",
                  sopt: "cn",
                  value: param.params.inputName
                }
              ]
            };
          } else {
            postdata = {
              conditions: []
            };
          }
          url = URL.syspermissionlist + "?size=10&page=" + param.page;
          break;
        case "roleManage":
          if (param.params.inputType && param.params.inputName) {
            // console.log("param", param.params.inputType)
            postdata = {
              conditions: [
                {
                  name: "role",
                  sopt: "cn",
                  value: param.params.inputName
                },
                {
                  name: "roleType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            }; 
            
          } else if (param.params.inputType) {
            postdata = {
              conditions: [
                {
                  name: "roleType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            };
          } else if (param.params.inputName) {
            postdata = {
              conditions: [
                {
                  name: "role",
                  sopt: "cn",
                  value: param.params.inputName
                }
              ]
            };
          } else {
            postdata = {
              conditions: []
            };
          }
          if (param.page == null) {
            //无分页查询
            url = URL.sysrolelist;
          } else {
            //有分页查询
            url = URL.sysrolelist + "?size=10&page=" + param.page;
          }
          break;
      }
      console.log("search", postdata, url, resolve);
      fetchApi(postdata, url, resolve);
    });
  }
  static updateCompanyInfo(param) {
    console.log("serviceApi -> updateCompanyInfo");
    return new Promise(resolve => {
      console.log("updateCompanyInfo", param);
      let url =
        URL.companyUpdate +
        "?country=" +
        param.params.country +
        "&city=" +
        param.params.city +
        "&mail=" +
        param.params.mail +
        "&contacts=" +
        param.params.contacts +
        "&address=" +
        param.params.address +
        "&industry=" +
        param.params.industry +
        "&pnumber=" +
        param.params.pnumber +
        "&phone=" +
        param.params.phone +
        "&mobile=" +
        param.params.mobile;
      console.log(url);
      let postdata = {};
      fetchApi(postdata, url, resolve);
    });
  }


}
export default ServiceApi;
