import "babel-polyfill";
import { takeEvery, takeLatest } from "redux-saga/effects";
import * as types from "../constants/ActionTypes";
import { loginFlow } from "./login";
import { logoutFlow } from "./logout";
import { getInfoFlow } from "./EquList";
import { getOperHistoryFlow } from "./OperHistory";
import {
  getUpdateTasksFlow,
  getAppidFlow,
  getVersionFlow,
  getAccountFlow,
  getDeviceTypeFlow
} from "./UpGrade";

import {
  addMethod,
  delMethod,
  getMethod,
  updateMethod,
  searchMethod,
  updateCompanyInfoMethod
} from "./systemManage/permissionManage/callApi";

import { updateByTypeFlow } from "./UpGrade";
import { updateByIdFlow } from "./UpGrade";
import { getDeviceAppsFlow } from "./UpGrade";
import { forceUpdateFlow } from "./UpGrade";
import { unforceUpdateFlow } from "./UpGrade";
import { versionInIdFlow } from "./UpGrade";
import { getFiManagementFlow, addNewFirmWareFlow, forbiddenFlow } from "./FiMAnagement";
import { clearAppIdFlow, cleraTypeFlow } from "./FiMAnagement";
import { getEquipControlFlow, getEquipControlTypeFlow, toControlEquipFlow } from "./EquipControl";
import { registerFlow } from "./Register";
import { getAppFlow, addAppFlow, appidDetailFlow } from "./App";
import { deleteTaskFlow } from "./UpGrade";
import {
  getEquipsFlow,
  delEquipsByDeviceIDFlow,
  getEquipsByDeviceIDFlow,
  addNewEquipmentFlow,
  unbindEquipmentFlow
} from "./EquipManage";
import { uploadFileFlow, clearFileFlow } from "./Upload";

export default function* mySaga() {
  yield [
    takeEvery(types.XAHC_LOGIN, loginFlow),
    takeEvery(types.XAHC_LOGOUT, logoutFlow),
    takeEvery(types.XAHC_REGISTER, registerFlow),
    takeEvery(types.XAHC_INFO_LIST, getInfoFlow),
    takeEvery(types.XAHC_UPDATE_HISTORY, getOperHistoryFlow),
    takeEvery(types.XAHC_EQU_UPGRADE, getUpdateTasksFlow),
    takeEvery(types.XAHC_EQU_MANAGEMENT, getFiManagementFlow),
    takeEvery(types.XAHC_GET_CONTROL_LIST, getEquipControlFlow),
    takeEvery(types.XAHC_GET_CONTROL_TYPE, getEquipControlTypeFlow),
    takeEvery(types.XAHC_TO_CONTROL_EQUIP, toControlEquipFlow),
    takeEvery(types.XAHC_EQU_APPID, getAppidFlow),
    takeEvery(types.XAHC_EQU_VERSION, getVersionFlow),
    takeEvery(types.XAHC_APP_MANAGE, getAppFlow),
    takeEvery(types.XAHC_ADD_APP, addAppFlow),
    takeEvery(types.XAHC_EQUIP_MANAGEMENT, getEquipsFlow),
    takeEvery(types.XAHC_EQUIP_MANAGEMENT_DEL, delEquipsByDeviceIDFlow),
    takeEvery(types.XAHC_GET_EQUIP_MANAGEMENT, getEquipsByDeviceIDFlow),
    takeEvery(types.XAHC_ADD_NEW_EQUIPMENT, addNewEquipmentFlow),
    takeEvery(types.XAHC_UNBIND_EQUIPMENT, unbindEquipmentFlow),
    takeEvery(types.XAHC_EQU_DELETE, deleteTaskFlow),
    takeEvery(types.XAHC_EQU_ACCOUNT, getAccountFlow),
    takeEvery(types.XAHC_EQU_TYPE, getDeviceTypeFlow),
    takeEvery(types.XAHC_EQU_TYPEUPDATE, updateByTypeFlow),
    takeEvery(types.XAHC_EQU_UPDATEBYID, updateByIdFlow),
    takeEvery(types.XAHC_EQU_DEVID, getDeviceAppsFlow),
    takeEvery(types.XAHC_EQU_FOUPDATE, forceUpdateFlow),
    takeEvery(types.XAHC_EQU_UNFOUPDATE, unforceUpdateFlow),
    takeEvery(types.XAHC_UPLOAD_FILE, uploadFileFlow),
    takeEvery(types.XAHC_ADD_NEW_FIREWARE, addNewFirmWareFlow),
    takeEvery(types.XAHC_EQU_FORBIDDEN, forbiddenFlow),
    takeEvery(types.XAHC_EQU_APPIDDETAILS, appidDetailFlow),
    takeEvery(types.XAHC_CLEAR_UPLOAD_FILE, clearFileFlow),
    takeEvery(types.XAHC_EQU_VERSIONINID, versionInIdFlow),
    takeEvery(types.XAHC_CLEAR_APPID, clearAppIdFlow),
    takeEvery(types.XAHC_CLEAR_TYPE, cleraTypeFlow),

    // permission
    takeEvery(types.XAHC_ADD, addMethod),
    takeEvery(types.XAHC_DEL, delMethod),
    takeEvery(types.XAHC_GET, getMethod),
    takeEvery(types.XAHC_UPDATE, updateMethod),
    takeEvery(types.XAHC_SEARCHGET, searchMethod),
    takeEvery(types.XAHC_UPDATE_COMPANY_INFO, updateCompanyInfoMethod),


  ];
}
