import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import { getManagement, addNewFirmWareRequest, unforcedUpdate, forbide } from "./apiCall";

export function* getFiManagement(payload) {
  try {
    var resData = yield call(getManagement, payload);
    yield put({ type: actionTypes.XAHC_EQU_MANAGEMENT_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addNewFirmWare(payload) {
  try {
    var resData = yield call(addNewFirmWareRequest, payload);
    yield put({ type: actionTypes.XAHC_ADD_NEW_FIREWARE_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getFiManagementFlow({ payload }) {
  let response = yield call(getFiManagement, payload);
}
export function* addNewFirmWareFlow({ payload }) {
  let response = yield call(addNewFirmWare, payload.data);
}
export function* forbidden(payload) {
  console.log("saga->forbidden");
  try {
    var resData = yield call(forbide, payload);
    yield put({ type: actionTypes.XAHC_EQU_FORBIDDEN_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* forbiddenFlow({ payload }) {
  console.log("saga->forbiddenFlow");
  let response = yield call(forbidden, payload);
}
//clear appId
export function* clearAppId() {
  try {
    yield put({ type: actionTypes.XAHC_CLEAR_APPID_SAGA });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* clearAppIdFlow() {
  let response = yield call(clearAppId);
}
//clear typeData
export function* clearTypeData() {
  try {
    yield put({ type: actionTypes.XAHC_CLEAR_TYPE_SAGA });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* cleraTypeFlow() {
  let response = yield call(clearTypeData);
}
