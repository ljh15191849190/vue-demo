import {put, call} from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {getEquInfo} from "./apiCall";

export function* getInfo(payload) {
  try {
    var resData = yield call(getEquInfo, payload);
    yield put({type: actionTypes.XAHC_INFO_LIST_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}

export function* getInfoFlow({payload}) {
  let response = yield call(getInfo, payload);
}
