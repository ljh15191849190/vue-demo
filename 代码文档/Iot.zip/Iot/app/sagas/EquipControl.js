import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import { getControl, getControlType, toControlEquip } from "./apiCall";

export function* getEquipControl(payload) {
  try {
    var resData = yield call(getControl, payload);
    yield put({ type: actionTypes.XAHC_GET_CONTROL_LIST_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEquipControlType(payload) {
  try {
    var resData = yield call(getControlType, payload);
    yield put({ type: actionTypes.XAHC_GET_CONTROL_TYPE_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* controlEquip(payload) {
  try {
    var control = yield call(toControlEquip, payload);
    yield put({ type: actionTypes.XAHC_TO_CONTROL_EQUIP_SAGA, control });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEquipControlFlow({ payload }) {
  let response = yield call(getEquipControl, payload);
}
export function* getEquipControlTypeFlow({ payload }) {
  let response = yield call(getEquipControlType, payload);
}
export function* toControlEquipFlow({ payload }) {
  let response = yield call(controlEquip, payload.data);
}
