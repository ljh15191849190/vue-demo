import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {
  getUpGradeTask,
  getAppidInfo,
  getVersionInfo,
  getAccounts,
  deleteTask,
  getDeviceTypes,
  addAppRequest
} from "./apiCall";
import { updateByTypeTask } from "./apiCall";
import { updateByIdTask } from "./apiCall";
import { getDeviceApp } from "./apiCall";
import { forcedUpdate } from "./apiCall";
import { unforcedUpdate } from "./apiCall";
import { versionInIds } from "./apiCall";
import { addApp } from "./App";

//updateTask
export function* getUpdateTasks(payload) {
  try {
    var resData = yield call(getUpGradeTask, payload);
    yield put({ type: actionTypes.XAHC_EQU_UPGRADE_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getUpdateTasksFlow({ payload }) {
  let response = yield call(getUpdateTasks, payload);
}

//equipment Appid
export function* getAppid(payload) {
  try {
    var resData = yield call(getAppidInfo, payload);
    yield put({ type: actionTypes.XAHC_EQU_APPID_SAGA, resData: resData });
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getAppidFlow({payload}) {
  let response = yield call(getAppid, payload);
}

//update version
export function* getVersion(payload) {
  try {
    console.log("saga-> getVersion");
    var resData = yield call(getVersionInfo, payload);
    yield put({type: actionTypes.XAHC_EQU_VERSION_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getVersionFlow({payload}) {
  let response = yield call(getVersion, payload);
}

//version in id
export function* versionInId(payload) {
  try {
    console.log("saga-> getVersion");
    var resData = yield call(versionInIds, payload);
    yield put({ type: actionTypes.XAHC_EQU_VERSIONINID_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* versionInIdFlow({ payload }) {
  let response = yield call(versionInId, payload);
}

//update account
export function* getAccount(payload) {
  try {
    var resData = yield call(getAccounts, payload);
    yield put({type: actionTypes.XAHC_EQU_ACCOUNT_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getAccountFlow({payload}) {
  let response = yield call(getAccount, payload);
}

//delete
export function* deleteTasks(payload) {
  try {
    console.log("saga-> deleteTask");
    var resData = yield call(deleteTask, payload);
    yield put({type: actionTypes.XAHC_EQU_DELETE_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* deleteTaskFlow({payload}) {
  console.log("saga-> deleteTaskFlow");
  let response = yield call(deleteTasks, payload);
}

//getDeviceType
export function* getDeviceType(payload) {
  try {
    var resData = yield call(getDeviceTypes, payload);
    yield put({type: actionTypes.XAHC_EQU_TYPE_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getDeviceTypeFlow({payload}) {
  let response = yield call(getDeviceType, payload);
}

//updateByType
export function* updateByType(payload) {
  try {
    var typeStatus = yield call(updateByTypeTask, payload);
    yield put({type: actionTypes.XAHC_EQU_TYPEUPDATE_SAGA, typeStatus});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* updateByTypeFlow({payload}) {
  let response = yield call(updateByType, payload);
}

//updateById
export function* updateById(payload) {
  try {
    var typeStatus = yield call(updateByIdTask, payload);
    yield put({type: actionTypes.XAHC_EQU_UPDATEBYID_SAGA, typeStatus});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* updateByIdFlow({payload}) {
  let response = yield call(updateById, payload);
}

//getDeviceApps
export function* getDeviceApps(payload) {
  try {
    var resData = yield call(getDeviceApp, payload);
    yield put({type: actionTypes.XAHC_EQU_DEVID_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getDeviceAppsFlow({payload}) {
  let response = yield call(getDeviceApps, payload);
}

//updateByType

//forceUpdate
export function* forceUpdate(payload) {
  try {
    var resData = yield call(forcedUpdate, payload);
    yield put({type: actionTypes.XAHC_EQU_FOUPDATE_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* forceUpdateFlow({payload}) {
  let response = yield call(forceUpdate, payload);
}

//unforceUpdate
export function* unforceUpdate(payload) {
  try {
    var resData = yield call(unforcedUpdate, payload);
    yield put({type: actionTypes.XAHC_EQU_UNFOUPDATE_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* unforceUpdateFlow({payload}) {
  let response = yield call(unforceUpdate, payload);
}