import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {
  addAllEquips,
  delEquipByDeviceId,
  getEquipByDeviceId,
  addNewEquip,
  unBindEquip
} from "./apiCall";

export function* getEquipList(payload) {
  try {
    var equipList = yield call(addAllEquips, payload);
    yield put({ type: actionTypes.XAHC_EQUIP_MANAGEMENT_SAGA, equipList });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* delEquipById(payload) {
  try {
    var delStatus = yield call(delEquipByDeviceId, payload);
    yield put({ type: actionTypes.XAHC_EQUIP_MANAGEMENT_DEL_SAGA, delStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEquipById(payload) {
  try {
    var equipList = yield call(getEquipByDeviceId, payload);
    yield put({ type: actionTypes.XAHC_GET_EQUIP_MANAGEMENT_SAGA, equipList });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addNewEqiup(payload) {
  try {
    var addEquipStatus = yield call(addNewEquip, payload);
    yield put({ type: actionTypes.XAHC_ADD_NEW_EQUIPMENT_SAGA, addEquipStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* unbindEqiupment(payload) {
  try {
    var unbindEquipStatus = yield call(unBindEquip, payload);
    yield put({ type: actionTypes.XAHC_UNBIND_EQUIPMENT_SAGA, unbindEquipStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEquipsFlow({ payload }) {
  let response = yield call(getEquipList, payload);
}
export function* delEquipsByDeviceIDFlow({ payload }) {
  let response = yield call(delEquipById, payload);
}
export function* getEquipsByDeviceIDFlow({ payload }) {
  let response = yield call(getEquipById, payload);
}
export function* addNewEquipmentFlow({ payload }) {
  let response = yield call(addNewEqiup, payload);
}
export function* unbindEquipmentFlow({ payload }) {
  let response = yield call(unbindEqiupment, payload);
}
