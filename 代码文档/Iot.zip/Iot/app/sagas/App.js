import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {queryAppList, addAppRequest, appIdDetails} from "./apiCall";

export function* getAppList() {
  try {
    var appList = yield call(queryAppList);
    yield put({type: actionTypes.XAHC_APP_MANAGE_SAGA, appList: appList});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* addApp(payload) {
  try {
    var appStatus = yield call(addAppRequest, payload);
    yield put({type: actionTypes.XAHC_ADD_APP_SAGA, appStatus});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* getAppFlow() {
  let response = yield call(getAppList);
}
export function* addAppFlow({payload}) {
  let response = yield call(addApp, payload);
}

//appid details
export function* appidDetail(payload) {
  try {
    let appDetail = yield call(appIdDetails, payload);
    yield put({type: actionTypes.XAHC_EQU_APPIDDETAILS_SAGA, appDetail});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}
export function* appidDetailFlow({payload}) {
  let response = yield call(appidDetail, payload);
}
