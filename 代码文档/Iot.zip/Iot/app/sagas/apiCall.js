import ajaxServiceApi from "../api/serviceApi";

//login
export const loginMethod = payload => {
  return ajaxServiceApi.login(payload).then(res => res);
};

//user register
export const registerMethod = payload => {
  return ajaxServiceApi.register(payload).then(res => res);
};

//get equpiment
export const getEquInfo = payload => {
  return ajaxServiceApi.getEquInfo(payload).then(res => res);
};

//equipmentUpdate
export const getUpGradeTask = payload => {
  return ajaxServiceApi.getUpdateTasks(payload).then(res => res);
};

//get update history
export const getOperaHistory = payload => {
  return ajaxServiceApi.getOperHistory(payload).then(res => res);
};

//get fireware list
export const getManagement = payload => {
  return ajaxServiceApi.getFiManagement(payload).then(res => res);
};
//add new firmware
export const addNewFirmWareRequest = payload => {
  return ajaxServiceApi.addNewFirmWare(payload).then(res => res);
};
//get control list
export const getControl = payload => {
  return ajaxServiceApi.getEquipControl(payload).then(res => res);
};
//get control type
export const getControlType = payload => {
  return ajaxServiceApi.getEquipControlType(payload).then(res => res);
};
export const toControlEquip = payload => {
  return ajaxServiceApi.toControlEquip(payload).then(res => res);
};

//get app id
export const getAppidInfo = payload => {
  return ajaxServiceApi.getAppidInfo(payload).then(res => res);
};

//get versions
export const getVersionInfo = payload => {
  console.log("apiCall->getVersion ");
  return ajaxServiceApi.getVersion(payload).then(res => res);
};
//version in id
export const versionInIds = payload => {
  console.log("apiCall->getVersion ");
  return ajaxServiceApi.versionInId(payload).then(res => res);
};

export const queryAppList = () => {
  return ajaxServiceApi.queryAppList().then(res => res);
};
export const addAppRequest = payload => {
  return ajaxServiceApi.addAppRequest(payload).then(res => res);
};
export const addAllEquips = payload => {
  return ajaxServiceApi.addAllEquips(payload).then(res => res);
};
export const delEquipByDeviceId = payload => {
  return ajaxServiceApi.delEquipByDeviceId(payload).then(res => res);
};
export const getEquipByDeviceId = payload => {
  return ajaxServiceApi.getEquipByDeviceId(payload).then(res => res);
};

export const addNewEquip = payload => {
  return ajaxServiceApi.addNewEquip(payload).then(res => res);
};
export const unBindEquip = payload => {
  return ajaxServiceApi.unBindEquip(payload).then(res => res);
};
//delete
export const deleteTask = payload => {
  console.log("apiCall->deleteTask ");
  return ajaxServiceApi.deleteTask(payload).then(res => res);
};

//equipment account
export const getAccounts = () => {
  return ajaxServiceApi.getAccount().then(res => res);
};

//getDeviceType
export const getDeviceTypes = payload => {
  return ajaxServiceApi.getDeviceType(payload).then(res => res);
};

//getDeviceApps
export const getDeviceApp = payload => {
  return ajaxServiceApi.getDeviceApps(payload).then(res => res);
};

//updateByType
export const updateByTypeTask = payload => {
  return ajaxServiceApi.updateByType(payload).then(res => res);
};

//updateById
export const updateByIdTask = payload => {
  return ajaxServiceApi.updateById(payload).then(res => res);
};

//forceUpdate
export const forcedUpdate = payload => {
  return ajaxServiceApi.forceUpdate(payload).then(res => res);
};

//unforceUpdate
export const unforcedUpdate = payload => {
  return ajaxServiceApi.unforceUpdate(payload).then(res => res);
};
//upload file
export const updateFileRequest = payload => {
  return ajaxServiceApi.uploadFile(payload).then(res => res);
};
//forbidden
export const forbide = payload => {
  console.log("apicall->forbide");
  return ajaxServiceApi.forbidden(payload).then(res => res);
};
//appid details
export const appIdDetails = payload => {
  return ajaxServiceApi.appIdDetails(payload).then(res => res);
};
