import {put, call, take} from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {registerMethod} from "./apiCall";

export function* register(payload) {
  try {
    console.log("saga-> register");
    var registerStatus = yield call(registerMethod, payload);
    yield put({type: actionTypes.XAHC_REGISTER_SAGA, registerStatus: registerStatus});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}

export function* registerFlow({payload}) {
  let response = yield call(register, payload);
}
