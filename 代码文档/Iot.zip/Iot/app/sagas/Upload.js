import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import { updateFileRequest } from "./apiCall";

export function* uploadFile(payload) {
  try {
    var uploadInfo = yield call(updateFileRequest, payload);
    yield put({ type: actionTypes.XAHC_UPLOAD_FILE_SAGA, uploadInfo });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* clearUploadFile() {
  try {
    yield put({ type: actionTypes.XAHC_CLEAR_UPLOAD_FILE_SAGA });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* uploadFileFlow({ payload }) {
  let response = yield call(uploadFile, payload);
}

export function* clearFileFlow() {
  let response = yield call(clearUploadFile);
}
