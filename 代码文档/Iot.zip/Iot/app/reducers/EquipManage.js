import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import { message } from "antd";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  delStatus: 0,
  addStatus: 0,
  unbindStatus: 0
});

const EquList = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_EQUIP_MANAGEMENT_SAGA:
      console.log("reducer->EquList");
      if (action.equipList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.equipList.res.data)
          .set("pageConfig", action.equipList.res.pageBean)
          .set("delStatus", 0)
          .set("addStatus", 0)
          .set("unbindStatus", 0);
      }
      return state;
    case types.XAHC_EQUIP_MANAGEMENT_DEL_SAGA:
      if (action.delStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1).set("addStatus", 0);
      }
    case types.XAHC_GET_EQUIP_MANAGEMENT_SAGA:
      if (action.equipList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", [action.equipList.res.data])
          .set("pageConfig", {})
          .set("delStatus", 0)
          .set("addStatus", 0)
          .set("unbindStatus", 0);
      }
    case types.XAHC_ADD_NEW_EQUIPMENT_SAGA:
      if (action.addEquipStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("addStatus", 1)
          .set("delStatus", 0)
          .set("unbindStatus", 0);
      } else if (action.addEquipStatus.res.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.info("该设备不存在");
        return state
          // .set("addStatus", 2)
          // .set("delStatus", 0)
          // .set("unbindStatus", 0);
      }else if (action.addEquipStatus.res.rtn_code == StatusCode.XAHC_ALREADY_BIND) {
        message.info("该设备已经绑定");
        return state
          // .set("addStatus", 3)
          // .set("delStatus", 0)
          // .set("unbindStatus", 0);
      }else if (action.addEquipStatus.res.rtn_code == StatusCode.XAHC_NOROLE_BIND) {
        message.info("没有权限绑定此设备");
        return state
          // .set("addStatus", 4)
          // .set("delStatus", 0)
          // .set("unbindStatus", 0);
      }
    case types.XAHC_UNBIND_EQUIPMENT_SAGA:
      if (action.unbindEquipStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        // message.info("解绑成功");
        return state
          .set("unbindStatus", 1)
          .set("delStatus", 0)
          .set("addStatus", 0);
      } else {
        message.info("解绑失败");
        return state
          // .set("unbindStatus", 2)
          // .set("delStatus", 0)
          // .set("addStatus", 0);
      }
    default:
      return state;
  }
};

export default EquList;
