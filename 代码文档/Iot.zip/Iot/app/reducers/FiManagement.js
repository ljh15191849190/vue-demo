import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";
import { message } from "antd";
import Immutable from "immutable";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  addStatus: 0
});

const FiManagement = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_EQU_MANAGEMENT_SAGA:
      console.log("reducer->FiManagement");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean)
          .set("addStatus", 0);
      }
    case types.XAHC_ADD_NEW_FIREWARE_SAGA:
      console.log("reducer->FiManagement");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("addStatus", 1);
      } else if (action.resData.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        message.warning("不能重复添加");
        return state.set("addStatus", 2);
      } else if (action.resData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("添加失败");
        return state.set("addStatus", -1);
      }
    default:
      return state;
  }
};
export default FiManagement;