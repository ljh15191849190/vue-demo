import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import history from "../routes/history";
import * as StatusCode from "../constants/StatusCode";
import { message } from "antd";

const initState = Immutable.Map({
  logininfo: 0,
  loginStatus: 0
});

const login = (state = initState, action) => {
  switch (action.type) {
    case types.LOGIN_SAGA:
      if (action.loginStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        localStorage.setItem("loginStatue", 1);
        localStorage.setItem("salt", action.loginStatus.res.salt);
        localStorage.setItem("uid", action.loginStatus.res.uid);
        localStorage.setItem("userInfo", JSON.stringify(action.loginStatus.res));
        return state.set("logininfo", 1);
      } else if (action.loginStatus.res.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        localStorage.setItem("loginStatue", 0);
        message.error("用户名或密码错误");
        return state.set("logininfo", 2);
      }
      return state.set("loginStatus", action.loginStatus.res.login);

    case types.LOGOUT_SAGA:
      history.push("/iot/login");
      localStorage.setItem("loginStatue", 0);
      return state.set("logininfo", 0);
    default:
      return state;
  }
};

export default login;
