import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";
import {message} from "antd";
import Immutable from "immutable";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  controlType: [],
  controlStatus: 0
});

const EquipControl = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_GET_CONTROL_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean)
          .set("controlStatus", 0);
      }
      return state;
    case types.XAHC_GET_CONTROL_TYPE_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("controlType", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean)
          .set("controlStatus", 0);
      }
      return state;
    case types.XAHC_TO_CONTROL_EQUIP_SAGA:
      if (action.control.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("controlStatus", 1);
      } else {
        message.info("控制失败");
        return state;
      }
      return state;
    default:
      return state;
  }
};
export default EquipControl;
