import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import { message } from "antd";

const initState = Immutable.Map({
  registerStatus: 0
});

const register = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_REGISTER_SAGA:
      console.log("reducer->logregisterin");
      if (action.registerStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("用户信息注册成功");
        return state.set("registerStatus", 1);
      } else if (action.registerStatus.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        localStorage.clear();
        message.warning("该用户已存在");
        return state;
      }
      return state;

    default:
      return state;
  }
};

export default register;
