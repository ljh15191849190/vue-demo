import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

import Immutable from "immutable";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {}
});

const OperHistory = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_UPDATE_HISTORY_SAGA:
      console.log("reducer->OperHistory");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state.set("resData", []).set("pageConfig", {});

    default:
      return state;
  }
};

export default OperHistory;
