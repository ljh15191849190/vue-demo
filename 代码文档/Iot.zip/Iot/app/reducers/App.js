import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import history from "../routes/history";

const initState = Immutable.Map({
  appList: [],
  appDetail: {},
  appAddStatus: 0,
  resData: []
});

const app = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_APP_MANAGE_SAGA:
      console.log("reducer->app");
      if (action.appList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("appList", action.appList.res.data).set("appAddStatus", 0);
      } else if (action.appList.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        localStorage.clear();
        return state.set("appList", []);
      }
      return state;
    case types.XAHC_ADD_APP_SAGA:
      if (action.appStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("appAddStatus", 1);
      } else if (action.appStatus.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        return state.set("appAddStatus", 2);
      }
      return state;
    case types.XAHC_EQU_APPIDDETAILS_SAGA:
      if (action.appDetail.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("appDetail", JSON.parse(action.appDetail.res.data));
      }
      return state.set("appIdDetails", []);
    default:
      return state;
  }
};

export default app;
