import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

import Immutable from "immutable";

const initState = Immutable.Map({
  uploadResInfo: [],
  uploadStatus: 0
});

const Upload = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_UPLOAD_FILE_SAGA:
      if (action.uploadInfo.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("uploadResInfo", action.uploadInfo.res.data).set("uploadStatus", 1);
      } else {
        return state.set("uploadResInfo", []).set("uploadStatus", 0);
      }
    case types.XAHC_CLEAR_UPLOAD_FILE_SAGA:
      return state.set("uploadResInfo", []).set("uploadStatus", 0);
    default:
      return state;
  }
};
export default Upload;
