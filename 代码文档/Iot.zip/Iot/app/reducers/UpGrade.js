import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

import Immutable from "immutable";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  appidData: [],
  appidDataStatus: 0,
  typeDataStatus: 0,
  versionInfo: []
});

const GradeTasks = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_EQU_UPGRADE_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_EQU_APPID_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("appidData", action.resData.res.data).set("appidDataStatus", 1);
      } else {
        return state.set("appidData", []).set("appidDataStatus", 0);
      }
      return state;
    case types.XAHC_EQU_TYPE_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("typeData", action.resData.res.data).set("typeDataStatus", 1);
      } else {
        return state.set("typeData", []).set("typeDataStatus", 0);
      }
      return state;
    case types.XAHC_EQU_DEVID_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("DeviceApp", action.resData.res.data);
      }
      return state;
    case types.XAHC_EQU_VERSION_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("versionInfo", action.resData.res.data);
      }
      return state.set("versionInfo", []);
      return state;
    case types.XAHC_EQU_VERSIONINID_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("versionInId", action.resData.res.data);
      }
      return state.set("versionInId", []);

    case types.XAHC_CLEAR_APPID_SAGA:
      return state.set("appidData", []).set("appidDataStatus", 0);
    case types.XAHC_CLEAR_TYPE_SAGA:
      return state.set("typeData", []).set("typeDataStatus", 0);
    default:
      return state;
  }
};
export default GradeTasks;
