import { combineReducers } from "redux";
import login from "./login";
import equList from "./EquList";
import OperHistory from "./OperHistory";
import upGrade from "./UpGrade";
import fiManagemet from "./FiManagement";
import equipControl from "./EquiControl";
import register from "./Register";
import app from "./App";
import account from "./getAccount";
import getAccount from "./getAccount";
import equipManage from "./EquipManage";
import upload from "./Upload";

import permissionManage from "./systemManage/permissionManage/reducer";

const rootReducer = combineReducers({
  login,
  equList,
  OperHistory,
  upGrade,
  fiManagemet,
  equipControl,
  register,
  app,
  account,
  getAccount,
  equipManage,
  upload,

  permissionManage,
});

export default rootReducer;
