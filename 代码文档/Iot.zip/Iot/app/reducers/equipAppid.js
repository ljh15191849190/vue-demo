import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

import Immutable from "immutable";

const initState = Immutable.Map({
  resData: []
});

const appidInfo = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_EQU_APPID_SAGA:
      console.log("reducer->appidInfo");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("resData", action.resData.res.data);
      }
      return state;

    default:
      return state;
  }
};
export default appidInfo;