import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import history from "../routes/history";

const initState = Immutable.Map({
  updateList: [],
  typeStatus: 0
});

const typeUpdate = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_EQU_TYPEUPDATE_SAGA:
      console.log("reducer->app");
      if (action.updateList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("updateList", action.updateList.res.data).set("typeStatus", 0);
      } else if (action.updateList.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        localStorage.clear();
        return state.set("updateList", []);
      }
      return state;
    case types.XAHC_ADD_APP_SAGA:
      if (action.appStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("typeStatus", 1);
      } else if (action.appStatus.res.rtn_code == StatusCode.XAHC_DATA_EXIST) {
        return state.set("typeStatus", 2);
      }
    default:
      return state;
  }
};

export default typeUpdate;