import * as type from "../../../constants/ActionTypes";
import * as StatusCode from "../../../constants/StatusCode";
import Immutable from "immutable";
import history from "../../../routes/history";
import { message } from "antd";

const initState = Immutable.Map({
  companyGetOneData: [],
  userManageData: [],
  roleManageData: [],
  resManageData: [],
  findresData: []
});

const reduce = (state = initState, action) => {
  console.log("reducereducer", action);
  switch (action.type) {
    case type.SAGA_ADD:
      if (action.status.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("添加成功！");
      } else {
        message.error("没有权限添加！");
      }
      return state;
      break;

    case type.SAGA_DEL:
      if (action.status.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("删除成功！");
      } else {
        message.error("没有权限删除！");
      }
      return state;
      break;

    case type.SAGA_GET:
      console.log("reducerroleManage", action.data)
      if (action.data.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "companyGetOne":
            localStorage.setItem("companyId", action.data.res.data.companyId);
            console.log("companyGetOne", action.data.res.data.companyId);
            return state.set("companyGetOneData", action.data.res);
            break;
          case "userManage":
            return state.set("userManageData", action.data.res);
            break;
          case "roleManage":
            return state.set("roleManageData", action.data.res);
            break;
          case "resManage":
            return state.set("resManageData", action.data.res);
            break;
          case "findres":
            return state.set("findresData", action.data.res);
            break;
        }
      } else {
        message.error("没有权限获取数据！");
        return state;
      }
      break;

    case type.SAGA_UPDATE:
      if (action.status.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("修改成功！");
      } else {
        message.error("没有权限修改！");
      }
      return state;
      break;
    
    case type.SAGA_SEARCH:
      console.log("reducerroleManage", action.data)
      if (action.data.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "userManage":
            return state.set("userManageData", action.data.res);
            break;
          case "roleManage":
            return state.set("roleManageData", action.data.res);
            break;
          case "resManage":
            return state.set("resManageData", action.data.res);
            break;
          case "findres":
            return state.set("findresData", action.data.res);
            break;
        }
      } else {
        message.error("没有权限获取数据！");
        return state;
      }
      break;

    case type.SAGA_UPDATE_COMPANY_INFO:
      console.log("reducerroleinfo", action.data)
      if (action.data.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "companyInfo":
            message.info("修改用户数据成功！");
            return state.set("companyInfo", action.data.res);
            break;
        }
      } else {
        message.error("没有权限修改用户数据！");
        return state;
      }
      break;



    default:
      return state;

  }
};

export default reduce;
