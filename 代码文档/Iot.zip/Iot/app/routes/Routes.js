import React from "react";
import {Router, Route, Switch} from "react-router-dom";
import history from "./history";
import RenderRoutes from "./RenderRoutes";

import LoginContainer from "../components/login/LoginContainer";
import Container from "../container/Container";
import Home from "../components/home/Home";
import Register from "../components/register/Register";
import Equipment from "../components/home/equipment/Layout";
import LayoutComponent from "../components/home/equipment/Layout";

//global router config
const routesConfig = [
  {
    path: "/iot/home",
    component: Home
  },
  {
    path: "/iot/equipment",
    component: Equipment
  },
  {
    path: "/iot",
    component: LayoutComponent
  }
];

export default () => (
  <Router history={history}>
    <Switch>
      <Route path="/iot/login" exact component={LoginContainer} />
      <Route path="/" exact component={LoginContainer} />
      <Route path="/iot" exact component={LoginContainer} />
      <Route path="/iot/register" exact component={Register} />
      <Container>
        <Switch>{routesConfig.map((route, i) => <RenderRoutes key={i} {...route} />)}</Switch>
      </Container>
    </Switch>
  </Router>
);
