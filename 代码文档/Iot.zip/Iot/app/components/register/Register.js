import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import { Button, FormControl, FormGroup, InputGroup } from "react-bootstrap";
import intl from "react-intl-universal";
import history from "../../routes/history";
import * as action from "../../actions/Register";
import "whatwg-fetch";
import _ from "lodash";
import "./Register.css";
import { Select, message } from "antd";
import md5 from "md5";

const Option = Select.Option;

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      pass: "",
      errMsg: "",
      initDone: false,
      defalutLanguage: "0" //0:中文 1:English
    };
    this.register = this.register.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
  }
  componentWillReceiveProps(nextProps) {
    // if (nextProps.registerStatus == 1) {
    //   message.success("公司信息注册成功，将在3秒后跳转到登录页");
    //   setTimeout(() => {
    //     history.push("/iot/login");
    //   }, 3000);
    // }
  }
  componentDidMount() {}
  componentDidUpdate() {}
  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.register();
    }
  }
  register() {
    let userName = _.trim(ReactDOM.findDOMNode(this.refs.userName).value);
    let password = _.trim(ReactDOM.findDOMNode(this.refs.password).value);
    let passPattern = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?![,\.#%'\+@!\$&\*\-:;^_`]+$)[,\.#%@!'\+\$&\*\-:;^_`0-9A-Za-z]{6,16}$/gm;
    let userPattern = /^\w+$/;
    if (userName && password) {
      if (!userPattern.test(userName)) {
        this.setState({
          errMsg: "用户名只能包含字母、数字、下划线"
        });
        return;
      }
      if (!passPattern.test(password)) {
        this.setState({
          errMsg: "密码应6到16位，至少包含字母、数字、符号两种"
        });
        return;
      }
      this.setState({
        errMsg: ""
      });
      localStorage.setItem("loggedIn", true);
      this.props.actions.register(userName, md5(password));
    } else if (userName == "" || password == "") {
      this.setState({
        errMsg: "用户名和密码不能为空"
      });
    } else {
      this.setState({
        errMsg: "用户名或密码不正确"
      });
    }
  }

  render() {
    return (
      <div className="registerBox">
        <div className="register">
          <div className="register_content">
            {this.state.errMsg ? (
              <div className="error-msg error-msg2">{this.state.errMsg}</div>
            ) : null}
            <form>
              <span className="register__inner_user">用户注册</span>
              <FormGroup style={{ width: "31%", marginLeft: "38%" }}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="user-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "70%" }}
                    className="user-input"
                    ref="userName"
                    type="text"
                    onKeyDown={this.onKeyDown}
                    placeholder="请输入用户名"
                    autoComplete="off"
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup style={{ width: "31%", marginLeft: "38%" }}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="pass-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "70%" }}
                    type="text"
                    ref="password"
                    placeholder="请输入密码"
                    onKeyDown={this.onKeyDown}
                    inputRef={ref => {
                      this.password = ref;
                    }}
                    autoComplete="new-password"
                    onFocus={() => {
                      this.password.type = "password";
                    }}
                  />
                </InputGroup>
              </FormGroup>

              <div className="register-inner__btn">
                <Button
                  style={{ width: "23%", marginLeft: "37%" }}
                  bsStyle="primary big-btn"
                  type="button"
                  onClick={this.register}
                >
                  注册
                </Button>
              </div>
            </form>
            <span className="register-login">
              <NavLink to="/iot/login" style={{ fontSize: 14 }}>
                去登录
              </NavLink>
            </span>
          </div>
        </div>
        <div>
          <span className="register-footer">西安华信智慧数字科技有限公司</span>
        </div>
      </div>
    );
  }
}
Register.propTypes = {};

const mapStateToProps = state => {
  return {
    registerStatus: state.register.get("registerStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Register);
