import React from "react";
import ReactDOM from "react-dom";
import { NavLink } from "react-router-dom";
import { Button, FormControl, FormGroup, InputGroup } from "react-bootstrap";
import intl from "react-intl-universal";
import history from "../../routes/history";
import "whatwg-fetch";
import _ from "lodash";
import "./login.css";
import { Select, message } from "antd";
import md5 from "md5";

const Option = Select.Option;

const SUPPOER_LOCALES = [
  {
    name: "English",
    value: "en-US"
  },
  {
    name: "简体中文",
    value: "zh-CN"
  }
];
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      pass: "",
      errMsg: "",
      initDone: false,
      defalutLanguage: "0" //0:中文 1:English
    };
    this.login = this.login.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.Login == 1) {
      history.push("/iot/equipment");
    }
  }
  shouldComponentUpdate(nextProps, nextState) {
    console.log(nextProps + ",," + nextState);
    return true;
  }
  componentDidMount() {
    this.loadLocales();
    this.props.actions.logout();
  }
  loadLocales() {
    let currentLocale = intl.determineLocale({
      urlLocaleKey: "lang",
      cookieLocaleKey: "lang"
    });
    if (!_.find(SUPPOER_LOCALES, { value: currentLocale })) {
      currentLocale = "en-US";
    }

    fetch(`/locales/${currentLocale}.json`)
      .then(res => {
        return res.json();
      })
      .then(data => {
        console.log(data);
        intl.init({
          currentLocale,
          locales: {
            [currentLocale]: data
          }
        });
        // After loading CLDR locale data, start to render
        this.setState({ initDone: true });
      });
  }
  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.login();
    }
  }
  login() {
    let userName = ReactDOM.findDOMNode(this.refs.userName).value;
    let password = md5(ReactDOM.findDOMNode(this.refs.password).value);
    // let password = ReactDOM.findDOMNode(this.refs.password).value;
    if (userName && password) {
      localStorage.setItem("loggedIn", true);
      this.props.actions.login(userName, password);
    } else if (userName == "" || password == "") {
      this.setState({
        errMsg: "用户名和密码不能为空"
      });
    } else {
      this.setState({
        errMsg: "用户名或密码不正确"
      });
    }
  }
  handleChange(value) {
    location.search = `?lang=${value}`;
  }
  render() {
    return (
      <div className="login">
        <span className="login__logo" />
        <div className="s_l">
          {/* <Select defaultValue="zh-CN" style={{ width: 120 }} onChange={this.handleChange}>
            <Option value="zh-CN">中文</Option>
            <Option value="en-US">English</Option>
          </Select> */}
        </div>
        <div className="login__inner">
          <div className="login__inner_slogan" />
          
          <div className="login__inner__right">
            {this.state.errMsg ? (
              <span className="error-msg error-msgs">{this.state.errMsg}</span>
            ) : null}
            <form>
              <span className="login__inner_user">用户登录</span>
              <FormGroup style={{ width: "91%" }}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="user-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "91%" }}
                    className="user-input"
                    ref="userName"
                    type="text"
                    onKeyDown={this.onKeyDown}
                    placeholder="请输入用户名"
                    autoComplete="off"
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup style={{ width: "91%" }}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="pass-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "91%" }}
                    type="text"
                    ref="password"
                    placeholder="请输入密码"
                    onKeyDown={this.onKeyDown}
                    inputRef={ref => {
                      this.password = ref;
                    }}
                    autoComplete="new-password"
                    onFocus={() => {
                      this.password.type = "password";
                    }}
                  />
                </InputGroup>
              </FormGroup>

              <div className="login-inner__btn">
                <Button
                  style={{ width: "91%" }}
                  bsStyle="primary big-btn"
                  type="button"
                  onClick={this.login}
                >
                  {/* {intl.get("login.loginBtn")} */}
                  立即登录
                </Button>
              </div>
            </form>
            <span className="login-register">
              <NavLink to="/iot/register">注册新用户</NavLink>
            </span>
          </div>
        </div>
        <div>
          <span className="login-footer">西安华信智慧数字科技有限公司</span>
        </div>
      </div>
    );
  }
}
Login.propTypes = {};

export default Login;
