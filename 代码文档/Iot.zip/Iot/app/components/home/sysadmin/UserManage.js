import React from "react";
import { connect } from "react-redux";
//11111
import * as action from "../../../actions/systemManage/permission";
// import * as actions from "../../../actions/baseinfoManage/policManage/policmanage";
/*import * as actions from "../../../actions/sysadmin/userManage";
import * as roleactions from "../../../actions/sysadmin/rolemanage";*/
import { bindActionCreators } from "redux";
import md5 from "md5";

import "./style/sysadmin.css";
import {
  Upload,
  Icon,
  Table,
  Popconfirm,
  Button,
  Modal,
  Input,
  Form,
  Select,
  Transfer
} from "antd";

const InputGroup = Input.Group;
const Option = Select.Option;
const Search = Input.Search;
const FormItem = Form.Item;

const UserForm = Form.create()(props => {
  const { visible, onCancel, onCreate, preview, upload, form, list } = props;
  const { getFieldDecorator } = form;
  const uploadButton = (
    <div>
      <Icon type="plus" />
      <div className="ant-upload-text">上传用户头像</div>
    </div>
  );
  return (
    <Modal
      visible={visible}
      title="创建新用户"
      okText="创建"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem>
          <div className="userimg">
            <Upload
              action="//jsonplaceholder.typicode.com/posts/"
              listType="picture-card"
              onPreview={preview}
              onChange={upload}
            >
              {uploadButton}
            </Upload>
          </div>
        </FormItem>
        <FormItem label="姓名">
          {getFieldDecorator("name", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="密码">
          {getFieldDecorator("password", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input type="password"/>)}
        </FormItem>
       
        <FormItem label="手机号码">
          {getFieldDecorator("mobile", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="Email">
          {getFieldDecorator("email", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const Setrole = Form.create()(props => {
  const {
    visible,
    onCancel,
    onCreate,
    form,
    data,
    targetkey,
    render,
    change
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="选择角色"
      okText="保存"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Transfer
        dataSource={data}
        listStyle={{ width: "41%", height: 260 }}
        operations={["添加", "移除"]}
        targetKeys={targetkey}
        titles={["角色列表", "当前角色"]}
        notFoundContent={"无数据..."}
        render={render}
        onChange={change}
      />
    </Modal>
  );
});
const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input
        style={{ margin: "-5px 0" }}
        value={value}
        onChange={e => onChange(e.target.value)}
      />
    ) : (
      value
    )}
  </div>
);

let isAdmin = [
  {
    key: "1",
    value: "是"
  },
  {
    key: "0",
    value: "否"
  }
];
const EditAdmin = ({ editable, value, onChange, defaultValue }) => (
  <div>
    {editable ? (
      <Select
        style={{ margin: "-5px 0" }}
        defaultValue={defaultValue}
        onSelect={e => {
          onChange(e);
        }}
      >
        <Option value={"1"}>是</Option>
        <Option value={"0"}>否</Option>
      </Select>
    ) : (
      value
    )}
  </div>
);
class UserManage extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID名",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "角色状态",
        dataIndex: "available",
        render: (text, record) => this.renderColumns(text, record, "available")
      },
      {
        title: "名称",
        dataIndex: "name",
        render: (text, record) => this.renderColumns(text, record, "name")
      },
      // {
      //   title: "权限",
      //   dataIndex: "permission",
      //   render: (text, record) => this.renderColumns(text, record, "permission")
      // },
      {
        title: "pid",
        dataIndex: "pid",
        render: (text, record) =>
          this.renderColumns(text, record, "pid")
      },
      {
        title: "资源类型",
        dataIndex: "resourceType",
        render: (text, record) =>
          this.renderColumns(text, record, "resourceType")
      },
      {
        title: "地址",
        dataIndex: "url",
        render: (text, record) =>
          this.renderColumns(text, record, "url")
      },
      {
        title: "校验类型",
        dataIndex: "validateType",
        render: (text, record) =>
          this.renderColumns(text, record, "validateType")
      },
      // {
      //   title: "父ID",
      //   dataIndex: "parent_id",
      //   render: (text, record) =>
      //     this.renderColumns(text, record, "parent_id")
      // },
      {
        title: "是否超级管理员",
        width: 150,
        dataIndex: "superadmin",
        render: (text, record) => this.renderColumns(text, record, "superadmin")
      },
      {
        title: "操作",
        width: 330,
        dataIndex: "operation",
        render: (text, record) => {
          const { editable } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {editable ? (
                <span>
                  <a onClick={() => this.save(record.id)}>
                    <span className="usaveicon" />保存
                  </a>
                  <Popconfirm
                    title="确定取消更改吗？"
                    onConfirm={() => this.nochange(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="udeletebtn">
                      <span className="udeleteicon" />取消
                    </a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <a onClick={() => this.edit(record.id)}>
                    <span className="uediticon" />编辑
                  </a>
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.onDelete(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="udeletebtn">
                      <span className="udeleteicon" />删除
                    </a>
                  </Popconfirm>
                  <a onClick={() => this.showroleModal(record)}>
                    <span className="uroleicon" />配置角色
                  </a>
                </span>
              )
              //编辑数据表中以key索引的数据
              }
            </div>
          );
        }
      }
    ];
    this.state = {
      dataSource: this.props.rowdata,
      pagination: {},
      loading: true,
      visible: false,
      rolevisible: false,
      confirmLoading: false,
      update: false,
      nowrole: null,
      roleId: [],
      fileList: [
        {
          uid: -1,
          name: "xxx.png",
          status: "done",
          url:
            "https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
        }
      ],
      selectValue:"",
    }; //modal弹窗
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleTableChange = this.handleTableChange.bind(this);
    this.showroleModal = this.showroleModal.bind(this);
    this.roleOk = this.roleOk.bind(this);
    this.roleCancel = this.roleCancel.bind(this);
    this.renderRoleItem = this.renderRoleItem.bind(this);
    this.changerole = this.changerole.bind(this);
    this.nochange = this.nochange.bind(this);

    this.searchGet = this.searchGet.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
  }
  nochange(key) {
    let newData = this.props.UserManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      target.editable = false;
      this.setState({ data: target }); //更新编辑视图
    }
  }
  edit(key) {
    let newData = this.props.UserManage.list;
    const target = newData.filter(item => key === item.id)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({ data: target }); //更新编辑视图
    }
    console.log(target);
  } //编辑
  save(key) {
    const newData = this.props.UserManage.list;
    const target = newData.filter(item => key === item.id)[0];
    this.props.actions.update(target, "userManage");
    if (target) {
      delete target.editable;
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "userManage");
        this.setState({ loading: false });
      }, 1000);
    }
    console.log(target);
  } //保存

  handleChange(value, key, column) {
    const newData = this.props.UserManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      if (column == "superadmin") {
        target[column] = Boolean(parseInt(value));
      } else {
        target[column] = value;
      }
      this.setState({ dataSource: newData });
    }
    console.log(target);
  } //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    if (column == "superadmin") {
      return (
        <EditAdmin
          editable={record.editable}
          value={
            isAdmin.find(item => text == Boolean(parseInt(item.key))).value
          }
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"" + Number(text)}
        />
      );
    } else if (column == "createTime") {
      return text;
    } else if (column == "creater") {
      return text;
    } else {
      return (
        <EditableCell
          editable={record.editable}
          value={text}
          onChange={value => this.handleChange(value, record.id, column)}
        />
      );
    }
  }
  //删除操作
  onDelete(key) {
    this.props.actions.del(key, "userManage");
    this.setState({ loading: true });
    setTimeout(() => {
      this.props.actions.get(this.state.pagination.current, "userManage");
      this.setState({ loading: false });
    }, 1000);
  }

  showModal() {
    this.setState({ visible: true }); //显示模态框
    this.props.actions.getPolic(1);
  }

  handleCancel() {
    this.setState({ visible: false });
  }
  //add User
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.createTime = new Date().toLocaleString("chinese", {
        hour12: false
      });
      let policeAreaName = values.policeArea.label;
      values.policeArea = values.policeArea.key;
      values.policeAreaName = policeAreaName;
      values.password = md5(values.password);
      values.creater = JSON.parse(sessionStorage.getItem("userInfo")).account;
      values.state = "1";
      values.superadmin = false;
      values.userType = "user";
      this.props.actions.add(values, "userManage");
      this.setState({ visible: false });
      form.resetFields();
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "userManage");
      }, 500);
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  showroleModal(data) {
    this.props.actions.get(1, "roleManage");
    let dat = [];
    for (let i = 0; i < data.roles.length; i++) {
      dat.push(data.roles[i].id); //获取当前用户拥有的所有角色id
    }
    this.setState({ rolevisible: true, nowrole: data.id, roleId: dat }); //存储当前用户id
  }
  roleOk() {
    let setdata = `?userId=${
      this.state.nowrole
    }&roleIds=${this.state.roleId.join()}`;
    this.props.actions.add(setdata, "addrole");
    this.setState({ rolevisible: false });
    setTimeout(() => {
      this.props.actions.get(1, "userManage");
    }, 300);
  }
  roleCancel() {
    this.setState({ rolevisible: false });
    this.setState({ targetKeys: [] });
  }
  changerole(targetKeys, direction, moveKeys) {
    this.setState({ roleId: targetKeys }); //将当前拥有角色id存入状态
  }
  renderRoleItem(item) {
    const customLabel = (
      <span className="custom-item">
        {item.role} - {item.description}
      </span>
    );
    return { label: customLabel, value: item.role };
  }
  handleTableChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.get(pagination.current, "userManage");
  }

// search segment
  searchGet(){
    let inputName = ReactDOM.findDOMNode(this.refs.inputName).value;
    // let inputType = ReactDOM.findDOMNode(this.refs.inputType).value;
    // console.log("searchGetinputType", ReactDOM.findDOMNode(this.refs.inputType));
    // console.log("inputType", this.state.selectValue);

    let params = {
      inputName: inputName,
      inputType: this.state.selectValue,
    };
    this.props.actions.search(1, params, "userManage");
  }
  handleSelectChange(value){
    this.setState({
      selectValue: value,
    })
    console.log(`selected ${value}`);
  }

  componentDidMount() {

    console.log("componentDidMount", this.props);

    this.props.actions.get(1, "userManage");
    setTimeout(() => {
      this.props.actions.get(1, "roleManage");
    }, 300);
  }
  componentWillReceiveProps(nextProps) {

    console.log("componentWillReceiveProps", nextProps);

    if (nextProps.UserManage.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.UserManage.pageBean.total,
          current: nextProps.UserManage.pageBean.page,
          pageSize: nextProps.UserManage.pageBean.size
        },
        loading: false
      });
    }
  }
  componentWillUnmount() {
    this.props.UserManage.list = [];
  }
  render() {

    console.log("renderloading",this.state.loading);
    console.log("UserManageprops",this.props);
    console.log("UserManage",this.props.UserManage);

    console.log("UserManagelist",this.props.UserManage.list);
    console.log("RoleManagelist",this.props.RoleManage.list);


    if (this.props.UserManage.list) {
      this.props.UserManage.list.map(item => {
        item.key = item.id;
      });
    }
    if (this.props.RoleManage.list) {
      this.props.RoleManage.list.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">

          <form action="#">
            <label htmlFor="name" className="lable namelable">
              名称
            </label>
            <input
              ref="inputName"
              type="text"
              name="name"
              id="name"
              className="table-input nameinput"
            />
            <label htmlFor="age" className="lable agelable">
              资源类型
            </label>
            {/* <input
              ref="inputType"
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            /> */}
            <Select ref="inputType" style={{ width: 120 }} onChange={this.handleSelectChange}>
              <Option value="button">button</Option>
              <Option value="globa">globa</Option>
              <Option value="menu">menu</Option>
              <Option value="lucy">Lucy</Option>
              <Option value="nav">nav</Option>
              <Option value="restapi">restapi</Option>
              <Option value="service">service</Option>
              <Option value="other">other</Option>
            </Select>
            <a href="#" className="abutton" onClick={this.searchGet} >
              <span className="searchicon" />搜索
            </a>
            <a className="addpeople" onClick={this.showModal}>
              添加+
            </a>
          </form>

          {/* <form action="#">
            <label htmlFor="name" className="lable namelable">
              姓名
            </label>
            <input
              type="text"
              name="name"
              id="name"
              className="table-input nameinput"
            />
            <label htmlFor="age" className="lable agelable">
              年龄
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              联系方式
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              家庭住址
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" />搜索
            </a>
            <a className="addpeople" onClick={this.showModal}>
              添加+
            </a>
          </form> */}
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          locale={{ emptyText: "暂无数据..." }}
          pagination={this.state.pagination}
          dataSource={this.props.UserManage.length !== 0 ? this.props.UserManage.list : this.props.UserManage}
          loading={{ spinning: this.state.loading, tip: "加载中..." }}
          onChange={this.handleTableChange}
        />
        <UserForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          upload={e => {
            console.log(e.fileList);
          }}

          preview={e => {
            console.log(e);
          }}
          list={this.props.PolicManage}
        />
        <Setrole
          visible={this.state.rolevisible}
          onCancel={this.roleCancel}
          onCreate={this.roleOk}
          data={this.props.RoleManage.list}
          targetkey={this.state.roleId}
          render={this.renderRoleItem}
          change={this.changerole}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    UserManage: state.permissionManage.get("userManageData"),
    RoleManage: state.permissionManage.get("roleManageData"),
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(action, dispatch)
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(UserManage);
