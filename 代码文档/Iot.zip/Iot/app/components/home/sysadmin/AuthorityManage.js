import React from "react";
import { connect } from "react-redux";
import * as action from "../../../actions/systemManage/permission";
import { bindActionCreators } from "redux";
import "./style/sysadmin.css";
import * as Mock_data from "../../../../config/chartConfig";
import {
  Upload,
  Icon,
  Table,
  Popconfirm,
  Button,
  Modal,
  Input,
  Form,
  Select
} from "antd";
const InputGroup = Input.Group;
const Option = Select.Option;
const Search = Input.Search;
const FormItem = Form.Item;

const UserForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="创建新资源"
      okText="创建"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="资源名称">
          {getFieldDecorator("name", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="资源种类">
          {getFieldDecorator("password", {
            rules: [{ required: true, message: "不能为空" }]
          })(
            <Select style={{ width: "100%" }}>
              <Option value="nav">导航</Option>
              <Option value="menu">菜单</Option>
              <Option value="button">按钮</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="资源种类">
          {getFieldDecorator("password", {
            rules: [{ required: true, message: "不能为空" }]
          })(
            <Select style={{ width: "100%" }}>
              <Option value="nav">导航</Option>
              <Option value="menu">菜单</Option>
              <Option value="button">按钮</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="资源种类">
          {getFieldDecorator("password", {
            rules: [{ required: true, message: "不能为空" }]
          })(
            <Select style={{ width: "100%" }}>
              <Option value="nav">导航</Option>
              <Option value="menu">菜单</Option>
              <Option value="button">按钮</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="手机号码">
          {getFieldDecorator("mobile", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="Email">
          {getFieldDecorator("email", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input
        style={{ margin: "-5px 0" }}
        value={value}
        onChange={e => onChange(e.target.value)}
      />
    ) : (
      value
    )}
  </div>
);

const ResType = ({ editable, value, onChange, defaultValue }) => (
  <div>
    {editable ? (
      <Select
        style={{ margin: "-5px 0" }}
        defaultValue={defaultValue}
        onSelect={e => {
          onChange(e);
        }}
      >
        <Option value={"nav"}>导航</Option>
        <Option value={"menu"}>菜单</Option>
        <Option value={"button"}>按钮</Option>
      </Select>
    ) : (
      value
    )}
  </div>
);
let isAdmin = [
  {
    key: "1",
    value: "是"
  },
  {
    key: "0",
    value: "否"
  }
];
let ResTypes = [
  {
    key: "nav",
    value: "导航"
  },
  {
    key: "menu",
    value: "菜单"
  },
  {
    key: "button",
    value: "按钮"
  }
];
const EditAdmin = ({ editable, value, onChange, defaultValue }) => (
  <div>
    {editable ? (
      <Select
        style={{ margin: "-5px 0" }}
        defaultValue={defaultValue}
        onSelect={e => {
          onChange(e);
        }}
      >
        <Option value={"1"}>是</Option>
        <Option value={"0"}>否</Option>
      </Select>
    ) : (
      value
    )}
  </div>
);
class resManage extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "资源名称",
        dataIndex: "name",
        render: (text, record) => this.renderColumns(text, record, "name")
      },
      {
        title: "资源种类",
        dataIndex: "resourceType",
        render: (text, record) =>
          this.renderColumns(text, record, "resourceType")
      },
      {
        title: "功能种类",
        dataIndex: "funcType",
        render: (text, record) => this.renderColumns(text, record, "funcType")
      },
      {
        title: "创建人",
        dataIndex: "creater",
        render: (text, record) => this.renderColumns(text, record, "creater")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "修改人",
        dataIndex: "modiffer",
        render: (text, record) => this.renderColumns(text, record, "modiffer")
      },
      {
        title: "修改时间",
        dataIndex: "modifyTime",
        render: (text, record) => this.renderColumns(text, record, "modifyTime")
      },
      {
        title: "是否可用",
        width: 150,
        dataIndex: "available",
        render: (text, record) => this.renderColumns(text, record, "available")
      },
      {
        title: "操作",
        width: 220,
        dataIndex: "operation",
        render: (text, record) => {
          const { editable } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {editable ? (
                <span>
                  <a onClick={() => this.save(record.id)}>
                    <span className="usaveicon" />保存
                  </a>
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.onDelete(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="udeletebtn">
                      <span className="udeleteicon" />删除
                    </a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <a onClick={() => this.edit(record.id)}>
                    <span className="uediticon" />编辑
                  </a>
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.onDelete(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="udeletebtn">
                      <span className="udeleteicon" />删除
                    </a>
                  </Popconfirm>
                </span>
              )
              //编辑数据表中以key索引的数据
              }
            </div>
          );
        }
      }
    ];
    this.state = {
      //dataSource : Mock_data.people_manage,
      dataSource: this.props.rowdata,
      pagination: {},
      loading: true,
      visible: false,
      rolevisible: false,
      confirmLoading: false,
      update: false,
      targetKeys: [],
      fileList: [
        {
          uid: -1,
          name: "xxx.png",
          status: "done",
          url:
            "https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
        }
      ]
    }; //modal弹窗
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleTableChange = this.handleTableChange.bind(this);
  }
  edit(key) {
    let newData = this.props.resManage.list;
    const target = newData.filter(item => key === item.id)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({ data: target }); //更新编辑视图
    }
    console.log(target);
  } //编辑

  save(key) {
    const newData = this.props.resManage.list;
    const target = newData.filter(item => key === item.id)[0];
    target.modiffer = JSON.parse(sessionStorage.getItem("userInfo")).account; //当前登录用户名
    target.modifyTime = new Date().toLocaleString("chinese", {
      hour12: false
    });

    this.props.actions.update(target, "resManage");
    if (target) {
      delete target.editable;
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "resManage");
        this.setState({ loading: false });
      }, 1000);
    }
    console.log(target);
  } //保存

  handleChange(value, key, column) {
    const newData = this.props.resManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      if (column == "superadmin") {
        target[column] = Boolean(parseInt(value));
      } else {
        target[column] = value;
      }
      this.setState({ dataSource: newData });
    }
    console.log(target);
  } //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    if (column == "available") {
      return (
        <EditAdmin
          editable={record.editable}
          value={
            isAdmin.find(item => text == Boolean(parseInt(item.key))).value
          }
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"" + Number(text)}
        />
      );
    }
    if (column == "resourceType") {
      return (
        <ResType
          editable={record.editable}
          value={ResTypes.find(item => item.key == text).value}
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"nav"}
        />
      );
    } else if (
      column == "creater" ||
      column == "createTime" ||
      column == "modiffer" ||
      column == "modifyTime"
    ) {
      return text;
    } else {
      return (
        <EditableCell
          editable={record.editable}
          value={text}
          onChange={value => this.handleChange(value, record.id, column)}
        />
      );
    }
  }
  //删除操作
  onDelete(key) {
    this.props.actions.del(key, "resManage");
    this.setState({ loading: true });
    setTimeout(() => {
      this.props.actions.get(this.state.pagination.current, "resManage");
      this.setState({ loading: false });
    }, 1000);
  }

  showModal() {
    this.setState({ visible: true }); //显示模态框
  }

  handleCancel() {
    this.setState({ visible: false });
  }
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.creater = "123123123";
      values.createTime = "2018-4-29";
      values.state = "1";
      values.superadmin = true;
      values.userType = "user";
      this.props.actions.add(values, "resManage");
      this.setState({ visible: false });
      form.resetFields();
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "resManage");
      }, 500);
    });
  }
  saveFormRef(form) {
    this.form = form;
  }

  handleTableChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.get(pagination.current, "resManage");
  }
  componentDidMount() {
    this.props.actions.get(1, "resManage");
    setTimeout(() => {
      this.props.actions.get(1, "roleManage");
    }, 300);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.resManage.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.resManage.pageBean.total,
          current: nextProps.resManage.pageBean.page,
          pageSize: nextProps.resManage.pageBean.size
        },
        loading: false
      });
    }
  }
  componentWillUnmount() {
    this.props.resManage.list = [];
  }
  render() {
    if (this.props.resManage.list) {
      this.props.resManage.list.map(item => {
        item.key = item.id;
      });
    }
    if (this.props.RoleManage.list) {
      this.props.RoleManage.list.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <form action="#">
            <label htmlFor="name" className="lable namelable">
              姓名
            </label>
            <input
              type="text"
              name="name"
              id="name"
              className="table-input nameinput"
            />
            <label htmlFor="age" className="lable agelable">
              年龄
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              联系方式
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              家庭住址
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" />搜索
            </a>
            <a className="addpeople" onClick={this.showModal}>
              添加+
            </a>
          </form>
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          locale={{ emptyText: "暂无数据..." }}
          pagination={this.state.pagination}
          dataSource={this.props.resManage.list}
          loading={{ spinning: this.state.loading, tip: "加载中..." }}
          onChange={this.handleTableChange}
        />
        <UserForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          upload={e => {
            console.log(e.fileList);
          }}
          preview={e => {
            console.log(e);
          }}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resManage: state.permissionManage.get("resManageData"),
    RoleManage: state.permissionManage.get("roleManageData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(mapStateToProps, mapDispatchToProps)(resManage);
