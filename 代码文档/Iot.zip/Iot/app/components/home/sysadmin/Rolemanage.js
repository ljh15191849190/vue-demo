import React from "react";
import { connect } from "react-redux";
import * as action from "../../../actions/systemManage/permission";
import { bindActionCreators } from "redux";
import {
  Table,
  Popconfirm,
  Button,
  Modal,
  Input,
  Form,
  Icon,
  Menu,
  Select,
  Tabs,
  Tree
} from "antd";

const TreeNode = Tree.TreeNode;
const InputGroup = Input.Group;
const Option = Select.Option;
const Search = Input.Search;
const FormItem = Form.Item;
const { TabPane } = Tabs;
const UserForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal
      visible={visible}
      title="创建新角色"
      okText="创建"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="角色名">
          {getFieldDecorator("role", {
            rules: [{ required: true, message: "不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="角色类型">
          {getFieldDecorator("roletype", {
            rules: [{ required: true, message: "不能为空" }]
          })(
            <Select style={{ width: "100%" }}>
              <Option value="user">用户</Option>
              <Option value="admin">管理员</Option>
              <Option value="superadmin">超级管理员</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="角色状态">
          {getFieldDecorator("available", {
            rules: [{ required: true, message: "不能为空" }]
          })(
            <Select style={{ width: "100%" }}>
              <Option value={1}>有效</Option>
              <Option value={0}>无效</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="角色描述">
          {getFieldDecorator("description")(<TextArea rows={4} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

const Setrole = Form.create()(props => {
  const { visible, onCancel, onCreate, reslist, treecheck } = props;
  let renderMethod = data => {
    return data.children.map((item, key) => {
      if (item.children.length == 0) {
        return <TreeNode title={item.name} key={item.pid} />;
      } else {
        return (
          <TreeNode title={item.name} key={item.pid}>
            {renderMethod(item)}
          </TreeNode>
        );
      }
    });
  };
  return (
    <Modal
      className="role-manager-modal"
      visible={visible}
      title="选择资源"
      okText="保存"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Tabs type="card">
        {reslist.list ? (
          reslist.list.map((item, key) => {
            if (item.resourceType == "nav") {
              return (
                <TabPane tab={item.name} key={key}>
                  <Tree checkable treeCheckStrictly={false} onCheck={treecheck}>
                    {renderMethod(item)}
                  </Tree>
                </TabPane>
              );
            }
          })
        ) : (
          <TabPane tab="无数据" key={1}>
            无数据
          </TabPane>
        )}
      </Tabs>
    </Modal>
  );
});
const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input
        style={{ margin: "-5px 0" }}
        value={value}
        onChange={e => onChange("" + e.target.value)}
      />
    ) : (
      value
    )}
  </div>
);

let isAdmin = [
  {
    key: "1",
    value: "有效"
  },
  {
    key: "0",
    value: "无效"
  }
];
const EditAdmin = ({ editable, value, onChange, defaultValue }) => (
  <div>
    {editable ? (
      <Select
        style={{ margin: "-5px 0" }}
        defaultValue={defaultValue}
        onSelect={e => {
          onChange(e);
        }}
      >
        <Option value={"1"}>有效</Option>
        <Option value={"0"}>无效</Option>
      </Select>
    ) : (
      value
    )}
  </div>
);
class RoleManage extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "角色名",
        dataIndex: "role",
        render: (text, record) => this.renderColumns(text, record, "role")
      },
      {
        title: "角色状态",
        dataIndex: "available",
        render: (text, record) => this.renderColumns(text, record, "available")
      },
      {
        title: "创建人",
        dataIndex: "creater",
        render: (text, record) => this.renderColumns(text, record, "creater")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "修改人",
        dataIndex: "modiffer",
        render: (text, record) => this.renderColumns(text, record, "modiffer")
      },
      {
        title: "修改时间",
        dataIndex: "modifyTime",
        render: (text, record) => this.renderColumns(text, record, "modifyTime")
      },
      {
        title: "角色描述",
        dataIndex: "description",
        render: (text, record) =>
          this.renderColumns(text, record, "description")
      },
      {
        title: "操作",
        width: 320,
        dataIndex: "operation",
        render: (text, record) => {
          const { editable } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {editable ? (
                <span>
                  <a onClick={() => this.save(record.id)}>
                    <span className="saveicon" />保存
                  </a>
                  <Popconfirm
                    title="确定取消吗？"
                    onConfirm={() => this.nochange(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="deletebtn">
                      <span className="deleteicon" />取消
                    </a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <a onClick={() => this.edit(record.id)}>
                    <span className="editicon" />编辑
                  </a>
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.onDelete(record.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a className="deletebtn">
                      <span className="deleteicon" />删除
                    </a>
                  </Popconfirm>
                  <a onClick={() => this.showroleModal(record)}>
                    <span className="uroleicon" />配置资源
                  </a>
                </span>
              )
              //编辑数据表中以key索引的数据
              }
            </div>
          );
        }
      }
    ];
    this.state = {
      //dataSource : Mock_data.people_manage,
      dataSource: [],
      pagination: {},
      loading: true,
      //modal弹窗
      visible: false,
      confirmLoading: false,
      update: false,
      ArrayData: [],

      selectValue:"",
    };
    this.cacheData = [];
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleTableChange = this.handleTableChange.bind(this);
    this.showroleModal = this.showroleModal.bind(this);
    this.roleOk = this.roleOk.bind(this);
    this.roleCancel = this.roleCancel.bind(this);
    this.Treecheck = this.Treecheck.bind(this);
    
    this.searchGet = this.searchGet.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
  }
  nochange(key) {
    let newData = this.props.RoleManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      target.editable = false;
      this.setState({ data: target }); //更新编辑视图
    }
  }
  edit(key) {
    let newData = this.props.RoleManage.list;
    const target = newData.filter(item => key === item.id)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({ data: newData }); //更新编辑视图
    }
    console.log(target);
  } //编辑

  save(key) {
    const newData = this.props.RoleManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      delete target.editable;
      target.modiffer = JSON.parse(sessionStorage.getItem("userInfo")).account; //当前登录用户名
      target.modifyTime = new Date().toLocaleString("chinese", {
        hour12: false
      });
      delete target.permissions;
      this.props.actions.update(target, "roleManage");
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "roleManage");
      }, 500);
    }
    console.log(target);
  } //保存

  handleChange(value, key, column) {
    const newData = this.props.RoleManage.list;
    const target = newData.filter(item => key === item.id)[0];
    if (target) {
      if (column == "available") {
        target[column] = Boolean(parseInt(value));
      } else {
        target[column] = value;
      }
      this.setState({ dataSource: newData });
    }
    console.log(target);
  } //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    if (column == "available") {
      return (
        <EditAdmin
          editable={record.editable}
          value={
            isAdmin.find(item => text == Boolean(parseInt(item.key))).value
          }
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"" + Number(text)}
        />
      );
    } else if (
      column == "creater" ||
      column == "createTime" ||
      column == "modiffer" ||
      column == "modifyTime"
    ) {
      return text;
    } else {
      return (
        <EditableCell
          editable={record.editable}
          value={text}
          onChange={value => this.handleChange(value, record.id, column)}
        />
      );
    }
  }
  //删除操作
  onDelete(key) {
    this.props.actions.del(key, "roleManage");
    this.setState({ loading: true });
    setTimeout(() => {
      this.props.actions.get(this.state.pagination.current, "roleManage");
      this.setState({ loading: false });
    }, 500);
  }

  showModal() {
    this.setState({ visible: true }); //显示模态框
  }

  handleCancel() {
    this.setState({ visible: false });
  }
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      console.log(values);
      if (err) {
        return;
      }
      if (values.available == 1) {
        values.available = true;
      } else if (values.available == 0) {
        values.available = false;
      }
      values.createTime = new Date().toLocaleString("chinese", {
        hour12: false
      });
      values.creater = JSON.parse(sessionStorage.getItem("userInfo")).account;
      this.props.actions.add(values, "roleManage");
      this.setState({ visible: false });
      form.resetFields();
      setTimeout(() => {
        this.props.actions.get(this.state.pagination.current, "roleManage");
      }, 300);
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  showroleModal(data) {
    this.props.actions.get(1, "findres");
    this.setState({ rolevisible: true, nowRes: data.id }); //存储当前用户id
  }
  roleOk() {
    this.setState({ rolevisible: false });
    let data = `?roleId=${
      this.state.nowRes
    }&permissionIds=${this.state.ArrayData.join()}`;
    console.log(data);
    this.props.actions.add(data, "addResource");
  }
  roleCancel() {
    this.setState({ rolevisible: false });
    this.setState({ targetKeys: [] });
  }
  Treecheck(checkedKeys, node) {
    let array = this.state.ArrayData;
    let key = node.node.props.eventKey;
    let check = false;
    if (array.indexOf(key) == -1) {
      check = false;
    } else {
      check = true;
    }

    if (check) {
      array.splice(array.indexOf(key), 1);
    } else {
      array.push(key);
    }
    this.setState({ ArrayData: array });
  }

  handleTableChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.get(pagination.current, "roleManage");
  }

  // search segment
  searchGet(){
    let inputName = ReactDOM.findDOMNode(this.refs.inputName).value;
    // let inputType = ReactDOM.findDOMNode(this.refs.inputType).value;
    // console.log("searchGetinputType", ReactDOM.findDOMNode(this.refs.inputType));
    // console.log("inputType", this.state.selectValue);

    let params = {
      inputName: inputName,
      inputType: this.state.selectValue,
    };
    this.props.actions.search(1, params, "userManage");
  }
  handleSelectChange(value){
    this.setState({
      selectValue: value,
    })
    console.log(`selected ${value}`);
  }

  componentDidMount() {
    this.props.actions.get(1, "roleManage");
    console.log(this.props);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.RoleManage.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.RoleManage.pageBean.total,
          current: nextProps.RoleManage.pageBean.page,
          pageSize: nextProps.RoleManage.pageBean.size
        },
        loading: false
      });
    }
  }
  componentWillUnmount() {
    this.props.RoleManage.list = [];
  }
  render() {
    if (this.props.RoleManage.list) {
      this.props.RoleManage.list.map(item => {
        item.key = item.id;
      });
    }

    return (
      <div>
        <div className="searchbar">

         <form action="#">
            <label htmlFor="name" className="lable namelable">
            角色名称
            </label>
            <input
              ref="inputName"
              type="text"
              name="name"
              id="name"
              className="table-input nameinput"
            />
            <label htmlFor="age" className="lable agelable">
              角色类型
            </label>
            {/* <input
              ref="inputType"
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            /> */}
            <Select ref="inputType" style={{ width: 120 }} onChange={this.handleSelectChange}>
              <Option value="system">system</Option>
              <Option value="user">user</Option>
            </Select>

            <a href="#" className="abutton" onClick={this.searchGet} >
              <span className="searchicon" />搜索
            </a>
            <a className="addpeople" onClick={this.showModal}>
              添加+
            </a>
          </form>
          {/* <form action="#">
            <label htmlFor="name" className="lable namelable">
              姓名
            </label>
            <input
              type="text"
              name="name"
              id="name"
              className="table-input nameinput"
            />
            <label htmlFor="age" className="lable agelable">
              年龄
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              联系方式
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <label htmlFor="age" className="lable agelable">
              家庭住址
            </label>
            <input
              type="text"
              name="age"
              id="age"
              className="table-input ageinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" />搜索
            </a>
            <a className="addpeople" onClick={this.showModal}>
              添加+
            </a>
          </form> */}
        </div>
        <Table
          bordered
          size="small"
          locale={{ emptyText: "暂无数据..." }}
          columns={this.columns}
          dataSource={this.props.RoleManage.list}
          pagination={
            this.state.pagination //替换为后台数据
          }
          loading={this.state.loading}
          onChange={this.handleTableChange}
        />
        <UserForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
        />
        <Setrole
          visible={this.state.rolevisible}
          onCancel={this.roleCancel}
          onCreate={this.roleOk}
          reslist={this.props.reslist}
          treecheck={this.Treecheck}
        />
      </div>
    );
  }
}
const StateToProps = state => {
  return {
    RoleManage: state.permissionManage.get("roleManageData"),
    reslist: state.permissionManage.get("findresData"),
    CURRENT: state.login.get("logininfo")
  };
};

const DispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(action, dispatch)
  };
};
export default connect(StateToProps, DispatchToProps)(RoleManage);
