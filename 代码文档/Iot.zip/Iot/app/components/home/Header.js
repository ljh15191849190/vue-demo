import React from "react";
import { NavLink, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { message, Icon } from "antd";
import * as actions from "../../actions/index";

import "../../assets/css/header.css";
import logo from "../../assets/images/dashboard/logo.png";

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loggedIn: localStorage.getItem("loggedIn"),
      showSearch: false,
      searchInput: "",
      words: [],
      userName: "",
      shouldFlush: true
    };
    this.currentUId = localStorage.getItem("uid");
    this.onLogout = this.onLogout.bind(this);
    this.localStorageUpdated = this.localStorageUpdated.bind(this);
  }
  componentWillMount() {
    let storage = JSON.parse(localStorage.getItem("userInfo"));
    if (storage) {
      this.setState({
        userName: storage.account
      });
    }
  }
  localStorageUpdated() {
    let uid = localStorage.getItem("uid");
    if (!uid || !this.currentUId) {
      return;
    }
    if (this.state.shouldFlush && uid != this.currentUId) {
      message.warning("登录账号已发生改变，请刷新页面");
      this.setState({
        shouldFlush: false
      });
    }
  }
  componentDidMount() {
    window.addEventListener("storage", this.localStorageUpdated);
  }
  onLogout() {
    localStorage.clear();
    this.props.actions.logout();
  }
  render() {
    return (
      <div className="header-top">
        <div className="header-logo">
          <img src={logo} alt="logo" />
        </div>
        <div className="header-right">
          {/* <div className="navul">
            <ul className="header-top-ul" />
          </div> */}

          <div className="dropmeau">
            <ol>
              <li>
                <span className="dropli">
                  <span className="header-manager" />
                  {this.state.userName}
                  <span className="oper-icon" />
                </span>
                <ul className="meaulist">
                  {/* <li>用户信息</li>
                <li>我的收藏</li>
                <li>设置</li> */}
                  <li onClick={this.onLogout}>退出</li>
                </ul>
              </li>
            </ol>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Logout: state.login
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(actions, dispatch)
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Header);
