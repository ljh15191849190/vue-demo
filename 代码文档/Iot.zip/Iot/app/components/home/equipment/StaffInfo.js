import React from "react";
import ReactDOM from "react-dom";
import { connect } from "react-redux";
import * as action from "../../../actions/StaffInfo";
import { bindActionCreators } from "redux";
import "./style/sysadmin.css";
import "./styles/app.css";
import { Icon, Modal, Input, Form, message, Table } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input style={{ margin: "-5px 0" }} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);
class UserManage extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "员工id",
        dataIndex: "staffId",
        render: (text, record) => this.renderColumns(text, record, "staffId")
      },
      {
        title: "姓名",
        dataIndex: "staffName",
        render: (text, record) => this.renderColumns(text, record, "staffName")
      },
      {
        title: "性别",
        dataIndex: "sex",
        render: (text, record) => {
          const { sex } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {sex == "man" ? <span>男</span> : <span>女</span>}
            </div>
          );
        }
      },
      {
        title: "联系方式",
        dataIndex: "mobile",
        render: (text, record) => this.renderColumns(text, record, "mobile")
      },
      {
        title: "所属部门",
        dataIndex: "department",
        render: (text, record) => this.renderColumns(text, record, "department")
      },
      {
        title: "创建时间",
        dataIndex: "createDate",
        render: (text, record) => this.renderColumns(text, record, "createDate")
      },
      {
        title: "更新时间",
        dataIndex: "updateDate",
        render: (text, record) => this.renderColumns(text, record, "updateDate")
      },
      {
        title: "公司id",
        dataIndex: "companyId",
        render: (text, record) => this.renderColumns(text, record, "companyId")
      }
    ];
    this.state = {
      pagination: {},
      loading: false,
      visible: false,
      rolevisible: false
    }; //modal弹窗
    this.cacheData = {};
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
  }
  //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    return (
      <EditableCell
        editable={record.editable}
        value={text}
        onChange={value => this.handleChange(value, record.key, column)}
      />
    );
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getStaffInfo(pagination.current);
  }
  saveFormRef(form) {
    this.form = form;
  }
  componentDidMount() {
    this.props.actions.getStaffInfo(1, "");
    // setTimeout(() => {
    //   this.props.actions.getAppList(1, "");
    // }, 300);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  componentWillUnmount() {}
  render() {
    return (
      <div>
        <Table
          style={{ marginTop: 10 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.staffInfo}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    staffInfo: state.staffInfo.get("staffInfo"),
    pageConfig: state.staffInfo.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, action), dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserManage);
