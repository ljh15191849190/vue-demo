import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import _ from "lodash";
import { Modal, Input, Form, Button, Icon, Select, message, Card, Col, Row } from "antd";
import * as action from "../../../actions/App";
import "./styles/app.css";
import "./styles/excel.css";
import addapp from "../../../assets/images/dashboard/addapp.png";

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

const NewForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form, checkName, handleChange } = props;
  const { getFieldDecorator } = form;
  const selectAfter = (
    <Select defaultValue=".pkg" style={{ width: 80 }}>
      <Option value=".pkg">.pkg</Option>
      <Option value=".zip">.zip</Option>
    </Select>
  );
  return (
    <Modal
      visible={visible}
      title="新建"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
      checkName={checkName}
    >
      <Form layout="vertical">
        <FormItem label="应用名称">
          {getFieldDecorator("appName", {
            rules: [{ required: true, message: "应用名称不能为空", maxLength: 32 }]
          })(<Input />)}
        </FormItem>
        <FormItem label="应用包名">
          {getFieldDecorator("pkgName", {
            rules: [{ required: true, message: "应用包名不能为空", maxLength: 32 }]
          })(<Input />)}
        </FormItem>
        <FormItem label="应用签名">
          {getFieldDecorator("signName", {
            rules: [{ required: true, message: "应用签名不能为空" }]
          })(<Input />)}
        </FormItem>
        <FormItem label="描述">
          {getFieldDecorator("describe", { rules: [{ required: true, message: "描述不能为空" }] })(
            <TextArea rows={2} />
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});
const DetailForm = Form.create()(props => {
  const { isVisible, detailCancel, form, appDetail } = props;
  const { getFieldDecorator } = form;
  let appDetails = [];
  appDetail == undefined ? null : appDetails.push(appDetail);
  return (
    <Modal
      visible={isVisible}
      title="应用详情"
      cancelText="取消"
      onCancel={detailCancel}
      footer={null}
    >
      <div>
        <FormItem>
          <label style={{ width: 100 }}>APP名称</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.appName} key={Math.random()}>
                    {ele.appName}
                  </span>
                );
              })
            : null}
        </FormItem>
        <FormItem>
          <label style={{ width: 100 }}>应用包名</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.pkgName} key={Math.random()}>
                    {ele.pkgName}
                  </span>
                );
              })
            : null}
        </FormItem>
        <FormItem>
          <label style={{ width: 100 }}>APPID</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.appId} key={Math.random()}>
                    {ele.appId}
                  </span>
                );
              })
            : null}
        </FormItem>
        <FormItem>
          <label style={{ width: 100 }}>APPKEY</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.appkey} key={Math.random()}>
                    {ele.appkey}
                  </span>
                );
              })
            : null}
        </FormItem>
        <FormItem>
          <label style={{ width: 100 }}>APPSECRET</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.appSecret} key={Math.random()}>
                    {ele.appSecret}
                  </span>
                );
              })
            : null}
        </FormItem>
        <FormItem>
          <label style={{ width: 100 }}>描述</label>
          {appDetails.length == 1
            ? _.map(appDetails, ele => {
                return (
                  <span value={ele.describe} key={Math.random()}>
                    {ele.describe}
                  </span>
                );
              })
            : null}
        </FormItem>
      </div>
    </Modal>
  );
});
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      isVisible: false,
      checkName: "不能为空"
    };
    this.showModal = this.showModal.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.showDetails = this.showDetails.bind(this);
    this.detailCancel = this.detailCancel.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    this.props.actions.getAppList();
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.addAppStatus == 1) {
      message.success("应用添加成功");
      this.props.actions.getAppList();
    } else if (nextProps.addAppStatus == 2) {
      message.error("应用名称重复");
    }
  }
  saveFormRef(form) {
    this.form = form;
  }
  handleChange() {}
  showModal() {
    this.setState({ visible: true }); //显示模态框
  }
  handleCancel() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    this.setState({ visible: false });
  }
  edit(appId) {
    console.log(appId);
  }
  handleCreate() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      this.props.actions.addApp(values);
      this.setState({ visible: false });
    });
  }
  //details
  showDetails(appId) {
    this.setState({ isVisible: true }); //显示模态框
    this.props.actions.appIdDetails(appId);
  }
  detailCancel() {
    // form.resetFields();
    this.setState({ isVisible: false });
  }

  render() {
    return (
      <div>
        <div className="meddie">
          <span className="meddie-font">云之家控制台</span>
          <Icon type="right" className="meddie-icon" />
          <span className="meddie-update">设备升级</span>
        </div>
        <div className="outer_container">
          {_.map(this.props.appList, element => {
            return (
              <div className="app_container" key={element.appId}>
                <span className="seperator seperator2">
                  <label className="app-title">App名称</label>
                  <span className="app-content">{element.appName}</span>
                </span>
                <span className="seperator">
                  <label className="app-title">应用包名</label>
                  <span className="app-content">{element.pkgName}</span>
                </span>
                <span className="seperator seperator4">
                  <label className="app-title">App标识</label>
                  <span className="app-content">{element.appId}</span>
                </span>
                <span
                  className="seperator seperator1"
                  onClick={() => {
                    this.showDetails(element.appId);
                  }}
                >
                  <a className="detail-font">
                    {/* <span className="saveicon" /> */}
                    详情
                  </a>
                </span>
                {/* <span className="app_operation">
                  <Button
                    type="primary"
                    onClick={() => {
                      this.edit(element.appId);
                    }}
                  >
                    修改
                  </Button>
                  <Button>删除</Button>
                </span> */}
              </div>
            );
          })}
        </div>
        <div className="oper-container">
          <span className="newApp" onClick={this.showModal}>
            {/* <Icon type="plus" /> */}
            <img className="add-icon" src={addapp} alt="logo" />
            <span className="add-app">添加新应用</span>
          </span>
        </div>
        <NewForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          checkName={this.state.checkName}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          handleChange={this.handleChange}
        />
        <DetailForm
          isVisible={this.state.isVisible}
          detailCancel={this.detailCancel}
          appDetail={this.props.appDetail}
        />
      </div>
    );
  }
}
App.propTypes = {
  apps: PropTypes.array
};
const mapStateToProps = state => {
  return {
    appList: state.app.get("appList"),
    addAppStatus: state.app.get("appAddStatus"),
    appDetail: state.app.get("appDetail")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
