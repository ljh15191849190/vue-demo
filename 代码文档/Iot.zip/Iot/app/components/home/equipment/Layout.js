import React from "react";
import { Layout, Menu, Breadcrumb, Icon } from "antd";
const { Content, Footer, Sider } = Layout;
const SubMenu = Menu.SubMenu;
import { Switch, NavLink, Route } from "react-router-dom";

import List from "./List";
import Upgrade from "./Upgrade";
import OperationHistroy from "./OperationHistroy";
import FirmwareManagement from "./FirmwareManagement";
import EquipmentControl from "./EquipmentControl";
import EquipmentManage from "./EquipManage";

import UserManage from "../sysadmin/UserManage";
import Rolemanage from "../sysadmin/Rolemanage";
import AuthorityManage from "../sysadmin/AuthorityManage";

import App from "./App";
import histroy from "../../../routes/history";

import "./styles/equipment.css";
import "./styles/public.css";
import appmanage from "../../../assets/images/dashboard/appmanage.png";
import firmanage from "../../../assets/images/dashboard/firmanage.png";
import equipmanage from "../../../assets/images/dashboard/equipmanage.png";
import infomanage from "../../../assets/images/dashboard/infomanage.png";
import equipupgrade from "../../../assets/images/dashboard/equipupgrade.png";
import upgradehistory from "../../../assets/images/dashboard/upgradehistory.png";
import equipcontorl from "../../../assets/images/dashboard/equipcontorl.png";
class LayoutComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
      menuKey: 0,
      isShow: true
    };
    this.menuKey = 0;
    this.onCollapse = this.onCollapse.bind(this);
    this.getData = this.getData.bind(this);
    console.log("Layout consturctor");

    this.routerMapper = {
      "1": "/iot/list",
      "2": "/iot/upgrade",
      "3": "/iot/operationhistroy",
      "4": "/iot/firmwaremanagement",
      "5": "/iot/equipmentcontrol",
      "6": "/iot/app",
      "7": "/iot/equipmanage",

      // "8": "/iot/UserManage",
      // "9": "/iot/Rolemanage",
      // "10": "/iot/AuthorityManage",
    };
  }
  componentWillMount() {
    switch (this.props.location.pathname) {
      case "/iot/app":
        this.menuKey = "6";
        break;
      case "/iot/firmwaremanagement":
        this.menuKey = "4";
        break;
      case "/iot/equipmanage":
        this.menuKey = "7";
        break;
      case "/iot/list":
        this.menuKey = "1";
        break;
      case "/iot/upgrade":
        this.menuKey = "2";
        break;
      case "/iot/operationhistroy":
        this.menuKey = "3";
        break;
      case "/iot/equipmentcontrol":
        this.menuKey = "5";
        break;

      // case "/iot/UserManage":
      //   this.menuKey = "8";
      //   break;
      // case "/iot/Rolemanage":
      //   this.menuKey = "9";
      //   break;
      // case "/iot/AuthorityManage":
      //   this.menuKey = "10";
      //   break;
    }
    let permissions = JSON.parse(localStorage.getItem("userInfo")).userinfo.superadmin;
    if (permissions) {
      let defaultMenu = this.menuKey == 0 ? "6" : this.menuKey;
      this.setState({
        isShow: true,
        menuKey: defaultMenu
      });
      histroy.push(this.routerMapper[defaultMenu]);
    } else {
      let defaultMenu = this.menuKey == 0 ? "7" : this.menuKey;
      this.setState({
        isShow: false,
        menuKey: defaultMenu
      });
      histroy.push(this.routerMapper[defaultMenu]);
    }
  }
  componentDidMount() {}
  onCollapse(collapsed) {
    console.log(collapsed);
    // this.setState({ collapsed });
  }
  getData(item) {
    this.setState({ menuKey: item.key });
  }
  render() {
    return (
      <div className="right-body-container" style={{ minHeight: "75vh" }}>
        <Sider>
          <Menu
            defaultSelectedKeys={[this.state.menuKey + ""]}
            selectedKeys={[this.state.menuKey + ""]}
            defaultOpenKeys={["sub1"]}
            onClick={this.getData}
            mode="inline"
            theme="dark"
            // inlineCollapsed={this.state.collapsed}
          >
            {/* <SubMenu
              key="sub1"
              title={
                <span>
                  <Icon type="appstore-o" />
                  <span>云之家控制台</span>
                </span>
              }
            > */}
            <Menu.Item key="sub1" className="right-header">
              <span>云之家控制台</span>
            </Menu.Item>
            {this.state.isShow ? (
              <Menu.Item key="6" className="right-top">
                <NavLink to="/iot/app">
                  {/* <Icon type="appstore" /> */}
                  <img className="app_img" src={appmanage} alt="logo" />
                  <span>应用管理</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {this.state.isShow ? (
              <Menu.Item key="4">
                <NavLink to="/iot/firmwaremanagement">
                  {/* <Icon type="android" /> */}
                  <img className="app_img" src={firmanage} alt="logo" />
                  <span>固件管理</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}

            <Menu.Item key="7">
              <NavLink to="/iot/equipmanage">
                {/* <Icon type="desktop" /> */}
                <img className="app_img" src={equipmanage} alt="logo" />
                <span>设备管理</span>
              </NavLink>
            </Menu.Item>
            <Menu.Item key="1">
              <NavLink to="/iot/list">
                {/* <Icon type="file-text" /> */}
                <img className="app_img" src={infomanage} alt="logo" />
                <span>设备信息管理</span>
              </NavLink>
            </Menu.Item>
            {this.state.isShow ? (
              <Menu.Item key="2">
                <NavLink to="/iot/upgrade">
                  {/* <Icon type="inbox" /> */}
                  <img className="app_img" src={equipupgrade} alt="logo" />
                  <span>设备升级</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {this.state.isShow ? (
              <Menu.Item key="3">
                <NavLink to="/iot/operationhistroy">
                  {/* <Icon type="line-chart" /> */}
                  <img className="app_img" src={upgradehistory} alt="logo" />
                  <span>升级历史</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {this.state.isShow ? (
              <Menu.Item key="5">
                <NavLink to="/iot/equipmentcontrol">
                  {/* <Icon type="lock" /> */}
                  <img className="app_img" src={equipcontorl} alt="logo" />
                  <span>设备控制</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {/* </SubMenu> */}

            {/* <Menu.Item key="sub2" className="right-header">
              <span>云之家权限管理</span>
            </Menu.Item>
            {this.state.isShow ? (
              <Menu.Item key="8">
                <NavLink to="/iot/UserManage">
                  <img className="app_img" src={appmanage} alt="logo" />
                  <span>用户管理</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {this.state.isShow ? (
              <Menu.Item key="9">
                <NavLink to="/iot/Rolemanage">
                  <img className="app_img" src={appmanage} alt="logo" />
                  <span>角色管理</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}
            {this.state.isShow ? (
              <Menu.Item key="10">
                <NavLink to="/iot/AuthorityManage">
                  <img className="app_img" src={appmanage} alt="logo" />
                  <span>权限管理</span>
                </NavLink>
              </Menu.Item>
            ) : (
              ""
            )}*/}
          </Menu> 
        </Sider>
        <div className="right-div-body">
          <Content style={{ background: "#ffffff" }}>
            <div style={{ background: "#ffffff" }}>
              <Switch>
                <Route path="/iot/app" component={App} />
                <Route path="/iot/firmwaremanagement" component={FirmwareManagement} />
                <Route path="/iot/equipmanage" component={EquipmentManage} />
                <Route path="/iot/list" component={List} />
                <Route path="/iot/upgrade" component={Upgrade} />
                <Route path="/iot/operationhistroy" component={OperationHistroy} />
                <Route path="/iot/equipmentcontrol" component={EquipmentControl} />

                {/* <Route path="/iot/UserManage" component={UserManage} />
                <Route path="/iot/Rolemanage" component={Rolemanage} /> */}
              </Switch>
            </div>
          </Content>
          {/* <Footer style={{ textAlign: "center" }} /> */}
        </div>
      </div>
    );
  }
}

export default LayoutComponent;
