import React from "react";
import ReactDOM from "react-dom";
import { connect } from "react-redux";
import * as action from "../../../actions/CompanyApp";
import { bindActionCreators } from "redux";
import "./style/sysadmin.css";
import "./styles/app.css";
import { Icon, Modal, Input, Form, message, Table, Button } from "antd";
const FormItem = Form.Item;
const { TextArea } = Input;
const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input style={{ margin: "-5px 0" }} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);
const AppForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="创建新应用"
      okText="创建"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="应用名称">
          {getFieldDecorator("appName", {
            rules: [{ required: true, message: "应用名称不能为空", maxLength: 32 }]
          })(<Input />)}
        </FormItem>
        <FormItem label="描述">
          {getFieldDecorator("describe", { rules: [{ required: true, message: "描述不能为空" }] })(
            <TextArea rows={2} />
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});
class UserManage extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "应用id",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "upgradeId")
      },
      {
        title: "APP名称",
        dataIndex: "appName",
        render: (text, record) => this.renderColumns(text, record, "upgradeId")
      },
      {
        title: "APP标识",
        dataIndex: "appId",
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "APPKEY",
        dataIndex: "appkey",
        render: (text, record) => this.renderColumns(text, record, "sourceVersion")
      },
      {
        title: "APPSECRET",
        dataIndex: "appSecret",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "url")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "targetVersion")
      },
      {
        title: "描述",
        dataIndex: "describe",
        render: (text, record) => this.renderColumns(text, record, "md5")
      },
      {
        title: "公司ID",
        dataIndex: "companyId",
        render: (text, record) => this.renderColumns(text, record, "description")
      }
    ];
    this.state = {
      pagination: {},
      loading: false,
      visible: false,
      rolevisible: false
    }; //modal弹窗
    this.cacheData = {};
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleTableChange = this.handleTableChange.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
  }
  //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    return (
      <EditableCell
        editable={record.editable}
        value={text}
        onChange={value => this.handleChange(value, record.key, column)}
      />
    );
  }
  showModal() {
    this.form.resetFields();
    this.setState({ visible: true });
  }
  handleTableChange() {}
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getAppList(pagination.current);
  }
  handleCancel() {
    this.setState({ visible: false });
  }
  //add User
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      // let userInfo = JSON.parse(localStorage.getItem("userInfo"));

      let companyId = localStorage.getItem("companyId");
      values["companyId"] = companyId;
      console.log(values);
      this.props.actions.addApp(values);
      this.setState({ visible: false });
      form.resetFields();
      setTimeout(() => {
        this.props.actions.getAppList(1, "");
      }, 500);
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  componentDidMount() {
    this.props.actions.getAppList(1, "");
    // setTimeout(() => {
    //   this.props.actions.getAppList(1, "");
    // }, 300);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.addAppStatus == 1) {
      message.success("应用添加成功");
      this.props.actions.getAppList(1, "");
    } else if (nextProps.addAppStatus == 2) {
      message.error("应用名称重复");
    }
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  componentWillUnmount() {}
  render() {
    return (
      <div>
        <div className="searchbar" style={{ height: 50 }}>
          <Button onClick={this.showModal}>
            <Icon type="plus-circle-o" /> 添加新应用
          </Button>
        </div>
        {/* <div className="outer_container">
          {_.map(this.props.appList, element => {
            return (
              <div className="app_container" key={element.appid}>
                <span className="seperator">
                  <label>APPKEY：</label>
                  <span>{element.appKey}</span>
                </span>
                <span className="seperator">
                  <label>APPSECRET：</label>
                  <span>{element.Secret}</span>
                </span>
                <span className="seperator">
                  <label>APPID：</label>
                  <span>{element.appid}</span>
                </span>
                <span
                  className="seperator seperator1"
                  onClick={() => {
                    this.showDetails(element.appId);
                  }}
                >
                  <a>
                    <span className="saveicon" />详情
                  </a>
                </span>
              </div>
            );
          })}
        </div> */}
        <Table
          style={{ marginTop: 10 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.appList}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
        {/* <div className="oper-container">
          <span className="newApp" onClick={this.showModal}>
            <Icon type="plus-circle-o" />
            <span>添加新应用</span>
          </span>
        </div> */}

        <AppForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          upload={e => {
            console.log(e.fileList);
          }}
          preview={e => {
            console.log(e);
          }}
          list={this.props.PolicManage}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    addAppStatus: state.companyApp.get("appAddStatus"),
    appList: state.companyApp.get("appList"),
    pageConfig: state.companyApp.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, action), dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserManage);
