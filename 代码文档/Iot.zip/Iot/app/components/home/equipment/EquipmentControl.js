import React from "react";
import { Table, message, Input, Form, Button, Select } from "antd";
import "antd/dist/antd.css";
import * as Mock_data from "../../../../config/chartConfig";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as action from "../../../actions/EquipmentControl";

const FormItem = Form.Item;
const Option = Select.Option;
const FormItems = Form.create()(props => {
  const { onControl, form, pressEnter, controlType } = props;
  const { getFieldDecorator } = form;
  const defaultType = controlType.length > 0 ? controlType[0].controlMode : "default";
  return (
    <Form layout="inline">
      <FormItem label="设备ID">
        {getFieldDecorator("deviceId", {rules: [{required: true, message: "设备ID不能为空"}]})(
          <Input initialvalue="deviceID" onPressEnter={pressEnter} style={{width: 200}} />
        )}
      </FormItem>
      <FormItem label="控制类型">
        {getFieldDecorator("command")(
          <Select initialvalue={defaultType} style={{ width: 200 }}>
            {_.map(controlType, ele => {
              return (
                <Option value={ele.controlMode} key={ele.controlMode + Math.random()}>
                  {ele.description}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem>
        <Button onClick={onControl}>控制</Button>
      </FormItem>
    </Form>
  );
});

class EquipmentControl extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "ID")
      },
      {
        title: "控制ID",
        dataIndex: "controlId",
        render: (text, record) => this.renderColumns(text, record, "KZID")
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        render: (text, record) => this.renderColumns(text, record, "SBID")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "TYPE")
      },
      {
        title: "控制内容",
        dataIndex: "controlContent",
        render: (text, record) => this.renderColumns(text, record, "CONTROLCONTENT")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "CREATEDATE")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "UPDATEDATE")
      }
    ];
    this.state = {
      data: [], //
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false
    };
    this.cacheData = {};
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.onControl = this.onControl.bind(this);
    this.pressEnter = this.pressEnter.bind(this);
  }

  handleChange(value, key, column) {
    //console.log(column);
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      target[column] = value;
      this.setState({ data: newData });
    }
  }

  renderColumns(text, record, column) {
    return text;
  }

  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getControl(pagination.current);
  }
  saveFormRef(form) {
    this.form = form;
  }
  onControl() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      this.props.actions.toControlEquip(values);
      form.resetFields();
    });
  }
  pressEnter(e) {
    let deviceId = e.target.value;
    this.props.actions.getControlType(deviceId);
  }
  componentDidMount() {
    this.props.actions.getControl(1, "");
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.controlStatus == 1) {
      message.success("控制成功");
      this.props.actions.getControl(1, "");
    }
  }

  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <FormItems
          ref={this.saveFormRef}
          onControl={this.onControl}
          controlType={this.props.controlType}
          pressEnter={this.pressEnter}
        />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.equipControl.get("resData"),
    pageConfig: state.equipControl.get("pageConfig"),
    controlType: state.equipControl.get("controlType"),
    controlStatus: state.equipControl.get("controlStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EquipmentControl);
