import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table } from "antd";
import * as action from "../../../actions/OperHistory";
import "antd/dist/antd.css";

class OperHistory extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "上个版本",
        dataIndex: "sourceVersion",
        render: (text, record) => this.renderColumns(text, record, "sourceVersion")
      },
      {
        title: "当前版本",
        dataIndex: "targetVersion",
        render: (text, record) => this.renderColumns(text, record, "targetVersion")
      },
      {
        title: "升级任务ID",
        dataIndex: "upgradeId",
        render: (text, record) => this.renderColumns(text, record, "upgradeId")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      }
    ];
    this.state = {
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      searchItem: {}
    };
    this.handlePageChange = this.handlePageChange.bind(this);
    this.search = this.search.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
  }

  renderColumns(text, record, column) {
    if (column == "state") {
      let s = column.toUpperCase();
      return s == "n" ? "可用" : "不可用";
    } else {
      return text;
    }
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (this.state.searchItem.value) {
      var condition = {
        name: "deviceId",
        sopt: "like",
        value: deviceId
      };
      this.props.actions.getOperHistory(pagination.current, condition);
    } else {
      this.props.actions.getOperHistory(pagination.current, "");
    }
  }
  componentDidMount() {
    this.props.actions.getOperHistory(1, "");
  }
  search() {
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (!deviceId) {
      this.setState({
        searchItem: {}
      });
      this.props.actions.getOperHistory(1, "");
    } else {
      var condition = {
        name: "deviceId",
        sopt: "like",
        value: deviceId
      };
      this.setState({
        searchItem: condition
      });
      this.props.actions.getOperHistory(1, condition);
    }
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.search();
    }
  }
  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <div>
            <label htmlFor="name" className="lable namelable">
              设备ID
            </label>
            <input
              type="text"
              ref="deviceId"
              onKeyDown={this.onKeyDown}
              className="table-input nameinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" onClick={this.search}>
                搜索
              </span>
            </a>
          </div>
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.OperHistory.get("resData"),
    pageConfig: state.OperHistory.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OperHistory);
