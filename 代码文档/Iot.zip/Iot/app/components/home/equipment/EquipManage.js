import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Popconfirm, message, Form, Input, Button, Icon, Modal, Select } from "antd";
import _ from "lodash";
import * as action from "../../../actions/EquipManage";
import * as updateAction from "../../../actions/UpGrade";

const FormItem = Form.Item;
const Option = Select.Option;
const NewForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form, accountData, handleChange, isAdmin } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="绑定设备"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
      isAdmin={isAdmin}
    >
      <Form layout="vertical">
        {isAdmin ? (
          <FormItem label="用户查询">
            {getFieldDecorator("uid", { rules: [{ required: true, message: "请选择用户" }] })(
              <Select
                showSearch
                initialValue="选择用户"
                onChange={handleChange}
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
              >
                {_.map(accountData, ele => {
                  return (
                    <Option value={ele.uid} key={ele.appId + Math.random()}>
                      {ele.name}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
        ) : (
          ""
        )}
        {/* {
          {
            true: (
              <FormItem label="用户查询">
                {getFieldDecorator("uid", { rules: [{ required: true, message: "请选择用户" }] })(
                  <Select initialValue="选择appId" onChange={handleChange}>
                    {_.map(accountData, ele => {
                      return (
                        <Option value={ele.uid} key={ele.appId + Math.random()}>
                          {ele.name}
                        </Option>
                      );
                    })}
                  </Select>
                )}
              </FormItem>
            ),
            false: ""
          }[isAdmin]
        } */}
        <FormItem label="设备序列号:">
          {getFieldDecorator("deviceId", {
            rules: [{ required: true, message: "序列号不能为空" }]
          })(<Input />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
class EquipManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      pagination: {},
      loading: false,
      searchItem: {},
      isAdmin: true
    };
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "版本",
        dataIndex: "version",
        render: (text, record) => this.renderColumns(text, record, "version")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "操作",
        dataIndex: "action",
        render: (text, record) => (
          <Popconfirm
            title="确定解除绑定吗？"
            onConfirm={() => this.unbind(record.deviceId)}
            okText="确定"
            cancelText="取消"
          >
            <a className="deletebtn">
              <span className="deleteicon" />解绑
            </a>
          </Popconfirm>
        )
      }
    ];
    this.search = this.search.bind(this);
    this.onDelete = this.onDelete.bind(this);
    this.unbind = this.unbind.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
  }
  onDelete(deviceId) {
    this.props.actions.delEquipByDeviceId(deviceId);
  }
  renderColumns(text, record, column) {
    return text;
  }
  search() {
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (!deviceId) {
      this.props.actions.getEquipList(1);
    } else {
      this.props.actions.getEquipByDeviceId(deviceId);
    }
  }
  showModal() {
    this.setState({ visible: true });
  }
  saveFormRef(form) {
    this.form = form;
  }
  unbind(deviceId) {
    this.props.actions.unBindEquipByDeviceId(deviceId);
  }
  handleChange(value) {
    console.log(value);
  }
  handleCancel() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    this.setState({ visible: false });
  }
  handleCreate() {
    const form = this.form;
    let self = this;
    form.validateFields((err, values) => {
      if (self.state.isAdmin && err) {
        return;
      } else if (!self.state.isAdmin && err.deviceId) {
        return;
      }
      if (!values.uid) {
        let userInfo = JSON.parse(localStorage.getItem("userInfo"));
        let uid = userInfo.uid;
        values["uid"] = uid + "";
        this.props.actions.addNewEquip(values);
      } else {
        values["uid"] = values.uid + "";
        this.props.actions.addNewEquip(values);
      }
      form.resetFields();
      this.setState({ visible: false });
    });
  }
  componentDidMount() {
    this.props.actions.getEquipList(1);
    this.props.actions.getAccount("1", "");
    let permissions = JSON.parse(localStorage.getItem("userInfo")).userinfo.superadmin;
    if (permissions) {
      this.setState({
        isAdmin: true
      });
    } else {
      this.setState({
        isAdmin: false
      });
    }
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getEquipList(pagination.current);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.delStatus == 1) {
      message.success("删除成功");
      this.props.actions.getEquipList(1);
    } else if (nextProps.delStatus == 2) {
      message.error("删除失败");
    }
    if (nextProps.addStatus == 1) {
      message.success("添加成功");
      this.props.actions.getEquipList(1);
    }
    if (nextProps.unbindStatus == 1) {
      message.success("解绑成功");
      this.props.actions.getEquipList(1);
    }
  }

  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Button onClick={this.showModal}>
            <Icon type="plus-circle-o" /> 绑定设备
          </Button>
          <NewForm
            ref={this.saveFormRef}
            visible={this.state.visible}
            onCancel={this.handleCancel}
            onCreate={this.handleCreate}
            handleChange={this.handleChange}
            accountData={this.props.accountData}
            isAdmin={this.state.isAdmin}
            handlePageChange={this.handlePageChange}
          />
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.equipManage.get("resData"),
    pageConfig: state.equipManage.get("pageConfig"),
    delStatus: state.equipManage.get("delStatus"),
    addStatus: state.equipManage.get("addStatus"),
    unbindStatus: state.equipManage.get("unbindStatus"),
    accountData: state.account.get("accountData") || []
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, updateAction, action), dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EquipManage);
