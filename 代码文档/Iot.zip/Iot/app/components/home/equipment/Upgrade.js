import React from "react";
import { Button, Input, Select, Card, Table, Form, Popconfirm, message, Collapse } from "antd";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import _ from "lodash";
import * as action from "../../../actions/UpGrade";
import "./styles/Upgrade.css";
const Option = Select.Option;
const FormItem = Form.Item;
const { TextArea } = Input;
const Panel = Collapse.Panel;

const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input style={{ margin: "-5px 0" }} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);
const NewForm = Form.create()(props => {
  const {
    form,
    accountData,
    appidData,
    typeData,
    versionInfo,
    handleChange,
    handleAppid,
    handleType,
    handleSversion,
    handleTVersion,
    upgradeByDevice
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Form layout="vertical">
      <FormItem
        style={{ marginBottom: 0, paddingBottom: 0 }}
        className="updateForm"
        label="查询用户："
      >
        {/* <label style={{ width: 100 }}>查询用户：</label> */}
        {getFieldDecorator("user", { rules: [{ required: true, message: "不能为空" }] })(
          <Select
            initialValue="查询用户"
            style={{ width: 200 }}
            onChange={handleChange}
            showSearch
            optionFilterProp="children"
            filterOption={(input, option) =>
              option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
          >
            {_.map(accountData, ele => {
              return (
                <Option value={ele.uid} key={ele.uid + Math.random()}>
                  {ele.name}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="app名称："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>app名称：</label> */}
        {getFieldDecorator("appid", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="选择appId" style={{ width: 200 }} onChange={handleAppid}>
            {_.map(appidData, ele => {
              return (
                <Option value={ele.appId} key={ele.appId + Math.random()}>
                  {ele.appName}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="设备类型："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>设备类型：</label> */}
        {getFieldDecorator("deviceMode", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="选择类型:" style={{ width: 200 }} onChange={handleType}>
            {_.map(typeData, ele => {
              return (
                <Option value={ele} key={Math.random()}>
                  {ele}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="当前版本："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>当前版本：</label> */}
        {getFieldDecorator("sourceVersion", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="选择类型:" style={{ width: 200 }} onChange={handleSversion}>
            {_.map(versionInfo, ele => {
              return (
                <Option value={ele.version} key={Math.random()}>
                  {ele.version}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem className="updateForm" label="目标版本：">
        {/* <label style={{ width: 100 }}>目标版本：</label> */}
        {getFieldDecorator("targetVersion", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="选择类型:" style={{ width: 200 }} onChange={handleTVersion}>
            {_.map(versionInfo, ele => {
              return (
                <Option value={ele.version} key={Math.random()}>
                  {ele.version}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem className="updateForm" label="升级描述">
        {/* <label style={{ width: 100, marginLeft: 96 }}>升级描述：</label> */}
        {getFieldDecorator("description")(<TextArea rows={1} style={{ width: 586 }} />)}
      </FormItem>
      <FormItem className="updateButton">
        <Button onClick={upgradeByDevice} style={{ width: 230 }} className="updateBtn">
          升级
        </Button>
      </FormItem>
    </Form>
  );
});
const IdForm = Form.create()(props => {
  const {
    form,
    deviceAppDate,
    handleSoVersion,
    handleTaVersion,
    upgradeById,
    onPressUp,
    handleappId,
    getDeviceId,
    versionInId
  } = props;
  const { getFieldDecorator } = form;
  let deviceAppDated = [];
  deviceAppDate == undefined || !deviceAppDate.appId
    ? (deviceAppDated.length = 0)
    : deviceAppDated.push(deviceAppDate);
  return (
    <Form layout="vertical">
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="设备ID："
      >
        {/* <label style={{ width: 100 }}></label> */}
        {getFieldDecorator("deviceId", { rules: [{ required: true, message: "不能为空" }] })(
          <Input
            style={{ width: 200 }}
            onPressEnter={onPressUp}
            onBlur={onPressUp}
            onChange={getDeviceId}
          />
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="app名称："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>app名称：</label> */}
        {getFieldDecorator("appId", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="appId:" style={{ width: 200 }} onChange={handleappId}>
            {deviceAppDated.length == 1
              ? _.map(deviceAppDated, ele => {
                  return (
                    <Option value={ele.appId} key={Math.random()}>
                      {ele.appName}
                    </Option>
                  );
                })
              : null}
          </Select>
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="当前版本："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>当前版本：</label> */}
        {getFieldDecorator("sourceVersion", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="当前版本:" style={{ width: 200 }} onChange={handleSoVersion}>
            {deviceAppDated.length == 1
              ? _.map(deviceAppDated, ele => {
                  return (
                    <Option value={ele.version} key={Math.random()}>
                      {ele.version}
                    </Option>
                  );
                })
              : null}
          </Select>
        )}
      </FormItem>
      <FormItem
        className="updateForm"
        style={{ marginBottom: 0, paddingBottom: 0 }}
        label="目标版本："
      >
        {/* <label style={{ width: 100, marginLeft: 96 }}>目标版本：</label> */}
        {getFieldDecorator("targetVersion", { rules: [{ required: true, message: "不能为空" }] })(
          <Select initialValue="目标版本:" style={{ width: 200 }} onChange={handleTaVersion}>
            {_.map(versionInId, ele => {
              return (
                <Option value={ele.version} key={Math.random()}>
                  {ele.version}
                </Option>
              );
            })}
          </Select>
        )}
      </FormItem>
      <FormItem className="updateForm" label="升级描述">
        {/* <label style={{ width: 100 }}>升级描述</label> */}
        {getFieldDecorator("description")(
          <TextArea rows={1} className="idupgrade-area" style={{ width: 669 }} />
        )}
      </FormItem>
      <FormItem className="updateButton">
        <Button onClick={upgradeById} style={{ width: 230 }} className="updateBtn">
          升级
        </Button>
      </FormItem>
    </Form>
  );
});
class UpdateTasks extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "任务ID",
        dataIndex: "upgradeId",
        width: 60,
        render: (text, record) => this.renderColumns(text, record, "upgradeId")
      },
      {
        title: "升级类型",
        dataIndex: "upgradeType",
        width: 120,
        render: (text, record) => {
          const { upgradeType } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {parseInt(upgradeType) == 1 ? <span>按设备id升级</span> : <span>按设备类型升级</span>}
            </div>
          );
        }
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        width: 60,
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "当前版本",
        dataIndex: "sourceVersion",
        width: 80,
        render: (text, record) => this.renderColumns(text, record, "sourceVersion")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        width: 80,
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "下载地址",
        dataIndex: "url",
        width: 200,
        render: (text, record) => this.renderColumns(text, record, "url")
      },
      {
        title: "目标版本",
        dataIndex: "targetVersion",
        width: 80,
        render: (text, record) => this.renderColumns(text, record, "targetVersion")
      },
      {
        title: "文件MD5值",
        dataIndex: "md5",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "md5")
      },
      {
        title: "文件大小",
        dataIndex: "size",
        width: 100,
        render: (text, record) => this.renderColumns(text, record, "size")
      },
      {
        title: "升级描述",
        dataIndex: "description",
        render: (text, record) => this.renderColumns(text, record, "description")
      },
      {
        title: "操作账号",
        dataIndex: "account",
        width: 80,
        render: (text, record) => this.renderColumns(text, record, "account")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "执行状态",
        dataIndex: "statu",
        width: 80,
        render: (text, record) => {
          const { statu } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {parseInt(statu) ? <span>已执行</span> : <span>待执行</span>}
            </div>
          );
        }
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          const { statu } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {parseInt(statu) ? (
                <span>
                  <Button disabled>强制升级</Button>
                  <Button style={{ marginTop: 5 }} disabled>
                    提示升级
                  </Button>
                </span>
              ) : (
                <span>
                  <Popconfirm
                    title="确定强制升级吗？"
                    onConfirm={() => this.forceUpdate(record.key)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <Button>强制升级</Button>
                  </Popconfirm>
                  <Popconfirm
                    title="确定提示升级吗？"
                    onConfirm={() => this.unforceUpdate(record.key)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <Button style={{ marginTop: 5 }}>提示升级</Button>
                  </Popconfirm>
                </span>
              )}
            </div>
          );
        }
      }
    ];
    this.state = {
      data: [], //
      dataSource: [],
      appId: [],
      count: 5,
      pagination: {},
      accountData: [],
      typeData: [],
      appidData: [],
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false,
      deviceid: ""
    };
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.upgradeByDevice = this.upgradeByDevice.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.saveForRef = this.saveForRef.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleType = this.handleType.bind(this);
    this.handleAppid = this.handleAppid.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.onPressUp = this.onPressUp.bind(this);
    this.handleappId = this.handleappId.bind(this);
    this.upgradeById = this.upgradeById.bind(this);
    this.forceUpdate = this.forceUpdate.bind(this);
    this.unforceUpdate = this.unforceUpdate.bind(this);
    this.handleSversion = this.handleSversion.bind(this);
    this.handleTversion = this.handleTversion.bind(this);
    this.handleSoVersion = this.handleSoVersion.bind(this);
    this.handleTaVersion = this.handleTaVersion.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.getDeviceId = this.getDeviceId.bind(this);
    // this.resetFormFields = this.resetFormFields.bind(this);
  }

  edit(key) {
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({ data: newData }); //更新编辑视图
    }
  } //编辑

  save(key) {
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      delete target.editable;
      this.setState({ data: newData });
      console.log(target); //此处与后台交互保存已修改数据
    }
  } //保存

  renderColumns(text, record, column) {
    return (
      <EditableCell
        editable={record.editable}
        value={text}
        onChange={value => this.handleChange(value, record.key, column)}
      />
    );
  }

  onDelete(key) {
    const dataSource = [...this.props.resData];
    console.log(dataSource);
    this.setState({ dataSource: dataSource.filter(item => item.key !== key) });
    this.state.count -= 1;
    console.log("删除第" + key + "项数据值");
    console.log(key);
    this.props.actions.deleteTask(key);
  } //删除操作

  showModal() {
    this.setState({ visible: true }); //显示模态框
  }

  handleCancel() {
    this.setState({ visible: false });
  }
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      console.log("Received values of form: ", values);
      values.key = Date.parse(new Date());
      this.state.dataSource.push(values);
      this.setState({ dataSource: this.state.dataSource, visible: false });
      form.resetFields();
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  saveForRef(form) {
    this.form2 = form;
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getUpdateTasks(pagination.current);
  }
  //upgradeByDevice
  handleChange(value) {
    if (value) {
      localStorage.setItem("duid", value);
      this.props.actions.getAppid(value);
    }
    this.form.setFieldsValue({
      appid: "",
      deviceMode: ""
    });
  }
  handleAppid(appid) {
    if (appid) {
      localStorage.setItem("appid", appid);
      let value = localStorage.getItem("duid");
      this.props.actions.getDeviceType(value, appid);
    }
    this.form.setFieldsValue({
      deviceMode: "",
      sourceVersion: "",
      targetVersion: ""
    });
  }
  handleType(deviceMode) {
    let appId = localStorage.getItem("appid");
    this.props.actions.getVersion(appId, deviceMode);
  }
  handleSversion(sourceVersion) {}
  handleTversion(targetVersion) {}
  upgradeByDevice() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      let userInfo = JSON.parse(localStorage.getItem("userInfo"));
      let account = userInfo.account;
      values["account"] = account;
      let duid = localStorage.getItem("duid");
      values["uid"] = duid;
      this.props.actions.updateByType(values);
      form.resetFields(); //清除输入表单中的数据
    });
    setTimeout(() => {
      this.props.actions.getUpdateTasks(1, "");
      // this.props.appidData.length = 0;
      // this.props.typeData.length = 0;
      // this.props.versionInfo.length = 0;
      this.props.appidData ? (this.props.appidData.length = 0) : null;
      this.props.typeData ? (this.props.typeData.length = 0) : null;
      this.props.versionInfo ? (this.props.versionInfo.length = 0) : null;
      form.resetFields();
    }, 1000);
  }
  //upgradeById
  getDeviceId(e) {
    let deviceId = e.target.value;
    this.setState({ deviceid: deviceId });
  }
  onPressUp(event) {
    const form = this.form2;
    event.preventDefault();
    let deviceId = this.state.deviceid;
    if (!deviceId) {
      message.warning("请输入设备id");
    } else {
      this.props.actions.getDeviceApps(this.state.deviceid);
    }
    this.form.setFieldsValue({
      appId: ""
    });
  }
  handleappId(appId) {
    if (appId) {
      let deviceAppDate = this.props.deviceAppDate;
      this.props.actions.versionInId(appId, deviceAppDate.deviceMode);
    }
    this.form.setFieldsValue({
      sourceVersion: "",
      targetVersion: ""
    });
  }
  handleSoVersion() {}
  handleTaVersion(targetVersion) {}
  upgradeById() {
    console.log(this.props.deviceAppDate);
    const form = this.form2;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      let userInfo = JSON.parse(localStorage.getItem("userInfo"));
      let account = userInfo.account;
      values["account"] = account;
      this.props.actions.updateById(values);
      form.resetFields();
    });
    setTimeout(() => {
      this.props.actions.getUpdateTasks(1, "");
      this.props.versionInId ? (this.props.versionInId.length = 0) : null;
      if (!(this.props.deviceAppDate == undefined)) {
        this.props.deviceAppDate.appId = "";
        this.props.deviceAppDate.appName = "";
        this.props.deviceAppDate.version = "";
        this.props.deviceAppDate.length = 0;
      } else {
        return;
      }
      form.resetFields();
    }, 500);
  }
  forceUpdate(key) {
    this.props.actions.forceUpdate(key);
    setTimeout(() => {
      this.props.actions.getUpdateTasks(1, "");
    }, 500);
  }
  unforceUpdate(key) {
    this.props.actions.unforceUpdate(key);
    setTimeout(() => {
      this.props.actions.getUpdateTasks(1, "");
    }, 500);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  componentDidMount() {
    this.props.actions.getUpdateTasks(1, "");
    /*this.props.actions.getAppid("1");*/
    this.props.actions.getAccount(1, "");
    // this.resetFormFields();
  }
  componentWillUnmount() {
    this.props.appidData ? (this.props.appidData.length = 0) : null;
    this.props.typeData ? (this.props.typeData.length = 0) : null;
    this.props.versionInfo ? (this.props.versionInfo.length = 0) : null;
    this.props.versionInId ? (this.props.versionInId.length = 0) : null;
    if (!(this.props.deviceAppDate == undefined)) {
      this.props.deviceAppDate.appId = "";
      this.props.deviceAppDate.appName = "";
      this.props.deviceAppDate.version = "";
      this.props.deviceAppDate.length = 0;
    } else {
      return;
    }
  }
  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div className="card">
        <Collapse accordion bordered={false} defaultActiveKey={["1"]}>
          <Panel header="设备类型升级" key="1" style={{ width: 1611, marginLeft: 10 }}>
            <NewForm
              ref={this.saveFormRef}
              visible={this.state.visible}
              onCancel={this.handleCancel}
              onCreate={this.handleCreate}
              accountData={this.props.accountData}
              appidData={this.props.appidData}
              typeData={this.props.typeData}
              versionInfo={this.props.versionInfo}
              accountChange={this.accountChange}
              appChange={this.appChange}
              handleChange={this.handleChange}
              handleAppid={this.handleAppid}
              handleType={this.handleType}
              handleSversion={this.handleSoVersion}
              handleaTversion={this.handleTversion}
              upgradeByDevice={this.upgradeByDevice}
              // resetFormFields={this.resetFormFields}
            />
          </Panel>
        </Collapse>

        <Collapse accordion bordered={false}>
          <Panel header="ID升级" key="1" style={{ width: 1611, marginLeft: 10, marginTop: 20 }}>
            <IdForm
              ref={this.saveForRef}
              visible={this.state.visible}
              onCancel={this.handleCancel}
              onCreate={this.handleCreate}
              accountData={this.props.accountData}
              deviceAppDate={this.props.deviceAppDate}
              typeData={this.props.typeData}
              versionInId={this.props.versionInId}
              accountChange={this.accountChange}
              appChange={this.appChange}
              onPressUp={this.onPressUp}
              getDeviceId={this.getDeviceId}
              handleappId={this.handleappId}
              handleType={this.handleType}
              handleSoVersion={this.handleSoVersion}
              handleTaVersion={this.handleTaVersion}
              upgradeById={this.upgradeById}
            />
          </Panel>
        </Collapse>
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
          scroll={{ y: 330 }}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.upGrade.get("resData"),
    pageConfig: state.upGrade.get("pageConfig"),
    accountData: state.getAccount.get("accountData"),
    typeData: state.upGrade.get("typeData"),
    appidData: state.upGrade.get("appidData"),
    deviceAppDate: state.upGrade.get("DeviceApp"),
    versionInfo: state.upGrade.get("versionInfo"),
    versionInId: state.upGrade.get("versionInId")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, action), dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UpdateTasks);
