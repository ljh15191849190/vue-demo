import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import _ from "lodash";
import {
  Upload,
  Icon,
  Table,
  Popconfirm,
  Button,
  Modal,
  Input,
  Form,
  Select,
  Transfer,
  Cascader
} from "antd";
// import { Modal, Input, Form, Button, Icon, Select, message, Table } from "antd";
import * as action from "../../../actions/systemManage/permission";
import * as actions from "../../../actions/systemManage/policmanage";
import "./styles/app.css";
import cityJson from "../../../assets/locales/city.json";

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

// // [{
// //   value: 'zhejiang',
// //   label: 'Zhejiang',
// //   children: [{
// //     value: 'hangzhou',
// //     label: 'Hangzhou',
// //     children: [{
// //       value: 'xihu',
// //       label: 'West Lake',
// //     }, {
// //       value: 'xiasha',
// //       label: 'Xia Sha',
// //       disabled: true,
// //     }],
// //   }],
// // }, {}]

const handleCity = cityJson.provinces;
// console.log("handleCity", handleCity);
let cityArr = [];
for (var i = 0; i < handleCity.length; i++) {
  let cityObj = {};
  // console.log("cityObj",cityObj);
  cityObj.value = handleCity[i].provinceName;
  cityObj.label = handleCity[i].provinceName;
  let cityList = handleCity[i].citys;
  var childArr = [];
  for (let j = 0; j < handleCity[i].citys.length; j++) {
    let childList = {};
    // console.log("cityList", cityList[j]);
    childList.value = cityList[j].citysName;
    childList.label = cityList[j].citysName;
    // console.log("childList", childList);
    childArr.push(childList);
    // console.log("childArr", childArr);
  }
  cityObj.children = childArr;
  // console.log("cityObj",cityObj);
  cityArr.push(cityObj);
  // console.log("cityArr",cityArr);
}
// console.log("cityArr",cityArr);
const residences = cityArr;
// console.log("residences", residences);

// let threeCity = [];
// let threeCityChild = {};
//   threeCityChild.value = "中国";
//   threeCityChild.label = "中国";
//   threeCityChild.children = cityArr;
// threeCity.push(threeCityChild);
// const residences = threeCity;
// console.log("residences", residences);

const NewForm = Form.create()(props => {
  const { visible, onCancel, onCreate, form, checkName, onCascaderChange, list, errMsg } = props;
  // console.log("NewFormprops", props);
  // console.log("NewFormpropslist", list);

  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="修改"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
      checkName={checkName}
    >
      <Form layout="vertical">
        <FormItem label="公司名称">
          {getFieldDecorator("companyName", {
            rules: [{ required: true, message: "公司名称不能为空", maxLength: 32 }],
            initialValue: list ? list.companyName : ""
          })(<Input disabled />)}
        </FormItem>
        <FormItem label="国家">
          {getFieldDecorator("country", {
            rules: [{ required: true, message: "国家不能为空", maxLength: 32 }],
            initialValue: list ? list.country : ""
          })(
            <Select>
              <Option value="中国">中国</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="城市">
          {getFieldDecorator("city", {
            rules: [{ required: true, message: "城市不能为空" }],
            initialValue: list ? (list.city ? list.city.split(",") : "") : ""
            // initialValue: ['福建', '厦门'],
          })(
            // <Select >
            //   <Option value="china">China</Option>
            //   <Option value="dongguan">dongguan</Option>
            //   <Option value="dalian">dalian</Option>
            // </Select>
            <Cascader options={residences} onChange={onCascaderChange} />
          )}
        </FormItem>
        <FormItem label="邮箱">
          {getFieldDecorator("mail", {
            rules: [{ required: true, message: "邮箱不能为空" }],
            initialValue: list ? list.mail : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="联系人">
          {getFieldDecorator("contacts", {
            rules: [{ required: true, message: "联系人不能为空", maxLength: 32 }],
            initialValue: list ? list.contacts : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="地址">
          {getFieldDecorator("address", {
            rules: [{ required: true, message: "地址不能为空", maxLength: 32 }],
            initialValue: list ? list.address : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="行业">
          {getFieldDecorator("industry", {
            rules: [{ required: true, message: "行业不能为空", maxLength: 32 }],
            initialValue: list ? list.industry : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="人数">
          {getFieldDecorator("pnumber", {
            rules: [{ required: true, message: "应用名称不能为空", maxLength: 32 }],
            initialValue: list ? list.pnumber : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="电话">
          {getFieldDecorator("phone", {
            rules: [{ required: true, message: "电话不能为空", maxLength: 32 }],
            initialValue: list ? list.phone : ""
          })(<Input />)}
        </FormItem>
        <FormItem label="移动电话">
          {getFieldDecorator("mobile", {
            rules: [{ required: true, message: "移动电话不能为空", maxLength: 32 }],
            initialValue: list ? list.mobile : ""
          })(<Input />)}
        </FormItem>
      </Form>
      {errMsg ? <span className="errorMsg">{errMsg}</span> : null}
    </Modal>
  );
});

const EditableCell = ({ editable, value, onChange }) => (
  <div>
    {editable ? (
      <Input style={{ margin: "-5px 0" }} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);

let isAdmin = [
  {
    key: "1",
    value: "可用"
  },
  {
    key: "0",
    value: "不可用"
  }
];
const EditAdmin = ({ editable, value, onChange, defaultValue }) => (
  <div>
    {editable ? (
      <Select
        style={{ margin: "-5px 0" }}
        defaultValue={defaultValue}
        onSelect={e => {
          onChange(e);
        }}
      >
        <Option value={"1"}>可用</Option>
        <Option value={"0"}>不可用</Option>
      </Select>
    ) : (
      value
    )}
  </div>
);

class CompanyInfo extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "公司名称",
        dataIndex: "companyName",
        render: (text, record) => this.renderColumns(text, record, "companyName")
      },
      {
        title: "手机",
        dataIndex: "mobile",
        render: (text, record) => this.renderColumns(text, record, "mobile")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "公司ID",
        dataIndex: "companyId",
        render: (text, record) => this.renderColumns(text, record, "companyId")
      },
      {
        title: "联系人",
        dataIndex: "contacts",
        render: (text, record) => this.renderColumns(text, record, "contacts")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          const { editable } = record; //当前行数据
          return (
            <div className="pointer">
              <span onClick={this.showModal}>
                <Icon type="form" />
                <span>编辑</span>
              </span>
            </div>
          );
        }
      }
    ];
    this.state = {
      visible: false,
      isVisible: false,
      checkName: "不能为空",
      loading: false,
      errMsg: ""
    };
    this.showModal = this.showModal.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.showDetails = this.showDetails.bind(this);
    this.detailCancel = this.detailCancel.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.onCascaderChange = this.onCascaderChange.bind(this);
  }

  componentDidMount() {
    this.props.actions.get(1, "companyGetOne");
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.companyGetOneData.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.companyGetOneData.pageBean.total,
          current: nextProps.companyGetOneData.pageBean.page,
          pageSize: nextProps.companyGetOneData.pageBean.size
        },
        loading: false
      });
    }
  }

  componentWillUnmount() {
    // this.props.UserManage.list = [];
  }
  showModal() {
    this.form.resetFields();
    this.setState({ visible: true });
  }
  //行内编辑动态更新对应字段的值
  renderColumns(text, record, column) {
    if (column == "superadmin") {
      return (
        <EditAdmin
          editable={record.editable}
          value={isAdmin.find(item => text == Boolean(parseInt(item.key))).value}
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"" + Number(text)}
        />
      );
    } else if (column == "available") {
      return (
        <EditAdmin
          editable={record.editable}
          value={isAdmin.find(item => text == Boolean(parseInt(item.key))).value}
          onChange={value => this.handleChange(value, record.id, column)}
          defaultValue={"" + Number(text)}
        />
      );
    } else {
      return (
        <EditableCell
          editable={record.editable}
          value={text}
          onChange={value => this.handleChange(value, record.id, column)}
        />
      );
    }
  }
  //模态框提交事件
  handleCreate() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      let companyName = _.trim(values.companyName);
      let contacts = _.trim(values.contacts);
      let mobile = _.trim(values.mobile);
      let email = _.trim(values.mail);
      let pnumber = _.trim(values.pnumber);
      let phone = _.trim(values.phone);

      let emailTest = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/;
      let mobileTest = /^1[0-9]{10}$/;
      let pnumberTest = /^\d+$/; //验证非负整数（正整数 + 0）
      let phoneTest = /^(\(\d{3,4}\)|\d{3,4}-)?\d{7,8}$/; //验证电话号码：--正确格式为：XXXX-XXXXXXX，XXXX-XXXXXXXX，XXX-XXXXXXX，XXX-XXXXXXXX，XXXXXXX，XXXXXXXX。
      // console.log("companyName", companyName);
      // console.log("contacts", contacts);
      // console.log("mobile", mobile);
      // console.log("email", email);
      if (companyName && email && mobile) {
        if (!emailTest.test(email)) {
          this.setState({
            errMsg: "请输入正确的邮件格式"
          });
          return;
        }
        if (!mobileTest.test(mobile)) {
          this.setState({
            errMsg: "请输入正确的移动电话格式"
          });
          return;
        }
        if (!pnumberTest.test(pnumber)) {
          this.setState({
            errMsg: "请输入正确的人数"
          });
          return;
        }
        if (!phoneTest.test(phone)) {
          this.setState({
            errMsg: "请输入正确的固定电话格式"
          });
          return;
        }
      } else if (companyName == "" || contacts == "" || mobile == "") {
        this.setState({
          errMsg: "上述信息不能为空"
        });
      } else {
        this.setState({
          errMsg: "上述信息不正确"
        });
      }
      this.props.actions.editInfo(1, values, "companyInfo");
      // this.props.actions.addApp(values);
      this.setState({
        visible: false,
        errMsg: ""
      });
      form.resetFields();
      setTimeout(() => {
        this.props.actions.get(1, "companyGetOne");
      }, 500);
    });
  }

  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getUpdateTasks(pagination.current);
  }
  saveFormRef(form) {
    this.form = form;
  }

  handleChange() {}

  onCascaderChange(value, selectedOptions) {}

  handleCancel() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    this.setState({ visible: false });
  }
  edit(appId) {}
  //details
  showDetails(appId) {
    this.setState({ isVisible: true }); //
    this.props.actions.appIdDetails(appId);
  }
  detailCancel() {
    // form.resetFields();
    this.setState({ isVisible: false });
  }

  render() {
    let companyGetOneDataArray = [];
    let arr = this.props.companyGetOneData.data;
    if (this.props.companyGetOneData.length !== 0) {
      companyGetOneDataArray.push(arr);
    }
    // console.log("companyGetOneDataArray", companyGetOneDataArray);
    return (
      <div className="card">
        <Table
          style={{ marginTop: 20, flex: 1 }}
          bordered
          size="small"
          locale={{ emptyText: "暂无数据..." }}
          columns={this.columns}
          dataSource={companyGetOneDataArray}
          // dataSource={[{companyId: 45,companyName: "FRGF",contacts: "23regfb",createdate: "2018-08-02 21:23:04",id: 23,mobile: "15768896546",state: "N",updatedate: "2018-08-02 21:23:04"}]}
          loading={this.state.loading}
          // scroll={{ y: 330 }}
        />
        <NewForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          upload={e => {
            console.log(e.fileList);
          }}
          preview={e => {
            console.log(e);
          }}
          onCascaderChange={this.onCascaderChange}
          list={this.props.companyGetOneData.data}
          errMsg={this.state.errMsg}
        />
      </div>
    );
  }
}
CompanyInfo.propTypes = {
  apps: PropTypes.array
};
const mapStateToProps = state => {
  return {
    companyGetOneData: state.permissionManage.get("companyGetOneData")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, action, actions), dispatch)
    // actions: bindActionCreators(action, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CompanyInfo);
