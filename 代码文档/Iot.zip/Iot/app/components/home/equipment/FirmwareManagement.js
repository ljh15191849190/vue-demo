import React from "react";
import { Table, Modal, Input, Form, message, Button, Icon, Select, Popconfirm, Spin } from "antd";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as action from "../../../actions/FiMAnagement";
import * as updateAction from "../../../actions/UpGrade";
import * as uploadAction from "../../../actions/Upload";

const FormItem = Form.Item;
const Option = Select.Option;

const NewForm = Form.create()(props => {
  const {
    visible,
    onCancel,
    onCreate,
    form,
    accountData,
    appidData,
    typeData,
    accountChange,
    appChange,
    fileUpload,
    uploading
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      visible={visible}
      title="新建固件"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Spin spinning={uploading}>
        <Form layout="vertical">
          <FormItem label="用户名">
            {getFieldDecorator("user", { rules: [{ required: true, message: "用户名不能为空" }] })(
              <Select
                initialValue="查询用户"
                onChange={accountChange}
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
              >
                {_.map(accountData, ele => {
                  return (
                    <Option value={ele.uid} key={ele.uid + Math.random()}>
                      {ele.name}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem label="应用名">
            {getFieldDecorator("appId", { rules: [{ required: true, message: "应用名不能为空" }] })(
              <Select initialValue="选择应用" onChange={appChange}>
                {_.map(appidData, ele => {
                  return (
                    <Option value={ele.appId} key={ele.appId + Math.random()}>
                      {ele.appName}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem label="设备类型">
            {getFieldDecorator("type", {
              rules: [{ required: true, message: "设备类型不能为空" }]
            })(
              <Select initialValue="选择类型">
                {_.map(typeData, ele => {
                  return (
                    <Option value={ele} key={Math.random()}>
                      {ele}
                    </Option>
                  );
                })}
              </Select>
            )}
          </FormItem>
          <FormItem label="版本号">
            {getFieldDecorator("version", {
              rules: [{ required: true, message: "版本号不能为空" }]
            })(<Input />)}
          </FormItem>
          <FormItem label="下载地址">
            {getFieldDecorator("url", {
              rules: [{ required: true, message: "请上传文件" }]
            })(<Input disabled />)}
          </FormItem>
          <FormItem label="MD5">
            {getFieldDecorator("md5", { rules: [{ required: true, message: "请上传文件" }] })(
              <Input disabled />
            )}
          </FormItem>
          <FormItem label="文件大小">
            {getFieldDecorator("size", { rules: [{ required: true, message: "请上传文件" }] })(
              <Input disabled />
            )}
          </FormItem>
          <FormItem label="上传文件">
            {getFieldDecorator("file")(
              <Input
                className="deploy-searh-input-img"
                type="file"
                title="上传固件"
                onChange={fileUpload}
              />
            )}
          </FormItem>
        </Form>
      </Spin>
    </Modal>
  );
});

class FmManager extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "应用标识",
        dataIndex: "appId",
        render: (text, record) => this.renderColumns(text, record, "appId")
      },
      {
        title: "版本号",
        dataIndex: "version",
        render: (text, record) => this.renderColumns(text, record, "version")
      },
      {
        title: "状态",
        dataIndex: "online",
        render: (text, record) => this.renderColumns(text, record, "online")
      },
      {
        title: "应用包下载地址",
        dataIndex: "url",
        width: 330,
        render: (text, record) => this.renderColumns(text, record, "url")
      },
      {
        title: "文件MD5值",
        dataIndex: "md5",
        render: (text, record) => this.renderColumns(text, record, "md5")
      },
      {
        title: "文件大小",
        dataIndex: "size",
        render: (text, record) => this.renderColumns(text, record, "size")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          const { online } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {parseInt(online) ? (
                <span>
                  <Popconfirm
                    title="确定启用吗？"
                    onConfirm={() => this.forbidden(record.id, record.online)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a>
                      <span className="saveicon" />启用
                    </a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <Popconfirm
                    title="确定禁用吗？"
                    onConfirm={() => this.forbidden(record.id, record.online)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <a>
                      <span className="saveicon" />禁用
                    </a>
                  </Popconfirm>
                </span>
              )}
            </div>
          );
        }
      }
    ];
    this.fileSize = 209715200;
    this.state = {
      data: [], //
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false,
      uploading: false
    };
    this.readyUpload = true;
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.accountChange = this.accountChange.bind(this);
    this.appChange = this.appChange.bind(this);
    this.fileUpload = this.fileUpload.bind(this);
    this.nochange = this.nochange.bind(this);
    this.forbidden = this.forbidden.bind(this);
  }

  //编辑
  edit(key) {
    const newData = [...this.state.dataSource];
    //console.log(newData);
    const target = newData.filter(item => key === item.key)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({ data: newData }); //更新编辑视图
    }
  }
  //保存
  save(key) {
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      delete target.editable;
      this.setState({ data: newData });
      console.log(target); //此处与后台交互保存已修改数据
    }
  }
  //行内编辑动态更新对应字段的值
  handleChange(value, key, column) {
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      target[column] = value;
      this.setState({ data: newData });
    }
  }
  //判断是禁用还是启用
  forbidden(id, online) {
    if (online === "1") {
      let online1 = 0;
      console.log(online1);
      this.props.actions.forbidden(id, online1);
      this.props.actions.getFiManagement(1, "");
    } else if (online === "0") {
      let online1 = 1;
      this.props.actions.forbidden(id, online1);
      this.props.actions.getFiManagement(1, "");
    }
    this.props.actions.getFiManagement(1, "");
  }
  nochange() {}
  renderColumns(text, record, column) {
    if (column == "online") {
      return text == "0" ? "启用" : "禁用";
    }
    return text;
  }
  //删除操作
  onDelete(key) {
    const dataSource = [...this.state.dataSource];
    this.setState({ dataSource: dataSource.filter(item => item.key !== key) });
    this.state.count -= 1;
  }
  //显示模态框
  showModal() {
    this.form.resetFields();
    this.setState({ visible: true });
  }

  handleCancel() {
    const form = this.form;
    form.resetFields();
    this.props.actions.clearUploadFile();
    this.props.actions.clearAppId();
    this.props.actions.clearTypeData();
    this.setState({ visible: false });
  }
  //模态框提交事件
  handleCreate() {
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      let uid = localStorage.getItem("uidForEquip");
      values["uid"] = uid;
      form.resetFields();
      this.props.uploadStatus &&
        this.props.appidDataStatus &&
        this.props.typeDataStatus &&
        this.readyUpload &&
        this.props.actions.addNewFireware(values);
      this.setState({ visible: false });
      this.props.actions.clearAppId();
      this.props.actions.clearTypeData();
    });
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    this.props.actions.getFiManagement(pagination.current);
  }
  saveFormRef(form) {
    this.form = form;
  }
  accountChange(value) {
    //query appIds
    if (value !== undefined) {
      localStorage.setItem("uidForEquip", value);
      this.props.actions.getAppid(value);
    }
    this.form.setFieldsValue({
      appId: "",
      type: ""
    });
    this.props.actions.getAppid(value);
  }
  appChange(appId) {
    let uid = localStorage.getItem("uidForEquip");
    this.form.setFieldsValue({
      type: ""
    });
    this.props.actions.getDeviceType(uid, appId);
  }
  fileUpload(e) {
    let fileObj = e.target.files[0];
    if (fileObj) {
      let fileName = fileObj.name;
      let size = fileObj.size;
      let index = fileName.lastIndexOf(".");
      if (index > -1) {
        let extention = fileName.substr(index + 1);
        if (!["pkg", "zip"].includes(extention)) {
          message.error("只允许传pkg或zip文件");
          this.readyUpload = false;
          return;
        }
      }
      if (size > this.fileSize) {
        message.error("上传的文件不能大于200M");
        this.readyUpload = false;
        return;
      }
      this.readyUpload = true;
      let fd = new FormData();
      fd.append("file", fileObj);
      this.props.actions.uploadFile(fd);
      this.setState({
        uploading: true
      });
    }
  }
  componentDidMount() {
    this.props.actions.getFiManagement(1, "");
    this.props.actions.getAccount("1", "");
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.uploadStatus == 1) {
      this.form.setFieldsValue({
        md5: nextProps.uploadInfo.md5,
        url: nextProps.uploadInfo.url,
        size: nextProps.uploadInfo.size
      });
      this.setState({
        uploading: false
      });
    }
  }
  componentDidUpdate() {
    if (this.props.addStatus == 1) {
      message.success("添加成功");
      this.props.actions.getFiManagement(1, "");
    }
  }
  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Button onClick={this.showModal}>
            <Icon type="plus-circle-o" /> 新建固件
          </Button>
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
        <NewForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          accountData={this.props.accountData}
          appidData={this.props.appidData}
          typeData={this.props.typeData}
          accountChange={this.accountChange}
          appChange={this.appChange}
          fileUpload={this.fileUpload}
          uploadInfo={this.props.uploadInfo}
          uploading={this.state.uploading}
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    resData: state.fiManagemet.get("resData"),
    accountData: state.account.get("accountData") || [],
    pageConfig: state.fiManagemet.get("pageConfig"),
    appidData: state.upGrade.get("appidData") || [],
    typeData: state.upGrade.get("typeData") || [],
    uploadInfo: state.upload.get("uploadResInfo"),
    uploadStatus: state.upload.get("uploadStatus"),
    addStatus: state.fiManagemet.get("addStatus"),
    appidDataStatus: state.upGrade.get("appidDataStatus"),
    typeDataStatus: state.upGrade.get("typeDataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(Object.assign({}, updateAction, uploadAction, action), dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(FmManager);
