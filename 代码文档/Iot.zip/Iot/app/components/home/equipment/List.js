import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table } from "antd";
import * as action from "../../../actions/List";
import "antd/dist/antd.css";

class Test extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {}
    };
    this.columns = [
      {
        title: "ID",
        dataIndex: "ida.id",
        render: (text, record) => this.renderColumns(text, record, "ida.id")
      },
      {
        title: "设备ID",
        dataIndex: "ida.device_id",
        render: (text, record) => this.renderColumns(text, record, "ida.device_id")
      },
      {
        title: "设备类型",
        dataIndex: "ida.device_mode",
        render: (text, record) => this.renderColumns(text, record, "ida.device_mode")
      },
      {
        title: "应用名",
        dataIndex: "iai.appname",
        render: (text, record) => this.renderColumns(text, record, "iai.appname")
      },
      {
        title: "包名",
        dataIndex: "iai.pkgname",
        render: (text, record) => this.renderColumns(text, record, "iai.pkgname")
      },
      {
        title: "签名",
        dataIndex: "iai.signname",
        render: (text, record) => this.renderColumns(text, record, "iai.signname")
      },
      // {
      //   title: "描述",
      //   dataIndex: "iai.description",
      //   render: (text, record) => this.renderColumns(text, record, "iai.description")
      // },
      {
        title: "当前版本号",
        dataIndex: "ida.version",
        render: (text, record) => this.renderColumns(text, record, "ida.version")
      },
      {
        title: "创建时间",
        dataIndex: "ida.createdate",
        render: (text, record) => this.renderColumns(text, record, "ida.createdate")
      },
      {
        title: "更新时间",
        dataIndex: "ida.updatedate",
        render: (text, record) => this.renderColumns(text, record, "ida.updatedate")
      },
      {
        title: "是否绑定",
        dataIndex: "operation",
        render: (text, record) => {
          // const { data } = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {record["idi.uid"] ? <span>已绑定</span> : <span>未绑定</span>}
            </div>
          );
        }
      }
    ];
    this.search = this.search.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
  }

  renderColumns(text, record, column) {
    return text;
  }
  search() {
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (!deviceId) {
      this.setState({
        searchItem: {}
      });
      this.props.actions.getInfo(1, "");
    } else {
      var condition = {
        name: "ida.device_id",
        sopt: "cn",
        value: deviceId
      };
      this.setState({
        searchItem: condition
      });
      this.props.actions.getInfo(1, condition);
    }
  }
  componentDidMount() {
    this.props.actions.getInfo(1, "");
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (this.state.searchItem.value) {
      var condition = {
        name: "ida.device_id",
        sopt: "cn",
        value: deviceId
      };
      this.props.actions.getInfo(pagination.current, condition);
    } else {
      this.props.actions.getInfo(pagination.current, "");
    }
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.search();
    }
  }
  render() {
    if (this.props.resData && this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div className="outer_container">
        <div className="searchbar">
          <div>
            <label htmlFor="name" className="lable namelable">
              设备ID
            </label>
            <input
              type="text"
              ref="deviceId"
              onKeyDown={this.onKeyDown}
              className="table-input nameinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" onClick={this.search}>
                搜索
              </span>
            </a>
          </div>
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.equList.get("resData"),
    pageConfig: state.equList.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Test);
