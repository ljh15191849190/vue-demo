import "whatwg-fetch";
import history from "../routes/history";
import URL from "./urlConfig";
import {message} from "antd";
import * as StatusCode from "../constants/StatusCode";
import {getDictionaryItem} from "../sagas/DictionaryItem";

let fetchApi = function(postData, url, resolve, obj) {
  let options = {
    method: "POST",
    credentials: "include",
    body: JSON.stringify(postData)
  };
  fetch(url, options)
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login");
        message.info("请登录！");
      } else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        history.push("/devops/login");
        message.info("数据不存在");
      } else {
        resolve({res: data, param: obj});
      }
    });
};

class ServiceApi {
  static login(payload) {
    console.log("serviceApi -> login");
    return new Promise(resolve => {
      // let url =
      //   URL.login + "?username=" + payload.name + "&pwd=" + payload.pass + "&equipmenttype=pc";
      // let postdata = {};
      // fetchApi(postdata, url, resolve);
      resolve({
        name: "sss"
      });
    });
  }

  static getEquInfo(payload) {
    console.log("serviceApi -> getEquInfo");
    return new Promise(resolve => {
      let url = URL.getEquInfo + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {};
      if (payload.condition) {
        reqParam["conditions"] = [payload.condition];
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  static getOperHistory(payload) {
    console.log("serviceApi -> getOperHistory");
    return new Promise(resolve => {
      let url = URL.getOperHistory + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  static getDictionaryItem(payload) {
    console.log("serviceApi -> getDictionaryItem");
    return new Promise(resolve => {
      let url = URL.getDictionaryItem + "?page=" + payload.currentPage + "&size=10";
      let reqParam = {
        page: payload.currentPage,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  static getDictionaryItemByName(payload) {
    console.log("serviceApi -> getDictionaryItemByName");
    return new Promise(resolve => {
      let url =
        URL.getDictionaryItemByName +
        "?page=" +
        payload.currentPage +
        "&size=10" +
        "&dictName=" +
        payload.dictName;
      let reqParam = {
        page: payload.currentPage,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }
}
export default ServiceApi;
