export default {
  login: "/user/login",
  logout: "/user/logout",
  getEquInfo: "/webdeviceinfo/deviceInfo/findAllDeviceInfo",
  getOperHistory: "/webupgradehistory/upgradeHistory/all",
  getDictionaryItem: "/dictionary/type/list",
  getDictionaryItemByName: "/dictionary/type/find"
};
