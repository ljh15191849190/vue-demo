import React from "react";
import {Layout, Menu, Breadcrumb, Icon} from "antd";
const {Content, Footer, Sider} = Layout;
const SubMenu = Menu.SubMenu;
import PersonManage from "./personManage/Index";

class LayoutComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
      key: 1
    };
    this.set = ["机构管理", "人员管理", "角色管理"];
    this.onCollapse = this.onCollapse.bind(this);
    this.getData = this.getData.bind(this);
  }
  onCollapse(collapsed) {
    console.log(collapsed);
    this.setState({collapsed});
  }
  getData(item) {
    this.setState({key: item.key});
    console.log(this.state.key);
  }
  render() {
    return (
      <div className="right-body-container" style={{minHeight: "100vh"}}>
        <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
          <Menu
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            onClick={this.getData}
            mode="inline"
            theme="dark"
            inlineCollapsed={this.state.collapsed}
          >
            <SubMenu
              key="sub1"
              title={
                <span>
                  <Icon type="user" />
                  <span>系统管理</span>
                </span>
              }
            >
              <Menu.Item key="1">
                <Icon type="inbox" />
                <span>机构管理</span>
              </Menu.Item>
              <Menu.Item key="2">
                <Icon type="inbox" />
                <span>人员管理</span>
              </Menu.Item>
              <Menu.Item key="3">
                <Icon type="inbox" />
                <span>角色管理</span>
              </Menu.Item>
            </SubMenu>
          </Menu>
        </Sider>
        <div className="right-div-body">
          <Content style={{margin: "0 16px"}}>
            <Breadcrumb style={{margin: "16px 0"}}>
              <Breadcrumb.Item>系统管理</Breadcrumb.Item>
              <Breadcrumb.Item>{this.set[this.state.key - 1]}</Breadcrumb.Item>
            </Breadcrumb>
            <div style={{padding: 20, background: "#fff", minHeight: 360}}>
              {this.state.key == 1 ? <PersonManage /> : ""}
            </div>
          </Content>
          <Footer style={{textAlign: "center"}} />
        </div>
      </div>
    );
  }
}

export default LayoutComponent;
