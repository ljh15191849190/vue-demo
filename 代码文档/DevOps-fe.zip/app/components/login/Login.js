import React from "react";
import ReactDOM from "react-dom";
import {Button, FormControl, FormGroup, InputGroup} from "react-bootstrap";
import intl from "react-intl-universal";
import history from "../../routes/history";
import "whatwg-fetch";
import _ from "lodash";
import "./login.css";
import {Select, message} from "antd";
import md5 from "md5";

const Option = Select.Option;

const SUPPOER_LOCALES = [
  {
    name: "English",
    value: "en-US"
  },
  {
    name: "简体中文",
    value: "zh-CN"
  }
];
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      pass: "",
      errMsg: "",
      initDone: false,
      defalutLanguage: "zh-CN"
    };
    this.login = this.login.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.Login == 1) {
      history.push("/devops/dashboard");
    } else if (nextProps.Login == 0) {
      message.info("登录失败！");
    }
  }
  shouldComponentUpdate(nextProps, nextState) {
    console.log(nextProps + ",," + nextState);
    return true;
  }
  componentDidMount() {
    this.loadLocales();
  }
  componentDidUpdate() {
    // console.log(this.props.Login.get("loginStatus"));
    // if (this.props.Login.get("loginStatus")) {
    //     this.props.history.push('/home');
    // }else {
    //     localStorage.clear();
    //     this.props.history.push('/login');
    // }
  }

  loadLocales() {
    let currentLocale = "en-US";
    if (sessionStorage.getItem("lang")) {
      currentLocale = sessionStorage.getItem("lang");
    } else {
      let currentLocale = intl.determineLocale({
        urlLocaleKey: "lang",
        cookieLocaleKey: "lang"
      });
      if (!_.find(SUPPOER_LOCALES, {value: currentLocale})) {
        currentLocale = "en-US";
      }
      this.setState({
        defalutLanguage: currentLocale
      });
    }
    fetch(`/locales/${currentLocale}.json`)
      .then(res => {
        return res.json();
      })
      .then(data => {
        console.log(data);
        intl.init({
          currentLocale,
          locales: {
            [currentLocale]: data
          }
        });
        // After loading CLDR locale data, start to render
        this.setState({initDone: true});
      });
  }
  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.login();
    }
  }
  login() {
    var userName = ReactDOM.findDOMNode(this.refs.userName).value;
    // var password = md5(ReactDOM.findDOMNode(this.refs.password).value);
    var password = ReactDOM.findDOMNode(this.refs.password).value;
    if (userName && password) {
      localStorage.setItem("loggedIn", true);
      this.props.actions.login(userName, password);
    } else if (userName == "" || password == "") {
      this.setState({
        errMsg: intl.get("login.passNotEmpty")
      });
    } else {
      this.setState({
        errMsg: intl.get("login.passError")
      });
    }
  }
  handleChange(value) {
    sessionStorage.setItem("lang", value);
    this.setState({
      defalutLanguage: value
    });
    location.search = `?lang=${value}`;
  }
  render() {
    return (
      <div className="login">
        <span className="login__logo" />
        <div className="login__inner">
          <div className="login__inner_slogan" />
          <div className="s_l">
            <Select
              defaultValue={sessionStorage.getItem("lang")}
              style={{width: 120}}
              onChange={this.handleChange}
            >
              <Option value="zh-CN">中文</Option>
              <Option value="en-US">English</Option>
            </Select>
          </div>
          <div className="login__inner__right">
            {this.state.errMsg ? <span className="error-msg">{this.state.errMsg}</span> : null}
            <form>
              <span className="login__inner_user">{intl.get("login.userLogon")}</span>
              <FormGroup style={{width: "91%"}}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="user-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{width: "91%"}}
                    className="user-input"
                    ref="userName"
                    type="text"
                    onKeyDown={this.onKeyDown}
                    placeholder={intl.get("login.inputUser")}
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup style={{width: "91%"}}>
                <InputGroup>
                  <InputGroup.Addon>
                    <span className="pass-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{width: "91%"}}
                    type="password"
                    ref="password"
                    placeholder={intl.get("login.inputPass")}
                    onKeyDown={this.onKeyDown}
                  />
                </InputGroup>
              </FormGroup>

              <div className="login-inner__btn">
                <Button style={{width: "91%"}} bsStyle="primary" type="button" onClick={this.login}>
                  {intl.get("login.loginBtn")}
                </Button>
              </div>
            </form>
          </div>
        </div>
        {/* <div>
          <span className="login-footer">西安华信智慧数字科技有限公司</span>
        </div> */}
      </div>
    );
  }
}
Login.propTypes = {};

export default Login;
