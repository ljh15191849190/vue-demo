import React from "react";
import PropTypes from "prop-types";
import _ from "lodash";
import {Checkbox} from "antd";

class Card extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let style = {
      marginRight: "20"
    };
    let cardContainer = {
      display: "inline-block"
    };
    let redStyle = {
      color: "red"
    };
    let greenStyle = {
      color: "green"
    };
    return (
      <div style={this.props.style}>
        <span className="" />
        <div style={cardContainer}>
          <span>组件数量（个)</span>
          <span>420</span>
          <span>
            <span />
            <span />
          </span>
        </div>
      </div>
    );
  }
}
Card.propTypes = {
  title: PropTypes.string || "未定义",
  style: PropTypes.object
};
Card.defaultProps = {
  title: "",
  style: {}
};
export default Card;
