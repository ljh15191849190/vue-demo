import React from "react";
import {NavLink, Redirect} from "react-router-dom";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import history from "../../routes/history";
import * as actions from "../../actions/index";
import intl from "react-intl-universal";
import {Menu, Dropdown, Icon} from "antd";
import "../../assets/css/header.css";
import logo from "../../assets/images/dashboard/logo.png";

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.menu = (
      <Menu>
        <Menu.Item>
          <NavLink to="/devops/dashboard" exact>
            proj1
          </NavLink>
        </Menu.Item>
        <Menu.Item>
          <NavLink to="/devops/equipment" exact>
            proj2
          </NavLink>
        </Menu.Item>
      </Menu>
    );
    this.onLogout = this.onLogout.bind(this);
    this.config = this.config.bind(this);
  }

  onLogout() {
    localStorage.clear();
    this.props.actions.logout();
  }
  config() {
    history.push("/devops/admin");
  }
  render() {
    let style = {
      position: "absolute",
      right: "8%"
    };
    return (
      <div className="header-top">
        <div className="header-logo">
          {/* <img src={logo} alt="logo" /> */}
          <span>西安华信DevOps平台</span>
        </div>
        <div className="navul">
          <Dropdown overlay={this.menu}>
            <a className="ant-dropdown-link" href="#">
              {intl.get("main.topBar.project")}
              <Icon type="down" />
            </a>
          </Dropdown>
          <span style={style}>
            <button onClick={this.config}>admin</button>
          </span>
        </div>

        <div className="dropmeau">
          <ol>
            <li>
              <span className="dropli">
                <span className="header-manager" />管理员<span className="oper-icon" />
              </span>
              <ul className="meaulist">
                <li>用户信息</li>
                <li>我的收藏</li>
                <li>设置</li>
                <li onClick={this.onLogout}>退出</li>
              </ul>
            </li>
          </ol>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Logout: state.login
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(actions, dispatch)
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Header);
