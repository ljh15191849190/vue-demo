import React from "react";
import {Table, Popconfirm, Modal, Input, Form, Upload, Button, Icon, Select} from "antd";
import "antd/dist/antd.css";
const FormItem = Form.Item;
const Option = Select.Option;
const CollectionCreateForm = Form.create()(props => {
  const {visible, onCancel, onCreate, form} = props;
  const {getFieldDecorator} = form;
  return (
    <Modal
      visible={visible}
      title="新建设备"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="类型">
          <Select defaultValue="lucy">
            <Option value="lucy">Lucy</Option>
          </Select>
        </FormItem>
        <FormItem label="应用包名称">
          <Input />
        </FormItem>
        <FormItem label="版本号">
          <Input />
        </FormItem>
        <FormItem label="上传文件">
          <Upload {...props}>
            <Button>
              <Icon type="upload" /> Upload
            </Button>
          </Upload>
        </FormItem>
      </Form>
    </Modal>
  );
});

const EditableCell = ({editable, value, onChange}) => (
  <div>
    {editable ? (
      <Input style={{margin: "-5px 0"}} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);
const props = {
  name: "file",
  action: "//jsonplaceholder.typicode.com/posts/",
  headers: {
    authorization: "authorization-text"
  },
  onChange(info) {
    if (info.file.status !== "uploading") {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === "done") {
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === "error") {
      message.error(`${info.file.name} file upload failed.`);
    }
  }
};
class Test extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "ID",
        render: (text, record) => this.renderColumns(text, record, "ID")
      },
      {
        title: "设备类型",
        dataIndex: "SBLX",
        render: (text, record) => this.renderColumns(text, record, "SBLX")
      },
      {
        title: "应用包名称",
        dataIndex: "YYBMC",
        render: (text, record) => this.renderColumns(text, record, "YYBMC")
      },
      {
        title: "版本号",
        dataIndex: "VERSIONNUM",
        render: (text, record) => this.renderColumns(text, record, "VERSIONNUM")
      },
      {
        title: "应用包下载地址",
        dataIndex: "YYBDOWNLOADURL",
        render: (text, record) => this.renderColumns(text, record, "YYBDOWNLOADURL")
      },
      {
        title: "文件MD5值",
        dataIndex: "MD5",
        render: (text, record) => this.renderColumns(text, record, "MD5")
      },
      {
        title: "文件大小",
        dataIndex: "SIZE",
        render: (text, record) => this.renderColumns(text, record, "SIZE")
      },
      {
        title: "创建时间",
        dataIndex: "CREATEDATE",
        render: (text, record) => this.renderColumns(text, record, "CREATEDATE")
      },
      {
        title: "更新时间",
        dataIndex: "UPDATEDATE",
        render: (text, record) => this.renderColumns(text, record, "UPDATEDATE")
      },
      {
        title: "数据类型",
        dataIndex: "DATATYPE",
        render: (text, record) => this.renderColumns(text, record, "DATATYPE")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          const {editable} = record; //当前行数据
          return (
            <div className="editable-row-operations">
              {
                <span>
                  <a onClick={() => this.save(record.key)}>
                    <span className="saveicon" />下载
                  </a>
                </span>
              }
            </div>
          );
        }
      }
    ];
    this.state = {
      data: [], //
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false
    };
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
  }

  edit(key) {
    const newData = [...this.state.dataSource];
    //console.log(newData);
    const target = newData.filter(item => key === item.key)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({data: newData}); //更新编辑视图
    }
  } //编辑

  save(key) {
    alert("DOWNLOAD");
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      delete target.editable;
      this.setState({data: newData});
      console.log(target); //此处与后台交互保存已修改数据
    }
  } //保存

  handleChange(value, key, column) {
    //console.log(column);
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      target[column] = value;
      this.setState({data: newData});
    }
  } //行内编辑动态更新对应字段的值

  renderColumns(text, record, column) {
    return (
      <EditableCell
        editable={record.editable}
        value={text}
        onChange={value => this.handleChange(value, record.key, column)}
      />
    );
  }
  //删除操作
  onDelete(key) {
    const dataSource = [...this.state.dataSource];
    this.setState({dataSource: dataSource.filter(item => item.key !== key)});
    this.state.count -= 1;
    console.log("删除第" + key + "项数据值");
  }

  showModal() {
    this.setState({visible: true}); //显示模态框
  }

  handleCancel() {
    this.setState({visible: false});
  }
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      console.log("Received values of form: ", values);
      values.key = Date.parse(new Date()); //前端试用后期不需要唯一key
      this.state.dataSource.push(values);
      this.setState({dataSource: this.state.dataSource, visible: false});
      form.resetFields();
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  componentDidMount() {
    console.log(this.state.dataSource);
  }
  render() {
    return (
      <div>
        <div className="searchbar">
          {/* <Upload {...props}> */}
          <Button onClick={this.showModal}>
            <Icon type="upload" /> 上传
          </Button>
          {/* </Upload> */}
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.state.dataSource} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handleTableChange}
        />
        <CollectionCreateForm
          ref={this.saveFormRef}
          visible={this.state.visible}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
        />
      </div>
    );
  }
}

export default Test;
