import React from "react";
import {Layout, Menu, Breadcrumb, Icon} from "antd";
const {Content, Footer, Sider} = Layout;
const SubMenu = Menu.SubMenu;

import List from "./List";
import Upgrade from "./Upgrade";
import OperationHistroy from "./OperationHistroy";
import FirmwareManagement from "./FirmwareManagement";
import EquipmentControl from "./EquipmentControl";
import "./styles/equipment.css";
import "./styles/public.css";
import DictionaryItem from "./DictionaryItem";
import Build from "./build/Build";

class LayoutComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
      key: 1
    };
    this.set = [
      "概览",
      "需求管理",
      "定义组件",
      "关联代码",
      "迭代管理",
      "测试管理",
      "构建管理",
      "部署管控",
      "流水线",
      "介质仓库",
      "效率报表",
      "质量报表",
      "项目监控",
      "组件运维",
      "环境",
      "资源",
      "团队",
      "自定义",
      "通知",
      "版本",
      "模块",
      "里程碑"
    ];
    this.onCollapse = this.onCollapse.bind(this);
    this.getData = this.getData.bind(this);
  }
  onCollapse(collapsed) {
    console.log(collapsed);
    this.setState({collapsed});
  }
  getData(item) {
    this.setState({key: item.key});
    console.log(this.state.key);
  }
  render() {
    return (
      <div className="right-body-container" style={{minHeight: "100vh"}}>
        <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
          <Menu
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            onClick={this.getData}
            mode="inline"
            theme="dark"
            inlineCollapsed={this.state.collapsed}
          >
            <Menu.Item key="1">
              <Icon type="dashboard" />
              <span>概览</span>
            </Menu.Item>
            <SubMenu
              key="sub2"
              title={
                <span>
                  <Icon type="appstore" />
                  <span>项目管理</span>
                </span>
              }
            >
              <Menu.Item key="2">
                <Icon type="layout" />
                <span>需求管理</span>
              </Menu.Item>
              <Menu.Item key="3">
                <Icon type="api" />
                <span>定义组件</span>
              </Menu.Item>
              <Menu.Item key="4">
                <Icon type="code" />
                <span>关联代码</span>
              </Menu.Item>
              <Menu.Item key="5">
                <Icon type="rocket" />
                <span>迭代管理</span>
              </Menu.Item>
              <Menu.Item key="6">
                <Icon type="database" />
                <span>测试管理</span>
              </Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub3"
              title={
                <span>
                  <Icon type="global" />
                  <span>构建&部署</span>
                </span>
              }
            >
              <Menu.Item key="7">
                <Icon type="profile" />
                <span>构建管理</span>
              </Menu.Item>
              <Menu.Item key="8">
                <Icon type="customer-service" />
                <span>部署管理</span>
              </Menu.Item>
              <Menu.Item key="9">
                <Icon type="trademark" />
                <span>流水线</span>
              </Menu.Item>
              <Menu.Item key="10">
                <Icon type="shopping-cart" />
                <span>介质仓库</span>
              </Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub4"
              title={
                <span>
                  <Icon type="contacts" />
                  <span>持续反馈</span>
                </span>
              }
            >
              <Menu.Item key="11">
                <Icon type="area-chart" />
                <span>效率报表</span>
              </Menu.Item>
              <Menu.Item key="12">
                <Icon type="bar-chart" />
                <span>质量报表</span>
              </Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub5"
              title={
                <span>
                  <Icon type="desktop" />
                  <span>运维监控</span>
                </span>
              }
            >
              <Menu.Item key="13">
                <Icon type="picture" />
                <span>项目监控</span>
              </Menu.Item>
              <Menu.Item key="14">
                <Icon type="camera" />
                <span>组件运维</span>
              </Menu.Item>
            </SubMenu>
            <SubMenu
              key="sub6"
              title={
                <span>
                  <Icon type="setting" />
                  <span>设置</span>
                </span>
              }
            >
              <Menu.Item key="15">
                <Icon type="environment" />
                <span>环境</span>
              </Menu.Item>
              <Menu.Item key="16">
                <Icon type="inbox" />
                <span>资源</span>
              </Menu.Item>
              <Menu.Item key="17">
                <Icon type="team" />
                <span>团队</span>
              </Menu.Item>
              <Menu.Item key="18">
                <Icon type="idcard" />
                <span>自定义</span>
              </Menu.Item>
              <Menu.Item key="19">
                <Icon type="notification" />
                <span>通知</span>
              </Menu.Item>
              <Menu.Item key="20">
                <Icon type="layout" />
                <span>版本</span>
              </Menu.Item>
              <Menu.Item key="21">
                <Icon type="api" />
                <span>模块</span>
              </Menu.Item>
              <Menu.Item key="22">
                <Icon type="fork" />
                <span>里程碑</span>
              </Menu.Item>
              <Menu.Item key="23">
                <Icon type="inbox" />
                <span>数据字典</span>
              </Menu.Item>
            </SubMenu>
          </Menu>
        </Sider>
        <div className="right-div-body">
          <Content style={{margin: "0 16px"}}>
            <Breadcrumb style={{margin: "16px 0"}}>
              <Breadcrumb.Item>项目管理</Breadcrumb.Item>
              <Breadcrumb.Item>{this.set[this.state.key - 1]}</Breadcrumb.Item>
            </Breadcrumb>
            <div style={{padding: 20, background: "#fff", minHeight: 360}}>
              {this.state.key == 1 ? (
                <List />
              ) : this.state.key == 2 ? (
                <Upgrade />
              ) : this.state.key == 3 ? (
                <OperationHistroy />
              ) : this.state.key == 4 ? (
                <FirmwareManagement />
              ) : this.state.key == 5 ? (
                <EquipmentControl />
              ) : this.state.key == 23 ? (
                <DictionaryItem />
              ) : this.state.key == 7 ? (
                <Build />
              ) : (
                ""
              )}
            </div>
          </Content>
          <Footer style={{textAlign: "center"}} />
        </div>
      </div>
    );
  }
}

export default LayoutComponent;
