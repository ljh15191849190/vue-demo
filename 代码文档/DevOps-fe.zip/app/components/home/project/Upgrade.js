import React from "react";
import {Button, Input, Select, Card} from "antd";
import "antd/dist/antd.css";
const Option = Select.Option;

const EditableCell = ({editable, value, onChange}) => (
  <div>
    {editable ? (
      <Input style={{margin: "-5px 0"}} value={value} onChange={e => onChange(e.target.value)} />
    ) : (
      value
    )}
  </div>
);
class Test extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "ID",
        render: (text, record) => this.renderColumns(text, record, "ID")
      },
      {
        title: "设备ID",
        dataIndex: "ApeID",
        render: (text, record) => this.renderColumns(text, record, "ApeID")
      },
      {
        title: "设备类型",
        dataIndex: "SBLX",
        render: (text, record) => this.renderColumns(text, record, "SBLX")
      },
      {
        title: "当前版本号",
        dataIndex: "VERSION",
        render: (text, record) => this.renderColumns(text, record, "VERSION")
      },
      {
        title: "创建时间",
        dataIndex: "CREATEDATE",
        render: (text, record) => this.renderColumns(text, record, "CREATEDATE")
      },
      {
        title: "更新时间",
        dataIndex: "UPDATEDATE",
        render: (text, record) => this.renderColumns(text, record, "UPDATEDATE")
      },
      {
        title: "数据状态",
        dataIndex: "DATASTATUS",
        render: (text, record) => this.renderColumns(text, record, "DATASTATUS")
      }
    ];
    this.state = {
      data: [], //
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false
    };
    this.cacheData = {};
    this.onDelete = this.onDelete.bind(this);
    this.showModal = this.showModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.saveFormRef = this.saveFormRef.bind(this);
  }

  edit(key) {
    const newData = [...this.state.dataSource];
    //console.log(newData);
    const target = newData.filter(item => key === item.key)[0]; //将当前行数据过滤出来
    if (target) {
      target.editable = true;
      this.setState({data: newData}); //更新编辑视图
    }
  } //编辑

  save(key) {
    const newData = [...this.state.dataSource];
    const target = newData.filter(item => key === item.key)[0];
    if (target) {
      delete target.editable;
      this.setState({data: newData});
      console.log(target); //此处与后台交互保存已修改数据
    }
  } //保存

  renderColumns(text, record, column) {
    return (
      <EditableCell
        editable={record.editable}
        value={text}
        onChange={value => this.handleChange(value, record.key, column)}
      />
    );
  }
  //删除操作
  onDelete(key) {
    const dataSource = [...this.state.dataSource];
    this.setState({dataSource: dataSource.filter(item => item.key !== key)});
    this.state.count -= 1;
    console.log("删除第" + key + "项数据值");
  }

  showModal() {
    this.setState({visible: true}); //显示模态框
  }

  handleCancel() {
    this.setState({visible: false});
  }
  handleCreate() {
    //模态框提交事件
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      console.log("Received values of form: ", values);
      values.key = Date.parse(new Date()); //前端试用后期不需要唯一key
      this.state.dataSource.push(values);
      this.setState({dataSource: this.state.dataSource, visible: false});
      form.resetFields();
    });
  }
  saveFormRef(form) {
    this.form = form;
  }
  componentDidMount() {
    console.log(this.state.dataSource);
  }
  handleChange() {}
  render() {
    return (
      <div className="card">
        <Card title="类型升级" style={{width: 280}}>
          <div>
            <label style={{width: 100}}>类型：</label>
            <Select defaultValue="type" style={{width: 120}}>
              <Option value="type">类型</Option>
            </Select>
          </div>
          <div style={{marginTop: 20}}>
            <label style={{width: 100}}>新版本号：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">新版本号</Option>
            </Select>
          </div>
          <div style={{marginTop: 20, textAlign: "center"}}>
            <Button>升级</Button>
          </div>
        </Card>

        <Card title="版本号升级" style={{width: 280}}>
          <div>
            <label style={{width: 100}}>当前版本号：</label>
            <Select defaultValue="type" style={{width: 120}}>
              <Option value="type">当前版本号：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20}}>
            <label style={{width: 100}}>目标版本号：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">目标版本号：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20, textAlign: "center"}}>
            <Button>升级</Button>
          </div>
        </Card>

        <Card title="具体设备升级" style={{width: 280}}>
          <div>
            <label style={{width: 100}}>输入设备ID：</label>
            <Input style={{width: 118}} placeholder="输入设备ID：" />
          </div>
          <div style={{marginTop: 20}}>
            <label style={{width: 100}}>目标版本号：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">目标版本号：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20, textAlign: "center"}}>
            <Button>升级</Button>
          </div>
        </Card>

        <Card title="设备类型和版本号升级" style={{width: 280}}>
          <div>
            <label style={{width: 100}}>类型：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">类型：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20}}>
            <label style={{width: 100}}>当前版本：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">当前版本：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20}}>
            <label style={{width: 100}}>目标版本：</label>
            <Select defaultValue="version" style={{width: 120}}>
              <Option value="version">目标版本：</Option>
            </Select>
          </div>
          <div style={{marginTop: 20, textAlign: "center"}}>
            <Button>升级</Button>
          </div>
        </Card>
      </div>
    );
  }
}

export default Test;
