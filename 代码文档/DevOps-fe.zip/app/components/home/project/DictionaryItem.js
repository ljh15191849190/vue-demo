import React from "react";
import ReactDOM from "react-dom";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {Button, Input, Select, Card, Table, message} from "antd";
import "antd/dist/antd.css";
import * as actions from "../../../actions/DictionaryItem";
import intl from "react-intl-universal";

const Option = Select.Option;

class DictionaryItem extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "字典Id",
        dataIndex: "dictId",
        render: (text, record) => this.renderColumns(text, record, "dictId")
      },
      {
        title: "字典名称",
        dataIndex: "dictName",
        render: (text, record) => this.renderColumns(text, record, "dictName")
      },
      {
        title: "字典编码",
        dataIndex: "dictCode",
        render: (text, record) => this.renderColumns(text, record, "dictCode")
      },
      {
        title: "数据状态",
        dataIndex: "dictStatus",
        render: (text, record) => this.renderColumns(text, record, "dictStatus")
      }
    ];
    this.state = {
      data: [], //
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false,
      //modal弹窗
      visible: false,
      confirmLoading: false
    };
    this.cacheData = {};
    this.showModal = this.showModal.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.search = this.search.bind(this);
  }
  renderColumns(text, record, column) {
    return text;
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({
      loading: true
    });
    this.props.actions.getDictionaryItem(pagination.current);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  componentDidMount() {
    this.props.actions.getDictionaryItem(1);
  }

  showModal() {
    this.setState({
      visible: true
    }); //显示模态框
  }

  search() {
    let dictName = ReactDOM.findDOMNode(this.refs.dictName).value;
    if (!dictName) {
      this.props.actions.getDictionaryItemByNames(1, "");
    } else {
      this.props.actions.getDictionaryItemByNames(1, dictName);
    }
  }

  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <form action="#">
            <label htmlFor="name" className="lable namelable">
              字典名称
            </label>
            <input
              type="text"
              ref="dictName"
              className="table-input nameinput"
            />
            <a href="#" className="abutton">
              <span className="searchicon" onClick={this.search}>
                搜索
              </span>
            </a>
          </form>
        </div>
        <Table
          style={{
            marginTop: 20
          }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.DictionaryItem.get("resData"),
    pageConfig: state.DictionaryItem.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(actions, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DictionaryItem);
