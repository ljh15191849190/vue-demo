import React from "react";
import ReactDOM from "react-dom";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {Table} from "antd";
import * as action from "../../../actions/List";
import "antd/dist/antd.css";

class Test extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {}
    };
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "当前版本号",
        dataIndex: "version",
        render: (text, record) => this.renderColumns(text, record, "version")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "数据状态",
        dataIndex: "state",
        render: (text, record) => this.renderColumns(text, record, "state")
      }
    ];
    this.search = this.search.bind(this);
  }

  renderColumns(text, record, column) {
    if (column == "state") {
      let s = column.toUpperCase();
      return s == "n" ? "可用" : "不可用";
    } else {
      return text;
    }
  }
  search() {
    let deviceId = ReactDOM.findDOMNode(this.refs.deviceId).value;
    if (!deviceId) {
      this.props.actions.getInfo(1, "");
    } else {
      var condition = {
        name: "deviceId",
        sopt: "eq",
        value: deviceId
      };
      this.setState({
        searchItem: condition
      });
      this.props.actions.getInfo(1, condition);
    }
  }
  componentDidMount() {
    this.props.actions.getInfo(1, "");
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({loading: true});
    if (this.state.searchItem.name) {
      this.props.actions.getInfo(pagination.current, this.state.searchItem);
    } else {
      this.props.actions.getInfo(pagination.current, "");
    }
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <form action="#">
            <label htmlFor="name" className="lable namelable">
              设备ID
            </label>
            <input type="text" ref="deviceId" className="table-input nameinput" />
            {/* <label htmlFor="age" className="lable agelable">
              位置
            </label>
            <input type="text" name="age" id="age" className="table-input ageinput" />
            <label htmlFor="age" className="lable agelable">
              设备序列号
            </label>
            <input type="text" name="age" id="age" className="table-input ageinput" />
            <label htmlFor="age" className="lable agelable">
              设备型号
            </label>
            <input type="text" name="age" id="age" className="table-input ageinput" /> */}
            <a href="#" className="abutton">
              <span className="searchicon" onClick={this.search}>
                搜索
              </span>
            </a>
          </form>
        </div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData}
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.equList.get("resData"),
    pageConfig: state.equList.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {actions: bindActionCreators(action, dispatch)};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Test);
