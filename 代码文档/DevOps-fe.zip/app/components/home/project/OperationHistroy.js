import React from "react";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {Table} from "antd";
import * as action from "../../../actions/OperHistory";
import "antd/dist/antd.css";

class OperHistory extends React.Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "ID",
        dataIndex: "id",
        render: (text, record) => this.renderColumns(text, record, "id")
      },
      {
        title: "设备ID",
        dataIndex: "deviceId",
        render: (text, record) => this.renderColumns(text, record, "deviceId")
      },
      {
        title: "设备类型",
        dataIndex: "deviceMode",
        render: (text, record) => this.renderColumns(text, record, "deviceMode")
      },
      {
        title: "上个版本",
        dataIndex: "sourceVersion",
        render: (text, record) => this.renderColumns(text, record, "sourceVersion")
      },
      {
        title: "当前版本",
        dataIndex: "targetVersion",
        render: (text, record) => this.renderColumns(text, record, "targetVersion")
      },
      {
        title: "升级任务ID",
        dataIndex: "upgradeId",
        render: (text, record) => this.renderColumns(text, record, "upgradeId")
      },
      {
        title: "创建时间",
        dataIndex: "createdate",
        render: (text, record) => this.renderColumns(text, record, "createdate")
      },
      {
        title: "更新时间",
        dataIndex: "updatedate",
        render: (text, record) => this.renderColumns(text, record, "updatedate")
      },
      {
        title: "状态",
        dataIndex: "state",
        render: (text, record) => this.renderColumns(text, record, "state")
      }
    ];
    this.state = {
      dataSource: [],
      count: 5,
      pagination: {},
      loading: false
    };
    this.handlePageChange = this.handlePageChange.bind(this);
  }

  renderColumns(text, record, column) {
    if (column == "state") {
      let s = column.toUpperCase();
      return s == "n" ? "可用" : "不可用";
    } else {
      return text;
    }
  }
  handlePageChange(pagination, filters, sorter) {
    this.setState({loading: true});
    this.props.actions.getOperHistory(pagination.current);
  }
  componentDidMount() {
    this.props.actions.getOperHistory(1);
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }
  render() {
    if (this.props.resData.length > 0) {
      this.props.resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={this.props.resData} //替换为后台数据
          pagination={this.state.pagination}
          loading={this.state.loading}
          onChange={this.handlePageChange}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.OperHistory.get("resData"),
    pageConfig: state.OperHistory.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {actions: bindActionCreators(action, dispatch)};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OperHistory);
