import React from "react";
import PropTypes from "prop-types";
import _ from "lodash";
import "../../assets/css/dashboard.css";

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {}
  render() {
    return (
      <div className="board_container">
        <div className="board_compon">
          <span className="chart_compon">图表组建</span>
          <span className="chart_compon">图表组建</span>
          <span className="chart_compon">图表组建</span>
          <span className="chart_compon">图表组建</span>
        </div>
        <div className="board_container__inner">
          <span className="big_chart">图表组建</span>
          <span className="big_chart">图表组建</span>
        </div>
        <div className="board_container__inner">
          <span className="big_chart">图表组建</span>
          <span className="big_chart">图表组建</span>
        </div>
      </div>
    );
  }
}
Dashboard.propTypes = {};
Dashboard.defaultProps = {};

export default Dashboard;
