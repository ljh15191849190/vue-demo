import * as types from "../constants/ActionTypes";

export const getOperHistory = currentPage => {
  console.log("action-> getOperHistory");
  return {
    type: types.XAHC_UPDATE_HISTORY,
    payload: {
      currentPage
    }
  };
};
