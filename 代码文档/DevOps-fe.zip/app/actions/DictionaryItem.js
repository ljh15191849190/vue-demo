import * as types from "../constants/ActionTypes";

export const getDictionaryItem = currentPage => {
  console.log(
    "action-> getDictionaryItem"
  );
  return {
    type: types.XAFC_DICTIONARY_ITEM,
    payload: {
      currentPage
    }
  };
};

export const getDictionaryItemByNames = (
  currentPage,
  dictName
) => {
  console.log(
    "action-> getDictionaryItemByName"
  );
  return {
    type:
      types.XAFC_DICTIONARY_ITEM_BYNAME,
    payload: {
      currentPage,
      dictName
    }
  };
};
