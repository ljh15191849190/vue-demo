import {combineReducers} from "redux";
import login from "./login";
import equList from "./EquList";
import OperHistory from "./OperHistory";
import DictionaryItem from "./DictionaryItem";

const rootReducer = combineReducers({
  login,
  equList,
  OperHistory,
  DictionaryItem
});

export default rootReducer;
