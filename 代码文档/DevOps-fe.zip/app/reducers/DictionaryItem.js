import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

import Immutable from "immutable";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {}
});

const DictionaryItem = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_DICTIONARY_ITEM_SAGA:
      console.log("reducer->DictionaryItem");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.list)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;

    case types.XAHC_DICTIONARY_ITEM_BYNAME_SAGA:
      console.log("reducer->DictionaryItem");
      var page = {
        pageBean: {
          "total": 11,
          "size": 10,
          "totalPage": 2,
          "page": 1
        }
      }
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.OK)
          .set("pageConfig", page);
      }
      return state;

    default:
      return state;
  }
};

export default DictionaryItem;