import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import history from "../routes/history";
import {message} from "antd";

const initState = Immutable.Map({
  logininfo: 0,
  loginStatus: 0
});

const login = (state = initState, action) => {
  switch (action.type) {
    case types.LOGIN_SAGA:
      console.log("reducer->login");
      // if (action.loginStatus.res.rtn_code == 0) {
      //   sessionStorage.setItem("loginStatue", 1);
      //   sessionStorage.setItem("salt", action.loginStatus.res.salt);
      //   sessionStorage.setItem("uid", action.loginStatus.res.uid);
      //   sessionStorage.setItem("userInfo", JSON.stringify(action.loginStatus.res));
      //   return state.set("logininfo", 1);
      // } else {
      //   sessionStorage.setItem("loginStatue", 0);
      //   return state.set("logininfo", 0);
      // }
      // return state.set("loginStatus", action.loginStatus.res.login);
      sessionStorage.setItem("loginStatue", 1);
      return state.set("logininfo", 1);
    case types.LOGOUT_SAGA:
      console.log("reducer->logout");
      sessionStorage.clear();
      message.info("登出成功！");
      history.push("/devops/login");
      return state;

    default:
      return state;
  }
};

export default login;
