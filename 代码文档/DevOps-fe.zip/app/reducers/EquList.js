import * as types from "../constants/ActionTypes";
import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {}
});

const EquList = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_INFO_LIST_SAGA:
      console.log("reducer->EquList");
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;

    default:
      return state;
  }
};

export default EquList;
