import React from "react";
import {Router, Route, Switch} from "react-router-dom";
import history from "./history";
import RenderRoutes from "./RenderRoutes";

//proj
import LoginContainer from "../components/login/LoginContainer";
import Container from "../container/Container";
import Dashboard from "../components/home/Dashboard";
import Equipment from "../components/home/project/Layout";
//admin
import Admin from "../components/admin/Index";

//global router config
const routesConfig = [
  {
    path: "/devops/dashboard",
    component: Dashboard
  },
  {
    path: "/devops/equipment",
    component: Equipment
  },
  {
    path: "/devops/admin",
    component: Admin
  }
];

export default () => (
  <Router history={history}>
    <Switch>
      <Route path="/devops/login" exact component={LoginContainer} />
      <Route path="/" exact component={LoginContainer} />
      <Route path="/devops" exact component={LoginContainer} />
      <Container>
        <Switch>{routesConfig.map((route, i) => <RenderRoutes key={i} {...route} />)}</Switch>
      </Container>
    </Switch>
  </Router>
);
