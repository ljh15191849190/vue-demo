import "babel-polyfill";
import { takeEvery, takeLatest } from "redux-saga/effects";
import * as types from "../constants/ActionTypes";
import { loginFlow } from "./login";
import { logoutFlow } from "./logout";
import { getInfoFlow } from "./EquList";
import { getOperHistoryFlow } from "./OperHistory";
import { getDictionaryItemFlow } from "./DictionaryItem";
import { getDictionaryItemByNameFlow } from "./DictionaryItem";

export default function* mySaga() {
  yield [
    takeEvery(types.XAHC_LOGIN, loginFlow),
    takeEvery(types.XAHC_LOGOUT, logoutFlow),
    takeEvery(types.XAHC_INFO_LIST, getInfoFlow),
    takeEvery(types.XAHC_UPDATE_HISTORY, getOperHistoryFlow),
    takeEvery(types.XAFC_DICTIONARY_ITEM, getDictionaryItemFlow),
    takeEvery(types.XAFC_DICTIONARY_ITEM_BYNAME, getDictionaryItemByNameFlow)
  ];
}
