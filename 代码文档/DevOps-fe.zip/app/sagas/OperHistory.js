import {put, call} from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import {getOperaHistory} from "./apiCall";

export function* getOperHistory(payload) {
  try {
    console.log("saga-> getOperHistory");
    var resData = yield call(getOperaHistory, payload);
    yield put({type: actionTypes.XAHC_UPDATE_HISTORY_SAGA, resData: resData});
  } catch (err) {
    yield put({type: actionTypes.ERROR});
  }
}

export function* getOperHistoryFlow({payload}) {
  console.log("saga-> getOperHistoryFlow");
  let response = yield call(getOperHistory, payload);
}
