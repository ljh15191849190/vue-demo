import ajaxServiceApi from "../api/serviceApi";

export const loginMethod = payload => {
  console.log("apiCall->loginMethod");
  console.log(ajaxServiceApi.login);
  return ajaxServiceApi.login(payload).then(res => res);
};
export const getEquInfo = payload => {
  console.log("apiCall->getEquInfo");
  return ajaxServiceApi.getEquInfo(payload).then(res => res);
};
export const getOperaHistory = payload => {
  console.log("apiCall->getEquHistory");
  return ajaxServiceApi.getOperHistory(payload).then(res => res);
};
export const getDictionaryItems = payload => {
  console.log("apiCall->getDictionaryItem");
  return ajaxServiceApi.getDictionaryItem(payload).then(res => res);
};
export const getDictionaryItemByNames = payload => {
  console.log("apiCall->getDictionaryItemByNames");
  return ajaxServiceApi.getDictionaryItemByName(payload).then(res => res);
};
export const getSysInteRepertoryCall = payload => {
  console.log("apiCall->getSysInteRepertory");
  return ajaxServiceApi.getSysInteRepertory(payload).then(res => res);
};