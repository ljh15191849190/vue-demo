import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/actionTypes";
import { getDictionaryItems } from "./apiCall";
import { getDictionaryItemByNames } from "./apiCall";

export function* getDictionaryItem(payload) {
  try {
    console.log("saga-> getDictionaryItem");
    var resData = yield call(getDictionaryItems, payload);
    yield put({ type: actionTypes.XAHC_DICTIONARY_ITEM_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getDictionaryItemFlow({ payload }) {
  console.log("saga-> getDictionaryItemFlow");
  let response = yield call(getDictionaryItem, payload);
}

export function* getDictionaryItemByName(payload) {
  try {
    console.log("saga-> getDictionaryItemByName");
    var resData = yield call(getDictionaryItemByNames, payload);
    yield put({ type: actionTypes.XAHC_DICTIONARY_ITEM_BYNAME_SAGA, resData: resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getDictionaryItemByNameFlow({ payload }) {
  console.log("saga-> getDictionaryItemByNameFlow");
  let response = yield call(getDictionaryItemByName, payload);
}