export const XAHC_SUCCESSED = "0"; //成功
export const XAHC_EXCEPTION = "-1"; //异常
export const XAHC_NOT_LOGIN = "1000"; //未登录
export const XAHC_NO_PERMISSION = "1001"; //没有权限
export const XAHC_NONE_PARAM = "1002"; //参数为空
export const XAHC_DATA_NOTEXIST = "1003"; //数据不存在
export const XAHC_USER_EXIST = "1004"; //该用户名已经存在
