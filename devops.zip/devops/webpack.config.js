const path = require("path");
const webpack = require("webpack");
const HTMLWebpachPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const MonacoWebpackPlugin = require("monaco-editor-webpack-plugin");
// const CleanWebpackPlugin = require("clean-webpack-plugin");
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin;

module.exports = {
  mode: "development",
  resolve: {
    extensions: [".js", ".jsx"]
  },
  devtool: "cheap-module-eval-source-map",
  entry: [path.resolve(__dirname, "app/index.js")],

  output: {
    path: __dirname + "/dist",
    filename: "[name].bundle.js",
    publicPath: "/"
  },
  devServer: {
    contentBase: __dirname + "/dist",
    compress: true,
    disableHostCheck: true,
    port: 8090,
    proxy: {
      // 测试环境
      "/user": "http://192.168.100.12:8080",
      "/webpjm": "http://192.168.100.12:8080",
      "/webbuildapplication": "http://192.168.100.12:8080",
      "/websystem": "http://192.168.100.12:8080",
      "/webdeployapplication": "http://192.168.100.12:8080",
      "/webcaasapplication": "http://192.168.100.12:8080",
      "/webmonitorapplication": "http://192.168.100.12:8080"
      // 开发环境
      // "/user": "http://192.168.100.212:8080",
      // "/websystem": "http://192.168.100.212:8080",
      // "/webdevopspjmapplication": "http://192.168.100.212:8080",
      // "/webpjm": "http://192.168.100.212:8080",
      // "/webbuildapplication": "http://192.168.100.212:8080",
      // "/webdeployapplication": "http://192.168.100.212:8080",
      // "/webcaasapplication": "http://192.168.100.212:8080",
      // "/webmonitorapplication": "http://192.168.100.212:8080"
    }
  },
  // devServer: {
  //   contentBase: __dirname + "/dist",
  //   compress: true,
  //   port: 8090,
  //   proxy: [
  //     {
  //       context: [
  //         "/user",
  //         "/websystem",
  //         "/webdevopspjmapplication",
  //         "/webpjm",
  //         "/webbuildapplication",
  //         "/webdeployapplication",
  //         "/webcaasapplication",
  //         "/webmonitorapplication"
  //       ],
  //       target: "http://localhost:8081"
  //     }
  //   ]
  // },
  plugins: [
    new BundleAnalyzerPlugin({
      statsFilename: "../analysis/stats.json",
      analyzerMode: "disable",
      generateStatsFile: true,
      statsOptions: { source: false }
    }),
    new webpack.optimize.OccurrenceOrderPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new MonacoWebpackPlugin(),
    // new CleanWebpackPlugin(['dist']),
    new HTMLWebpachPlugin({
      title: "hc-portal-fe",
      template: "./app/assets/index.html",
      files: {
        //  css : ["./app/assets/css/bootstrap.min.css"]
      }
    }),
    // new webpack.optimize.CommonsChunkPlugin({
    //   name: "duplication"
    // }),
    new CopyWebpackPlugin([
      {
        from: "app/assets/images",
        to: "images"
      },
      {
        from: "app/assets/index.html",
        to: "index.html"
      },
      {
        from: "app/assets/css",
        to: "css"
      },
      {
        from: "app/assets/locales",
        to: "locales"
      }
    ]),
    new MiniCssExtractPlugin({
      filename: "styles.css"
    })
  ],
  optimization: {
    splitChunks: {
      cacheGroups: {
        vendor: {
          chunks: "initial",
          test: path.resolve(__dirname, "node_modules"),
          name: "duplication",
          enforce: true
        }
      }
    }
  },
  module: {
    rules: [
      {
        test: /\.(png|jpg|svg|jpeg|mp4)$/,
        use: ["file-loader"]
      },
      {
        test: /\.(scss|css)$/,
        use: [
          MiniCssExtractPlugin.loader,
          "css-loader"
          // 'postcss-loader',
          // 'sass-loader',
        ]
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: "babel-loader",
        options: {
          presets: ["react", "es2015", "stage-0"]
        }
      },
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        loader: "babel-loader",
        query: {
          presets: ["react", "es2015"]
        }
      },
      // {
      //   test: /\.(js|jsx)$/,
      //   exclude: /node_modules/,
      //   use: ["babel-loader", "eslint-loader"]
      // },
      {
        test: /\.(otf|ttf|eot|woff|woff2)$/,
        use: ["file-loader"]
      }
    ]
  }
};
