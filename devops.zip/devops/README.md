# react-project-tpl
### install nodejs
> https://nodejs.org/en/

### install yarn
> https://yarnpkg.com/en/docs/install


### install project node packages
* install by yarn or npm 

>  yarn install or npm install 

* run the demo

> yarn run start:dev

* remote debug

> "start:dev": "webpack-dev-server -d --host 0.0.0.0 --hot --history-api-fallback"


### resource
[React](https://reactjs.org/)

[Redux 中文](http://www.redux.org.cn/)

[react-router](https://github.com/ReactTraining/react-router)

[Redux-saga](https://github.com/redux-saga/redux-saga)

[React-Native](https://facebook.github.io/react-native/)

[ES6](http://es6.ruanyifeng.com/)

### fix errors

* error Msg:The engine "node" is incompatible with this module. Expected version ">=4 <=9".

> resolve :  yarn config set ignore-engines true

* error msg: Node v10.0.0 error Found incompatible module, upath@1.0.4: The engine "node" is incompatible with this module. Expected version ">=4 <=9" 

> delete upath@^1.0.0 in the yarn.lock , and run yarn install

### code formate
* vs code  setting
> "editor.formatOnSave": false,
    "[javascript]": {
        "editor.formatOnSave": true
    }

*  webstorm    
> ctrl+alt+shift +P