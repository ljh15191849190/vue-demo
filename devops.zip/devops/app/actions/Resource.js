import * as types from "../constants/ActionTypes";
// 查询
export const getResource = data => {
  return {
    type: types.XAHC_RESOURCE_LIST,
    payload: {
      data
    }
  };
};
// 保存——修改
export const addResource = data => {
  return {
    type: types.XAHC_RESOURCE_ADD,
    payload: {
      data
    }
  };
};
// 修改
export const updateResource = data => {
  return {
    type: types.XAHC_RESOURCE_UPDATE,
    payload: {
      data
    }
  };
};
// 删除
export const deleteResource = data => {
  return {
    type: types.XAHC_RESOURCE_DELETE,
    payload: {
      data
    }
  };
};
// 环境名称
export const getEnvironmentName = data => {
  return {
    type: types.XAHC_ENVIRONMENT_NAME,
    payload: {
      data
    }
  };
};
// 测试
export const getResourceTest = data => {
  return {
    type: types.XAHC_RESOURCE_TEST,
    payload: {
      data
    }
  };
};
// 容器云模块
// 容器保存
export const addCluster = data => {
  return {
    type: types.XAHC_RESOURCE_CLUSTER_ADD,
    payload: {
      data
    }
  };
};
// 容器信息
export const findClusterInfos = data => {
  return {
    type: types.XAHC_RESOURCE_FIND_CLUSTER_INFO,
    payload: {
      data
    }
  };
};
// 容器连接测试
export const validateCluster = data => {
  return {
    type: types.XAHC_RESOURCE_CLUSTER_TEST,
    payload: {
      data
    }
  };
};
// 主机save
export const addCaasNode = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NODE_ADD,
    payload: {
      data
    }
  };
};
// 主机delete
export const deleteCaasNode = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NODE_DELETE,
    payload: {
      data
    }
  };
};
// 主机修改
export const updateCaasNode = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NODE_UPDATE,
    payload: {
      data
    }
  };
};
// 主机测试
export const testCaasNode = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NODE_TEST,
    payload: {
      data
    }
  };
};
// 主机list
export const getCaasNodeList = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NODE_LIST,
    payload: {
      data
    }
  };
};
// find主机
export const findPodInfo = data => {
  return {
    type: types.XAHC_RESOURCE_FIND_POD_INFO,
    payload: {
      data
    }
  };
};
// 工作区save
export const addCaasNamespace = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NAMESPACE_ADD,
    payload: {
      data
    }
  };
};
// 工作区delete
export const deleteCaasNamespace = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NAMESPACE_DELETE,
    payload: {
      data
    }
  };
};
// 工作区name查询
export const searchCaasNamespace = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NAMESPACE_SEARCH,
    payload: {
      data
    }
  };
};
// 工作区修改
export const updateCaasNamespace = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NAMESPACE_UPDATE,
    payload: {
      data
    }
  };
};

// 工作区list
export const getCaasNamespaceList = data => {
  return {
    type: types.XAHC_RESOURCE_CAAS_NAMESPACE_LIST,
    payload: {
      data
    }
  };
};

// 应用市场
export const getmarketAppList = data => {
  return {
    type: types.XAHC_CAAS_MARKETAPPS_LIST,
    payload: {
      data
    }
  };
};
// 应用市场detail
export const getmarketAppDetail = data => {
  return {
    type: types.XAHC_CAAS_MARKETAPPS_DETAIL,
    payload: {
      data
    }
  };
};
// 应用市场部署
export const findMarketdeploy = data => {
  return {
    type: types.XAHC_DEPLOY_MARKETAPPS_DEPLOY,
    payload: {
      data
    }
  };
};
// 根据projectId查找集群信息
export const getClusterslistById = data => {
  return {
    type: types.XAHC_FIND_CLUSTER_BY_ID,
    payload: {
      data
    }
  };
};
// 根据clusterId查询命名空间
export const getNamespacePodListByClusterId = data => {
  return {
    type: types.XAHC_FIND_NAMESPACE_BY_CLUSTER_ID,
    payload: {
      data
    }
  };
};
// 基本信息
export const getmonitorPodBasic = data => {
  return {
    type: types.XAHC_RESOURCE_POD_BASIC_INFO,
    payload: {
      data
    }
  };
};
// 事件
export const getmonitorPodEvent = data => {
  return {
    type: types.XAHC_RESOURCE_POD_EVENT_INFO,
    payload: {
      data
    }
  };
};
// 日志
export const getmonitorPodLog = data => {
  return {
    type: types.XAHC_RESOURCE_POD_LOG_INFO,
    payload: {
      data
    }
  };
};
// 监控
export const getmonitorInfo = data => {
  return {
    type: types.XAHC_RESOURCE_POD_MONITOR_INFO,
    payload: {
      data
    }
  };
};
// 重置所在集群
export const resetClusterList = () => {
  return {
    type: types.XAHC_RESET_CLUSTER
  };
};
// 重置命名空间
export const resetNameSpaceList = () => {
  return {
    type: types.XAHC_RESET_NAMESPACE
  };
};
