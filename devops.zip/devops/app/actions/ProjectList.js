import * as types from "../constants/ActionTypes";

export const getProjects = data => {
  return {
    type: types.XAHC_PJM_PROJECT,
    payload: {
      data
    }
  };
};
// pjm保存
export const addProjects = payload => {
  return {
    type: types.XAHC_PJM_ADD_PROJECT,
    payload: {
      projectCode: payload.projectCode,
      projectStatus: payload.projectStatus,
      projectName: payload.projectName,
      projectOwner: payload.projectOwner,
      projectDesc: payload.projectDesc,
      projectPermission: payload.projectPermission
    }
  };
};
// pjm删除
export const deleteDeviceId = deviceId => {
  return {
    type: types.XAHC_PJM_DELETE_PROJECT,
    payload: {
      deviceId
    }
  };
};
// pjm修改
export const updataProjects = payload => {
  return {
    type: types.XAHC_PJM_UPDATA_PROJECT,
    payload: {
      projectId: payload.projectId,
      projectStatus: payload.projectStatus,
      projectCode: payload.projectCode,
      projectName: payload.projectName,
      projectOwner: payload.projectOwner,
      projectDesc: payload.projectDesc,
      approvingDesc: payload.approvingDesc,
      projectPermission: payload.projectPermission
    }
  };
};
// codeorname
export const getProjectscodeOrName = data => {
  return {
    type: types.XAHC_PJM_CODEORNAME_PROJECT,
    payload: {
      data
    }
  };
};
// userall
export const getSystemUserall = data => {
  return {
    type: types.XAHC_PJM_PROJECT_USERALL,
    payload: {
      data
    }
  };
};
