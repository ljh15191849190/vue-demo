import * as types from "../constants/ActionTypes";
// 查询
export const getRole = data => {
  return {
    type: types.XAHC_ROLE_LIST,
    payload: {
      data
    }
  };
};
// 保存
export const addRole = data => {
  return {
    type: types.XAHC_ROLE_ADD,
    payload: {
      data
    }
  };
};
// 删除
export const deleteRole = data => {
  return {
    type: types.XAHC_ROLE_DELETE,
    payload: {
      data
    }
  };
};
// 修改
export const updateRole = data => {
  return {
    type: types.XAHC_ROLE_UPDATE,
    payload: {
      data
    }
  };
};
// 全部角色
export const getAllMenu = data => {
  return {
    type: types.XAHC_ROLE_ALL_MENU,
    payload: {
      data
    }
  };
};
// 已选择角色
export const getSelectMenu = data => {
  return {
    type: types.XAHC_ROLE_SELECT_MENU,
    payload: {
      data
    }
  };
};
// 保存角色
export const saveSelectMenu = data => {
  return {
    type: types.XAHC_ROLE_SAVE_SELECT_MENU,
    payload: {
      data
    }
  };
};
// 团队模块

// 查询
export const getTeam = data => {
  return {
    type: types.XAHC_TEAM_LIST,
    payload: {
      data
    }
  };
};
// 保存
export const addTeam = data => {
  return {
    type: types.XAHC_TEAM_ADD,
    payload: {
      data
    }
  };
};
// 删除
export const deleteTeam = data => {
  return {
    type: types.XAHC_TEAM_DELETE,
    payload: {
      data
    }
  };
};
// 授权
export const authorizeTeam = data => {
  return {
    type: types.XAHC_TEAM_AUTHORIZE,
    payload: {
      data
    }
  };
};
// 成员姓名
export const userallTeam = data => {
  return {
    type: types.XAHC_TEAM_TEAM_USER_ALL,
    payload: {
      data
    }
  };
};
