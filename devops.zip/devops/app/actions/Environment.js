import * as types from "../constants/ActionTypes";
// 查询
export const getEnvironment = data => {
  return {
    type: types.XAHC_ENVIRONMENT_LIST,
    payload: {
      data
    }
  };
};
// 保存
export const addEnvironment = data => {
  return {
    type: types.XAHC_ENVIRONMENT_ADD,
    payload: {
      data
    }
  };
};
// 删除
export const deleteEnvironment = data => {
  return {
    type: types.XAHC_ENVIRONMENT_DELETE,
    payload: {
      data
    }
  };
};
// 修改
export const updateEnvironment = data => {
  return {
    type: types.XAHC_ENVIRONMENT_UPDATE,
    payload: {
      data
    }
  };
};
// 环境类型
export const getEnvironmentType = data => {
  return {
    type: types.XAHC_ENVIRONMENT_TYPE,
    payload: {
      data
    }
  };
};
