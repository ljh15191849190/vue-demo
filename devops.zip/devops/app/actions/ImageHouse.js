import * as types from "../constants/ActionTypes";
// 收藏
export const houseCollect = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_COLLECT,
    payload: {
      data
    }
  };
};
// 收藏列表
export const gethouseCollectList = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_COLLECTS_LIST,
    payload: {
      data
    }
  };
};
// 镜像信息
export const gethouseImageInfo = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_IMAGEINFO,
    payload: {
      data
    }
  };
};
// 镜像公有私有列表
export const gethouseImageList = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_IMAGES_LIST,
    payload: {
      data
    }
  };
};
// 镜像公有私有列表
export const gethouseImagePublicList = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_IMAGES_PUBLIC_LIST,
    payload: {
      data
    }
  };
};

// 镜像同步
export const houseImageSync = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_SYNC,
    payload: {
      data
    }
  };
};
// 扫描镜像(暂时不用了)
export const houseImageScan = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_SCAN,
    payload: {
      data
    }
  };
};
// 扫描镜像1
export const houseImageScanTag = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_SCAN_TAG,
    payload: {
      data
    }
  };
};
// 扫描镜像2
export const houseImageScanTags = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_SCAN_TAGS,
    payload: {
      data
    }
  };
};
// 扫描镜像3
export const houseImageUpdateScan = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_SCAN_UPDATETAG,
    payload: {
      data
    }
  };
};
// 镜像(版本)
export const houseImageTags = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_TAGS,
    payload: {
      data
    }
  };
};

// 保存
export const houseImageUpdate = data => {
  return {
    type: types.XAHC_CAAS_HOUSE_UPDATE,
    payload: {
      data
    }
  };
};
