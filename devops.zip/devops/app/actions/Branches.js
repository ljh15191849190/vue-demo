/**
 * code relaction module
 */
import * as types from "../constants/ActionTypes";

export const getRepoBranches = payload => {
  return {
    type: types.XAHC_GET_BRANCH,
    payload
  };
};

export const branchDel = payload => {
  return {
    type: types.XAHC_GET_BRANCH_DEL,
    payload
  };
};
export const branchCreate = payload => {
  return {
    type: types.XAHC_GET_BRANCH_CREATE,
    payload
  };
};
export const branchProtect = payload => {
  return {
    type: types.XAHC_GET_BRANCH_PROTECT,
    payload
  };
};
export const branchUnprotect = payload => {
  return {
    type: types.XAHC_GET_BRANCH_UNPROTECT,
    payload
  };
};
