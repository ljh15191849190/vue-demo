import * as types from "../constants/ActionTypes";

export const getSysInteRepertory = currentPage => {
  return {
    type: types.XAHC_SYS_INTE_REPERTORY,
    payload: {
      currentPage
    }
  };
};
