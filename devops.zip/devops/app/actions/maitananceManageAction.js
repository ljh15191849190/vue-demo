import * as types from "../constants/ActionTypes";

// 分页查询
export const get = (page = null, params = null, from = null) => {
  return {
    type: types.XAHC_MAITANANCE_GET,
    page,
    params,
    from
  };
};

// 搜索查询
export const search = (page = null, params = null, from = null) => {
  return {
    type: types.XAHC_MAITANANCE_SEARCHGET,
    page,
    params,
    from
  };
};

// 添加
export const add = (data = null, params = null, from = null) => {
  return {
    type: types.XAHC_MAITANANCE_ADD,
    data,
    params,
    from
  };
};
// 删除
export const del = (id = null, from = null) => {
  return {
    type: types.XAHC_MAITANANCE_DEL,
    id,
    from
  };
};
// 更新
export const update = (data = null, from = null) => {
  return {
    type: types.XAHC_MAITANANCE_UPDATE,
    data,
    from
  };
};
