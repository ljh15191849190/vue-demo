import * as types from "../constants/ActionTypes";

// 上传介质
export const uploadMedium = payload => {
  return {
    type: types.XAHC_BUILD_MEDIUM_WH_UPLOAD,
    payload
  };
};
// 查询
export const findMedium = payload => {
  return {
    type: types.XAHC_BUILD_MEDIUM_WH_FIND,
    payload
  };
};
// 搜索
export const getMedium = payload => {
  return {
    type: types.XAHC_BUILD_SEARCH_WH_FIND,
    payload
  };
};

//
export const searchNameSystemType = payload => {
  return {
    type: types.XAHC_BUILD_SEARCH_NAME_SYSTEM_TYPE,
    payload
  };
};

//
export const repListByName = payload => {
  return {
    type: types.XAHC_BUILD_REP_LIST_BYNAME,
    payload
  };
};
// 上传软件包
export const uploadSoft = data => {
  return {
    type: types.XAHC_BUILD_UPLOAD_SOFT,
    payload: {
      data
    }
  };
};
