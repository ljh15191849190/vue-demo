import * as types from "../constants/ActionTypes";

export const getComponentList = data => {
  return {
    type: types.XAHC_PJM_COMPONENT,
    payload: {
      data
    }
  };
};
// 组件保存
export const addComponentList = payload => {
  return {
    type: types.XAHC_PJM_ADD_COMPONENT,
    payload: {
      projectId: payload.projectId,
      versionCode: payload.versionCode,
      applicationCode: payload.applicationCode,
      applicationName: payload.applicationName,
      applicationDesc: payload.applicationDesc
    }
  };
};
// 组件修改
export const updateComponent = payload => {
  return {
    type: types.XAHC_PJM_UPDATE_COMPONENT,
    payload: {
      projectId: payload.projectId,
      versionCode: payload.versionCode,
      applicationId: payload.applicationId,
      applicationCode: payload.applicationCode,
      applicationName: payload.applicationName,
      applicationDesc: payload.applicationDesc
    }
  };
};
// 组件删除
export const deleteComponent = deviceId => {
  return {
    type: types.XAHC_PJM_DELETE_COMPONENT,
    payload: {
      deviceId
    }
  };
};
// 下载
export const repositoryAddress = data => {
  return {
    type: types.XAHC_PJM_COMPONENT_ADDRESS,
    //
    payload: {
      data
    }
  };
};
// 详情
export const getModuleDetail = data => {
  return {
    type: types.XAHC_PJM_COMPONENT_MODULE_DETAIL,
    payload: {
      data
    }
  };
};
