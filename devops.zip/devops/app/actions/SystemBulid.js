import * as types from "../constants/ActionTypes";

export const getSystem = (systemType, condition) => {
  if (condition) {
    return {
      type: types.XAHC_SYSTEM_SEARCH_LIST,
      payload: {
        systemType,
        condition
      }
    };
  } else {
    return {
      type: types.XAHC_SYSTEM_SEARCH_LIST,
      payload: {
        systemType
      }
    };
  }
};
// 系统集成保存deleteSystem
export const addSystemList = payload => {
  return {
    type: types.XAHC_ADD_SYSTEM_SEARCH_LIST,
    payload: {
      systemId: payload.systemId,
      category: payload.category,
      alias: payload.alias,
      username: payload.username,
      password: payload.password,
      address: payload.address,
      systemDesc: payload.systemDesc,
      extend: payload.extend,
      systemType: payload.systemType
    }
  };
};
// 集成修改
export const updateSystem = payload => {
  return {
    type: types.XAHC_UPDATE_SYSTEM_SEARCH_LIST,
    payload: {
      systemId: payload.systemId,
      id: payload.id,
      category: payload.category,
      alias: payload.alias,
      username: payload.username,
      password: payload.password,
      address: payload.address,
      extend: payload.extend,
      systemDesc: payload.systemDesc,
      systemType: payload.systemType
    }
  };
};
// 集成删除
export const deleteSystem = deviceId => {
  return {
    type: types.XAHC_DELETE_SYSTEM_SEARCH_LIST,
    payload: {
      deviceId
    }
  };
};
// 搜索补全
export const getsystemTypeByValue = (systemType, category, alias) => {
  return {
    type: types.XAHC_SYSTEMTYPE_SEARCHBYNAME,
    payload: {
      systemType,
      category,
      alias
    }
  };
};
// 集成类别单选
export const categorySystem = deviceId => {
  return {
    type: types.XAHC_SYSTEMTYPE_CATEGORY,
    payload: {
      deviceId
    }
  };
};
// 系统集成测试
export const testSystem = payload => {
  return {
    type: types.XAHC_TESE_SYSTEM_SEARCH_LIST,
    payload: {
      category: payload.category,
      alias: payload.alias,
      username: payload.username,
      password: payload.password,
      address: payload.address,
      extend: payload.extend,
      systemDesc: payload.systemDesc,
      systemType: payload.systemType
    }
  };
};
export const resetField = name => {
  return {
    type: types.XAHC_RESET_SYSTEM_FIELDS,
    payload: {
      name
    }
  };
};
