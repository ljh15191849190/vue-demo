/**
 * code relaction module
 */
import * as types from "../constants/ActionTypes";

export const getRepoType = () => {
  return {
    type: types.XAHC_GET_REPO_TYPE
  };
};
export const getComponentList = projectId => {
  return {
    type: types.XAHC_GET_COMPONENT_REQ,
    payload: {
      projectId
    }
  };
};
export const getRCComponentsList = projectId => {
  return {
    type: types.XAHC_GET_RC_COMPONENT,
    payload: {
      projectId
    }
  };
};
export const saveRCComponent = payload => {
  return {
    type: types.XAHC_SAVE_RC_COMPONENT,
    payload
  };
};
export const delRCRelation = repoId => {
  return {
    type: types.XAHC_DEL_RC_RELACTION,
    repoId
  };
};
export const updateRCRelation = payload => {
  return {
    type: types.XAHC_UPDATE_RC_COMPONENT,
    payload
  };
};
export const enterRCRep = payload => {
  return {
    type: types.XAHC_ENTER_RC_REPO,
    payload
  };
};
export const getFileContent = payload => {
  return {
    type: types.XAHC_GET_FILE_CONTENT,
    payload
  };
};
export const searchRep = payload => {
  return {
    type: types.XAHC_SEARCH_REP,
    payload
  };
};
export const getTagList = data => {
  return {
    type: types.XAHC_CODE_GET_TAG_LIST,
    payload: {
      data
    }
  };
};
export const createTag = data => {
  return {
    type: types.XAHC_CODE_GET_TAG_ADD,
    payload: {
      data
    }
  };
};
export const deleteTag = data => {
  return {
    type: types.XAHC_CODE_GET_TAG_DELETE,
    payload: {
      data
    }
  };
};
export const downLoadTag = data => {
  return {
    type: types.XAHC_CODE_GET_TAG_DOWNLOAD,
    payload: {
      data
    }
  };
};
