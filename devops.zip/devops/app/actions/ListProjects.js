/**
 *  get all projects in Nav
 */
import * as types from "../constants/ActionTypes";

export const getAllProjects = data => {
  return {
    type: types.XAHC_GET_ALL_PROJECTS,
    payload: {
      data
    }
  };
};
// 项目概览
export const getProjectsOvewview = data => {
  return {
    type: types.XAHC_PROJECT_OVERVIEW,
    payload: {
      data
    }
  };
};
// 项目概览
export const getProjectsdeploytop = data => {
  return {
    type: types.XAHC_PROJECT_DEPLOYTOP,
    payload: {
      data
    }
  };
};
// 项目概览
export const getProjectsbuildtop = data => {
  return {
    type: types.XAHC_PROJECT_BUILD_DEPLOYTOP,
    payload: {
      data
    }
  };
};
// 项目概览
export const getProjectsRate = data => {
  return {
    type: types.XAHC_PROJECT_RATE,
    payload: {
      data
    }
  };
};
// project name update
export const updateProjectName = name => {
  return {
    type: types.XAHC_UPDATE_PROJECT_NAME,
    payload: {
      name
    }
  };
};
// 报表
// 构建
export const getBuildstatement = data => {
  return {
    type: types.XAHC_PROJECT_BUILDSTATEMENT,
    payload: {
      data
    }
  };
};
// 部署
export const getdeploystatement = data => {
  return {
    type: types.XAHC_PROJECT_DEPLOYSTATEMENT,
    payload: {
      data
    }
  };
};
// 质量
export const getcodequality = data => {
  return {
    type: types.XAHC_PROJECT_CODEQUALITY,
    payload: {
      data
    }
  };
};
// 代码提交
export const getcodeCommit = data => {
  return {
    type: types.XAHC_PROJECT_CODECOMMIT,
    payload: {
      data
    }
  };
};
