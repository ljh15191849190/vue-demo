import React from "react";
import { Router, Route, Switch, Redirect } from "react-router-dom";
import history from "./history";
import RenderRoutes from "./RenderRoutes";
// proj
import LoginContainer from "../components/login/LoginContainer";
import Container from "../container/Container";
import Dashboard from "../components/home/Dashboard";
import Layout from "../components/home/project/Layout";
import ProjectAll from "../components/home/ProjectAll";
// admin
import Admin from "../components/admin/Index";
// admin

// global router config
const routesConfig = [
  {
    path: "/devops/dashboard",
    component: Dashboard
  },
  {
    path: "/devops/project/:projectId/:projectName/:projectCode",
    // path: "/devops/project",
    component: Layout
  },
  {
    path: "/devops/admin",
    component: Admin
  },
  {
    path: "/devops/projectAll",
    component: ProjectAll
  }
];

function AuthRoute({ component: Component, ...rest }) {
  return (
    <Route
      {...rest}
      render={props =>
        parseInt(sessionStorage.getItem("loginStatue")) === 1 ? (
          <Redirect to="/devops/dashboard" />
        ) : (
          <Route component={LoginContainer} />
        )
      }
    />
  );
}

export default () => (
  <Router history={history}>
    <Switch>
      <AuthRoute path="/devops/login" exact component={LoginContainer} />
      <AuthRoute path="/" exact component={LoginContainer} />
      <AuthRoute path="/devops" exact component={LoginContainer} />
      {/* <Route path="/devops/login" exact component={LoginContainer} />
      <Route path="/" exact component={LoginContainer} />
      <Route path="/devops" exact component={LoginContainer} /> */}
      <Container>
        <Switch>
          {routesConfig.map((route, i) => (
            <RenderRoutes key={Math.random()} {...route} />
          ))}
          <Route
            render={() =>
              parseInt(sessionStorage.getItem("loginStatue")) === 1 ? (
                // <Route component={Dashboard} />
                <Redirect to="/devops/dashboard" />
              ) : (
                <Redirect to="/devops/login" />
              )
            }
          />
        </Switch>
      </Container>
    </Switch>
  </Router>
);
