import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Modal, Form, Input, Select, Button, Checkbox, Row, Col, Table, Popconfirm } from "antd";
import * as action from "../../../actions/SystemBulid";
import Validation from "../../../utils/Validation";

const FormItem = Form.Item;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleClose, onTest, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false} visible={visible} title="新增邮件服务器" footer={null} onCancel={handleClose}>
      <Form layout="vertical">
        <FormItem label="系统别名:">
          {getFieldDecorator("alias", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="发送服务器：">
          {getFieldDecorator("address", {
            rules: Validation.Rule_nochinese
          })(<Input type="url" maxLength={32} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_nochinese
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem style={{ marginTop: 20 }}>
          {getFieldDecorator("ssl", {
            valuePropName: "checked",
            // defaultValue={ssl},
            initialValue: false
          })(<Checkbox>使用SSL协议</Checkbox>)}
        </FormItem>
        <FormItem style={{ marginTop: 20 }} label="SMTP端口：">
          {getFieldDecorator("port", {
            rules: Validation.Rule_number
          })(<Input maxLength={16} />)}
        </FormItem>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onCreate} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});
const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onCancel, onTest, checkboxChange, handleClose, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false} visible={updatavisible} title="修改邮件服务器" footer={null} onCancel={handleClose}>
      <Form layout="vertical">
        <FormItem label="系统别名:">
          {getFieldDecorator("alias", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="发送服务器：">
          {getFieldDecorator("address", {
            rules: Validation.Rule_nochinese
          })(<Input type="url" maxLength={32} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_nochinese
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem style={{ marginTop: 20 }}>
          {getFieldDecorator("ssl", {
            valuePropName: "checked"
          })(<Checkbox>使用SSL协议</Checkbox>)}
        </FormItem>
        <FormItem style={{ marginTop: 20 }} label="SMTP端口：">
          {getFieldDecorator("port", {
            rules: Validation.Rule_number
          })(<Input maxLength={16} />)}
        </FormItem>

        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onUpdata} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});

class Email extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      updataData: {},
      key: 1
    };
    this.columns = [
      {
        title: "系统别名",
        dataIndex: "alias",
        key: "alias",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "alias")
      },
      {
        title: "发送服务器",
        dataIndex: "address",
        key: "address",
        width: "20%",
        render: (text, record) => this.renderColumns(text, record, "address")
      },
      {
        title: "用户名",
        dataIndex: "username",
        key: "username",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "username")
      },
      {
        title: "使用SSL协议",
        dataIndex: "ssl",
        width: "10%",
        key: "ssl",
        render: (text, record) => this.renderColumns(text, record, "ssl")
      },
      {
        title: "端口",
        dataIndex: "port",
        key: "port",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "port")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        key: "createTime",
        width: "15%",
        defaultSortOrder: "descend",
        sorter: (a, b) => new Date(a.createTime).getTime() - new Date(b.createTime).getTime(),
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },

      {
        title: "操作",
        key: "operation",
        width: "15%",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
  }

  //   确认删除projectId
  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteSystem(record.systemId);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "ssl") {
      return record.extend ? (JSON.parse(record.extend).ssl == "0" ? "是" : "否") : "";
    } else if (column == "port") {
      return record.extend ? JSON.parse(record.extend).port : "";
    } else {
      return text;
    }
  }

  //  编号项目名称控件搜索
  search() {
    const { actions } = this.props;
    const systemnName = ReactDOM.findDOMNode(this.refs.projectCode).value;
    if (!systemnName) {
      actions.getSystem("5");
    } else {
      actions.getsystemTypeByValue("5", "Email", systemnName);
    }
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getSystem("5");
    actions.categorySystem(5);
  }

  componentDidUpdate() {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击修改弹框
  showEditModal(record) {
    this.form.setFieldsValue({
      alias: record.alias,
      username: record.username,
      password: record.password,
      address: record.address,
      // "port":"465","to":"849816228@qq.com","ssl":"0"
      port: JSON.parse(record.extend).port,
      ssl: JSON.parse(record.extend).ssl == "0" ? true : false
    });
    this.setState({
      updataData: {
        systemId: record.systemId,
        id: record.id
      },
      loading: false,
      updatavisible: true
    });
  }

  // 确认修改updata
  handleUpdataOk(e) {
    const { actions } = this.props;
    const { updataData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.systemType = "5";
      values.category = "Email";
      values.extend = { port: values.port, ssl: values.ssl == true ? "0" : "1" };
      values.systemId = updataData.systemId;
      values.id = updataData.id;
      actions.updateSystem(values);
      this.setState({ updatavisible: false });
    });
  }

  // 测试连接
  handleTest(e) {
    const { actions } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.systemType = "5";
      values.category = "Email";
      values.extend = { port: values.port, ssl: values.ssl == true ? "0" : "1" };
      actions.testSystem(values);
    });
  }

  // 测试连接修改
  handleTestUp(e) {
    const form = this.form;
    const { actions } = this.props;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.systemType = "5";
      values.category = "Email";
      values.extend = { port: values.port, ssl: values.ssl == true ? "0" : "1" };
      actions.testSystem(values);
    });
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  checkboxChange(result) {}

  // 保存
  handleOk(e) {
    const forms = this.forms;
    const { actions } = this.props;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.systemType = "5";
      values.category = "Email";
      values.extend = { port: values.port, ssl: values.ssl == true ? "0" : "1" };
      actions.addSystemList(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.form.resetFields();
    this.forms.resetFields();
    this.setState({
      visible: false,
      updatavisible: false
    });
  }

  render() {
    const { resData } = this.props;
    const { loading, visible, updatavisible } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={7}>
              <span style={{ marginRight: 10 }}>系统别名:</span>
              <Input style={{ width: "65%" }} ref="projectCode" />
            </Col>

            <Col span={15} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
            <div style={{ width: "100%", marginTop: 20 }}>
              <Table
                bordered
                size="small"
                columns={this.columns}
                dataSource={resData}
                pagination={false}
                loading={loading}
                // onChange={this.onChangeTime.bind(this)}
              />
            </div>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
            onTest={this.handleTest.bind(this)}
            handleClose={this.handleCancel.bind(this)}
          />
          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
            onTest={this.handleTestUp.bind(this)}
            handleClose={this.handleCancel.bind(this)}
            checkboxChange={this.checkboxChange.bind(this)}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.SystemBulid.get("resData"),
    categoryData: state.SystemBulid.get("categoryData"),
    addStatus: state.SystemBulid.get("AddStatus"),
    delStatus: state.SystemBulid.get("delStatus"),
    pageConfig: state.SystemBulid.get("pageConfig"),
    testStatus: state.SystemBulid.get("TestStatus"),
    updataStatus: state.SystemBulid.get("UpdataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Email);
