import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Modal,
  Form,
  Input,
  Select,
  Button,
  Row,
  Col,
  Table,
  Menu,
  message,
  Popconfirm
} from "antd";
import * as action from "../../../actions/SystemBulid";
import "antd/dist/antd.css";
import Email from "./Email";
import Validation from "../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;
// 新增
const NewForm = Form.create()(props => {
  const {
    visible,
    onCreate,
    onCancel,
    onTest,
    handleChange,
    form,
    categoryData,
    title,
    handleClose
  } = props;
  const { getFieldDecorator } = form;

  return (
    <Modal
      maskClosable={false}
      visible={visible}
      title={`新增${title}`}
      footer={null}
      onCancel={handleClose}
    >
      <Form layout="vertical">
        <FormItem label={`${title}类型`}>
          {getFieldDecorator("category", {
            rules: [{ required: true, message: `${title}不能为空`, maxLength: 32 }]
          })(
            <Select allowClear onChange={handleChange}>
              {categoryData
                ? categoryData.map(ele => {
                    return (
                      <Option value={ele} key={Math.random()}>
                        {ele}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem label="系统别名:">
          {getFieldDecorator("alias", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem label="地址：">
          {getFieldDecorator("address", {
            rules: Validation.Rule_url
          })(<Input type="url" maxLength={128} />)}
        </FormItem>

        <FormItem label="描述：">
          {getFieldDecorator("systemDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onCreate} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});
// 修改
const UpdataForm = Form.create()(props => {
  const {
    updatavisible,
    onUpdata,
    onCancel,
    onTest,
    handleChange,
    form,
    categoryData,
    handleClose,
    title
  } = props;
  const { getFieldDecorator } = form;

  return (
    <Modal
      maskClosable={false}
      visible={updatavisible}
      title={`修改${title}`}
      footer={null}
      onCancel={handleClose}
    >
      <Form layout="vertical">
        <FormItem label={`${title}类型`}>
          {getFieldDecorator("category", {
            rules: [{ required: true, message: `${title}不能为空` }]
          })(
            <Select initialValue="所有类型" allowClear onChange={handleChange}>
              {categoryData
                ? categoryData.map(ele => {
                    return (
                      <Option value={ele} key={Math.random()}>
                        {ele}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem label="系统别名:">
          {getFieldDecorator("alias", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem label="地址：">
          {getFieldDecorator("address", {
            rules: Validation.Rule_url
          })(<Input maxLength={128} />)}
        </FormItem>

        <FormItem label="描述：">
          {getFieldDecorator("systemDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onUpdata} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});
class ProjectSystem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sortedInfo: null,
      statevalue: "全部类型",
      systemnName: "",
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      confirmLoading: false,
      updataData: {},
      MenuKey: "1",
      MenuName: "代码仓库集成",
      menuLable: "代码仓库",
      MenuType: "1",
      MenuList: [
        {
          id: "1",
          name: "vcs",
          value: "仓库类型",
          menuTitle: "代码仓库集成",
          menuLable: "代码仓库"
        },
        {
          id: "2",
          name: "bpr",
          value: "介质仓库类型",
          menuTitle: "介质仓库集成",
          menuLable: "介质仓库"
        },
        {
          id: "3",
          name: "build",
          value: "引擎类型",
          menuTitle: "构建引擎集成",
          menuLable: "构建引擎"
        },
        {
          id: "4",
          name: "deploy",
          value: "引擎类型",
          menuTitle: "部署引擎集成",
          menuLable: "部署引擎"
        },
        {
          id: "5",
          name: "email",
          value: "服务器类型",
          menuTitle: "邮件服务器集成",
          menuLable: "邮件服务器"
        },
        {
          id: "6",
          name: "analysis",
          value: "服务器类型",
          menuTitle: "质量分析服务集成",
          menuLable: "质量分析"
        },
        {
          id: "7",
          name: "harbor",
          value: "镜像仓库类型",
          menuTitle: "镜像仓库集成",
          menuLable: "镜像仓库"
        }
      ]
    };

    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
  }

  menuClick(v, i, e) {
    const { actions } = this.props;
    this.setState({
      MenuKey: e.key,
      MenuName: v.menuTitle,
      MenuType: v.id,
      menuLable: v.menuLable
    });
    if (v.menuTitle != "邮件服务器集成") {
      this.state.statevalue = "全部类型";
      this.state.systemnName = "";
      // ReactDOM.findDOMNode(this.refs.systemnName).value = "";
      // actions.resetField(v.name);
      actions.getSystem(e.key);
      actions.categorySystem(v.id);
    }
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  //   确认删除
  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteSystem(record.systemId);
  }

  //   搜索
  search() {
    const { actions } = this.props;
    const { statevalue, MenuType, systemnName } = this.state;
    // 先不删
    // if (!systemnName) {
    //   actions.getSystem(MenuType);
    // } else {
    //   if (statevalue == "" || statevalue == "全部类型") {
    //     actions.getsystemTypeByValue(MenuType, "All", systemnName);
    //   } else {
    //     actions.getsystemTypeByValue(MenuType, statevalue, systemnName);
    //   }
    // }
    if (!systemnName) {
      actions.getSystem(MenuType);
    } else if (statevalue == "" || statevalue == "全部类型" || statevalue == undefined) {
      actions.getsystemTypeByValue(MenuType, "All", systemnName);
    } else {
      actions.getsystemTypeByValue(MenuType, statevalue, systemnName);
    }
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getSystem("1");
    actions.categorySystem(1);
  }

  componentDidUpdate() {
    const { MenuType } = this.state;
    const { actions, addStatus, delStatus, updataStatus, testStatus } = this.props;
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      actions.getSystem(MenuType, "");
    } else if (addStatus && addStatus === 2) {
      message.error("系统别名已存在");
      actions.getSystem(MenuType, "");
    }
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      actions.getSystem(MenuType, "");
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      actions.getSystem(MenuType, "");
    } else if (updataStatus && updataStatus === 2) {
      message.error("系统别名已存在");
      actions.getSystem(MenuType, "");
    }
    if (testStatus && testStatus === 1) {
      message.info("测试成功");
      actions.getSystem(MenuType, "");
    } else if (testStatus && testStatus === 2) {
      message.error("测试失败");
      actions.getSystem(MenuType, "");
    } else if (testStatus && testStatus === 3) {
      message.error("连接超时！");
      actions.getSystem(MenuType, "");
    }
  }

  handleChange(value) {}
  // handleChangeType(statevalue) {
  //   this.setState({
  //     statevalue: statevalue
  //   });
  // }

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const { actions } = this.props;
    const { MenuType } = this.state;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.systemType = MenuType;
      actions.addSystemList(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.setState({
      visible: false,
      updatavisible: false
    });
  }

  // 测试连接
  handleTest(e) {
    const forms = this.forms;
    const { actions } = this.props;
    const { MenuType } = this.state;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.systemType = MenuType;
      actions.testSystem(values);
    });
  }

  // 测试连接修改
  handleTestUp(e) {
    const form = this.form;
    const { actions } = this.props;
    const { MenuType } = this.state;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.systemType = MenuType;
      actions.testSystem(values);
    });
  }

  // 点击修改弹框
  showEditModal(record) {
    this.form.setFieldsValue({
      alias: record.alias,
      username: record.username,
      password: record.password,
      address: record.address,
      systemDesc: record.systemDesc,
      category: record.category
    });
    this.setState({
      updataData: {
        systemId: record.systemId,
        id: record.id
      },
      loading: false
    });
    this.setState({
      updatavisible: true
    });
  }

  // 确认修改updata1
  handleUpdataOk(e) {
    const form = this.form;
    const { actions } = this.props;
    const { MenuType, updataData } = this.state;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.systemType = MenuType;
      values.systemId = updataData.systemId;
      values.id = updataData.id;
      actions.updateSystem(values);
      this.setState({ updatavisible: false });
    });
  }

  onChangeTime(pagination, filters, sorter) {
    this.setState({
      sortedInfo: sorter
    });
  }

  render() {
    const { resData, categoryData } = this.props;
    const {
      MenuList,
      MenuKey,
      MenuName,
      systemnName,
      menuLable,
      statevalue,
      loading,
      visible,
      updatavisible
    } = this.state;
    const columns = [
      {
        title: "系统别名",
        dataIndex: "alias",
        key: "alias",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "alias")
      },
      {
        title: "地址",
        dataIndex: "address",
        key: "address",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "address")
      },
      {
        title: "用户名",
        dataIndex: "username",
        key: "username",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "username")
      },
      {
        title: "类型",
        dataIndex: "category",
        key: "category",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "category")
      },
      {
        title: "描述",
        dataIndex: "systemDesc",
        key: "systemDesc",
        width: "20%",
        render: (text, record) => this.renderColumns(text, record, "systemDesc")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        key: "createTime",
        width: "15%",
        defaultSortOrder: "descend",
        sorter: (a, b) => new Date(a.createTime).getTime() - new Date(b.createTime).getTime(),
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },

      {
        title: "操作",
        key: "operation",
        width: "20%",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    this.menuDom = MenuList
      ? MenuList.map((v, i) => {
          return (
            <Menu onSelect={this.menuClick.bind(this, v, i)} key={v.id} selectedKeys={[MenuKey]}>
              <Menu.Item key={v.id}>{v.menuTitle}</Menu.Item>
            </Menu>
          );
        })
      : "";
    return (
      <div style={{ width: "calc(100vw - 300px)" }}>
        <Row style={{ height: "80vh" }}>
          <Col span={4} style={{ borderRight: "1px solid rgba(228, 228, 228, 1)", height: "100%" }}>
            {this.menuDom}
          </Col>
          <Col span={20} style={{ height: "80vh", overflow: "auto" }}>
            <div
              style={{
                textAlign: "left",
                height: "60px",
                lineHeight: "60px",
                padding: "8px",
                marginLeft: "20px",
                borderBottom: "1px solid #ccc"
              }}
            >
              {MenuName}
            </div>
            <div className="searchbar">
              {MenuName != "邮件服务器集成" ? (
                <Row style={{ marginTop: "10px", padding: "0 30px" }} type="flex">
                  <Col span={8}>
                    <span style={{ marginRight: 20 }}>系统别名:</span>
                    <Input
                      style={{ width: "60%" }}
                      value={systemnName}
                      onChange={e => this.setState({ systemnName: e.target.value })}
                    />
                    {/* <Search
                    placeholder="请输入系统别名"
                    enterButton
                    className="padright"
                    onSearch={this.search.bind(this)}
                    style={{width: 250}}
                  /> */}
                  </Col>
                  <Col span={8}>
                    <span style={{ marginRight: 20 }}>
                      {menuLable}
                      类型
                    </span>
                    <Select
                      allowClear
                      defaultValue="全部类型"
                      placeholder="全部类型"
                      value={statevalue}
                      style={{ width: "60%" }}
                      onChange={val => this.setState({ statevalue: val ? val : "" })}
                    >
                      {categoryData
                        ? categoryData.map(ele => {
                            return (
                              <Option value={ele} key={Math.random()}>
                                {ele}
                              </Option>
                            );
                          })
                        : ""}
                    </Select>
                  </Col>
                  <Col span={5} style={{ textAlign: "right" }}>
                    <Button
                      type="primary"
                      style={{ marginRight: 10 }}
                      onClick={this.search.bind(this)}
                    >
                      查询
                    </Button>
                    <Button type="primary" onClick={this.showModal.bind(this)}>
                      新增
                    </Button>
                  </Col>
                  <div style={{ width: "100%", marginTop: 20 }}>
                    <Table
                      bordered
                      size="small"
                      columns={columns}
                      dataSource={resData}
                      pagination={false}
                      loading={loading}
                      onChange={this.onChangeTime.bind(this)}
                    />
                  </div>
                </Row>
              ) : (
                <Email />
              )}
            </div>
            <NewForm
              ref={this.saveFormRef.bind(this)}
              visible={visible}
              onCancel={this.handleCancel.bind(this)}
              onCreate={this.handleOk.bind(this)}
              onTest={this.handleTest.bind(this)}
              categoryData={categoryData}
              handleChange={this.handleChange.bind(this)}
              handleClose={this.handleCancel.bind(this)}
              title={menuLable}
            />
            <UpdataForm
              ref={this.updataFormRef.bind(this)}
              updatavisible={updatavisible}
              onCancel={this.handleCancel.bind(this)}
              onUpdata={this.handleUpdataOk.bind(this)}
              onTest={this.handleTestUp.bind(this)}
              categoryData={categoryData}
              handleChange={this.handleChange.bind(this)}
              handleClose={this.handleCancel.bind(this)}
              title={menuLable}
            />
          </Col>
        </Row>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.SystemBulid.get("resData"),
    categoryData: state.SystemBulid.get("categoryData"),
    addStatus: state.SystemBulid.get("AddStatus"),
    delStatus: state.SystemBulid.get("delStatus"),
    pageConfig: state.SystemBulid.get("pageConfig"),
    testStatus: state.SystemBulid.get("TestStatus"),
    updataStatus: state.SystemBulid.get("UpdataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProjectSystem);
