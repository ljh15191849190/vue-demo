import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  Popconfirm,
  Row,
  Col,
  message,
  TreeSelect
} from "antd";
import md5 from "md5";
import * as action from "../../../actions/systemManageAction";
import RULES from "../../../utils/Validation";

const FormItem = Form.Item;
const { Option } = Select;
const TreeNode = TreeSelect.TreeNode;

const UpdateForm = Form.create()(props => {
  const {
    updateVisible,
    onCreate,
    onCancel,
    form,
    thatState,
    list,
    onSecondChange,
    chooseRoleOption,
    chooseOrgOption,
    that,
    renderTreeNodesUpdate,
    onLoadDataUpdate,
    onTreeChangeUpdate,
    onUpdateFormFocus,
    treeDefaultExpandedKeysNew
  } = props;
  const { getFieldDecorator } = form;

  const roleList = [];
  if (list.length !== 0) {
    // var roleList = [];
    if (list.roles.length !== 0) {
      for (let m = 0, listRoles = list.roles; m < listRoles.length; m++) {
        roleList.push(listRoles[m].roleId);
      }
    }
  }

  // 角色授权选项
  const optionRoleChildren = [];
  if (chooseRoleOption.length !== 0) {
    for (let i = 0; i < chooseRoleOption.length; i++) {
      optionRoleChildren.push(
        <Option value={chooseRoleOption[i].roleId} key={chooseRoleOption[i].roleId}>
          {chooseRoleOption[i].roleName}
        </Option>
      );
    }
  }
  // 机构选项
  const optionOrgChildren = [];
  if (chooseOrgOption.length !== 0) {
    for (let i = 0; i < chooseOrgOption.length; i++) {
      optionOrgChildren.push(
        <Option value={chooseOrgOption[i].orgId} key={chooseOrgOption[i].orgId}>
          {chooseOrgOption[i].orgName}
        </Option>
      );
    }
  }
  // // userStatus
  // if (list.userStatus === 0) {
  //   var userStatusText = "禁用";
  // } else {
  //   var userStatusText = "启用";
  // }
  return (
    <Modal
      maskClosable={false}
      visible={updateVisible}
      title="修改人员"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="用户名：">
          {getFieldDecorator("userName", {
            rules: RULES.Rule_code,
            initialValue: list ? list.userName : ""
          })(<Input maxLength={32} />)}
        </FormItem>

        <FormItem label="用户密码：">
          {getFieldDecorator("password", {
            rules: [
              {
                required: true,
                message: "密码应为6到16位，非中文"
              }
            ],
            initialValue: list ? list.password : ""
          })(
            <Input
              type="password"
              maxLength={32}
              style={{ fontFamily: "Arial,sans-serif,Tahoma", fontSize: "12px" }}
            />
          )}
          {thatState.passwordText.length !== 0 ? (
            <span style={{ color: "red" }}>密码应为6到16位，非中文</span>
          ) : null}
        </FormItem>
        <FormItem label="真实姓名：">
          {getFieldDecorator("realName", {
            rules: RULES.Rule_name,
            initialValue: list ? list.realName : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="邮箱地址：">
          {getFieldDecorator("email", {
            rules: RULES.Rule_mail,
            initialValue: list ? list.email : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="手机号码：">
          {getFieldDecorator("phone", {
            rules: RULES.Rule_tel,
            initialValue: list ? list.phone : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="状态：">
          {getFieldDecorator("userStatus", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ],
            initialValue: list ? `${list.userStatus}` : ""
          })(
            <Select style={{ width: "100%" }}>
              <Option value="1">启用</Option>
              <Option value="0">禁用</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="所属机构：">
          {getFieldDecorator("orgId", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ],
            initialValue: list ? list.orgId : ""
          })(
            <TreeSelect
              dropdownStyle={{ maxHeight: "56vh" }}
              loadData={onLoadDataUpdate}
              onChange={onTreeChangeUpdate}
              treeDefaultExpandedKeys={treeDefaultExpandedKeysNew}
              // treeExpandedKeys = {treeExpandedKeysNew}
            >
              {that.state.treeDataUpdate ? renderTreeNodesUpdate(that.state.treeDataUpdate) : null}
            </TreeSelect>
          )}
        </FormItem>
        <FormItem label="角色授权：">
          {getFieldDecorator("roles", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ],
            initialValue: list ? (list.length !== 0 ? roleList : []) : []
          })(
            <Select
              className="hide-searchSelectUpdate"
              style={{ width: "100%" }}
              mode="multiple"
              onFocus={onUpdateFormFocus}
              onSelect={value => {
                onSecondChange(value);
              }}
            >
              {optionRoleChildren}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

const NewForm = Form.create()(props => {
  const {
    addVisible,
    onCreate,
    onCancel,
    form,
    onSelectChange,
    onSecondChange,
    chooseRoleOption,
    chooseOrgOption,
    renderTreeNodes,
    onLoadData,
    that,
    onTreeChange,
    onNewFormFocus,

    treeDefaultExpandedKeysUpdate
    // treeExpandedKeysUpdate,
  } = props;

  const { getFieldDecorator } = form;
  // 角色授权选项
  const optionRoleChildren = [];
  if (chooseRoleOption.length !== 0) {
    for (let i = 0; i < chooseRoleOption.length; i++) {
      optionRoleChildren.push(
        <Option value={chooseRoleOption[i].roleId} key={`roles${Math.random()}`}>
          {chooseRoleOption[i].roleName}
        </Option>
      );
    }
  }
  return (
    <Modal
      maskClosable={false}
      visible={addVisible}
      title="新增人员"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="用户名：">
          {getFieldDecorator("userName", {
            rules: RULES.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>

        <FormItem label="用户密码：">
          {getFieldDecorator("password", {
            rules: RULES.Rule_password
          })(
            <Input
              type="password"
              maxLength={32}
              style={{ fontFamily: "Arial,sans-serif,Tahoma", fontSize: "12px" }}
            />
          )}
        </FormItem>
        <FormItem label="真实姓名：">
          {getFieldDecorator("realName", {
            rules: RULES.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="邮箱地址：">
          {getFieldDecorator("email", {
            rules: RULES.Rule_mail
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="手机号码：">
          {getFieldDecorator("phone", {
            rules: RULES.Rule_tel
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="状态：">
          {getFieldDecorator("userStatus", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ],
            initialValue: "1"
          })(
            <Select style={{ width: "100%" }}>
              <Option value="1">启用</Option>
              <Option value="0">禁用</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="所属机构：">
          {getFieldDecorator("orgId", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ]
          })(
            <TreeSelect
              dropdownStyle={{ maxHeight: "56vh" }}
              loadData={onLoadData}
              onChange={onTreeChange}
              treeDefaultExpandedKeys={treeDefaultExpandedKeysUpdate}
              // treeExpandedKeys = {treeExpandedKeysUpdate}
            >
              {that.state.treeData ? renderTreeNodes(that.state.treeData) : null}
            </TreeSelect>
          )}
        </FormItem>
        <FormItem label="角色授权：">
          {getFieldDecorator("roles", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ]
          })(
            <Select
              className="hide-searchSelect"
              style={{ width: "100%" }}
              onFocus={onNewFormFocus}
              mode="multiple"
              onSelect={value => {
                onSecondChange(value);
              }}
            >
              {optionRoleChildren}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class PersonManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {
        name: "",
        userStatus: ""
      },
      addVisible: false,
      // visible: false,
      oldPassword: "",
      passwordText: "",
      updateVisible: false,
      userInformation: null,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: "",
      treeDefaultExpandedKeysNew: [],
      // treeExpandedKeysNew: [],
      treeDefaultExpandedKeysUpdate: [],
      // treeExpandedKeysUpdate: [],
      selectValue: "",
      treeData: [],
      treeDataUpdate: []
    };
    this.columns = [
      {
        title: "用户名",
        dataIndex: "userName",
        render: (text, record) => this.renderColumns(text, record, "userName")
      },
      {
        title: "真实姓名",
        dataIndex: "realName",
        render: (text, record) => this.renderColumns(text, record, "realName")
      },
      {
        title: "邮箱",
        dataIndex: "email",
        render: (text, record) => this.renderColumns(text, record, "email")
      },
      {
        title: "手机号码",
        dataIndex: "phone",
        render: (text, record) => this.renderColumns(text, record, "phone")
      },
      {
        title: "状态",
        dataIndex: "userStatus",
        render: (text, record) => this.renderColumns(text, record, "userStatus")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          const { userStatus } = record; // 当前行数据
          return (
            <div className="editable-row-operations">
              {parseInt(userStatus, 0) === 0 ? (
                <span>
                  <Popconfirm
                    title="确定进行启用操作吗？"
                    onConfirm={() => this.forbidden(record.userId, record.userStatus)}
                    okText="继续"
                    cancelText="取消"
                  >
                    <a className="padright">启用</a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <Popconfirm
                    title="确定进行禁用操作吗？"
                    onConfirm={() => this.forbidden(record.userId, record.userStatus)}
                    okText="继续"
                    cancelText="取消"
                  >
                    <a className="padright">禁用</a>
                  </Popconfirm>
                </span>
              )}
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.handleDelOk = this.handleDelOk.bind(this);
    this.onTreeChange = this.onTreeChange.bind(this);
    this.onSelectChange = this.onSelectChange.bind(this);
    this.onSecondChange = this.onSecondChange.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.forbidden = this.forbidden.bind(this);
    this.onTreeChange = this.onTreeChange.bind(this);
    this.onLoadData = this.onLoadData.bind(this);
    this.renderTreeNodes = this.renderTreeNodes.bind(this);
    this.renderTreeNodesUpdate = this.renderTreeNodesUpdate.bind(this);
    this.onLoadDataUpdate = this.onLoadDataUpdate.bind(this);
    this.onTreeChangeUpdate = this.onTreeChangeUpdate.bind(this);
    this.onNewFormFocus = this.onNewFormFocus.bind(this);
    this.onUpdateFormFocus = this.onUpdateFormFocus.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.UserManage.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.UserManage.pageBean.total,
          current: nextProps.UserManage.pageBean.page,
          pageSize: nextProps.UserManage.pageBean.size
        },
        loading: false
      });
    }
  }

  componentWillMount() {
    const { actions } = this.props;
    const orgAll = { orgId: 1 };
    actions.get(null, orgAll, "organizationAll");

    setTimeout(() => {
      const { OrganizationAll } = this.props;
      this.setState({
        treeData: OrganizationAll.data
      });
    }, 800);

    setTimeout(() => {
      const { OrganizationAll } = this.props;
      this.setState({
        treeDataUpdate: OrganizationAll.data
      });
    }, 800);
  }

  componentDidMount() {
    const { actions } = this.props;
    const params = { userStatus: 0 }; // 获取redux里的用户登陆信息数据
    actions.get(1, params, "userManage");
    const orgAll = { orgId: 1 };
    actions.get(null, { roleName: "All" }, "roleAll");
  }

  componentDidUpdate() {
    const { actions, updateStatus, delStatus, addStatus, otherStatus } = this.props;
    const { searchItem } = this.state;

    if (updateStatus && updateStatus === 1) {
      const { UserManage } = this.props;
      message.success("编辑成功");
      if (searchItem.name || searchItem.userStatus) {
        actions.search(1, searchItem, "userManage");
      } else {
        actions.get(UserManage.pageBean.page, null, "userManage");
      }
    } else if (delStatus && delStatus === 1) {
      const { UserManage } = this.props;
      message.success("删除成功");
      if (
        UserManage.pageBean.total % UserManage.pageBean.size === 1 &&
        UserManage.pageBean.totalPage > 1 &&
        UserManage.pageBean.page > 1
      ) {
        actions.get(UserManage.pageBean.page - 1, null, "userManage");
      } else {
        actions.get(UserManage.pageBean.page, null, "userManage");
      }
    } else if (addStatus && addStatus === 1) {
      const { UserManage } = this.props;
      message.success("新增成功");
      if (searchItem.name || searchItem.userStatus) {
        actions.search(1, searchItem, "userManage");
      } else {
        actions.get(UserManage.pageBean.page, null, "userManage");
      }
    } else if (otherStatus && otherStatus === 1) {
      const { UserManage } = this.props;
      message.success("修改成功");
      if (searchItem.name || searchItem.userStatus) {
        actions.search(1, searchItem, "userManage");
      } else {
        actions.get(UserManage.pageBean.page, null, "userManage");
      }
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const { searchItem } = this.state;
    this.setState({ loading: true });
    if (searchItem.name || searchItem.userStatus) {
      const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
      if (roleName) {
        actions.search(pagination.current, searchItem, "userManage");
      } else {
        actions.search(
          pagination.current,
          { name: "", userStatus: searchItem.userStatus },
          "userManage"
        );
      }
    } else {
      actions.get(pagination.current, null, "userManage");
    }
  }

  handleDelOk(record) {
    const { actions } = this.props;
    const userId = record.userId;
    actions.del(userId, "userManage");
  }

  saveFormRef(form) {
    this.form = form;
  }

  saveUpdateFormRef(forms) {
    this.forms = forms;
  }

  // 点击编辑弹框
  showEditModal(record) {
    const { actions } = this.props;
    actions.get(null, { id: record.userId }, "userFind");
    actions.get(record.orgId, null, "orgFind");
    this.forms.resetFields();
    setTimeout(() => {
      const { OrgFind } = this.props;
      if (OrgFind.data.length !== 0) {
        this.forms.setFieldsValue({
          orgId: OrgFind.data.orgName
        });
      }
    }, 800);
    this.setState({
      userInformation: record,
      oldPassword: record.password,
      updateVisible: true
    });
  }

  onNewFormFocus() {
    document
      .getElementsByClassName("hide-searchSelect")[0]
      .getElementsByClassName("ant-select-search__field")[0]
      .setAttribute("readOnly", "readOnly");
  }

  onUpdateFormFocus() {
    document
      .getElementsByClassName("hide-searchSelectUpdate")[0]
      .getElementsByClassName("ant-select-search__field")[0]
      .setAttribute("readOnly", "readOnly");
  }

  // 异步加载的选择树
  onLoadData(treeNode) {
    const { actions } = this.props;
    const { treeData } = this.state;
    actions.get(null, { orgId: treeNode.props.value }, "organizationAll");
    return new Promise(resolve => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
      setTimeout(() => {
        const { OrganizationAll } = this.props;
        treeNode.props.dataRef.children = OrganizationAll.data;
        this.setState({
          treeData: [...treeData]
        });
        resolve();
      }, 1000);
    });
  }

  renderTreeNodes(data) {
    return data.map(item => {
      if (item.children) {
        return (
          <TreeNode title={item.orgName} key={item.orgId} dataRef={item} value={item.orgId}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode title={item.orgName} key={item.orgId} value={item.orgId} dataRef={item} />;
    });
  }

  onTreeChange(value, label, extra) {
    // this.setState({ value });
    this.form.setFieldsValue({
      orgId: value
    });
  }

  // update
  // 异步加载的选择树
  onLoadDataUpdate(treeNode) {
    const { actions } = this.props;
    const { treeDataUpdate } = this.state;
    actions.get(null, { orgId: treeNode.props.value }, "organizationAll");
    return new Promise(resolve => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
      setTimeout(() => {
        const { OrganizationAll } = this.props;
        treeNode.props.dataRef.children = OrganizationAll.data;
        this.setState({
          treeDataUpdate: [...treeDataUpdate]
        });
        resolve();
      }, 1000);
    });
  }

  renderTreeNodesUpdate(data) {
    return data.map(item => {
      if (item.children) {
        return (
          <TreeNode title={item.orgName} key={item.orgId} dataRef={item} value={item.orgId}>
            {this.renderTreeNodesUpdate(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode title={item.orgName} key={item.orgId} value={item.orgId} dataRef={item} />;
    });
  }

  onTreeChangeUpdate(value, label, extra) {
    // this.setState({ value });
    this.forms.setFieldsValue({
      orgId: value
    });
  }

  handleUpdataOk(e) {
    const { actions, RoleAll } = this.props;
    const { userInformation, oldPassword } = this.state;
    const forms = this.forms;
    const roleAllList = RoleAll.data;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.userId = userInformation.userId;
      values.id = userInformation.id;
      if (typeof values.orgId === "string") {
        values.orgId = userInformation.orgId;
      }
      if (oldPassword !== values.password) {
        const regex = /^[^\u4e00-\u9fa5]{6,16}$/gm;
        if (!regex.test(values.password)) {
          this.setState({
            passwordText: "密码应为6到16位，非中文"
          });
          return;
        }
        values.password = md5(values.password);
      }
      if (values.roles !== undefined) {
        if (values.roles.length !== 0) {
          const roleChoose = values.roles;
          const roleList = roleAllList.filter(item => roleChoose.indexOf(item.roleId) !== -1);
          values.roles = roleList;
        }
      }
      actions.update(values, "userManage");
      this.setState({
        updateVisible: false
      });
      forms.resetFields();
    });
  }

  search() {
    const { actions } = this.props;
    const { selectValue } = this.state;
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    this.setState({
      searchItem: {
        name: roleName ? (roleName === undefined ? "" : roleName) : "",
        userStatus: selectValue === undefined ? "" : selectValue
      }
    });
    const params = { name: roleName, userStatus: selectValue === undefined ? "" : selectValue };
    actions.search(1, params, "userManage");
  }

  // able disable  changeavailable
  handleSelectChange(value) {
    this.setState({
      selectValue: value
    });
  }

  // 判断是禁用还是启用
  forbidden(id, userStatus) {
    const { actions } = this.props;
    if (parseInt(userStatus, 0) === 1) {
      // 1启用 0禁用
      userStatus = 0;
      actions.update({ id, userStatus }, "forbidden"); // 发送请求
    } else if (parseInt(userStatus, 0) === 0) {
      userStatus = 1;
      actions.update({ id, userStatus }, "forbidden"); // 发送请求
    }
  }

  renderColumns(text, record, column) {
    if (column === "userStatus") {
      return parseInt(text, 0) === 0 ? "禁用" : "启用";
    }
    return text;
  }

  // 点击新增弹框
  showAddModal() {
    this.setState({
      addVisible: true
    });
  }

  onSelectChange(value, option) {
    // this.setState({
    //   chooseType: value
    // });
  }

  onSecondChange(value, option) {
    // this.setState({
    //   secondType: value,
    // })
  }

  handleOk(e) {
    const { actions, RoleAll } = this.props;
    const roleAllList = RoleAll.data;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      if (values.roles !== undefined) {
        if (values.roles.length !== 0) {
          const roleChoose = values.roles;
          const roleList = roleAllList.filter(item => roleChoose.indexOf(item.roleId) !== -1);
          values.roles = roleList;
        }
      }
      values.password = md5(values.password);
      actions.add(values, null, "userManage");
      this.setState({
        addVisible: false
      });
      form.resetFields();
    });
  }

  handleCancel(e) {
    this.setState({
      addVisible: false,
      updateVisible: false,
      passwordText: "",
      treeDefaultExpandedKeysNew: [],
      treeDefaultExpandedKeysUpdate: []
      // treeExpandedKeysNew: [],
      // treeExpandedKeysUpdate: [],
    });
    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  render() {
    const { RoleAll, OrganizationAll, UserManage, UserFind } = this.props;
    const {
      addVisible,
      updateVisible,
      pagination,
      loading,
      treeDefaultExpandedKeysNew,
      treeDefaultExpandedKeysUpdate
    } = this.state;
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "row"
        }}
      >
        <div
          style={{
            minHeight: "78vh",
            flex: 6,
            textAlign: "left",
            padding: "10px",
            borderBottom: "1px solid #ccc"
          }}
        >
          <div
            style={{
              textAlign: "left",
              height: "38px",
              padding: "10px",
              lineHeight: "26px",
              borderBottom: "1px solid #ccc",
              marginBottom: "10px",
              marginTop: "10px"
            }}
          >
            人员列表
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "20px" }} type="flex" justify="space-between">
              <Col span={10}>
                查询条件：
                <Input
                  placeholder="请输入手机号码、邮箱地址或者真实姓名"
                  style={{ width: "80%" }}
                  ref="roleName"
                />
              </Col>
              <Col span={4}>
                状态：
                <Select
                  allowClear={true}
                  defaultValue="所有状态"
                  style={{ width: "70%" }}
                  onChange={this.handleSelectChange}
                >
                  <Option value="1">启用</Option>
                  <Option value="0">禁用</Option>
                </Select>
              </Col>
              <Col span={4} style={{ textAlign: "right" }}>
                <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: 10 }}>
                  查询
                </Button>
                <Button type="primary" onClick={this.showAddModal.bind(this)}>
                  新增
                </Button>
              </Col>
            </Row>
          </div>
          <NewForm
            that={this}
            ref={this.saveFormRef.bind(this)}
            addVisible={addVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
            onSelectChange={this.onSelectChange}
            onSecondChange={this.onSecondChange}
            chooseRoleOption={RoleAll.length !== 0 ? RoleAll.data : []}
            chooseOrgOption={OrganizationAll.length !== 0 ? OrganizationAll.data : []}
            onNewFormFocus={this.onNewFormFocus}
            renderTreeNodes={this.renderTreeNodes}
            onLoadData={this.onLoadData}
            onTreeChange={this.onTreeChange}
            treeDefaultExpandedKeysNew={treeDefaultExpandedKeysNew}
            // treeExpandedKeysNew = {this.state.treeExpandedKeysNew}
            // treeExpandedKeysNew: [],
            // treeDefaultExpandedKeysUpdate: [],
          />
          <UpdateForm
            that={this}
            ref={this.saveUpdateFormRef.bind(this)}
            updateVisible={updateVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleUpdataOk.bind(this)}
            onUpdateFormFocus={this.onUpdateFormFocus}
            thatState={this.state}
            onSelectChange={this.onSelectChange}
            onSecondChange={this.onSecondChange}
            chooseRoleOption={RoleAll.length !== 0 ? RoleAll.data : []}
            chooseOrgOption={OrganizationAll.length !== 0 ? OrganizationAll.data : []}
            list={UserFind.length !== 0 ? UserFind.data : UserFind}
            renderTreeNodesUpdate={this.renderTreeNodesUpdate}
            onLoadDataUpdate={this.onLoadDataUpdate}
            onTreeChangeUpdate={this.onTreeChangeUpdate}
            treeDefaultExpandedKeysUpdate={treeDefaultExpandedKeysUpdate}
            // treeExpandedKeysUpdate = {this.state.treeExpandedKeysUpdate}
          />
          <Table
            bordered
            size="small"
            columns={this.columns}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={UserManage.data}
            pagination={pagination}
            loading={loading}
            onChange={this.handlePageChange.bind(this)}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Login: state.login.get("logininfo"),
    UserManage: state.SystemManage.get("userManageData"),
    UserFind: state.SystemManage.get("userFindData"),
    RoleAll: state.SystemManage.get("roleAllData"),
    OrganizationAll: state.SystemManage.get("organizationAllData"),
    RoleManage: state.SystemManage.get("roleManageData"),
    OrgFind: state.SystemManage.get("orgFindData"),
    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PersonManage);
