import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { Table, Input, Button, Form, Modal, Popconfirm, Row, Col, message, Tabs, Tree } from "antd";
import * as action from "../../../actions/systemManageAction";

const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;
const { TabPane } = Tabs;

const UpdateForm = Form.create()(props => {
  const { updateVisible, onCreate, onCancel, form, list } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;

  return (
    <Modal
      maskClosable={false}
      visible={updateVisible}
      title="修改角色"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="角色编号：">
          {getFieldDecorator("roleCode", {
            rules: [
              {
                required: true,
                message: "请输入字母、数字、下划线，不能以下划线开头或结尾",
                pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_]+$/
              }
            ],
            initialValue: list ? list.roleCode : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="角色名称：">
          {getFieldDecorator("roleName", {
            rules: [
              {
                required: true,
                message: "请输入字母、数字、中文、下划线，不能以下划线开头或结尾",
                pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/
              }
            ],
            initialValue: list ? list.roleName : ""
          })(<Input maxLength={32} />)}
        </FormItem>

        <FormItem label="角色描述">
          {getFieldDecorator("roleDesc", {
            initialValue: list ? list.roleDesc : ""
          })(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const NewForm = Form.create()(props => {
  const { addVisible, onCreate, onCancel, form } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal
      maskClosable={false}
      visible={addVisible}
      title="新增角色"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="角色编号：">
          {getFieldDecorator("roleCode", {
            rules: [
              {
                required: true,
                message: "请输入字母、数字、下划线，不能以下划线开头或结尾",
                pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_]+$/
              }
            ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="角色名称：">
          {getFieldDecorator("roleName", {
            rules: [
              {
                required: true,
                message: "请输入字母、数字、中文、下划线，不能以下划线开头或结尾",
                pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/
              }
            ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="角色描述">
          {getFieldDecorator("roleDesc", {})(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

const Setrole = Form.create()(props => {
  const {
    visible,
    onCancel,
    onCreate,
    treecheck,
    treeSelectValue,
    onTreeSelectChange,
    reslist,
    onSelectTree,
    onExpand,
    // onChangeSearch,
    expandedKeys,
    autoExpandParent,
    checkedKeys,
    selectedKeys
  } = props;

  const renderMethod = data => {
    if (data && data.length !== 0) {
      return data.map((item, key) => {
        if (item.childMenus && item.childMenus.length !== 0) {
          return (
            <TreeNode value={item.menuId} title={item.menuName} key={item.menuId}>
              {renderMethod(item.childMenus)}
            </TreeNode>
          );
        } else {
          return <TreeNode value={item.menuId} title={item.menuName} key={item.menuId} />;
        }
      });
    }
  };
  return (
    <Modal
      maskClosable={false}
      width="650px"
      height="600px"
      visible={visible}
      title="选择菜单"
      okText="保存"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Tabs type="card">
        {reslist ? (
          <TabPane tab="menu目录" key="key">
            <div>
              <Tree
                checkable
                expandedKeys={expandedKeys}
                autoExpandParent={autoExpandParent}
                checkedKeys={checkedKeys}
                selectedKeys={selectedKeys}
                onExpand={onExpand}
                onCheck={treecheck}
                onSelect={onSelectTree}
              >
                {renderMethod(reslist)}
              </Tree>
            </div>
          </TabPane>
        ) : (
          <TabPane tab="无数据" key={1}>
            无数据
          </TabPane>
        )}
      </Tabs>
    </Modal>
  );
});
class roleManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      addVisible: false,
      // visible: false,
      updateVisible: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: "",
      roleInformation: null,

      roleVisible: false,
      treeSelectValue: [],
      selectValue: "",
      // tree
      expandedKeys: [],
      autoExpandParent: true,
      checkedKeys: [],
      selectedKeys: [],
      isActive: false
    };
    this.columns = [
      {
        title: "角色编号",
        width: 130,
        dataIndex: "roleCode",
        render: (text, record) => this.renderColumns(text, record, "roleCode")
      },
      {
        title: "角色名称",
        width: 140,
        dataIndex: "roleName",
        render: (text, record) => this.renderColumns(text, record, "roleName")
      },
      {
        title: "角色描述",
        dataIndex: "roleDesc",
        render: (text, record) => this.renderColumns(text, record, "roleDesc")
      },
      {
        title: "创建时间",
        width: 145,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        width: 170,
        dataIndex: "operation",
        render: (text, record) => {
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.roleAuthorize(record);
                }}
                className="padright"
              >
                <span />
                授权
              </a>
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.handleDelOk = this.handleDelOk.bind(this);
    this.Treecheck = this.Treecheck.bind(this);
    this.onExpand = this.onExpand.bind(this);
    this.onSelectTree = this.onSelectTree.bind(this);
    this.onTreeSelectChange = this.onTreeSelectChange.bind(this);
    this.getCheckedId = this.getCheckedId.bind(this);
    this.roleOk = this.roleOk.bind(this);
    this.roleCancel = this.roleCancel.bind(this);
    this.roleAuthorize = this.roleAuthorize.bind(this);
    this.findNode = this.findNode.bind(this);
  }

  getCheckedId(checkedList, resultList) {
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i].children.length === 0) {
        resultList.push(checkedList[i].id);
      }
      if (checkedList[i].children.length > 0) {
        this.getCheckedId(checkedList[i], resultList);
      }
    }
  }

  // 查出选中的ID 展示授权弹窗， 并设置选中的状态
  findNode(datas, key, resultList) {
    let index = 0;
    while (index < datas.length) {
      const temp = datas[index];
      if (temp.menuId == key) {
        resultList.push(temp);
      }
      if (temp.childMenus) {
        if (temp.childMenus.length > 0) {
          this.findNode(temp.childMenus, key, resultList);
        }
      }
      index++;
    }
  }

  roleAuthorize(data) {
    const { actions } = this.props;
    actions.get(data.roleId, null, "roleMenus");
    if (this.timer) {
      clearTimeout(this.timer);
    }
    // this.timer = setTimeout(() => {
    //   this.setState({
    //     checkedKeys: selectData ? selectData.menuIds : []
    //   }, () => {
    //     console.log("111", selectData, this.state.checkedKeys)
    //   });
    // }, 1000)
    this.timer = setTimeout((originList, showListMenuIds, resultList) => {
      const { menuTreeManage, roleMenus } = this.props;
      originList = menuTreeManage.data;
      showListMenuIds = roleMenus.data.menuIds;
      resultList = [];
      // 根据后台提供的ID查出数据源中的对象
      for (let j = showListMenuIds.length - 1; j >= 0; j--) {
        this.findNode(originList, showListMenuIds[j], resultList);
      }
      // 已知树状结构层级时
      // 第一级父树
      const halfShowListId = [];
      let child = {};
      let child1 = {};
      for (const m of resultList) {
        // 没有子树的选项
        if (m.childMenus) {
          // 可能半选状态
          child = m.childMenus.filter(item => showListMenuIds.indexOf(item.menuId) === -1); //
          if (child.length !== 0) {
            halfShowListId.push(m.menuId);
          }
          for (const n of m.childMenus) {
            // 找最外层的（三层的第一层）
            if (n.childMenus) {
              child1 = n.childMenus.filter(item => showListMenuIds.indexOf(item.menuId) === -1); //
              if (child1.length !== 0) {
                halfShowListId.push(m.menuId);
              }
            }
          }
        }
      }

      let halfShowListIdOnly = [];
      let showLastList = [];

      if (halfShowListId.length !== 0) {
        halfShowListIdOnly = [...new Set(halfShowListId)]; //  去重
        const parentItem = resultList.filter(
          itemId => halfShowListIdOnly.indexOf(itemId.menuId) !== -1
        );

        if (parentItem.length !== 0) {
          for (const n of parentItem) {
            halfShowListIdOnly.push(n.menuId);
          }
        }
        showLastList = showListMenuIds.filter(itemId => halfShowListIdOnly.indexOf(itemId) === -1);
      } else {
        showLastList = showListMenuIds; // 全树时的
      }
      this.setState({
        checkedKeys: {
          checked: showLastList,
          halfChecked: halfShowListIdOnly
        }
      });
    }, 600);
    const dat = [];
    if (data.roles) {
      for (let i = 0; i < data.roles.length; i++) {
        dat.push(data.roles[i].id); // 获取当前用户拥有的所有角色id
      }
    }
    this.setState({
      roleVisible: true,
      nowRes: data.roleId,
      resourseId: dat
    }); // save the id of this user
  }

  roleOk() {
    const { isActive, treeSelectValue, nowRes } = this.state;
    const { actions } = this.props;
    this.setState({ roleVisible: false });
    if (isActive) {
      // 判断是否有更改
      const data = {
        menuIds: treeSelectValue,
        roleId: nowRes
      };
      actions.add(data, null, "roleAuthorize");
      this.setState({ checkedKeys: [] });
    } else {
      message.info("授权成功");
    }
  }

  roleCancel() {
    this.setState({ roleVisible: false });
    this.setState({ targetKeys: [], checkedKeys: [] });
  }

  // treeSearch
  // onChangeSearch(e) {
  //   const value = e.target.value;
  //   const expandedKeys = dataList
  //     .map(item => {
  //       if (item.title.indexOf(value) > -1) {
  //         return getParentKey(item.key, gData);
  //       }
  //       return null;
  //     })
  //     .filter((item, i, self) => item && self.indexOf(item) === i);
  //   this.setState({
  //     expandedKeys,
  //     searchValue: value,
  //     autoExpandParent: true
  //   });
  // }

  onExpand(expandedKeys) {
    this.setState({
      expandedKeys,
      autoExpandParent: false
    });
  }

  Treecheck(checkedKeys, { halfCheckedKeys, checkedNodes, node, event }) {
    this.setState({ checkedKeys }); // 替换
    const checkList = checkedKeys.concat(halfCheckedKeys);
    this.setState({
      treeSelectValue: checkList,
      isActive: true
    });
  }

  onSelectTree(selectedKeys, info) {
    this.setState({ selectedKeys });
  }

  onTreeSelectChange(value, label, extra) {
    this.setState({ treeSelectValue: value });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.RoleManage.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.RoleManage.pageBean.total,
          current: nextProps.RoleManage.pageBean.page,
          pageSize: nextProps.RoleManage.pageBean.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.get(1, null, "roleManage");
    actions.get(null, null, "menuTreeManage");
  }

  componentDidUpdate() {
    const { actions, updateStatus, delStatus, addStatus, otherStatus, RoleManage } = this.props;
    const { currentId } = this.state;

    if (updateStatus && updateStatus === 1) {
      message.success("编辑成功");
      ReactDOM.findDOMNode(this.refs.roleName).value = "";
      actions.get(RoleManage.pageBean.page, null, "roleManage");
    } else if (delStatus && delStatus === 1) {
      message.success("删除成功");
      ReactDOM.findDOMNode(this.refs.roleName).value = "";
      if (
        RoleManage.pageBean.total % RoleManage.pageBean.size === 1 &&
        RoleManage.pageBean.totalPage > 1 &&
        RoleManage.pageBean.page > 1
      ) {
        actions.get(RoleManage.pageBean.page - 1, null, "roleManage");
      } else {
        actions.get(RoleManage.pageBean.page, null, "roleManage");
      }
    } else if (addStatus && addStatus === 1) {
      message.success("新增成功");
      ReactDOM.findDOMNode(this.refs.roleName).value = "";
      actions.get(RoleManage.pageBean.page, null, "roleManage");
    } else if (otherStatus && otherStatus === 1) {
      message.success("授权成功");
      ReactDOM.findDOMNode(this.refs.roleName).value = "";
      actions.get(RoleManage.pageBean.page, null, "roleManage");
    }
  }

  // unmount
  componentWillUnmount() {
    if (this.timer) {
      clearTimeout(this.timer); // 卸载定时器
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { searchItem } = this.state;
    const { actions } = this.props;
    this.setState({ loading: true });

    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    if (searchItem.roleName === roleName) {
      actions.search(pagination.current, searchItem, "roleManage");
    } else {
      actions.get(pagination.current, null, "roleManage");
    }
  }

  renderColumns(text, record, column) {
    return text;
  }

  handleDelOk(record) {
    const { actions } = this.props;
    const roleId = record.roleId;
    actions.del(roleId, "roleManage");
  }

  saveFormRef(form) {
    this.form = form;
  }

  saveUpdateFormRef(forms) {
    this.forms = forms;
  }

  // 点击编辑弹框
  showEditModal(record) {
    const { actions } = this.props;
    actions.get(record.roleId, null, "sysroleFind");
    this.form.resetFields();
    this.setState({
      roleInformation: record,
      updateVisible: true
    });
  }

  // update
  handleUpdataOk(e) {
    const { actions } = this.props;
    const { roleInformation } = this.state;
    const forms = this.forms;

    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.roleId = roleInformation.roleId;
      values.id = roleInformation.id;
      actions.update(values, "roleManage");
      this.setState({
        updateVisible: false
      });
      forms.resetFields();
    });
  }

  search() {
    const { actions } = this.props;
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    this.setState({
      searchItem: {
        roleName
      }
    });
    const params = { roleName };
    actions.search(null, params, "roleManage");
  }

  // 点击新增弹框
  showAddModal() {
    this.setState({
      addVisible: true
    });
  }

  handleOk(e) {
    const { actions } = this.props;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      actions.add(values, null, "roleManage");
      this.setState({
        addVisible: false
      });
      form.resetFields();
    });
  }

  handleCancel(e) {
    this.setState({
      addVisible: false,
      updateVisible: false
    });
    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  render() {
    const { RoleManage, components, SysroleFind, menuTreeManage } = this.props;
    const {
      addVisible,
      updateVisible,
      pagination,
      loading,
      treeSelectValue,
      roleVisible,
      expandedKeys,
      autoExpandParent,
      checkedKeys,
      selectedKeys
    } = this.state;

    if (RoleManage.length > 0) {
      RoleManage.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          minHeight: "78vh",
          textAlign: "left",
          width: "83vw",
          padding: "10px"
        }}
      >
        <div
          style={{
            textAlign: "left",
            height: "60px",
            lineHeight: "60px",
            padding: "10px",
            borderBottom: "1px solid #ccc"
          }}
        >
          角色列表
        </div>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Row style={{ marginTop: "20px" }} type="flex" justify="space-between">
            <Col span={8}>
              角色名称：
              <Input placeholder="请输入角色名称" style={{ width: "70%" }} ref="roleName" />
            </Col>
            <Col span={6} style={{ textAlign: "right" }}>
              <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: 10 }}>
                查询
              </Button>
              <Button type="primary" onClick={this.showAddModal.bind(this)}>
                新增
              </Button>
            </Col>
          </Row>
        </div>
        <NewForm
          ref={this.saveFormRef.bind(this)}
          addVisible={addVisible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.handleOk.bind(this)}
          components={components}
        />
        <UpdateForm
          ref={this.saveUpdateFormRef.bind(this)}
          updateVisible={updateVisible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.handleUpdataOk.bind(this)}
          list={SysroleFind.length !== 0 ? SysroleFind.data : SysroleFind}
        />
        <Table
          bordered
          size="small"
          columns={this.columns}
          locale={{ emptyText: "暂无数据..." }}
          dataSource={RoleManage.data}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />

        <Setrole
          treeSelectValue={treeSelectValue}
          onTreeSelectChange={this.onTreeSelectChange}
          visible={roleVisible}
          onCancel={this.roleCancel}
          onCreate={this.roleOk}
          reslist={menuTreeManage ? menuTreeManage.data : []}
          treecheck={this.Treecheck}
          // onChangeSearch={this.onChangeSearch}
          expandedKeys={expandedKeys}
          autoExpandParent={autoExpandParent}
          checkedKeys={checkedKeys}
          selectedKeys={selectedKeys}
          onExpand={this.onExpand}
          onSelectTree={this.onSelectTree}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Login: state.login.get("logininfo"),
    RoleManage: state.SystemManage.get("roleManageData"),
    SysroleFind: state.SystemManage.get("sysroleFindData"),
    roleMenus: state.SystemManage.get("roleMenusData"),
    menuTree: state.SystemManage.get("menuTreeData"),
    menuTreeManage: state.SystemManage.get("menuTreeManageData"),
    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(roleManage);
