import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { Table, Input, Select, Modal, Button, Row, Col, message, Tabs, DatePicker } from "antd";
import * as action from "../../../actions/systemManageAction";
import "./index.css";

const { Option } = Select;
const OperationLogDetail = props => {
  const { detailVisible, dataSource, detailColumns, that, onCancel, loadingLogDetail } = props;
  return (
    <Modal
      maskClosable={false}
      width="850px"
      visible={detailVisible}
      title="日志详情"
      footer={null}
      // okText="确定"
      // cancelText="取消"
      onCancel={onCancel}
      // onOk={onCreate}
    >
      <div
        style={{
          width: "830px"
        }}
      >
        <Table
          bordered
          size="small"
          columns={detailColumns}
          locale={{ emptyText: "暂无数据..." }}
          dataSource={dataSource}
          loading={loadingLogDetail}
          pagination={false}
        />
      </div>
    </Modal>
  );
};

class OperationLog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {
        queryStr: "",
        actionType: "ALL",
        startTime: "",
        endTime: ""
      },
      detailVisible: false,
      confirmLoading: false,
      updataData: {},
      roleInformation: null,
      selectValue: "",
      currentDetail: [],
      // datetime
      startValue: null,
      endValue: null,
      endOpen: false,
      detailInformation: [],
      loadingLogDetail: false
    };
    this.detailColumns = [
      {
        key: "attrName",
        title: "属性",
        width: 100,
        dataIndex: "attrName",
        render: (text, record) => this.renderColumns(text, record, "attrName")
      },
      {
        key: "oldValue",
        title: "旧值",
        width: 300,
        dataIndex: "oldValue",
        render: (text, record) => this.renderColumns(text, record, "oldValue")
      },
      {
        key: "newValue",
        title: "新值",
        className: "newValueLog",
        width: 300,
        dataIndex: "newValue",
        render: (text, record) => this.renderColumns(text, record, "newValue")
      }
    ];
    this.columns = [
      {
        title: "操作类型",
        width: 100,
        dataIndex: "actionType",
        render: (text, record) => this.renderColumns(text, record, "actionType")
      },
      {
        title: "操作人",
        width: 100,
        dataIndex: "createUser",
        render: (text, record) => this.renderColumns(text, record, "createUser")
      },
      {
        title: "操作时间",
        width: 150,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "描述",
        dataIndex: "actionDesc",
        render: (text, record) => this.renderColumns(text, record, "actionDesc")
      },
      {
        title: "操作详情",
        width: 140,
        dataIndex: "operation",
        render: (text, record) => {
          const { online } = record; // 当前行数据
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showDetailModal(record);
                }}
                className="padright"
              >
                <span />
                详情
              </a>
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showDetailModal = this.showDetailModal.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    // datetime
    this.disabledStartDate = this.disabledStartDate.bind(this);
    this.disabledEndDate = this.disabledEndDate.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onStartChange = this.onStartChange.bind(this);
    this.onEndChange = this.onEndChange.bind(this);
    this.handleStartOpenChange = this.handleStartOpenChange.bind(this);
    this.handleEndOpenChange = this.handleEndOpenChange.bind(this);
  }

  showDetailModal(record) {
    const { actions } = this.props;
    actions.get(record.id, null, "operationLogDetail");
    this.setState({
      detailVisible: true,
      currentDetail: record,
      loadingLogDetail: true
    });
    // origin test
    setTimeout(() => {
      const { operationLogDetail } = this.props;
      this.setState({
        detailInformation: operationLogDetail.data,
        loadingLogDetail: false
      });
    }, 800);
  }

  // datetime
  disabledStartDate(startValue) {
    const { endValue } = this.state;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }

  disabledEndDate(endValue) {
    const { startValue } = this.state;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.valueOf() <= startValue.valueOf();
  }

  onChange(field, value) {
    this.setState({
      [field]: value
    });
  }

  onStartChange(value) {
    this.onChange("startValue", value);
  }

  onEndChange(value) {
    this.onChange("endValue", value);
  }

  handleStartOpenChange(open) {
    if (!open) {
      this.setState({ endOpen: true });
    }
  }

  handleEndOpenChange(open) {
    this.setState({ endOpen: open });
  }

  renderColumns(text, record, column) {
    if (column === "newValue") {
      if (text === "null") {
        return "-";
      }
    }
    if (column === "oldValue") {
      if (text === "null") {
        return "-";
      }
    }
    return text;
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.operationLog.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.operationLog.pageBean.total,
          current: nextProps.operationLog.pageBean.page,
          pageSize: nextProps.operationLog.pageBean.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.get(1, null, "operationLog");
  }

  componentDidUpdate() {
    const { actions, updateStatus, delStatus, addStatus, otherStatus, operationLog } = this.props;
    const { searchItem } = this.state;
    if (updateStatus && updateStatus === 1) {
      message.success("编辑成功");
      if (searchItem.queryStr || searchItem.startTime || searchItem.endTime) {
        actions.get(1, searchItem, "operationLog");
      } else {
        actions.get(operationLog.pageBean.page, null, "operationLog");
      }
    } else if (delStatus && delStatus === 1) {
      message.success("删除成功");
      if (searchItem.queryStr || searchItem.startTime || searchItem.endTime) {
        actions.get(1, searchItem, "operationLog");
      } else {
        actions.get(operationLog.pageBean.page, null, "operationLog");
      }
    } else if (addStatus && addStatus === 1) {
      message.success("新增成功");
      if (searchItem.queryStr || searchItem.startTime || searchItem.endTime) {
        actions.get(1, searchItem, "operationLog");
      } else {
        actions.get(operationLog.pageBean.page, null, "operationLog");
      }
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const { searchItem, selectValue } = this.state;
    this.setState({ loading: true });
    if (searchItem.queryStr || searchItem.startTime || searchItem.endTime) {
      actions.search(pagination.current, searchItem, "operationLog");
    } else if (selectValue !== "ALL" && selectValue !== "") {
      actions.search(pagination.current, searchItem, "operationLog");
    } else if (searchItem.actionType === "ALL") {
      actions.get(pagination.current, null, "operationLog");
    }
  }

  saveFormRef(form) {
    this.form = form;
  }

  search() {
    const { actions } = this.props;
    const { searchItem, startValue, endValue } = this.state;
    const startDate = startValue ? new Date(startValue) : "";
    const endDate = endValue ? new Date(endValue) : "";
    const startTime = startValue
      ? `${startDate.getFullYear()}-${startDate.getMonth() +
          1}-${startDate.getDate()} ${startDate.getHours()}:${startDate.getMinutes()}:${startDate.getSeconds()}`
      : "";
    // const startTime = startValue
    //   ? startDate.getFullYear() +
    //     "-" +
    //     (startDate.getMonth() + 1) +
    //     "-" +
    //     startDate.getDate() +
    //     " " +
    //     startDate.getHours() +
    //     ":" +
    //     startDate.getMinutes() +
    //     ":" +
    //     startDate.getSeconds()
    //   : "";
    const endTime = endValue
      ? `${endDate.getFullYear()}-${endDate.getMonth() +
          1}-${endDate.getDate()} ${endDate.getHours()}:${endDate.getMinutes()}:${endDate.getSeconds()}`
      : "";
    // const endTime = endValue
    //   ? endDate.getFullYear() +
    //     "-" +
    //     (endDate.getMonth() + 1) +
    //     "-" +
    //     endDate.getDate() +
    //     " " +
    //     endDate.getHours() +
    //     ":" +
    //     endDate.getMinutes() +
    //     ":" +
    //     endDate.getSeconds()
    //   : "";
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    this.setState({
      searchItem: {
        queryStr: roleName ? (roleName === undefined ? "" : roleName) : "",
        actionType: searchItem.actionType,
        startTime: startValue ? startTime : "",
        endTime: endValue ? endTime : ""
      }
    });
    const params = {
      queryStr: roleName ? (roleName === undefined ? "" : roleName) : "",
      actionType: searchItem.actionType,
      startTime: startValue ? startTime : "",
      endTime: endValue ? endTime : ""
    };
    actions.search(1, params, "operationLog");
  }

  // able disable  changeavailable
  handleSelectChange(value) {
    this.setState({
      selectValue: value,
      searchItem: {
        actionType: value
      }
    });
  }

  handleCancel(e) {
    this.setState({
      detailVisible: false
    });
  }

  render() {
    const { operationLog } = this.props;
    const {
      startValue,
      endValue,
      endOpen,
      pagination,
      loading,
      loadingLogDetail,
      detailVisible,
      detailInformation
    } = this.state;
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "row"
        }}
      >
        <div
          style={{
            minHeight: "78vh",
            flex: 6,
            textAlign: "left",
            padding: "10px"
          }}
        >
          <div
            style={{
              textAlign: "left",
              height: "38px",
              padding: "10px",
              lineHeight: "26px",
              borderBottom: "1px solid #ccc",
              marginBottom: "10px",
              marginTop: "10px"
            }}
          >
            操作日志
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "20px" }} type="flex" justify="space-between">
              <Col span={6}>
                查询条件：
                <Input
                  placeholder="请输入操作人或操作描述"
                  style={{ width: "70%" }}
                  ref="roleName"
                />
              </Col>
              <Col span={4}>
                类型：
                <Select
                  // allowClear = {true}
                  defaultValue="ALL"
                  style={{ width: "75%" }}
                  onChange={this.handleSelectChange}
                >
                  <Option value="ALL">所有类型</Option>
                  <Option value="ADD">ADD</Option>
                  <Option value="DELETE">DELETE</Option>
                  <Option value="UPDATE">UPDATE</Option>
                  <Option value="OTHER">OTHER</Option>
                </Select>
              </Col>
              <Col span={10.5}>
                <span style={{ paddingRight: "3px" }}>操作时间:</span>
                <DatePicker
                  disabledDate={this.disabledStartDate}
                  // locale={locale}
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  value={startValue}
                  placeholder="开始时间"
                  onChange={this.onStartChange}
                  onOpenChange={this.handleStartOpenChange}
                />
                <span style={{ padding: "0 2px" }}>到</span>
                <DatePicker
                  disabledDate={this.disabledEndDate}
                  showTime
                  format="YYYY-MM-DD HH:mm:ss"
                  value={endValue}
                  placeholder="截止时间"
                  onChange={this.onEndChange}
                  open={endOpen}
                  onOpenChange={this.handleEndOpenChange}
                />
              </Col>
              <Col span={1.5} style={{ textAlign: "right" }}>
                <Button type="primary" onClick={this.search.bind(this)}>
                  查询
                </Button>
              </Col>
            </Row>
          </div>
          <Table
            bordered
            size="small"
            columns={this.columns}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={operationLog.data}
            pagination={pagination}
            loading={loading}
            onChange={this.handlePageChange.bind(this)}
          />
          <OperationLogDetail
            that={this}
            loadingLogDetail={loadingLogDetail}
            detailVisible={detailVisible}
            detailColumns={this.detailColumns}
            dataSource={detailInformation ? detailInformation : []}
            onCancel={this.handleCancel.bind(this)}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Login: state.login.get("logininfo"),
    operationLog: state.SystemManage.get("operationLogData"),
    operationLogDetail: state.SystemManage.get("operationLogDetailData"),
    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus")
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OperationLog);
