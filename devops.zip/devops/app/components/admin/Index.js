import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Layout, Menu, Breadcrumb, Icon } from "antd";
import * as action from "../../actions/systemManageAction";
import ProjectApproval from "./projectManage/ProjectApproval";
import ProjectApproving from "./projectApproving/Index";
import SystemIntegration from "./systemIntegration/Index";
import MechanismManage from "./MechanismManage/Index";
import PersonManage from "./personManage/Index";
import RoleManage from "./roleManage/Index";
import MenuManage from "./menuManage/Index";
import OperationLog from "./operationLog";
import NotFound from "../commons/notFound";

const { Content, Footer, Sider } = Layout;
const SubMenu = Menu.SubMenu;
class LayoutComponent extends React.Component {
  constructor(props) {
    const adminKey = JSON.parse(sessionStorage.getItem("adminKey"));
    let stringArr = "";
    const subStringArr = [];
    if (props.userMenuAllData.length !== 0 && props.userMenuAllData.data) {
      const menuList = props.userMenuAllData.data[0].childMenus;
      stringArr =
        menuList[0].childMenus && menuList[0].childMenus.length !== 0
          ? menuList[0].childMenus[0].menuUrl
          : menuList[0].menuUrl;
      const menuSubmenuKey = menuList.filter(item => {
        if (item.childMenus.length !== 0) {
          const childKey = item.childMenus.filter(
            itemChildMenus => itemChildMenus.menuUrl === stringArr
          );
          if (childKey.length !== 0) {
            return true;
          }
        } else {
          return item.menuUrl === stringArr;
        }
      });
      subStringArr.push(menuSubmenuKey[0].menuUrl);
    }
    const aaa = adminKey
      ? adminKey !== null
        ? adminKey.key !== ""
          ? adminKey.key
          : stringArr.length !== 0
          ? stringArr
          : "admin/1"
        : "admin/1"
      : stringArr.length !== 0
      ? stringArr
      : "admin/1";

    super(props);
    this.state = {
      collapsed: false,
      // key: adminKey !== null ? adminKey.key : stringArr.length !== 0 ? stringArr : "admin/1",
      // openKeys:
      //   adminKey !== null
      //     ? adminKey.openSubKey
      //     : subStringArr.length !== 0
      //       ? subStringArr
      //       : ["admin/sub1"],
      // openSubmenuKey:
      //   adminKey !== null
      //     ? adminKey.openSubKey
      //     : subStringArr.length !== 0
      //       ? subStringArr
      //       : ["admin/sub1"],
      // key:
      //   adminKey !== null
      //     ? adminKey.key !== ""
      //       ? adminKey.key
      //       : stringArr.length !== 0
      //         ? stringArr
      //         : "admin/1"
      //     : "admin/1",
      // openKeys:
      //   adminKey !== null
      //     ? adminKey.openSubKey !== ""
      //       ? adminKey.openSubKey
      //       : subStringArr.length !== 0
      //         ? subStringArr
      //         : ["admin/sub1"]
      //     : ["admin/sub1"],
      // openSubmenuKey:
      //   adminKey !== null
      //     ? adminKey.openSubKey !== ""
      //       ? adminKey.openSubKey
      //       : subStringArr.length !== 0
      //         ? subStringArr
      //         : ["admin/sub1"]
      //     : ["admin/sub1"],

      key: adminKey
        ? adminKey !== null
          ? adminKey.key !== ""
            ? adminKey.key
            : stringArr.length !== 0
            ? stringArr
            : "admin/1"
          : "admin/1"
        : stringArr.length !== 0
        ? stringArr
        : "admin/1",

      openKeys: adminKey
        ? adminKey !== null
          ? adminKey.openSubKey !== ""
            ? adminKey.openSubKey
            : subStringArr.length !== 0
            ? subStringArr
            : ["admin/sub1"]
          : ["admin/sub1"]
        : subStringArr.length !== 0
        ? subStringArr
        : ["admin/sub1"],
      openSubmenuKey:
        adminKey !== null || adminKey
          ? adminKey.openSubKey !== ""
            ? adminKey.openSubKey
            : subStringArr.length !== 0
            ? subStringArr
            : ["admin/sub1"]
          : subStringArr.length !== 0
          ? subStringArr
          : ["admin/sub1"]
    };
    this.set = [
      "机构管理",
      "人员管理",
      "角色管理",
      "菜单管理",
      "操作日志",
      "项目立项",
      "项目审批",
      "系统集成"
    ];
    this.onCollapse = this.onCollapse.bind(this);
    this.getData = this.getData.bind(this);
  }

  componentDidMount() {
    // console.log("userMenuAllData", this.props, this.props.userMenuAllData);
    // if(this.props.userMenuAllData.length !== 0 && this.props.userMenuAllData.data){
    //   let menuList = this.props.userMenuAllData.data[0].childMenus;
    //   console.log("defaultSelectedKeys11",menuList);
    //   let stringArr = menuList[0].childMenus && menuList[0].childMenus.length !== 0 ? menuList[0].childMenus[0].menuUrl : menuList[0].menuUrl;
    //   console.log("componentDidMountdefaultSelectedKeys11", stringArr);
    //   this.setState({
    //     key: stringArr
    //   })
    // }
    // let firstKey = {key: this.state.key};
    // this.getData(firstKey);
  }

  // componentWillUnmount() {
  //   sessionStorage.setItem("adminKey", JSON.stringify({ key: "", openSubKey: "" }));
  // }

  onCollapse(collapsed) {
    this.setState({ collapsed });
  }

  // 左侧菜单的折叠
  onOpenChange(openKeysList) {
    const { openKeys } = this.state;
    const arr = ["admin/sub1", "admin/sub2", "admin/sub3"];
    const latestOpenKey = openKeysList.find(key => openKeys.indexOf(key) === -1);
    if (arr.indexOf(latestOpenKey) === -1) {
      this.setState({ openKeys: openKeysList });
    } else {
      this.setState({
        openKeys: latestOpenKey ? [latestOpenKey] : []
      });
    }
  }

  getData(item) {
    const { userMenuAllData } = this.props;
    const openSubmenuKey = [];
    if (userMenuAllData.length !== 0 && userMenuAllData.data) {
      if (item) {
        const itemKey = item.key;
        const menuList = userMenuAllData.data[0].childMenus;
        const menuSubmenuKey = menuList.filter(menuListItem => {
          // return item.menuUrl === "admin/sub2"
          if (menuListItem.childMenus.length !== 0) {
            const childKey = menuListItem.childMenus.filter(
              itemChildMenus => itemChildMenus.menuUrl === itemKey
            );
            if (childKey.length !== 0) {
              return true;
            }
          } else {
            return menuListItem.menuUrl === itemKey;
          }
        });
        openSubmenuKey.push(menuSubmenuKey[0].menuUrl);
      }
    }
    this.setState({ key: item.key });
    sessionStorage.setItem(
      "adminKey",
      JSON.stringify({ key: item.key, openSubKey: openSubmenuKey })
    );
    // sessionStorage.setItem("adminKey", item.key);
  }

  render() {
    const { userMenuAllData } = this.props;
    const { key, openSubmenuKey, openKeys, collapsed } = this.state;

    if (userMenuAllData.length !== 0 && userMenuAllData.data) {
      const menuList = userMenuAllData.data[0].childMenus;
      this.menuShowList = menuList.map(menuItem => {
        if (menuItem.childMenus && menuItem.childMenus.length !== 0) {
          return (
            <SubMenu
              key={menuItem.menuUrl}
              title={
                <span>
                  <Icon type={menuItem.menuIcon} />
                  <span>{menuItem.menuName}</span>
                </span>
              }
            >
              {menuItem.childMenus.length !== 0
                ? menuItem.childMenus.map(menuChild => {
                    return (
                      <Menu.Item key={menuChild.menuUrl}>
                        <Icon type={menuChild.menuIcon} />
                        <span>{menuChild.menuName}</span>
                      </Menu.Item>
                    );
                  })
                : ""}
            </SubMenu>
          );
        } else if (menuItem.childMenus === "undefind" || menuItem.childMenus.length === 0) {
          return (
            <Menu.Item key={menuItem.menuUrl}>
              <Icon type={menuItem.menuIcon} />
              <span>{menuItem.menuName}</span>
            </Menu.Item>
          );
        } else {
          this.menuShowList = "";
        }
      });
      const stringArr =
        menuList[0].childMenus && menuList[0].childMenus.length !== 0
          ? menuList[0].childMenus[0].menuUrl
          : menuList[0].menuUrl;
      const defaultStr = [];
      defaultStr.push(stringArr);
      this.defaultSelectedKeys = menuList && menuList.length !== 0 ? defaultStr : [""];
      if (key.length !== 0) {
        const menuSubmenuKey = menuList.filter(item => {
          // return item.menuUrl === "admin/sub2"
          if (item.childMenus.length !== 0) {
            const childKey = item.childMenus.filter(
              itemChildMenus => itemChildMenus.menuUrl === key
            );
            if (childKey.length !== 0) {
              return true;
            }
          } else {
            return item.menuUrl === key;
          }
        });
        // let openSubmenuKey = menuSubmenuKey[0].menuUrl;
      }
    }

    return (
      <div className="right-body-container" style={{ minHeight: "100vh" }}>
        {/* <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}> */}
        <Sider>
          <Menu
            style={{ paddingBottom: "20px" }}
            // defaultSelectedKeys= {this.defaultSelectedKeys !== "undefind" ? this.defaultSelectedKeys : ["admin/1"] }
            defaultSelectedKeys={[key]}
            defaultOpenKeys={openSubmenuKey}
            selectedKeys={[key]}
            openKeys={openKeys}
            onOpenChange={this.onOpenChange.bind(this)}
            onClick={this.getData}
            mode="inline"
            theme="dark"
            inlineCollapsed={collapsed}
          >
            {this.menuShowList}
            {/* <SubMenu
              key="sub1"
              title={
                <span>
                  <Icon type="user" />
                  <span>系统管理</span>
                </span>
              }
            >
              <Menu.Item key="1">
                <Icon type="usergroup-add" />
                <span>机构管理</span>
              </Menu.Item>
              <Menu.Item key="2">
                <Icon type="user-add" />
                <span>人员管理</span>
              </Menu.Item>
              <Menu.Item key="3">
                <Icon type="compass" />
                <span>角色管理</span>
              </Menu.Item>
              <Menu.Item key="4">
                <Icon type="menu-fold" />
                <span>菜单管理</span>
              </Menu.Item>
              <Menu.Item key="5">
                <Icon type="profile" />
                <span>操作日志</span>
              </Menu.Item>
            </SubMenu>
            <Menu.Item key="sub2">
              <Icon type="disconnect" />
              <span>系统集成</span>
            </Menu.Item>
            <SubMenu
              key="sub3"
              title={
                <span>
                  <Icon type="desktop" />
                  <span>项目管理</span>
                </span>
              }
            >
              <Menu.Item key="6">
                <Icon type="schedule" />
                <span>项目立项</span>
              </Menu.Item>
              <Menu.Item key="7">
                <Icon type="printer" />
                <span>项目审批</span>
              </Menu.Item>
            </SubMenu> */}
          </Menu>
        </Sider>
        <div className="right-div-body">
          <Content style={{ margin: "0 16px" }}>
            <Breadcrumb style={{ margin: "16px 0" }}>
              {/* <Breadcrumb.Item>系统管理</Breadcrumb.Item>
              <Breadcrumb.Item>{this.set[this.state.key - 1]}</Breadcrumb.Item> */}
            </Breadcrumb>
            <div style={{ padding: 20, background: "#fff", minHeight: 360 }}>
              {key === "admin/1" ? (
                <MechanismManage />
              ) : key === "admin/2" ? (
                <PersonManage />
              ) : key === "admin/3" ? (
                <RoleManage />
              ) : key === "admin/4" ? (
                <MenuManage />
              ) : key === "admin/5" ? (
                <OperationLog />
              ) : key === "admin/6" ? (
                <ProjectApproval />
              ) : key === "admin/7" ? (
                <ProjectApproving />
              ) : key === "admin/sub2" ? (
                <SystemIntegration />
              ) : (
                <NotFound />
              )}
            </div>
          </Content>
          <Footer style={{ textAlign: "center" }} />
        </div>
      </div>
    );
  }
}
// export default LayoutComponent;
const mapStateToProps = state => {
  return {
    userMenuAllData: state.SystemManage.get("userMenuAllData"),

    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LayoutComponent);
