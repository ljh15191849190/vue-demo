import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { Table, Input, Modal, Form, Popconfirm, Row, Col, message, Tree, Menu, Icon } from "antd";
import * as action from "../../../actions/systemManageAction";
import RULES from "../../../utils/Validation";

const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;
const UpdateForm = Form.create()(props => {
  const { updateVisible, onCreate, onCancel, form, list } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal maskClosable={false}
      visible={updateVisible}
      title="修改机构"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="机构编号：">
          {getFieldDecorator("orgCode", {
            rules: RULES.Rule_code,
            initialValue: list ? list.orgCode : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="机构名称：">
          {getFieldDecorator("orgName", {
            rules: RULES.Rule_name,
            initialValue: list ? list.orgName : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="机构描述">
          {getFieldDecorator("orgDesc", {
            initialValue: list ? list.orgDesc : ""
          })(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const NewForm = Form.create()(props => {
  const { addVisible, onCreate, onCancel, form } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal maskClosable={false}
      visible={addVisible}
      title="新增机构"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="机构编号：">
          {getFieldDecorator("orgCode", {
            rules: RULES.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="机构名称：">
          {getFieldDecorator("orgName", {
            rules: RULES.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="机构描述">
          {getFieldDecorator("orgDesc", {})(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

class OrgManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      addVisible: false,
      updateVisible: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: "",
      roleInformation: null,
      selectedKeys: [],
      treeData: [],
      currentId: 1,
      currentSelected: null,
      expandedKeys: [],
      loadedKeys: [],
      autoExpandParent: true,
      originTree: []
    };
    this.columns = [
      {
        title: "机构编号",
        width: 100,
        dataIndex: "orgCode",
        render: (text, record) => this.renderColumns(text, record, "orgCode")
      },
      {
        title: "机构名称",
        width: 100,
        dataIndex: "orgName",
        render: (text, record) => this.renderColumns(text, record, "orgName")
      },
      {
        title: "机构描述",
        dataIndex: "orgDesc",
        render: (text, record) => this.renderColumns(text, record, "orgDesc")
      },
      {
        title: "创建时间",
        width: 95,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        width: 120,
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.handleDelOk = this.handleDelOk.bind(this);
    this.handleOk = this.handleOk.bind(this);
    this.onLoadData = this.onLoadData.bind(this);
    this.renderTreeNodes = this.renderTreeNodes.bind(this);
    this.rightClick = this.rightClick.bind(this);
    this.onExpand = this.onExpand.bind(this);
    this.onTreeSelect = this.onTreeSelect.bind(this);
    this.onSelect = this.onSelect.bind(this);
    this.handleMenuClick = this.handleMenuClick.bind(this);
    this.DOMClick = this.DOMClick.bind(this);
  }

  // OrganizationAll
  rightClick(info) {
    this.setState({ selectedKeys: [info.node.props.eventKey], currentSelected: info.node.props });
    this.renderCm(info);
  }

  onTreeSelect(selectedKeys, event) {
    // this.setState({
    //   currentSelected: [event.node.props]
    // });
    this.setState({
      currentParentId: event.node.props.dataRef.parentOrgId,
      currentId: selectedKeys,
      selectedKeys
    });
    // 请求更新数据  机构信息 列表
    if (selectedKeys.length !== 0) {
      const { actions } = this.props;
      actions.get(null, { id: selectedKeys }, "introduceOrg");
      actions.get(1, { id: selectedKeys }, "childOrgs");
    }
  }

  onSelect(selectedKeys) {
    this.setState({ selectedKeys });
  }

  getContainer() {
    if (!this.cmContainer) {
      this.cmContainer = document.createElement("div");
      document.body.appendChild(this.cmContainer);
    }
    return this.cmContainer;
  }

  // 异步加载的选择树
  onExpand(expandedKeys, expandedEvent) {
    this.setState({
      expandedKeys,
      autoExpandParent: false
    });
  }

  onLoadData(treeNode) {
    const { actions } = this.props;
    actions.get(null, { orgId: treeNode.props.value }, "organizationAll");
    const { expandedKeys } = this.state;
    this.setState({
      loadedKeys: expandedKeys
    });

    return new Promise(resolve => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
      setTimeout(() => {
        const { OrganizationAll } = this.props;
        treeNode.props.dataRef.children = OrganizationAll.data;
        const { treeData } = this.state;
        this.setState({ treeData: [...treeData] });
        resolve();
      }, 1000);
    });
  }

  renderTreeNodes(data) {
    return data.map(item => {
      if (item.children) {
        return (
          <TreeNode title={item.orgName} key={item.orgId} dataRef={item} value={item.orgId}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode title={item.orgName} key={item.orgId} value={item.orgId} dataRef={item} />;
    });
  }

  onTreeChange(value, label, extra) {
    // this.setState({ value });
    this.form.setFieldsValue({
      orgId: value
    });
  }

  handleMenuClick(info) {
    ReactDOM.unmountComponentAtNode(this.cmContainer);
    this.toolTip = null;
    const { currentSelected } = this.state;
    if (info.key === "1") {
      this.showAddModal(currentSelected.dataRef);
    } else if (info.key === "2") {
      this.showEidtModal(currentSelected.dataRef);
    } else if (info.key === "3") {
      this.handleDelOk(currentSelected.dataRef);
    }
  }

  DOMClick() {
    if (this.toolTip) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      this.toolTip = null;
    }
  }

  renderCm(info) {
    if (this.toolTip) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      this.toolTip = null;
    }
    const tmpStyle = {
      borderRadius: 20,
      zIndex: 99,
      position: "absolute",
      left: `${info.event.pageX + 50}px`,
      top: `${info.event.pageY}px`,
      backgroundColor: "#e6f7ff"
    };
    this.toolTip = (
      <Menu onClick={this.handleMenuClick} style={tmpStyle}>
        {/* {info.node.props.pos.split('-').length- 1 !== 3 ? */}
        <Menu.Item key="1">
          <Icon type="plus-circle" />
          {"增加下级机构"}
        </Menu.Item>
        {/* : null
      }    */}
        <Menu.Item key="2">
          <Icon type="plus-circle-o" />
          {"编辑此机构"}
        </Menu.Item>
        {info.node.props.pos.split("-").length - 1 !== 1 ? (
          <Menu.Item key="3">
            <Icon type="plus-circle-o" />
            {"删除此机构"}
          </Menu.Item>
        ) : null}
      </Menu>
    );

    const container = this.getContainer();
    Object.assign(this.cmContainer.style, {
      // position: "absolute",
      // left: `${info.event.pageX}px`,
      // top: `${info.event.pageY}px`,
      // backgroundColor: "#fff"
    });
    ReactDOM.render(this.toolTip, container);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.ChildOrgs.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.ChildOrgs.pageBean.total,
          current: nextProps.ChildOrgs.pageBean.page,
          pageSize: nextProps.ChildOrgs.pageBean.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    this.getContainer();
    const { actions } = this.props;
    const { currentId } = this.state;
    actions.get(null, { orgId: 0 }, "organizationAll");
    actions.get(null, { id: currentId }, "introduceOrg");
    actions.get(1, { id: currentId }, "childOrgs");

    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setTimeout(() => {
      const { OrganizationAll } = this.props;
      this.setState({
        treeData: OrganizationAll.data
      });
    }, 900);
  }

  componentDidUpdate() {
    const { actions, updateStatus, delStatus, addStatus } = this.props;

    if (updateStatus && updateStatus === 1) {
      message.success("编辑成功");
      actions.get(null, { orgId: 0 }, "organizationAll");
      actions.get(null, { id: 1 }, "introduceOrg");
      actions.get(1, { id: 1 }, "childOrgs");

      // this.props.actions.get(
      //   this.props.ChildOrgs.pageBean.page,
      //   { id: this.state.currentId },
      //   "childOrgs"
      // );
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        const { OrganizationAll } = this.props;
        this.setState({
          treeData: OrganizationAll.data,
          loadedKeys: [],
          expandedKeys: []
        });
      }, 800);
    } else if (delStatus && delStatus === 1) {
      message.success("删除成功");
      actions.get(null, { orgId: 0 }, "organizationAll"); // before
      actions.get(null, { id: 1 }, "introduceOrg"); // before
      actions.get(1, { id: 1 }, "childOrgs");

      // this.props.actions.get(null, { id: this.state.currentParentId }, "introduceOrg"); // after
      // let treeNodeParams = {
      //   props: {
      //     checked: false,
      //     children: [],
      //     dataRef: {
      //       createTime: "",
      //       id: null,
      //       orgCode: "",
      //       orgDesc: "",
      //       orgId: this.state.currentParentId
      //     },
      //     dragOver: false,
      //     value: this.state.currentParentId
      //   }
      // };
      // this.onLoadData(treeNodeParams);
      // this.props.actions.get(null, { id: this.state.currentParentId }, "introduceOrg"); // after
      //   if (
      //     this.props.ChildOrgs.pageBean.total % this.props.ChildOrgs.pageBean.size === 1 &&
      //     this.props.ChildOrgs.pageBean.totalPage > 1 &&
      //     this.props.ChildOrgs.pageBean.page > 1
      //   ) {
      //     this.props.actions.get(
      //       this.props.ChildOrgs.pageBean.page - 1,
      //       { id: this.state.currentId },
      //       "childOrgs"
      //     );
      //   } else {
      //     this.props.actions.get(
      //       this.props.ChildOrgs.pageBean.page,
      //       { id: this.state.currentId },
      //       "childOrgs"
      //     );
      //   }
      if (this.timer) {
        clearTimeout(this.timer);
      }
      // console.log("OrganizationAll000", this.props.OrganizationAll.data);
      this.timer = setTimeout(() => {
        const { OrganizationAll } = this.props;
        this.setState({
          treeData: OrganizationAll.data,
          loadedKeys: [],
          expandedKeys: []
        });
      }, 800);
    } else if (addStatus && addStatus === 1) {
      message.success("新增成功");
      actions.get(null, { orgId: 0 }, "organizationAll");
      actions.get(null, { id: 1 }, "introduceOrg");
      actions.get(1, { id: 1 }, "childOrgs");
      // this.props.actions.get(null, { id: this.state.currentId }, "introduceOrg");
      // this.props.actions.get(
      //   this.props.ChildOrgs.pageBean.page,
      //   { id: this.state.currentId },
      //   "childOrgs"
      // );

      if (this.timer) {
        clearTimeout(this.timer);
        // console.log("addStatus1111", this.props.OrganizationAll);
      }
      this.timer = setTimeout(() => {
        const { OrganizationAll } = this.props;
        this.setState({
          treeData: OrganizationAll.data.concat([]),
          loadedKeys: [],
          expandedKeys: []
        });
      }, 800);
    }
  }

  // unmount
  componentWillUnmount() {
    if (this.timer) {
      clearTimeout(this.timer); // 卸载定时器
    }
    if (this.cmContainer) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      document.body.removeChild(this.cmContainer);
      this.cmContainer = null;
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    this.setState({ loading: true });
    // if (this.state.searchItem.name) {
    //   // console.log("paginationsearchItem", pagination)
    //   this.props.actions.get(pagination.current, null, this.state.searchItem, "childOrgs");
    // } else {
    //   // console.log("pagination", pagination)

    //   this.props.actions.get(pagination.current, {id: this.state.currentId}, "childOrgs");
    // }
    const { actions } = this.props;
    const { currentId } = this.state;
    actions.get(pagination.current, { id: currentId }, "childOrgs");
  }

  renderColumns(text, record, column) {
    return text;
  }

  handleDelOk(record) {
    const orgId = record.orgId;
    const { actions } = this.props;

    if (record.childOrgs) {
      message.error("此机构有子机构，不能删除！");
    } else {
      this.setState({
        currentParentId: record.parentOrgId
      });
      actions.del(orgId, "orgManage");
    }
  }

  saveFormRef(form) {
    this.form = form;
  }

  saveUpdateFormRef(forms) {
    this.forms = forms;
  }

  // 点击编辑弹框
  showEditModal(record) {
    const { actions } = this.props;
    actions.get(record.orgId, null, "orgFind");
    this.form.resetFields();
    this.setState({
      roleInformation: record,
      updateVisible: true
    });
  }

  // update
  handleUpdataOk(e) {
    const forms = this.forms;
    const { actions } = this.props;
    const { roleInformation } = this.state;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.orgId = roleInformation.orgId;
      values.parentOrgId = roleInformation.parentOrgId;
      values.id = roleInformation.id;
      actions.update(values, "orgManage");
      this.setState({
        updateVisible: false,
        // currentId: this.state.roleInformation.orgId,  // before
        currentId: roleInformation.parentOrgId // after
        // treeData: [],
        // // expandedKeys: [],
        // loadedKeys: [],
      });
      forms.resetFields();
    });
  }

  search() {
    const { actions } = this.props;
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    if (roleName.length === 0) {
      message.warning("角色名称不能为空");
      return;
    }
    this.setState({
      searchItem: {
        name: roleName
      }
    });
    const params = { roleName };
    actions.search(1, params, "roleManage");
  }

  // 点击新增弹框
  showAddModal(info) {
    this.setState({
      roleInformation: info, // 拿过信息
      addVisible: true
    });
  }

  handleOk(e) {
    const form = this.form;
    const { actions } = this.props;
    const { roleInformation } = this.state;

    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      // values.roleId = this.state.roleInformation.roleId;
      values.parentOrgId = roleInformation.orgId;
      // values.orgId = this.state.roleInformation.orgId;
      // values.id = this.state.roleInformation.id;
      actions.add(values, null, "orgManage");
      // this.props.actions.addApp(values);
      this.setState({
        addVisible: false,
        currentId: roleInformation.orgId
        // treeData: [],
        // expandedKeys: [],
      });
      form.resetFields();
    });
  }

  handleCancel(e) {
    this.setState({
      addVisible: false,
      updateVisible: false,
      roleInformation: null,
      currentSelected: null
    });

    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  render() {
    const {
      expandedKeys,
      loadedKeys,
      treeData,
      addVisible,
      updateVisible,
      pagination,
      loading,
      selectedKeys
    } = this.state;
    const { IntroduceOrg, ChildOrgs, OrgFind } = this.props;

    return (
      <div
        style={{
          display: "flex",
          flexDirection: "row"
        }}
        onClick={this.DOMClick}
      >
        <div
          style={{
            width: "200px",
            overflowX: "auto",
            textAlign: "left",
            lineHeight: "60px",
            padding: "10px",
            borderBottom: "1px solid #ccc",
            zIndex: 9
          }}
        >
          <Tree
            selectedKeys={selectedKeys}
            loadData={this.onLoadData}
            // defaultExpandAll = {true}
            onRightClick={this.rightClick}
            onSelect={this.onTreeSelect}
            expandedKeys={expandedKeys}
            onExpand={this.onExpand}
            // autoExpandParent = {this.state.autoExpandParent}
            loadedKeys={loadedKeys}
            // onChange = {this.onTreeChange}
          >
            {treeData ? (treeData.length !== 0 ? this.renderTreeNodes(treeData) : null) : null}
          </Tree>
        </div>
        <div
          style={{
            minHeight: "78vh",
            flex: 6,
            textAlign: "left",
            padding: "5px",
            borderBottom: "1px solid #ccc"
          }}
        >
          <div
            style={{
              textAlign: "left",
              height: "60px",
              lineHeight: "60px",
              padding: "10px",
              borderBottom: "1px solid #ccc"
            }}
          >
            基本信息
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "10px" }} type="flex" justify="space-between">
              <Col span={5}>
                机构编号：
                {IntroduceOrg.length !== 0 ? IntroduceOrg.data.orgCode : ""}
              </Col>
              <Col span={5}>
                机构名称：
                {IntroduceOrg.length !== 0 ? IntroduceOrg.data.orgName : ""}
              </Col>
            </Row>
            <Row style={{ marginTop: "10px" }} type="flex" justify="start">
              <Col span={20}>
                机构描述：
                {IntroduceOrg.length !== 0 ? IntroduceOrg.data.orgDesc : ""}
              </Col>
            </Row>
          </div>

          {ChildOrgs.data ? (
            ChildOrgs.data.length !== 0 ? (
              <div
                style={{
                  textAlign: "left",
                  height: "38px",
                  padding: "10px",
                  lineHeight: "26px",
                  borderBottom: "1px solid #ccc",
                  marginBottom: "10px",
                  marginTop: "10px"
                }}
              >
                子机构列表
              </div>
            ) : (
              ""
            )
          ) : (
            ""
          )}
          {/* <div style={{padding: "10px",marginBottom: "10px",}}>
            <Row style={{marginTop: "10px"}} type="flex" justify="space-between">
              <Col span={8}>
                机构名称：<Input placeholder="请输入机构名称" style={{width: "70%"}} ref="roleName" />
              </Col>
              <Col span={8} style={{textAlign: "right"}}>
                <Button type="primary" onClick={this.search.bind(this)} style={{marginRight: 10}}>
                  查询
                </Button>
                <Button type="primary" onClick={this.showAddModal.bind(this)}>
                  新增
                </Button>
              </Col>
            </Row>
          </div> */}
          <NewForm
            ref={this.saveFormRef.bind(this)}
            addVisible={addVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdateForm
            ref={this.saveUpdateFormRef.bind(this)}
            updateVisible={updateVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleUpdataOk.bind(this)}
            list={OrgFind.length !== 0 ? OrgFind.data : OrgFind}
          />
          {ChildOrgs.data ? (
            ChildOrgs.data.length !== 0 ? (
              <Table
                bordered
                size="small"
                columns={this.columns}
                locale={{ emptyText: "暂无数据..." }}
                dataSource={ChildOrgs.data}
                pagination={pagination}
                loading={loading}
                onChange={this.handlePageChange.bind(this)}
              />
            ) : (
              ""
            )
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Login: state.login.get("logininfo"),
    OrganizationAll: state.SystemManage.get("organizationAllData"),
    RoleManage: state.SystemManage.get("roleManageData"),
    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus"),
    SysroleFind: state.SystemManage.get("sysroleFindData"),
    roleMenus: state.SystemManage.get("roleMenusData"),
    IntroduceOrg: state.SystemManage.get("introduceOrgData"),
    ChildOrgs: state.SystemManage.get("childOrgsData"),
    OrgFind: state.SystemManage.get("orgFindData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OrgManage);
