import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Popconfirm, Row, Col } from "antd";
import * as action from "../../../actions/ProjectList";
import * as projectAction from "../../../actions/ListProjects";
import "antd/dist/antd.css";

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;

const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onReturn, handleChange, form, handleClose, userallData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false} visible={updatavisible} title="项目审核" footer={null} onCancel={handleClose}>
      <Form layout="vertical">
        <FormItem label="项目编号:">
          {getFieldDecorator("projectCode")(<Input disabled />)}
        </FormItem>
        <FormItem label="项目名称：">
          {getFieldDecorator("projectName")(<Input disabled />)}
        </FormItem>
        <FormItem label="访问级别：">
          {getFieldDecorator("projectPermission")(<Input disabled />)}
        </FormItem>
        <FormItem label="项目经理：">
          {getFieldDecorator("projectOwner")(
            <Select placeholder="请选择项目经理" allowClear onChange={handleChange} disabled>
              {userallData
                ? userallData.map(v => {
                    return (
                      <Option value={v.userId} key={v.userId}>
                        {v.realName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem label="描述：">
          {getFieldDecorator("projectDesc")(<Input type="textarea" disabled />)}
        </FormItem>
        <FormItem label="备注">
          {getFieldDecorator("approvingDesc")(<TextArea maxLength={256} />)}
        </FormItem>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onReturn} style={{ marginLeft: 10 }}>
              驳回
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onUpdata} style={{ marginLeft: 10 }}>
              通过
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});

class ProjectApproval extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      confirmLoading: false,
      updataData: {}
    };
    this.columns = [
      {
        title: "项目编号",
        dataIndex: "projectCode",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "projectCode")
      },
      {
        title: "项目名称",
        dataIndex: "projectName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "projectName")
      },
      {
        title: "访问级别",
        dataIndex: "projectPermission",
        width: "5%",
        // render: (text, record) => this.renderColumns(text, record, "projectPermission")
        render(state) {
          const config = {
            "1": "私有",
            "2": "公有"
          };
          return config[state];
        }
      },
      {
        title: "状态",
        dataIndex: "projectStatus",
        width: "6%",
        render: (text, record) => this.renderColumns(text, record, "projectStatus")
      },
      {
        title: "组件个数",
        dataIndex: "appCount",
        width: "5%",
        render: (text, record) => this.renderColumns(text, record, "appCount")
      },
      {
        title: "项目经理",
        dataIndex: "projectOwner",
        width: "8%",
        render: (text, record) => this.renderColumns(text, record, "projectOwner")
      },
      {
        title: "项目描述",
        dataIndex: "projectDesc",
        width: "20%",
        render: (text, record) => this.renderColumns(text, record, "projectDesc")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        width: "15%",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                审核
              </a>
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "projectStatus") {
      return text == "0" ? "未审核" : text == "1" ? "已审核" : "已驳回";
    } else {
      return text;
    }
  }

  //   搜索
  search() {
    const { actions } = this.props;
    const { projectOwner, projectStatus } = this.state;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;
    actions.getProjectscodeOrName({
      page: 1,
      size: 10,
      searchValue,
      projectOwner,
      projectStatus: "0"
    });
  }

  handleChangeStatus(value) {
    this.setState({
      projectStatus: value
    });
  }

  handleChangeOwer(value) {
    this.setState({
      projectOwner: value
    });
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getProjectscodeOrName({
      page: 1,
      size: 10,
      projectStatus: "0"
    });
    actions.getSystemUserall();
  }

  componentDidUpdate() {
    const { updataStatus, actions } = this.props;
    if (updataStatus && updataStatus === 1) {
      // message.info("审核");
      actions.getProjectscodeOrName({
        page: 1,
        size: 10,
        projectStatus: "0"
      });
    } else if (updataStatus && updataStatus === 2) {
      // message.error("驳回");
      actions.getProjectscodeOrName({
        page: 1,
        size: 10,
        projectStatus: "0"
      });
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const { projectOwner } = this.state;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;
    this.setState({ loading: true });
    actions.getProjectscodeOrName({
      page: pagination.current,
      searchValue,
      projectOwner,
      projectStatus: "0"
    });
  }

  handleChange(value) {}

  saveFormRef(form) {
    this.form = form;
  }

  // 点击审核
  showEditModal(record) {
    this.form.setFieldsValue({
      projectCode: record.projectCode,
      projectName: record.projectName,
      projectPermission: record.projectPermission,
      projectOwner: record.projectOwner,
      projectDesc: record.projectDesc,
      approvingDesc: record.approvingDesc
    });
    this.setState({
      updataData: {
        projectStatus: record.projectStatus,
        userId: record.userId,
        projectId: record.projectId
      },
      loading: false
    });
    this.setState({
      updatavisible: true
    });
  }

  // 确认审核updata
  handleUpdataOk(e) {
    const { actions } = this.props;
    const { updataData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.projectId = updataData.projectId;
      values.projectOwner = updataData.userId;
      values.projectStatus = "1";
      actions.updataProjects(values);
      this.setState({ updatavisible: false });
    });
    setTimeout(() => {
      actions.getAllProjects({
        page: 1,
        searchValue: "",
        conditions: []
      });
    }, 2000);
  }

  // 驳回
  handleCancel(e) {
    const { actions } = this.props;
    const { updataData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.projectId = updataData.projectId;
      values.projectOwner = updataData.userId;
      // values.approvingDesc =updataData.approvingDesc;
      values.projectStatus = "2";
      actions.updataProjects(values);
      this.setState({ updatavisible: false });
    });
  }

  // 关闭
  handleClose(e) {
    this.setState({
      updatavisible: false
    });
  }

  render() {
    const { resData, userallData } = this.props;
    const { updatavisible, pagination, loading } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={7}>
              <span style={{ marginRight: 10 }}>编号或名称:</span>
              <Input style={{ width: "65%" }} placeholder="项目编号或项目名称" ref="projectCode" />
            </Col>

            <Col span={7}>
              <span style={{ marginRight: 10 }}>项目经理:</span>
              <Select
                allowClear
                placeholder="所有项目经理"
                style={{ width: "65%" }}
                className="padright"
                onChange={this.handleChangeOwer.bind(this)}
              >
                {userallData
                  ? userallData.map(v => {
                      return (
                        <Option value={v.userId} key={v.userId}>
                          {v.realName}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            </Col>
            <Col span={8} style={{ textAlign: "right" }}>
              <Button type="primary" onClick={this.search.bind(this)} className="padright">
                查询
              </Button>
            </Col>
          </Row>
          <UpdataForm
            ref={this.saveFormRef.bind(this)}
            userallData={userallData}
            updatavisible={updatavisible}
            onReturn={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
            handleClose={this.handleClose.bind(this)}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.PjmProjects.get("resData"),
    userallData: state.PjmProjects.get("userallData"),
    pageConfig: state.PjmProjects.get("pageConfigs"),
    updataStatus: state.PjmProjects.get("UpdataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, action, projectAction);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProjectApproval);
