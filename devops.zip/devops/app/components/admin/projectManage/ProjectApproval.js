import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Popconfirm, Row, Col } from "antd";
import * as action from "../../../actions/ProjectList";
import "antd/dist/antd.css";
import Validation from "../../../utils/Validation";
import ProjectDetail from "./ProjectDetail";

const FormItem = Form.Item;
const Option = Select.Option;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form, userallData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增立项申请"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="项目编号:">
          {getFieldDecorator("projectCode", {
            rules: Validation.Rule_projectCode
          })(<Input minLength={2} maxLength={32} />)}
        </FormItem>
        <FormItem label="项目名称：">
          {getFieldDecorator("projectName", {
            rules: Validation.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="访问级别：">
          {getFieldDecorator("projectPermission", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择访问级别" allowClear>
              <Option value={1}>私有</Option>
              <Option value={2}>公有</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="项目经理：">
          {getFieldDecorator("projectOwner", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择项目经理" allowClear onChange={handleChange}>
              {userallData
                ? userallData.map(v => {
                    return (
                      <Option value={v.userId} key={v.userId}>
                        {v.realName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem label="描述：">
          {getFieldDecorator("projectDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onCancel, handleChange, form, userallData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={updatavisible}
      title="修改立项申请"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onUpdata}
    >
      <Form layout="vertical">
        <FormItem label="项目编号:">
          {getFieldDecorator("projectCode")(<Input disabled />)}
        </FormItem>
        <FormItem label="项目名称：">
          {getFieldDecorator("projectName", {
            rules: Validation.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="访问级别：">
          {getFieldDecorator("projectPermission", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择访问级别" allowClear>
              <Option value={1}>私有</Option>
              <Option value={2}>公有</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="项目经理：">
          {getFieldDecorator("projectOwner", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择项目经理" allowClear onChange={handleChange}>
              {userallData
                ? userallData.map(v => {
                    return (
                      <Option value={v.userId} key={v.userId}>
                        {v.realName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem label="描述：">
          {getFieldDecorator("projectDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

class ProjectApproval extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      projectDetailVisual: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      selectedRowData: {},
      projectName: "",
      key: 1
    };
    this.columns = [
      {
        title: "项目编号",
        dataIndex: "projectCode",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "projectCode")
      },
      {
        title: "项目名称",
        dataIndex: "projectName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "projectName")
      },
      {
        title: "访问级别",
        dataIndex: "projectPermission",
        width: "5%",
        // render: (text, record) => this.renderColumns(text, record, "projectPermission")
        render(state) {
          const config = {
            "1": "私有",
            "2": "公有"
          };
          return config[state];
        }
      },
      {
        title: "状态",
        dataIndex: "projectStatus",
        width: "6%",
        render: (text, record) => this.renderColumns(text, record, "projectStatus")
      },
      {
        title: "组件个数",
        dataIndex: "appCount",
        width: "5%",
        render: (text, record) => this.renderColumns(text, record, "appCount")
      },
      {
        title: "项目经理",
        width: "8%",
        dataIndex: "projectOwner",
        render: (text, record) => this.renderColumns(text, record, "projectOwner")
      },
      {
        title: "项目描述",
        width: "20%",
        dataIndex: "projectDesc",
        render: (text, record) => this.renderColumns(text, record, "projectDesc")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        width: "15%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showDetailModal(record);
                }}
                className="padright"
              >
                <span />
                详情
              </a>
              {record.projectStatus != 1 ? (
                <a
                  onClick={() => {
                    this.showEditModal(record);
                  }}
                  className="padright"
                >
                  <span />
                  编辑
                </a>
              ) : (
                ""
              )}
              {record.projectStatus != 1 ? (
                <Popconfirm
                  title="确定删除吗？"
                  onConfirm={() => this.handleDelOk(record)}
                  okText="确定"
                  cancelText="取消"
                >
                  <a className="padright">
                    <span />
                    删除
                  </a>
                </Popconfirm>
              ) : (
                ""
              )}
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.showDetailModal = this.showDetailModal.bind(this);
  }

  //   确认删除projectId
  handleDelOk(record) {
    const { actions } = this.props;
    if (record.projectStatus != "1") {
      actions.deleteDeviceId(record.projectId);
    } else {
      message.info("已审核不能删除");
    }
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "projectStatus") {
      return text == "0" ? "未审核" : text == "1" ? "已审核" : "已驳回";
    } else {
      return text;
    }
  }

  //   编号项目名称控件搜索
  search() {
    const { actions } = this.props;
    const { projectOwner, projectStatus } = this.state;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;

    actions.getProjectscodeOrName({
      page: 1,
      size: 10,
      searchValue,
      projectOwner,
      projectStatus
    });
  }

  handleChangeStatus(value) {
    this.setState({
      projectStatus: value
    });
  }

  handleChangeOwer(value) {
    this.setState({
      projectOwner: value
    });
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getProjectscodeOrName({
      page: 1,
      searchValue: ""
    });
    actions.getSystemUserall();
  }

  componentDidUpdate() {
    const { actions, delStatus, addStatus, updataStatus } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    } else if (addStatus && addStatus === 3) {
      message.error("项目编码已存在");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    } else if (updataStatus && updataStatus === 2) {
      message.error("修改失败");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    } else if (updataStatus && updataStatus === 3) {
      message.error("项目编码已存在");
      actions.getProjectscodeOrName({
        page: 1,
        searchValue: ""
      });
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    // this.setState({ loading: true });
    const { projectOwner, projectStatus } = this.state;
    const { actions } = this.props;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;

    actions.getProjectscodeOrName({
      page: pagination.current,
      size: 10,
      searchValue,
      projectOwner,
      projectStatus
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击修改弹框
  showEditModal(record) {
    if (record.projectStatus != "1") {
      this.form.setFieldsValue({
        projectCode: record.projectCode,
        projectName: record.projectName,
        projectOwner: record.userId,
        projectDesc: record.projectDesc,
        projectPermission: record.projectPermission
      });
      this.setState({
        updataData: {
          projectStatus: "0",
          projectId: record.projectId
        },
        loading: false
      });
      this.setState({
        updatavisible: true
      });
    } else {
      message.info("已审核不能修改");
    }
  }

  // 确认修改updata
  handleUpdataOk(e) {
    const form = this.form;
    const { updataData } = this.state;
    const { actions } = this.props;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.projectId = updataData.projectId;
      values.projectStatus = updataData.projectStatus;
      actions.updataProjects(values);
      this.setState({ updatavisible: false });
    });
  }

  // 点击详情弹框
  showDetailModal(record) {
    // this.props.actions.getComponentList(1, record.projectId, "");
    this.setState({
      selectedRowData: record,
      projectDetailVisual: true,
      key: Math.random()
    });
  }

  viewHandleCancel() {
    this.setState({
      projectDetailVisual: false
    });
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const forms = this.forms;
    const { actions } = this.props;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.projectStatus = "0";
      actions.addProjects(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.form.resetFields();
    this.setState({
      visible: false,
      updatavisible: false
    });
  }

  // changeSearch(e) {
  //   this.setState({
  //     projectName: e.target.value
  //   });
  // }

  render() {
    const Search = Input.Search;
    const { resData, userallData } = this.props;
    const {
      visible,
      updatavisible,
      pagination,
      loading,
      projectDetailVisual,
      key,
      selectedRowData
    } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={7}>
              <span style={{ marginRight: 10 }}>编号或名称:</span>
              <Input style={{ width: "65%" }} placeholder="项目编号或项目名称" ref="projectCode" />
              {/* <Search
                ref="projectName"
                placeholder="请输入项目编号或项目名称"
                enterButton
                className="padright"
                onChange={this.changeSearch.bind(this)}
                onSearch={this.search.bind(this)}
                style={{width: 250}}
              /> */}
            </Col>
            <Col span={6}>
              <span style={{ marginRight: 10 }}>项目状态:</span>
              <Select
                allowClear
                placeholder="所有状态"
                style={{ width: "70%" }}
                className="padright"
                onChange={this.handleChangeStatus.bind(this)}
              >
                <Option value="0">未审核</Option>
                <Option value="1">已审核</Option>
                <Option value="2">已驳回</Option>
              </Select>
            </Col>
            <Col span={6}>
              <span style={{ marginRight: 10 }}>项目经理:</span>
              <Select
                allowClear
                placeholder="所有项目经理"
                style={{ width: "70%" }}
                className="padright"
                onChange={this.handleChangeOwer.bind(this)}
              >
                {userallData
                  ? userallData.map(v => {
                      return (
                        <Option value={v.userId} key={v.userId}>
                          {v.realName}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            </Col>
            <Col span={3} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            userallData={userallData}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            userallData={userallData}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
        {/* 详情 */}
        <Modal maskClosable={false}
          visible={projectDetailVisual}
          onCancel={this.viewHandleCancel.bind(this)}
          key={key}
          width="60vw"
          footer={null}
        >
          <ProjectDetail selectedRowData={selectedRowData} />
        </Modal>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.PjmProjects.get("resData"),
    userallData: state.PjmProjects.get("userallData"),
    pageConfig: state.PjmProjects.get("pageConfigs"),
    addStatus: state.PjmProjects.get("AddStatus"),
    delStatus: state.PjmProjects.get("delStatus"),
    updataStatus: state.PjmProjects.get("UpdataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProjectApproval);
