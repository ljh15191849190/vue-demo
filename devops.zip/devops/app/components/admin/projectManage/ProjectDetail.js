import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Row, Col } from "antd";
import * as action from "../../../actions/ComponentList";

class ProjectDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      projectId: "",
      ModalText: "您确定要删除么？"
    };
    this.columns = [
      {
        title: "组件编号",
        dataIndex: "applicationCode",
        render: (text, record) => this.renderColumns(text, record, "applicationCode")
      },
      {
        title: "组件名称",
        dataIndex: "applicationName",
        render: (text, record) => this.renderColumns(text, record, "applicationName")
      },
      {
        title: "版本编号",
        dataIndex: "versionCode",
        render: (text, record) => this.renderColumns(text, record, "versionCode")
      },

      {
        title: "状态",
        dataIndex: "applicationStatus",
        render: (text, record) => this.renderColumns(text, record, "applicationStatus")
      },

      {
        title: "组件描述",
        dataIndex: "applicationDesc",
        render: (text, record) => this.renderColumns(text, record, "applicationDesc")
      },

      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      }
    ];
    this.setState = this.setState.bind(this);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "applicationStatus") {
      return text == "0" ? "已启用" : "未启用";
    } else {
      return text;
    }
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { selectedRowData, actions } = this.props;
    if (selectedRowData.projectId) {
      actions.getComponentList({
        projectId: selectedRowData.projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      });
    }
  }

  componentDidUpdate() {}

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { selectedRowData, actions } = this.props;
    this.setState({ loading: true });
    actions.getComponentList({
      projectId: selectedRowData.projectId,
      page: pagination.current,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    });
  }

  render() {
    const { resData, selectedRowData } = this.props;
    const { pagination, loading } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={8}>
              <span style={{ marginRight: 10 }}>项目编号:</span>
              <Input style={{ width: "70%" }} disabled value={selectedRowData.projectCode} />
            </Col>
            <Col span={8}>
              <span style={{ marginRight: 10 }}>项目名称:</span>
              <Input style={{ width: "70%" }} disabled value={selectedRowData.projectName} />
            </Col>
            <Col span={8}>
              <span style={{ marginRight: 10 }}>项目经理:</span>
              <Input style={{ width: "70%" }} disabled value={selectedRowData.projectOwner} />
            </Col>
            <Col span={8} style={{ marginTop: 15 }}>
              <span style={{ marginRight: 10 }}>项目状态:</span>
              <Input
                disabled
                style={{ width: "70%" }}
                value={
                  selectedRowData.projectStatus == "0"
                    ? "未审核"
                    : selectedRowData.projectStatus == "1"
                    ? "已审核"
                    : "已驳回"
                }
              />
            </Col>
            <Col span={8} style={{ marginTop: 15 }}>
              <span style={{ marginRight: 10 }}>项目描述:</span>
              <Input style={{ width: "70%" }} disabled value={selectedRowData.projectDesc} />
            </Col>
          </Row>
        </div>
        <div />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.PjmComponent.get("resData"),
    pageConfig: state.PjmComponent.get("pageConfig"),
    searchStatus: state.PjmComponent.get("searchStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProjectDetail);
