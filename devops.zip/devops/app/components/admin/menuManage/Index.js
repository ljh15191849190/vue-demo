import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  Popconfirm,
  Row,
  Col,
  message,
  Tabs,
  Tree,
  Menu,
  Icon
} from "antd";
import * as action from "../../../actions/systemManageAction";
import RULES from "../../../utils/Validation";

const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;
const Search = Input.Search;
const { Option } = Select;
const { TabPane } = Tabs;

const UpdateForm = Form.create()(props => {
  const { updateVisible, onCreate, onCancel, form, list } = props;
  // console.log("list", list);
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal maskClosable={false}
      visible={updateVisible}
      title="修改菜单"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="菜单编号：">
          {getFieldDecorator("menuCode", {
            rules: RULES.Rule_code,
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入字母、数字、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_]+$/
            //   }
            // ],
            initialValue: list ? list.menuCode : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="菜单名称：">
          {getFieldDecorator("menuName", {
            rules: RULES.Rule_name,
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入字母、数字、中文、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
            //   }
            // ],
            initialValue: list ? list.menuName : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="地址：">
          {getFieldDecorator("menuUrl", {
            rules: RULES.Rule_nochinese,
            // rules: [
            //   {
            //     required: true,
            //     message: "不能为空"
            //     // message: "请输入字母、数字、下划线,字母或者数字开头,至少两位",
            //     // pattern: /^[a-zA-Z0-9][a-zA-Z0-9_]+$/
            //   }
            // ],
            initialValue: list ? list.menuUrl : ""
          })(<Input maxLength={128} />)}
        </FormItem>
        <FormItem label="菜单类型">
          {getFieldDecorator("menuType", {
            rules: [{ required: true, message: "不能为空" }],
            initialValue: list ? `${list.menuType}` : ""
          })(
            <Select style={{ width: "100%" }} disabled={true}>
              <Option value="0">菜单</Option>
              <Option value="button">按钮</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="菜单描述">
          {getFieldDecorator("menuDesc", {
            //   rules: [{
            //     required: true,
            //     message: "不能为空，不能包含如下字符：@#$%^&*\<>",
            //     pattern: /^[^@#$^%&*\\<>]*$/,
            // }],
            initialValue: list ? list.menuDesc : ""
          })(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const NewForm = Form.create()(props => {
  const { addVisible, onCreate, onCancel, form } = props;
  const { getFieldDecorator } = form;
  const { TextArea } = Input;
  return (
    <Modal maskClosable={false}
      visible={addVisible}
      title="新增菜单"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="菜单编号：">
          {getFieldDecorator("menuCode", {
            rules: RULES.Rule_code
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入字母、数字、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_]+$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="菜单名称：">
          {getFieldDecorator("menuName", {
            rules: RULES.Rule_name
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入中文、字母、数字、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="地址：">
          {getFieldDecorator("menuUrl", {
            rules: RULES.Rule_nochinese

            // rules: [
            //   {
            //     required: true,
            //     message: "不能为空"
            //     // message: "请输入字母、数字、下划线,字母或者数字开头,至少两位",
            //     // pattern: /^[a-zA-Z0-9][a-zA-Z0-9_]+$/
            //   }
            // ]
          })(<Input maxLength={128} />)}
        </FormItem>

        <FormItem label="菜单类型">
          {getFieldDecorator("menuType", {
            rules: [{ required: true, message: "不能为空" }],
            initialValue: "0"
          })(
            <Select style={{ width: "100%" }} disabled={true}>
              <Option value="0">菜单</Option>
              <Option value="button">按钮</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="菜单描述">
          {getFieldDecorator("menuDesc", {
            // rules: [{
            //   required: true,
            //   message: "不能为空，不能包含如下字符：@#$%^&*\<>",
            //   pattern: /^[^@#$^%&*\\<>]*$/,
            // }]
          })(<TextArea maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

class MenuManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      addVisible: false,
      // visible: false,
      updateVisible: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: "",
      roleInformation: null,

      // menuTree
      selectedKeys: [],
      treeData: [],
      currentId: 1,
      currentSelected: null
    };
    this.columns = [
      {
        title: "菜单编号",
        width: 140,
        dataIndex: "menuCode",
        render: (text, record) => this.renderColumns(text, record, "menuCode")
      },
      {
        title: "菜单名称",
        width: 100,
        dataIndex: "menuName",
        render: (text, record) => this.renderColumns(text, record, "menuName")
      },
      {
        title: "菜单类型",
        width: 75,
        dataIndex: "menuType",
        render: (text, record) => this.renderColumns(text, record, "menuType")
      },
      {
        title: "菜单描述",
        dataIndex: "menuDesc",
        render: (text, record) => this.renderColumns(text, record, "menuDesc")
      },
      {
        title: "创建时间",
        width: 145,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        width: 120,
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              {record.initFlag == 0 ? (
                <Popconfirm
                  title="确定删除吗？"
                  onConfirm={() => this.handleDelOk(record)}
                  okText="确定"
                  cancelText="取消"
                >
                  <a className="padright">
                    <span />
                    删除
                  </a>
                </Popconfirm>
              ) : null}
            </div>
          );
        }
      }
    ];
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.handleDelOk = this.handleDelOk.bind(this);
    this.handleOk = this.handleOk.bind(this);
    this.handleOk = this.handleOk.bind(this);
    this.onLoadData = this.onLoadData.bind(this);
    this.renderTreeNodes = this.renderTreeNodes.bind(this);
    this.rightClick = this.rightClick.bind(this);
    this.onTreeSelect = this.onTreeSelect.bind(this);
    this.onSelect = this.onSelect.bind(this);
    this.handleMenuClick = this.handleMenuClick.bind(this);
    this.DOMClick = this.DOMClick.bind(this);
  }

  // menuTree
  rightClick(info) {
    this.setState({ selectedKeys: [info.node.props.eventKey], currentSelected: info.node.props });
    this.renderCm(info);

    // console.log(info.event.target.parentNode.parentNode.parentNode.childNodes);
    // if (info.event.target.parentNode.parentNode.parentNode.childNodes.previousSibling) {
    //   let Nodes = info.event.target.parentNode.parentNode.parentNode.childNodes;
    //   for (var i = 0; i < Nodes.length; i++) {
    //     ReactDOM.findDOMNode(Nodes[i]).style.backgroundColor = "#ffffff";
    //     ReactDOM.findDOMNode(Nodes[i].childNodes[1]).style.backgroundColor = "#ffffff";
    //     console.log(Nodes[i].childNodes[1]);
    //   }
    // }

    // let Nodes = info.event.target.parentNode.parentNode.parentNode.childNodes;

    // for (var i = 0; i < Nodes.length; i++) {
    //   if (Nodes[i].className == "ant-tree-treenode-switcher-close") {
    //     ReactDOM.findDOMNode(Nodes[i].childNodes[1]).style.backgroundColor = "#ffffff";
    //     // console.log(Nodes[i].childNodes[1]);
    //   } else {
    //     let NodesTwo = info.event.target.parentNode.parentNode.parentNode.childNodes;
    //     for (var i = 0; i < NodesTwo.length; i++) {
    //       ReactDOM.findDOMNode(NodesTwo[i].childNodes[1]).style.backgroundColor = "#ffffff";
    //     }
    //     console.log(NodesTwo);
    //   }
    // }
    // ReactDOM.findDOMNode(info.event.target.parentNode).style.backgroundColor = "#bae7ff";
  }

  onTreeSelect(selectedKeys, event) {
    // 请求更新数据  菜单信息 列表
    const { actions } = this.props;
    this.setState({ currentId: selectedKeys, selectedKeys });
    if (selectedKeys.length !== 0) {
      actions.get(null, { id: selectedKeys }, "introduceMenu");
      actions.get(1, { id: selectedKeys }, "childMenus");
    }
  }

  onSelect(selectedKeys) {
    this.setState({ selectedKeys });
  }

  getContainer() {
    if (!this.cmContainer) {
      this.cmContainer = document.createElement("div");
      document.body.appendChild(this.cmContainer);
    }
    return this.cmContainer;
  }

  onLoadData(treeNode) {
    const self = this;
    const { treeData } = this.state;
    return new Promise(resolve => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
      setTimeout(() => {
        treeNode.props.dataRef.children = [
          { title: "Child Node", key: `${treeNode.props.eventKey}-0` },
          { title: "Child Node", key: `${treeNode.props.eventKey}-1` }
        ];
        self.setState({
          treeData: [...treeData]
        });
        resolve();
      }, 800);
    });
  }

  handleMenuClick(info) {
    ReactDOM.unmountComponentAtNode(this.cmContainer);
    const { currentSelected } = this.state;
    this.toolTip = null;
    if (info.key === "1") {
      this.showAddModal(currentSelected.dataRef);
    } else if (info.key === "2") {
      this.showEidtModal(currentSelected.dataRef);
    } else if (info.key === "3") {
      this.handleDelOk(currentSelected.dataRef);
    }
  }

  DOMClick() {
    if (this.toolTip) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      this.toolTip = null;
    }
  }

  renderCm(info) {
    if (this.toolTip) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      this.toolTip = null;
    }
    const tmpStyle = {
      borderRadius: 20,
      zIndex: 99,
      position: "absolute",
      left: `${info.event.pageX + 50}px`,
      top: `${info.event.pageY}px`,
      backgroundColor: "#e6f7ff"
    };
    this.toolTip = (
      <Menu onClick={this.handleMenuClick} style={tmpStyle}>
        {info.node.props.pos.split("-").length - 1 !== 3 ? (
          <Menu.Item key="1">
            <Icon type="plus-circle" />
            {"增加下级菜单"}
          </Menu.Item>
        ) : null}
        <Menu.Item key="2">
          <Icon type="plus-circle-o" />
          {"编辑此菜单"}
        </Menu.Item>
        {info.node.props.dataRef.initflag == 0 ? (
          <Menu.Item key="3">
            <Icon type="plus-circle-o" />
            {"删除此菜单"}
          </Menu.Item>
        ) : null}
      </Menu>
    );

    const container = this.getContainer();
    Object.assign(this.cmContainer.style, {
      // position: "absolute",
      // left: `${info.event.pageX}px`,
      // top: `${info.event.pageY}px`,
      // backgroundColor: "#fff"
    });
    ReactDOM.render(this.toolTip, container);
  }

  renderTreeNodes(data) {
    return data.map(item => {
      if (item.childMenus && item.childMenus.length !== 0) {
        return (
          <TreeNode
            value={item.menuId}
            title={item.menuName}
            key={item.menuId}
            dataRef={item}
            // onSelect={this.onSelect}
          >
            {this.renderTreeNodes(item.childMenus)}
          </TreeNode>
        );
      }
      return (
        <TreeNode
          value={item.menuId}
          title={item.menuName}
          key={item.menuId}
          dataRef={item}
          // onSelect={this.onSelect}
        />
      );
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.ChildMenus.pageBean) {
      this.setState({
        pagination: {
          total: nextProps.ChildMenus.pageBean.total,
          current: nextProps.ChildMenus.pageBean.page,
          pageSize: nextProps.ChildMenus.pageBean.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    const { currentId } = this.state;
    actions.get(null, null, "menuTree");
    actions.get(null, { id: currentId }, "introduceMenu");
    actions.get(1, { id: currentId }, "childMenus");

    if (this.timer) {
      clearTimeout(this.timer);
    }
    this.timer = setTimeout(() => {
      const { menuTree } = this.props;

      this.setState({
        treeData: menuTree.data
      });
    }, 800);
  }

  componentDidUpdate() {
    const {
      actions,
      updateStatus,
      delStatus,
      addStatus,
      otherStatus,
      OrganizationAll
    } = this.props;
    const { currentId } = this.state;

    if (updateStatus && updateStatus === 1) {
      const { ChildMenus } = this.props;
      message.success("编辑成功");
      // ReactDOM.findDOMNode(this.refs.roleName).value = "";
      actions.get(null, null, "menuTree");
      actions.get(null, { id: currentId }, "introduceMenu");
      actions.get(ChildMenus.pageBean.page, { id: currentId }, "childMenus");
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        const { menuTree } = this.props;
        this.setState({
          treeData: menuTree.data
        });
      }, 800);
    } else if (delStatus && delStatus === 1) {
      const { ChildMenus } = this.props;
      message.success("删除成功");
      // ReactDOM.findDOMNode(this.refs.roleName).value = "";
      actions.get(null, null, "menuTree");
      actions.get(null, { id: currentId }, "introduceMenu");
      if (
        ChildMenus.pageBean.total % ChildMenus.pageBean.size === 1 &&
        ChildMenus.pageBean.totalPage > 1 &&
        ChildMenus.pageBean.page > 1
      ) {
        actions.get(ChildMenus.pageBean.page - 1, { id: currentId }, "childMenus");
      } else {
        actions.get(ChildMenus.pageBean.page, { id: currentId }, "childMenus");
      }

      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        const { menuTree } = this.props;
        this.setState({
          treeData: menuTree.data
        });
      }, 800);
    } else if (addStatus && addStatus === 1) {
      const { ChildMenus } = this.props;

      message.success("新增成功");
      actions.get(null, null, "menuTree");
      actions.get(null, { id: currentId }, "introduceMenu");
      actions.get(ChildMenus.pageBean.page, { id: currentId }, "childMenus");

      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        const { menuTree } = this.props;
        this.setState({
          treeData: menuTree.data
        });
      }, 800);
    } else if (otherStatus && otherStatus === 1) {
      const { ChildMenus } = this.props;

      message.success("授权成功");
      actions.get(null, null, "menuTree");
      actions.get(null, { id: currentId }, "introduceMenu");
      actions.get(ChildMenus.pageBean.page, { id: currentId }, "childMenus");

      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        const { menuTree } = this.props;
        this.setState({
          treeData: menuTree.data
        });
      }, 800);
    }
  }

  // unmount
  componentWillUnmount() {
    if (this.timer) {
      clearTimeout(this.timer); // 卸载定时器
    }
    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();

    if (this.cmContainer) {
      ReactDOM.unmountComponentAtNode(this.cmContainer);
      document.body.removeChild(this.cmContainer);
      this.cmContainer = null;
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { currentId } = this.state;
    const { actions } = this.props;

    this.setState({ loading: true });
    // if (this.state.searchItem.name) {
    //   // console.log("paginationsearchItem", pagination)
    //   this.props.actions.get(pagination.current, null, this.state.searchItem, "childMenus");
    // } else {
    //   // console.log("pagination", pagination)

    //   this.props.actions.get(pagination.current, {id: this.state.currentId}, "childMenus");
    // }
    actions.get(pagination.current, { id: currentId }, "childMenus");
  }

  renderColumns(text, record, column) {
    if (column === "menuType") {
      return "菜单";
    }
    return text;
  }

  handleDelOk(record) {
    const menuId = record.menuId;
    const { currentId } = this.state;
    const { actions } = this.props;

    if (record.childMenus && record.childMenus.length !== 0) {
      message.error("此菜单有子菜单，不能删除！");
    } else {
      const currentIdNum = Number(currentId.toString());
      if (menuId == currentIdNum || !currentIdNum) {
        this.setState({
          currentId: record.parentMenuId
        });
      }
      actions.del(menuId, "menuManage");
    }
  }

  saveFormRef(form) {
    this.form = form;
  }

  saveUpdateFormRef(forms) {
    this.forms = forms;
  }

  // 点击编辑弹框
  showEditModal(record) {
    const { actions } = this.props;
    actions.get(record.menuId, null, "menuFind");
    this.form.resetFields();
    this.setState({
      roleInformation: record,
      updateVisible: true
    });
  }

  // update
  handleUpdataOk(e) {
    const forms = this.forms;
    const { roleInformation } = this.state;
    const { actions } = this.props;

    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.menuId = roleInformation.menuId;
      values.id = roleInformation.id;
      actions.update(values, "menuManage");
      // this.props.actions.addApp(values);
      this.setState({
        updateVisible: false
        // currentId:  roleInformation.menuId,
      });
      forms.resetFields();
    });
  }

  search() {
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    const { actions } = this.props;

    if (roleName.length === 0) {
      message.warning("角色名称不能为空");
      return;
    }
    this.setState({
      searchItem: {
        name: roleName
      }
    });
    const params = {
      roleName
    };
    actions.search(1, params, "roleManage");
    // let searchValue = ReactDOM.findDOMNode(this.refs.codeName).value;
    // let projectId = this.props.projectId;
    // if (searchValue === "") {
    //   this.props.actions.getRCComponentsList(projectId);
    // } else {
    //   this.props.actions.searchRep({projectId: projectId, searchValue: searchValue});
    // }
  }

  // 点击新增弹框
  showAddModal(info) {
    this.setState({
      roleInformation: info, // 拿过信息
      addVisible: true
    });
  }

  handleOk(e) {
    // console.log("addhandleOk", e);
    const form = this.form;
    const { actions } = this.props;
    const { roleInformation } = this.state;

    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      // console.log("handleUpdataOk", this.state.roleInformation);
      // values.roleId = this.state.roleInformation.roleId;
      values.parentMenuId = roleInformation.menuId;
      // values.menuId = this.state.roleInformation.menuId;
      // values.id = this.state.roleInformation.id;
      // console.log("handleOk", values);

      actions.add(values, null, "menuManage");
      // this.props.actions.addApp(values);
      this.setState({
        addVisible: false,
        currentId: roleInformation.menuId
      });
      form.resetFields();
    });
  }

  handleCancel(e) {
    this.setState({
      addVisible: false,
      updateVisible: false,
      roleInformation: null,
      currentSelected: null
    });
    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  render() {
    // console.log("ChildMenus", this.props.ChildMenus.data)
    const { IntroduceMenu, ChildMenus, MenuFind } = this.props;
    const { treeData, addVisible, updateVisible, pagination, loading, selectedKeys } = this.state;

    return (
      <div
        style={{
          display: "flex",
          flexDirection: "row"
        }}
        onClick={this.DOMClick}
      >
        <div
          style={{
            width: "200px",
            overflowX: "auto",
            textAlign: "left",
            lineHeight: "60px",
            padding: "10px",
            borderBottom: "1px solid #ccc",
            zIndex: 9
          }}
        >
          <Tree
            // loadData={this.onLoadData}
            selectedKeys={selectedKeys}
            autoExpandParent={true}
            defaultExpandAll={true}
            onRightClick={this.rightClick}
            onSelect={this.onTreeSelect}
          >
            {treeData ? (treeData.length !== 0 ? this.renderTreeNodes(treeData) : null) : null}
            {/* {this.renderTreeNodes(this.state.treeData)}; */}
          </Tree>
        </div>
        <div
          style={{
            minHeight: "78vh",
            flex: 6,
            textAlign: "left",
            padding: "10px",
            borderBottom: "1px solid #ccc"
          }}
        >
          <div
            style={{
              textAlign: "left",
              height: "60px",
              lineHeight: "60px",
              padding: "10px",
              borderBottom: "1px solid #ccc"
            }}
          >
            基本信息
          </div>

          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "10px" }} type="flex">
              <Col span={8}>
                菜单编号：
                {IntroduceMenu.length !== 0 ? IntroduceMenu.data.menuCode : ""}
              </Col>
              <Col span={8}>
                菜单名称：
                {IntroduceMenu.length !== 0 ? IntroduceMenu.data.menuName : ""}
              </Col>
              <Col span={8}>
                菜单类型：
                {IntroduceMenu.length !== 0 ? (IntroduceMenu.data.menuType ? "其他" : "菜单") : ""}
              </Col>
            </Row>
            <Row style={{ marginTop: "10px" }} type="flex">
              <Col span={6}>
                菜单描述：
                {IntroduceMenu.length !== 0 ? IntroduceMenu.data.menuDesc : ""}
              </Col>
            </Row>
          </div>
          {ChildMenus.data ? (
            ChildMenus.data.length !== 0 ? (
              <div
                style={{
                  textAlign: "left",
                  height: "38px",
                  padding: "10px",
                  lineHeight: "26px",
                  borderBottom: "1px solid #ccc",
                  marginBottom: "10px",
                  marginTop: "10px"
                }}
              >
                子菜单列表
              </div>
            ) : (
              ""
            )
          ) : (
            ""
          )}
          {/* <div style={{padding: "10px",marginBottom: "10px",}}>
            <Row style={{marginTop: "10px"}} type="flex" justify="space-between">
              <Col span={8}>
                菜单名称：<Input placeholder="请输入菜单名称" style={{width: "70%"}} ref="roleName" />
              </Col>
              <Col span={8} style={{textAlign: "right"}}>
                <Button type="primary" onClick={this.search.bind(this)} style={{marginRight: 10}}>
                  查询
                </Button>
                <Button type="primary" onClick={this.showAddModal.bind(this)}>
                  新增
                </Button>
              </Col>
            </Row>
          </div> */}
          <NewForm
            ref={this.saveFormRef.bind(this)}
            addVisible={addVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdateForm
            ref={this.saveUpdateFormRef.bind(this)}
            updateVisible={updateVisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleUpdataOk.bind(this)}
            list={MenuFind.length !== 0 ? MenuFind.data : MenuFind}
          />
          {ChildMenus.data ? (
            ChildMenus.data.length !== 0 ? (
              <Table
                bordered
                size="small"
                columns={this.columns}
                locale={{ emptyText: "暂无数据..." }}
                dataSource={ChildMenus.data}
                pagination={pagination}
                loading={loading}
                onChange={this.handlePageChange.bind(this)}
              />
            ) : (
              ""
            )
          ) : (
            ""
          )}
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    Login: state.login.get("logininfo"),
    RoleManage: state.SystemManage.get("roleManageData"),
    SysroleFind: state.SystemManage.get("sysroleFindData"),

    roleMenus: state.SystemManage.get("roleMenusData"),
    menuTree: state.SystemManage.get("menuTreeData"),
    IntroduceMenu: state.SystemManage.get("introduceMenuData"),
    ChildMenus: state.SystemManage.get("childMenusData"),

    MenuFind: state.SystemManage.get("menuFindData"),

    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MenuManage);
