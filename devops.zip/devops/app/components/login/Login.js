import React from "react";
import ReactDOM from "react-dom";
import { Button, FormControl, FormGroup, InputGroup } from "react-bootstrap";
import intl from "react-intl-universal";
import "whatwg-fetch";
import _ from "lodash";
import "./Login.css";
import { message, Icon } from "antd";
import md5 from "md5";
import history from "../../routes/history";

const SUPPOER_LOCALES = [
  {
    name: "English",
    value: "en-US"
  },
  {
    name: "简体中文",
    value: "zh-CN"
  }
];
class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      pass: "",
      errMsg: "",
      initDone: false,
      defalutLanguage: "zh-CN"
    };
    this.login = this.login.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
    // this.handleChange = this.handleChange.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.Login == 1) {
      history.push("/devops/dashboard");
    } else if (nextProps.Login == 0) {
      // message.info("登录失败！");
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    return true;
  }

  componentDidMount() {
    const { location, actions } = this.props;
    this.loadLocales();

    if (location.state && location.state.key == "logout") {
      message.info("请重新登录");
      actions.logout();
    }
  }

  componentDidUpdate() {
    // console.log(this.props.Login.get("loginStatus"));
    // if (this.props.Login.get("loginStatus")) {
    //     this.props.history.push('/home');
    // }else {
    //     localStorage.clear();
    //     this.props.history.push('/login');
    // }
  }

  loadLocales() {
    let currentLocale = "zh-CN";
    if (sessionStorage.getItem("lang")) {
      currentLocale = sessionStorage.getItem("lang");
    } else {
      currentLocale = intl.determineLocale({
        urlLocaleKey: "lang",
        cookieLocaleKey: "lang"
      });
      if (!_.find(SUPPOER_LOCALES, { value: currentLocale })) {
        currentLocale = "zh-CN";
      }
      this.setState({
        defalutLanguage: currentLocale
      });
    }
    fetch(`/locales/${currentLocale}.json`)
      .then(res => {
        return res.json();
      })
      .then(data => {
        intl.init({
          currentLocale,
          locales: {
            [currentLocale]: data
          }
        });
        // After loading CLDR locale data, start to render
        this.setState({ initDone: true });
      });
  }

  onKeyDown(event) {
    if (event.keyCode == 13) {
      this.login();
    }
  }

  login() {
    const { actions } = this.props;
    const userName = ReactDOM.findDOMNode(this.refs.userName).value;
    // let password = md5(ReactDOM.findDOMNode(this.refs.password).value);
    const pass = ReactDOM.findDOMNode(this.refs.password).value;
    const password = md5(pass);
    if (userName && pass) {
      localStorage.setItem("loggedIn", true);
      sessionStorage.setItem("userName", userName);
      actions.login(userName, password);
      this.setState({
        errMsg: ""
      });
    } else if (userName == "") {
      this.setState({
        errMsg: intl.get("login.nameNotEmpty")
      });
    } else if (pass == "") {
      this.setState({
        errMsg: intl.get("login.passNotEmpty")
      });
    } else {
      this.setState({
        errMsg: intl.get("login.passError")
      });
    }
  }
  // 暂时注释
  // handleChange(value) {
  //   sessionStorage.setItem("lang", value);
  //   this.setState({
  //     defalutLanguage: value
  //   });
  //   location.search = `?lang=${value}`;
  // }

  render() {
    const { errMsg } = this.state;
    return (
      <div className="login">
        <div className="login__logo">
          {/* <img className="login_img" src={"../../assets/images/login/title.png"} alt="logo" /> */}
        </div>
        <div className="login__inner">
          <div className="login__inner_slogan">
            {/* <img src={"../../assets/images/login/slogon.png"} alt="logo" /> */}
          </div>
          {/* <div className="s_l">
            <Select
              defaultValue={sessionStorage.getItem("lang")}
              style={{ width: 120 }}
              onChange={this.handleChange}
            >
              <Option value="zh-CN">中文</Option>
              <Option value="en-US">English</Option>
            </Select>
          </div> */}
          <div className="login__inner__right">
            {errMsg ? (
              <span className="error-msg">
                <Icon
                  type="minus-circle"
                  theme="filled"
                  style={{ color: "#f45b41", margin: "0px 10px" }}
                />
                {errMsg}
              </span>
            ) : null}

            <form>
              <span className="login__inner_user">{intl.get("login.userLogon")}</span>
              <FormGroup style={{ width: "100%" }}>
                <InputGroup style={{ width: "84%" }}>
                  <InputGroup.Addon>
                    <span className="user-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "100%", border: "1px solid #b5b5b5" }}
                    ref="userName"
                    type="text"
                    onKeyDown={this.onKeyDown}
                    placeholder={intl.get("login.inputUser")}
                  />
                </InputGroup>
              </FormGroup>
              <FormGroup style={{ width: "100%" }}>
                <InputGroup style={{ width: "84%" }}>
                  <InputGroup.Addon>
                    <span className="pass-icon" />
                  </InputGroup.Addon>
                  <FormControl
                    style={{ width: "100%", border: "1px solid #b5b5b5" }}
                    type="password"
                    ref="password"
                    placeholder={intl.get("login.inputPass")}
                    onKeyDown={this.onKeyDown}
                  />
                </InputGroup>
              </FormGroup>

              <div className="login-inner__btn">
                <Button
                  style={{ width: "91%" }}
                  bsStyle="primary"
                  type="button"
                  onClick={this.login}
                >
                  {intl.get("login.loginBtn")}
                </Button>
              </div>
            </form>
          </div>
        </div>
        {/* <div>
          <span className="login-footer">西安华信智慧数字科技有限公司</span>
        </div> */}
      </div>
    );
  }
}
Login.propTypes = {};

export default Login;
