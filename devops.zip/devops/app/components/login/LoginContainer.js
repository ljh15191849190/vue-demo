import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

import Login from "./Login";
import * as actions from "../../actions/index";

import * as action from "../../actions/systemManageAction";

const mapStateToProps = state => {
  return {
    Login: state.login.get("loginStatue"),
    loginData: state.login.get("loginData"),
    Logout: state.login.get("logoutStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    // actions: bindActionCreators(actions, dispatch),
    actions: bindActionCreators(Object.assign({}, action, actions), dispatch)
  };
};

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(Login)
);
