import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  message,
  Popconfirm,
  Row,
  Col,
  Checkbox,
  TreeSelect
} from "antd";
import _ from "lodash";
import * as action from "../../../../actions/Role";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;
const SHOW_PARENT = TreeSelect.SHOW_PARENT;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, form, treeData, resData } = props;
  const { getFieldDecorator } = form;
  const tProps = {
    treeData,
    allowClear: true,
    treeCheckable: true,
    showCheckedStrategy: SHOW_PARENT,
    searchPlaceholder: "请选择成员名称"
  };

  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增团队"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="成员名称：">
          {getFieldDecorator("userIds", {
            rules: Validation.Rule_select
          })(
            <TreeSelect
              {...tProps}
              filterTreeNode={(inputValue, treeNode) => {
                return treeNode.props.title.indexOf(inputValue) !== -1;
              }}
            />
          )}
        </FormItem>
        <FormItem label="角色名称：">
          {getFieldDecorator("roleId", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择角色名称" allowClear>
              {resData
                ? resData.map(v => {
                    return (
                      <Option value={v.id} key={v.id}>
                        {v.roleName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class EditableCheckbook extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: null,
      checked: null
    };
  }

  componentWillMount() {
    const { value, checked } = this.props;
    this.setState({
      value,
      checked
    });
  }

  chenkboxonChange(e) {
    const { record, checkRoleadd, checkRoledelete } = this.props;
    // this.setState({
    //   checked: e.target.checked
    // });
    if (e.target.checked === true) {
      record.roleIds.push(e.target.value);
      checkRoleadd(record.roleIds);
    } else {
      _.pull(record.roleIds, e.target.value);
      checkRoledelete(record.roleIds);
    }
  }

  render() {
    const { value } = this.state;
    const { checked } = this.props;
    return (
      <Checkbox
        value={value}
        defaultChecked={checked}
        onChange={this.chenkboxonChange.bind(this)}
      />
    );
  }
}

class Team extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updataData: {},
      environmentValue: "",
      key: 1
    };
    this.checkedvalue = [];
    this.checkRoledelete = this.checkRoledelete.bind(this);
    this.checkRoleadd = this.checkRoleadd.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  //   确认删除
  handleDelOk(record) {
    const { actions, projectId } = this.props;
    actions.deleteTeam({ teamId: record.teamId });
  }

  // 授权
  handleauthorize(record) {
    const { actions, projectId } = this.props;
    actions.authorizeTeam({
      teamId: record.teamId,
      roleIds: record.roleIds
    });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  //   控件搜索
  search() {
    const { actions, projectId } = this.props;
    const environmentName = ReactDOM.findDOMNode(this.refs.environmentName).value;
    actions.getTeam({
      realName: encodeURIComponent(environmentName),
      projectId,
      page: 1
    });
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentWillMount() {
    const { actions } = this.props;
    actions.userallTeam();
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getRole({
      roleName: "",
      projectId,
      page: 1,
      size: 50,
      conditions: []
    });
    actions.getTeam({
      realName: "",
      projectId,
      page: 1
    });
  }
  // componentWillUnmount() {
  //   this.query();
  // }

  query() {
    const { actions, projectId } = this.props;
    actions.getTeam({
      realName: "",
      projectId,
      page: 1
    });
  }

  componentDidUpdate(nextProps) {
    const { delStatus, pageConfig, actions, projectId, addStatus, authorStatus } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      // this.query()
      if (
        nextProps.pageConfig.total % nextProps.pageConfig.size === 1 &&
        nextProps.pageConfig.totalPage > 1
      ) {
        actions.getTeam({
          realName: "",
          projectId,
          page: nextProps.pageConfig.totalPage - 1
        });
      } else {
        actions.getTeam({
          realName: "",
          projectId,
          page: nextProps.pageConfig.page
        });
      }
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      this.query();
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      this.query();
    }
    if (authorStatus && authorStatus === 1) {
      message.info("授权成功");
      this.query();
    } else if (authorStatus && authorStatus === 2) {
      message.error("授权失败");
      this.query();
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { actions, projectId } = this.props;
    // this.setState({ loading: true });
    const environmentName = ReactDOM.findDOMNode(this.refs.environmentName).value;
    actions.getTeam({
      realName: environmentName,
      projectId,
      page: pagination.current
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const { actions, projectId } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.projectId = projectId;
      // values.projectId = 2;
      actions.addTeam(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.setState({
      visible: false
    });
  }

  chenkboxonChange(e) {
    // console.log(`checked = ${e.target.checked}`);
  }

  checkRoleadd(checkedvalue) {
    // console.log(checkedvalue)
    this.checkedvalue = checkedvalue;
  }

  checkRoledelete(checkedvalue) {
    // _.pull(this.checkedvalue, checkedvalue)
    this.checkedvalue = checkedvalue;
  }

  render() {
    const { resData, teamresData, treeData, typeData } = this.props;
    const { pagination, loading, visible } = this.state;
    // 动态表头
    const children = [];
    if (resData) {
      resData.map(item => {
        const obj = {};
        obj.title = item.roleName;
        obj.align = "center";
        obj.dataIndex = item.id;
        obj.key = item.id;
        obj.render = (text, record, index) => (
          <EditableCheckbook
            key={Math.random()}
            record={record}
            value={item.id ? item.id : ""}
            checked={_.includes(record.roleIds, item.id)}
            checkRoleadd={this.checkRoleadd}
            checkRoledelete={this.checkRoledelete}
          />
        );
        children.push(obj);
      });
    }
    // 成员
    if (teamresData) {
      teamresData.map(val => {
        val.key = val.teamId;
      });
    }

    // 弹出框 成员名称(树)
    if (treeData) {
      treeData.map(treeval => {
        treeval.key = treeval.id;
        treeval.title = `${treeval.realName}     ${treeval.email}`;
        treeval.value = treeval.userId;
      });
    }
    const columns = [
      {
        title: "成员姓名",
        dataIndex: "realName",
        key: "realName",
        render: (text, record) => this.renderColumns(text, record, "realName")
      },
      {
        title: "角色",
        children
      },
      {
        title: "操作",
        dataIndex: "operation",
        align: "center",
        width: "15%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.handleauthorize(record);
                }}
                className="padright"
              >
                <span />
                授权
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>成员名称:</span>
              <Input placeholder="成员名称" style={{ width: "70%" }} ref="environmentName" />
            </Col>
            <Col span={16} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            typeData={typeData}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
            treeData={treeData ? treeData : []}
            resData={resData ? resData : []}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={columns}
          dataSource={teamresData ? teamresData : []}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.Role.get("resData"),
    teamresData: state.Role.get("teamresData"),
    treeData: state.Role.get("userallData"),
    pageConfig: state.Role.get("teampageConfig"),
    addStatus: state.Role.get("teamAddStatus"),
    delStatus: state.Role.get("teamdelStatus"),
    authorStatus: state.Role.get("authorStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Team);
