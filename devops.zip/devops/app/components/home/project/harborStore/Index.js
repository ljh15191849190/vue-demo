import React from "react";
import HarborStore from "./harborStore";
import HarborStoreDetail from "./harborStoreDetail";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: false,
      selectedRowData: {}
    };
    this.triggleStatus = this.triggleStatus.bind(this);
  }

  triggleStatus(show) {
    this.setState({
      showRepository: show
    });
  }

  selectedRow(record) {
    this.setState({
      selectedRowData: record
    });
  }

  componentDidMount() {}

  render() {
    const { projectId, projectCode } = this.props;
    const { showRepository, selectedRowData } = this.state;
    return (
      <div>
        {showRepository ? (
          <HarborStoreDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : (
          <HarborStore
            projectId={projectId}
            projectCode={projectCode}
            selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        )}
      </div>
    );
  }
}

export default Index;
