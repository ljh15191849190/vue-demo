import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { CopyToClipboard } from "react-copy-to-clipboard";
import _ from "lodash";
import {
  Table,
  Card,
  Popover,
  Button,
  Tooltip,
  Row,
  Col,
  Icon,
  Tabs,
  Divider,
  Spin,
  message
} from "antd";
import CodeMirror from "../../../commons/CodeMirror/codemirroe";
import component from "../../../../assets/images/dashboard/component.png";
import * as actionsharbor from "../../../../actions/ImageHouse";
import QuillEditor from "../../../commons/QuillEditor/Index";
import BugBar from "../../../commons/BugBar/Bug";

const TabPane = Tabs.TabPane;

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "fdsdgfdgfdgfdgfd",
      copied: false,
      dataSource: [],
      pagination: {},
      loading: false,
      visible: false,
      updataData: {},
      enshrine: null,
      SpinState: "end"
    };
    this.timer = null;
    this.YarnValue = "";
    this.EditorValue = "";
  }

  componentWillMount() {
    const { selectedRow } = this.props;
    this.setState({
      enshrine: selectedRow.collectStatus
    });
  }

  // 扫描
  ScanHorbor(record) {
    const { actions, selectedRow } = this.props;
    this.setState({
      id: record.id,
      SpinState: "start"
    });
    actions.houseImageScanTag({
      imageName: selectedRow.imageName,
      imageId: selectedRow.imageId,
      tagName: record.tagName
    });
    this.timer = setInterval(() => {
      actions.houseImageScanTags({
        imageName: selectedRow.imageName,
        tagName: record.tagName
      });
    }, 1000);
  }

  componentWillReceiveProps(nextProps) {
    const { id } = this.state;
    const { actions, ScanTagsData, selectedRow } = this.props;
    if (
      nextProps.ScanTagsData &&
      nextProps.ScanTagsData.scan_overview &&
      nextProps.ScanTagsData.scan_overview.scan_status == "finished"
    ) {
      this.setState({
        SpinState: "end"
      });
      nextProps.ScanTagsData.id = id;
      clearInterval(this.timer);
      if (nextProps.ScanTagsData !== ScanTagsData) {
        actions.houseImageUpdateScan({
          data: nextProps.ScanTagsData
        });
        // 刷新列表
        setTimeout(() => {
          actions.houseImageTags({
            page: 1,
            size: 10,
            sortid: "updateTime",
            sortvalue: "desc",
            conditions: [
              {
                name: "imageId",
                sopt: "eq",
                value: String(selectedRow.imageId)
              }
            ]
          });
        }, 1000);

        clearInterval(this.timer);
      } else {
        clearInterval(this.timer);
      }
    } else if (
      nextProps.ScanTagsData &&
      nextProps.ScanTagsData.scan_overview &&
      nextProps.ScanTagsData.scan_overview.scan_status == "error"
    ) {
      this.setState({
        SpinState: "end"
      });
      clearInterval(this.timer);
      if (nextProps.ScanTagsData !== ScanTagsData) {
        message.info("扫描失败");
      }
    } else if (nextProps.ScanTagsData == "-1") {
      this.setState({
        SpinState: "end"
      });
      clearInterval(this.timer);
    }
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(false);
    clearInterval(this.timer);
  }

  Enshrine() {
    const { actions, selectedRow } = this.props;
    actions.houseCollect({
      imageId: selectedRow.imageId,
      flag: 1
    });
    this.setState({
      enshrine: "1"
    });
  }

  cancleEnshrine() {
    const { actions, selectedRow } = this.props;
    actions.houseCollect({
      imageId: selectedRow.imageId,
      flag: 2
    });
    this.setState({
      enshrine: "2"
    });
  }

  componentDidMount() {
    const { selectedRow, projectId, actions } = this.props;
    actions.gethouseImageInfo({
      id: selectedRow.id,
      projectId
    });
    actions.houseImageTags({
      page: 1,
      size: 10,
      sortid: "updateTime",
      sortvalue: "desc",
      conditions: [
        {
          name: "imageId",
          sopt: "eq",
          value: String(selectedRow.imageId)
        }
      ]
    });
  }

  callback() {
    const { selectedRow, projectId, actions } = this.props;
    actions.gethouseImageInfo({
      id: selectedRow.id,
      projectId
    });
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    // this.setState({ loading: true });
  }

  // 保存imageInfo
  handleSave() {
    const { actions, selectedRow } = this.props;
    actions.houseImageUpdate({
      id: selectedRow.id,
      imageInfo: this.EditorValue
    });
  }

  handleSaveYarn() {
    const { actions, selectedRow } = this.props;
    actions.houseImageUpdate({
      id: selectedRow.id,
      dockerfile: this.YarnValue
    });
  }

  getYmlValue(value) {
    this.YarnValue = value;
  }

  getEditorValue(value) {
    this.EditorValue = value;
  }

  onCopy() {
    this.setState({ copied: true });
  }

  render() {
    const { houseTagsData, imageInfoData, ScanTagsData } = this.props;
    const { SpinState, enshrine, loading } = this.state;
    if (houseTagsData) {
      houseTagsData.map(item => {
        item.key = item.id;
      });
    }

    const columns = [
      {
        title: "标签",
        dataIndex: "tagName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "tagName")
      },
      {
        title: "大小(MB)",
        dataIndex: "imageSize",
        width: "15%",
        // render: (text, record) => this.renderColumns(text, record, "imageSize")
        render(imageSize) {
          return (Number(imageSize) / 1024 / 1024).toFixed(2);
        }
      },
      {
        title: "Pull命令",
        dataIndex: "pullUrl",
        width: "15%",
        render: (text, record) => {
          return (
            <div>
              <CopyToClipboard text={`docker pull ${text}`} onCopy={this.setState.bind(this)}>
                {/* <Button icon="copy" ghost={true} size="large" /> */}
                <Icon
                  type="copy"
                  theme="outlined"
                  style={{ fontSize: "18px", color: "#08c", cursor: "pointer" }}
                />
              </CopyToClipboard>
            </div>
          );
        }
      },
      {
        title: "漏洞",
        dataIndex: "severity",
        width: "15%",
        render(text, record) {
          let wu;
          let loudongNum;
          let weizhi;
          let jiaodi;
          let zhongdeng;
          let yanzhong;
          let total = 0;

          if (record.scanInfo.components && record.scanInfo.components.summary) {
            total = record.scanInfo.components.total || "";
            record.scanInfo.components.summary.map(item => {
              switch (item.severity) {
                case 1:
                  wu = item.count ? item.count / total : 0;
                  loudongNum = item.count ? item.count : 0;
                  break;
                case 2:
                  weizhi = item.count ? item.count / total : 0;
                  break;
                case 3:
                  jiaodi = item.count ? item.count / total : 0;
                  break;
                case 4:
                  zhongdeng = item.count ? item.count / total : 0;
                  break;
                case 5:
                  yanzhong = item.count ? item.count / total : 0;
                  break;
                default:
                  break;
              }
            });
          }
          const width = {};
          width.yanzhong = (yanzhong * 100).toFixed(2);
          width.zhongdeng = (zhongdeng * 100).toFixed(2);
          width.jiaodi = (jiaodi * 100).toFixed(2);
          width.weizhi = (weizhi * 100).toFixed(2);
          width.wu = (wu * 100).toFixed(2);
          const config = {
            1: "无",
            2: "未知",
            3: "较低",
            4: "中等",
            5: "严重"
          };
          const configColor = {
            1: "#008000",
            2: "#848484",
            3: "#FFFF00",
            4: "#FFA500",
            5: "#D1210A"
          };
          const configIcon = {
            1: "check-circle",
            2: "question-circle",
            3: "minus-circle",
            4: "warning",
            5: "exclamation-circle"
          };
          const content = (
            <div>
              <p style={{ fontSize: 15 }}>
                {record.scanInfo.components ? record.scanInfo.components.total : ""}个组件中的
                {Number(record.scanInfo.components ? record.scanInfo.components.total : "") -
                  Number(loudongNum)}
                个含有漏洞
              </p>
              {record.scanInfo.components && record.scanInfo.components.summary.length > 0
                ? _.orderBy(record.scanInfo.components.summary, ["severity"], ["desc"]).map(
                    item => {
                      return (
                        <div>
                          <p key={Math.random()}>
                            <span>
                              <Icon
                                type={configIcon[item.severity]}
                                style={{
                                  fontSize: 16,
                                  marginRight: 10,
                                  color: configColor[item.severity]
                                }}
                              />
                            </span>
                            <span>{`${item.count}    ${config[item.severity]}`}</span>
                          </p>
                        </div>
                      );
                    }
                  )
                : ""}
              <p style={{ fontSize: 15 }}>扫描完成时间：{record.scanInfo.update_time}</p>
            </div>
          );

          return (
            <Popover
              content={content}
              // title={`漏洞严重度：${config[record.scanInfo.severity]}`}
              title={
                <div>
                  <span>漏洞严重度：</span>
                  <span>
                    <Icon
                      type={configIcon[record.scanInfo.severity]}
                      style={{
                        fontSize: 16,
                        marginRight: 10,
                        color: configColor[record.scanInfo.severity]
                      }}
                    />
                  </span>
                  <span>{config[record.scanInfo.severity]}</span>
                </div>
              }
            >
              {/* <div>{config[record.scanInfo.severity]}</div> */}
              <div>
                {(record.tagName == ScanTagsData.name &&
                  ScanTagsData &&
                  ScanTagsData.scan_overview &&
                  ScanTagsData.scan_overview.scan_status == "pending") ||
                (ScanTagsData &&
                  ScanTagsData.scan_overview &&
                  ScanTagsData.scan_overview.scan_status == "running") ? (
                  <Spin spinning={true}>
                    <BugBar width={width} />
                  </Spin>
                ) : (
                  <Spin spinning={false}>
                    <BugBar width={width} />
                  </Spin>
                )}
              </div>
            </Popover>
          );
          // return config[record.scanInfo.severity];
        }
      },
      {
        title: "作者",
        dataIndex: "author",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "author")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "20%",
        // render: (text, record) => this.renderColumns(text, record, "createTime")
        render(text, record) {
          return record.createTime;
        }
      },
      {
        title: "操作",
        dataIndex: "operation",
        width: "10%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              {SpinState !== "start" ? (
                <a
                  onClick={() => {
                    this.ScanHorbor(record);
                  }}
                  className="padright"
                >
                  扫描
                </a>
              ) : (
                <span className="padright">扫描</span>
              )}
            </div>
          );
        }
      }
    ];

    return (
      <div>
        <div>
          <span onClick={() => this.goBack()} style={{ cursor: "pointer" }}>
            <Icon type="left" style={{ fontSize: 16, color: "#08c" }} />
            返回
          </span>
          <span> /镜像仓库</span>
        </div>
        <div>
          <Row type="flex" style={{ marginTop: 20 }}>
            <Col span={4} style={{ textAlign: "center" }}>
              <img src={component} alt="" />
            </Col>
            <Col span={10}>
              <p>{imageInfoData.imageName}</p>
              {/* <p>
                <Input.TextArea
                  disabled
                  value={
                    imageInfoData.imageDesc ? imageInfoData.imageDesc : "此镜像仓库没有描述信息"
                  }
                />
              </p> */}
            </Col>
            <Col span={6} style={{ textAlign: "right" }}>
              {enshrine == "2" ? (
                <Button type="primary" onClick={this.Enshrine.bind(this)} className="padright">
                  <Icon type="star" theme="outlined" />
                  收藏
                </Button>
              ) : (
                <Button
                  type="primary"
                  onClick={this.cancleEnshrine.bind(this)}
                  className="padright"
                >
                  <Icon type="star" theme="filled" />
                  取消收藏
                </Button>
              )}
            </Col>
            <Col span={24}>
              <Card>
                <Row type="flex">
                  <Col span={14}>
                    <span>下载镜像：</span>
                    <span>
                      <a>{imageInfoData.imageUrl}</a>
                    </span>
                    <span style={{ marginLeft: 30 }}>
                      <CopyToClipboard
                        text={`docker pull ${imageInfoData.imageUrl}`}
                        onCopy={this.setState.bind(this)}
                      >
                        <Icon
                          type="copy"
                          theme="outlined"
                          style={{ fontSize: "18px", color: "#08c", cursor: "pointer" }}
                        />
                      </CopyToClipboard>
                    </span>
                  </Col>
                  <Divider type="vertical" />
                  <Col span={3}>
                    <span>
                      <Tooltip title="下载数">
                        <Icon
                          type="cloud-download"
                          theme="outlined"
                          style={{ fontSize: "18px", color: "#08c" }}
                        />
                      </Tooltip>
                    </span>
                    <span style={{ fontSize: "18px", marginLeft: 15 }}>
                      {imageInfoData.pullCount}
                    </span>
                  </Col>
                  <Divider type="vertical" />
                  <Col span={3}>
                    <span>
                      <Tooltip title="收藏数">
                        <Icon
                          type="star"
                          theme="filled"
                          style={{ fontSize: "18px", color: "#08c" }}
                        />
                      </Tooltip>
                    </span>
                    <span style={{ fontSize: "18px", marginLeft: 15 }}>
                      {imageInfoData.collectNum}
                    </span>
                  </Col>
                </Row>
              </Card>
            </Col>
            <Col span={24}>
              <Tabs defaultActiveKey="1" onChange={this.callback.bind(this)}>
                <TabPane tab="基本信息" key="1">
                  <Button
                    type="primary"
                    onClick={this.handleSave.bind(this)}
                    className="floatbaseInfo"
                  >
                    保存
                  </Button>
                  {/* {imageInfoData.imageInfo} */}
                  <QuillEditor
                    EditorData={imageInfoData.imageInfo}
                    key={Math.random()}
                    getValue={this.getEditorValue.bind(this)}
                  />
                </TabPane>
                <TabPane tab="Dockerfile" key="2">
                  <Button
                    type="primary"
                    onClick={this.handleSaveYarn.bind(this)}
                    className="floatbaseInfo"
                  >
                    保存
                  </Button>
                  <CodeMirror
                    title="Dockerfile"
                    serviceOrchestrationYml={
                      imageInfoData.imageDockerfile ? imageInfoData.imageDockerfile : ""
                    }
                    getValue={this.getYmlValue.bind(this)}
                  />
                </TabPane>
                <TabPane tab="版本及接口" key="3">
                  <Table
                    bordered
                    size="small"
                    columns={columns}
                    dataSource={houseTagsData}
                    // pagination={this.state.pagination}
                    loading={loading}
                    onChange={this.handlePageChange.bind(this)}
                  />
                </TabPane>
                {/* <TabPane tab="属性" key="4">
                  <p>{`贡献者：${
                    imageInfoData.createUser ? imageInfoData.createUser : "admin"
                  }`}</p>
                  <p>{`收藏数：${imageInfoData.collectNum}`}</p>

                  <p>{`创建时间：${imageInfoData.createTime}`}</p>
                </TabPane> */}
              </Tabs>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    imageInfoData: state.ImageHouse.get("imageInfoData"),
    houseTagspageConfig: state.ImageHouse.get("houseTagspageConfig"),
    houseTagsData: state.ImageHouse.get("houseTagsData"), // 版本
    houseScanStatus: state.ImageHouse.get("houseScanStatus"),
    ScanTagsData: state.ImageHouse.get("ScanTagsData") // 扫描2
    // housePubpageConfig: state.ImageHouse.get("housePubpageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(actionsharbor, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Index);
