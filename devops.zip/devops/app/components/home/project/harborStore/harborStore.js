import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Card, Input, Modal, Button, message, Row, Col, Tabs, Divider, Pagination } from "antd";
import "./Index.css";
import * as Pathactions from "../../../../actions/ImageHouse";
import component from "../../../../assets/images/dashboard/component.png";

const TabPane = Tabs.TabPane;
// 窗口
const CreateFormUp = props => {
  const { visible, onCancel, loading } = props;
  return (
    <Modal
      maskClosable={false}
      visible={visible}
      loading={loading}
      title="上传镜像"
      onCancel={onCancel}
      footer={null}
      width={600}
    >
      <Row>
        <Col span={24}>1.在本地docker环境中输入以下命令进行登录</Col>
        <div className="upanddownmodalMargin">
          <a>sudo docker login harbor.hscloud.local</a>
        </div>
        <Col span={24}>2.然后，对本地需要push的image进行标记，比如：</Col>
        <div className="upanddownmodalMargin">
          <a>sudo docker tag hscloud/ubuntu:latest harbor.hscloud.local/hscloud/ubuntu:latest</a>
        </div>
        {/* <div className="upanddownmodalMargin">
          <a>{"index.tenxcloud.com/<username>/<repository>:<tag>"}</a>
        </div> */}
        <Col span={24}>3.最后在命令行输入如下命令，就可以push这个image到镜像仓库中了</Col>
        <div className="upanddownmodalMargin">
          <a>sudo docker push harbor.hscloud.local/hscloud/ubuntu:latest</a>
        </div>
      </Row>
    </Modal>
  );
};
class CreateFormDown extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { downvisible, onCancel } = this.props;

    return (
      <Modal
        maskClosable={false}
        visible={downvisible}
        onCancel={onCancel}
        title="下载镜像"
        footer={null}
        width={600}
      >
        <Row>
          <Col span={24}>1.私有镜像需要login后才能拉取</Col>
          <div className="upanddownmodalMargin">
            <a>{"sudo docker pull harbor.hscloud.local/<projectname>/<repository>:<tag>"}</a>
          </div>
          <Col span={24}>{"2.为了在本地方便使用，下载后可以修改<tag>为短标签，比如："}</Col>
          <div className="upanddownmodalMargin">
            <a>
              {
                "sudo docker tag harbor.hscloud.local/hscloud/hello-world:latest hscloud/hello-world:latest"
              }
            </a>
          </div>
        </Row>
      </Modal>
    );
  }
}
class CommonTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  openHouseDetail(element) {
    const { openHouseDetail } = this.props;
    openHouseDetail(element);
  }

  render() {
    const { tableData, pagination, PaginationonChange } = this.props;
    return (
      <div>
        {tableData.map(element => {
          return (
            <div key={element.id}>
              <Row>
                <Card bordered={false}>
                  <Col span={8}>
                    <Card bordered={false}>
                      <img className="FloatLeft" src={component} alt="" />
                      <span className="FloatLeft Margin-Left">
                        <a
                          onClick={this.openHouseDetail.bind(this, element)}
                          className="harborStroeName"
                        >
                          {element.imageName}
                        </a>
                        <p>
                          所属项目：
                          {element.harborProjectName}
                        </p>
                      </span>
                    </Card>
                  </Col>
                  <Col span={8}>
                    <Card style={{ marginTop: 15 }} bordered={false}>
                      镜像地址：
                      {element.imageUrl}
                    </Card>
                  </Col>
                  <Col span={8}>
                    <Card style={{ marginTop: 15 }} bordered={false}>
                      下载次数：
                      {element.pullCount}
                    </Card>
                  </Col>
                </Card>
              </Row>
              <Divider />
            </div>
          );
        })}
        <Card bordered={false} style={{ textAlign: "right" }}>
          <Pagination
            current={pagination.current}
            pageSize={pagination.pageSize}
            onChange={PaginationonChange}
            total={pagination.total}
            defaultCurrent={1}
          />
        </Card>
      </div>
    );
  }
}

class HarborStore extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 1,
      visible: false,
      downvisible: false,
      loading: false,
      pagination: {},
      pubpagination: {},
      collectpagination: {}
    };
  }

  showModalUpHarbor() {
    this.setState({
      visible: true
    });
  }

  showModalDownHarbor() {
    this.setState({
      downvisible: true
    });
  }

  // 同步
  syncHarbor() {
    const { actions } = this.props;
    actions.houseImageSync();
    setTimeout(() => {
      this.queryPrivate();
    }, 8000);
  }

  hideModalHarbor() {
    this.setState({
      visible: false,
      downvisible: false
    });
  }

  // 获取表单数据
  getForm(form) {
    this.form = form;
  }

  // 控件搜索
  searchCollects() {
    const { actions } = this.props;
    const CollectsName = ReactDOM.findDOMNode(this.refs.CollectsName).value;
    actions.gethouseCollectList({
      page: 1,
      projectCode: CollectsName ? CollectsName : ""
    });
  }

  searchPrivate() {
    const { actions, projectCode } = this.props;
    const PrivateName = ReactDOM.findDOMNode(this.refs.PrivateName).value;
    actions.gethouseImageList({
      page: 1,
      conditions: [
        {
          name: "projectCode",
          sopt: "eq",
          value: projectCode
        },
        {
          name: "imageName",
          sopt: "cn",
          value: PrivateName
        }
      ]
    });
  }

  searchPub() {
    const { actions } = this.props;
    const PublicName = ReactDOM.findDOMNode(this.refs.PublicName).value;
    actions.gethouseImagePublicList({
      page: 1,
      conditions: [
        {
          name: "imagePublic",
          sopt: "eq",
          value: "2"
        },
        {
          name: "imageName",
          sopt: "cn",
          value: PublicName
        }
      ]
    });
  }

  queryPrivate() {
    const { actions, projectCode } = this.props;
    actions.gethouseImageList({
      page: 1,
      conditions: [
        {
          name: "projectCode",
          sopt: "eq",
          value: projectCode
        }
      ]
    });
  }

  queryPub() {
    const { actions } = this.props;
    actions.gethouseImagePublicList({
      page: 1,
      conditions: [
        {
          name: "imagePublic",
          sopt: "eq",
          value: "2"
        }
      ]
    });
  }

  componentDidMount() {
    const { actions } = this.props;
    this.queryPrivate();
    this.queryPub();
    actions.gethouseCollectList({
      page: 1,
      projectCode: ""
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.housepageConfig) {
      this.setState({
        pagination: {
          total: nextProps.housepageConfig.total,
          current: nextProps.housepageConfig.page,
          pageSize: nextProps.housepageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.housePubpageConfig) {
      this.setState({
        pubpagination: {
          total: nextProps.housePubpageConfig.total,
          current: nextProps.housePubpageConfig.page,
          pageSize: nextProps.housePubpageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.pageConfig) {
      this.setState({
        collectpagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    // collectpagination
  }

  callback(key) {
    const { actions } = this.props;
    if (key == "1") {
      this.queryPrivate();
      if (this.refs.PrivateName) {
        ReactDOM.findDOMNode(this.refs.PrivateName).value = "";
      }
    } else if (key == "2") {
      this.queryPub();
      if (this.refs.PublicName) {
        ReactDOM.findDOMNode(this.refs.PublicName).value = "";
      }
    } else {
      actions.gethouseCollectList({
        page: 1,
        projectCode: ""
      });
      if (this.refs.CollectsName) {
        ReactDOM.findDOMNode(this.refs.CollectsName).value = "";
      }
    }
  }

  // 私有分页
  PaginationPrivateChange(pagination, filters, sorter) {
    const { actions, projectCode } = this.props;
    // this.setState({ loading: true });
    const PrivateName = ReactDOM.findDOMNode(this.refs.PrivateName).value;
    actions.gethouseImageList({
      page: pagination,
      conditions: [
        {
          name: "projectCode",
          sopt: "eq",
          value: projectCode
        },
        {
          name: "imageName",
          sopt: "cn",
          value: PrivateName
        }
      ]
    });
  }

  // 公有分页
  PaginationPubChange(pubpagination, filters, sorter) {
    const { actions } = this.props;
    // this.setState({ loading: true });
    const PublicName = ReactDOM.findDOMNode(this.refs.PublicName).value;
    actions.gethouseImagePublicList({
      page: pubpagination,
      conditions: [
        {
          name: "imagePublic",
          sopt: "eq",
          value: "2"
        },
        {
          name: "imageName",
          sopt: "cn",
          value: PublicName
        }
      ]
    });
  }

  // 收藏分页
  PaginationChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const CollectsName = ReactDOM.findDOMNode(this.refs.CollectsName).value;
    actions.gethouseCollectList({
      page: pagination,
      projectCode: CollectsName ? CollectsName : ""
    });
  }

  openHouseDetail(elementData) {
    const { triggleStatus, selectedRow } = this.props;
    triggleStatus(true);
    selectedRow(elementData);
  }

  render() {
    const { houseimageData, houseimagePubData, collectsData } = this.props;
    const { pagination, pubpagination, collectpagination, visible, downvisible } = this.state;
    if (houseimageData) {
      houseimageData.map(item => {
        item.key = item.id;
      });
    }

    return (
      <div style={{ width: "calc(100vw - 300px)" }}>
        <Tabs defaultActiveKey="1" onChange={this.callback.bind(this)}>
          <TabPane tab="私有空间" key="1">
            <div>
              <Card>
                <p style={{ textAlign: "center", marginBottom: 0 }}>
                  私有空间——该空间下存放本项目的镜像
                </p>
              </Card>
            </div>
            <div>
              <Row>
                <Col span={6}>
                  <span style={{ marginRight: 20 }}>镜像名称:</span>
                  <Input
                    placeholder="镜像名称"
                    style={{ width: "70%" }}
                    ref="PrivateName"
                    defaultValue=""
                  />
                </Col>
                <Col span={15} style={{ textAlign: "right" }}>
                  <Button
                    type="primary"
                    onClick={this.searchPrivate.bind(this)}
                    style={{ marginRight: "10px" }}
                  >
                    查询
                  </Button>
                  <Button
                    type="primary"
                    onClick={this.showModalUpHarbor.bind(this)}
                    style={{ marginRight: "10px" }}
                  >
                    上传镜像
                  </Button>
                  <Button
                    type="primary"
                    style={{ marginRight: "10px" }}
                    onClick={() => this.showModalDownHarbor()}
                  >
                    下载镜像
                  </Button>
                  <Button type="primary" onClick={() => this.syncHarbor()}>
                    同步镜像
                  </Button>
                </Col>
              </Row>
              <div style={{ marginTop: 10 }}>
                <CommonTable
                  key={Math.random()}
                  tableData={houseimageData}
                  openHouseDetail={this.openHouseDetail.bind(this)}
                  PaginationonChange={this.PaginationPrivateChange.bind(this)}
                  pagination={pagination}
                />
              </div>
            </div>
          </TabPane>
          <TabPane tab="公有空间" key="2">
            <div>
              <Card>
                <p style={{ textAlign: "center", marginBottom: 0 }}>
                  公有空间——该空间下存放平台所有项目公开的镜像资源，实现跨团队共享容器镜像服务，建立企业内部高效开发协作的容器镜像PaaS平台。
                </p>
              </Card>
            </div>
            <div>
              <Row>
                <Col span={6}>
                  <span style={{ marginRight: 20 }}>镜像名称:</span>
                  <Input
                    placeholder="镜像名称"
                    style={{ width: "70%" }}
                    ref="PublicName"
                    defaultValue=""
                  />
                </Col>
                <Col span={15} style={{ textAlign: "right" }}>
                  <Button
                    type="primary"
                    onClick={this.searchPub.bind(this)}
                    style={{ marginRight: "10px" }}
                  >
                    查询
                  </Button>
                </Col>
              </Row>
              <div>
                <CommonTable
                  key={Math.random()}
                  tableData={houseimagePubData ? houseimagePubData : []}
                  openHouseDetail={this.openHouseDetail.bind(this)}
                  PaginationonChange={this.PaginationPubChange.bind(this)}
                  pagination={pubpagination}
                />
              </div>
            </div>
          </TabPane>
          <TabPane tab="我的收藏" key="3">
            <div>
              <Card>
                <p style={{ textAlign: "center", marginBottom: 0 }}>
                  我的收藏 ——
                  您可以将任意可见的镜像空间内的镜像，一键收藏到我的收藏，便捷的管理常用容器镜像。
                </p>
              </Card>
            </div>
            <div>
              <Row>
                <Col span={6}>
                  <span style={{ marginRight: 20 }}>镜像名称:</span>
                  <Input
                    placeholder="镜像名称"
                    style={{ width: "70%" }}
                    ref="CollectsName"
                    defaultValue=""
                  />
                </Col>
                <Col span={15} style={{ textAlign: "right" }}>
                  <Button
                    type="primary"
                    onClick={this.searchCollects.bind(this)}
                    style={{ marginRight: "10px" }}
                  >
                    查询
                  </Button>
                </Col>
              </Row>
              <div>
                <CommonTable
                  key={Math.random()}
                  tableData={collectsData}
                  openHouseDetail={this.openHouseDetail.bind(this)}
                  PaginationonChange={this.PaginationChange.bind(this)}
                  pagination={collectpagination}
                />
              </div>
            </div>
          </TabPane>
        </Tabs>

        <CreateFormUp visible={visible} onCancel={this.hideModalHarbor.bind(this)} />
        <CreateFormDown downvisible={downvisible} onCancel={this.hideModalHarbor.bind(this)} />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    collectsData: state.ImageHouse.get("collectsData"), // 收藏
    pageConfig: state.ImageHouse.get("pageConfig"),
    houseimageData: state.ImageHouse.get("houseimageData"), // 私有
    housepageConfig: state.ImageHouse.get("housepageConfig"),
    houseimagePubData: state.ImageHouse.get("houseimagePubData"), // 公有
    housePubpageConfig: state.ImageHouse.get("housePubpageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(Pathactions, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HarborStore);
