import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Layout, Menu, Breadcrumb, Icon } from "antd";

import "./styles/equipment.css";
import "./styles/public.css";
import moment from "moment";
import Components from "./defComponent/Index";
import Build from "./build/Index";
import CodeRelaction from "./code/Index";
import Repository from "./repository/MediumWarehouse";
import Overview from "./Overview/Index";
import CodeQuality from "../../commons/CodeQuality/CodeQuality";
import DeploymentManage from "./deployment/LayoutContainer";
import Environment from "./environment/Index";
import Resource from "./resource/Index";
import Role from "./role/Index";
import Team from "./team/Index";
import Maitanance from "./maitanance/index";
import HarborStore from "./harborStore/Index";
import AppMarket from "./appMarket/Index";
import Efficiency from "./efficiency/Index";
import Quailty from "./quailty/Index";
import NotFound from "../../commons/notFound";
import ScreenDisplay from "./display/Main";
import FeedBack from "./display/FeedBack";

// import Test from "../../commons/test2";

// import * as menuAction from "../../../actions/systemManageAction.js";
import * as projectAction from "../../../actions/ListProjects";
import * as DeploymentManageActions from "../../../actions/build/DeploymentManage";
import * as BuildActions from "../../../actions/build/BuildManage";

import { uncompileStr } from "../../../utils/commonFunction";
import * as action from "../../../actions/systemManageAction";

const { Content, Footer, Sider } = Layout;
const SubMenu = Menu.SubMenu;
class LayoutComponent extends React.Component {
  constructor(props) {
    super(props);
    const projectKey = JSON.parse(sessionStorage.getItem("projectKey"));
    let stringArr = "";
    const subStringArr = [];
    if (
      props.pjmMenuListData &&
      props.pjmMenuListData.data &&
      props.pjmMenuListData.data.childMenus
    ) {
      const menuList = props.pjmMenuListData.data.childMenus;
      stringArr =
        menuList[0].childMenus && menuList[0].childMenus.length !== 0
          ? menuList[0].childMenus[0].menuUrl
          : menuList[0].menuUrl;
      const menuSubmenuKey = menuList.filter(item => {
        if (item.childMenus.length !== 0) {
          const childKey = item.childMenus.filter(
            itemChildMenus => itemChildMenus.menuUrl === stringArr
          );
          if (childKey.length !== 0) {
            return true;
          }
        } else {
          return item.menuUrl === stringArr;
        }
      });
      subStringArr.push(menuSubmenuKey[0].menuUrl);
    }
    this.state = {
      // // 调试代码
      // openKeys: ["display1"],
      // collapsed: false,
      // key: "display1",
      // openSubmenuKey: ["display1"],

      // 正常代码：
      openKeys:
        projectKey !== null ? projectKey.openSubKey : subStringArr.length !== 0 ? subStringArr : [],
      collapsed: false,
      key:
        projectKey !== null ? projectKey.key : stringArr.length !== 0 ? stringArr : "project/sub1",
      openSubmenuKey:
        projectKey !== null
          ? projectKey.openSubKey
          : subStringArr.length !== 0
          ? subStringArr
          : ["project/sub1"],

      projectId: props.match.params.projectId,
      projectName: props.match.params.projectName,
      projectCode: props.match.params.projectCode
    };
    this.set = [
      "需求管理",
      "定义组件",
      "关联代码",
      "迭代管理",
      "测试管理",
      "构建管理",
      "部署管控",
      "流水线",
      "介质仓库",
      "效率报表",
      "质量报表",
      "项目监控",
      "组件运维",
      "环境",
      "资源",
      "团队",
      "角色",
      "自定义",
      "通知",
      "版本",
      "模块",
      "里程碑",
      "数据字典"
    ];
    this.onCollapse = this.onCollapse.bind(this);
    this.getData = this.getData.bind(this);
  }

  componentWillMount() {
    const { actions, location } = this.props;
    const urlList = location.pathname.split("/");
    let projectId = "";
    for (let i = 0; i < urlList.length; i++) {
      projectId = urlList[i - 2];
    }
    projectId = uncompileStr(projectId);
    actions.add(null, { useId: 10, projectId }, "pjmMenuList");
  }

  componentDidMount() {
    const { actions, location, pjmMenuListData } = this.props;

    const subStringArr = [];
    if (pjmMenuListData && pjmMenuListData.data) {
      if (pjmMenuListData.data.childMenus.length !== 0) {
        const menuList = pjmMenuListData.data.childMenus;
        const stringArr =
          menuList[0].childMenus && menuList[0].childMenus.length !== 0
            ? menuList[0].childMenus[0].menuUrl
            : menuList[0].menuUrl;
        const menuSubmenuKey = menuList.filter(item => {
          if (item.childMenus.length !== 0) {
            const childKey = item.childMenus.filter(
              itemChildMenus => itemChildMenus.menuUrl === stringArr
            );
            if (childKey.length !== 0) {
              return true;
            }
          } else {
            return item.menuUrl === stringArr;
          }
        });
        subStringArr.push(menuSubmenuKey[0].menuUrl);
        this.setState({
          key: stringArr.length !== 0 ? stringArr : "project/sub1",
          openSubmenuKey: subStringArr.length !== 0 ? subStringArr : ["project/sub1"]
        });
      }
    } else {
      const urlList = location.pathname.split("/");
      let projectId = "";
      for (let i = 0; i < urlList.length; i++) {
        projectId = urlList[i - 2];
      }
      projectId = uncompileStr(projectId);
      actions.add(null, { useId: 10, projectId }, "pjmMenuList");
      // 概览页面
      const mouthstart = `${moment()
        .add("month", 0)
        .format("YYYY-MM")}-01 00:00:00`;
      const mouthend = `${moment(mouthstart)
        .add("month", 1)
        .add("days", -1)
        .format("YYYY-MM-DD")} 23:59:59`;
      const todaystart = `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`;
      const todayend = `${moment(new Date()).format("YYYY-MM-DD")} 23:59:59`;
      actions.getProjectsOvewview({
        projectId,
        date: todaystart,
        sDate: todayend
      });
      actions.getProjectsbuildtop({
        projectId,
        dataJson: {
          type: "self",
          start: mouthstart,
          end: mouthend
        }
      });
      actions.getProjectsdeploytop({
        projectId,
        dataJson: {
          type: "self",
          start: mouthstart,
          end: mouthend
        }
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    const { actions, match } = this.props;
    const preciousProjectId = match.params.projectId;
    const currentProjectId = nextProps.match.params.projectId;
    if (preciousProjectId === currentProjectId) {
      return;
    }
    this.setState({
      collapsed: false,
      openKeys: [],
      key: "project/sub1",
      openSubmenuKey: ["project/sub1"]
    });

    const urlList = nextProps.location.pathname.split("/");
    let projectId = "";
    for (let i = 0; i < urlList.length; i++) {
      projectId = urlList[i - 2];
    }
    projectId = uncompileStr(projectId);
    actions.add(null, { useId: 10, projectId }, "pjmMenuList");
  }

  onCollapse(collapsed) {
    this.setState({ collapsed });
    if (collapsed) {
      this.setState({
        width: "calc(100vw - 130px)"
      });
    } else {
      this.setState({
        width: "calc(100vw - 250px)"
      });
    }
  }

  // 折叠
  onOpenChange(openKeysList) {
    const { openKeys } = this.state;
    const arr = [
      "project/sub1",
      "project/sub2",
      "project/sub3",
      "project/sub4",
      "project/sub5",
      "project/sub6",
      "project/sub7"
    ];
    const latestOpenKey = openKeysList.find(key => openKeys.indexOf(key) === -1);
    if (arr.indexOf(latestOpenKey) === -1) {
      this.setState({ openKeys: openKeysList });
    } else {
      this.setState({
        openKeys: latestOpenKey ? [latestOpenKey] : []
      });
    }
  }

  getData(item) {
    const { actions, pjmMenuListData } = this.props;

    // actions.setCurrentpage(1);
    // actions.setBuildCurrentpage(1);
    // const openSubmenuKey = [];
    // if (pjmMenuListData && pjmMenuListData.data && pjmMenuListData.data.childMenus) {
    //   if (item) {
    //     const itemKey = item.key;
    //     const menuList = pjmMenuListData.data.childMenus;
    //     const menuSubmenuKey = menuList.filter(menuListItem => {
    //       // return item.menuUrl === "admin/sub2"
    //       if (menuListItem.childMenus.length !== 0) {
    //         const childKey = menuListItem.childMenus.filter(
    //           itemChildMenus => itemChildMenus.menuUrl === itemKey
    //         );
    //         if (childKey.length !== 0) {
    //           return true;
    //         }
    //       } else {
    //         return menuListItem.menuUrl === itemKey;
    //       }
    //     });

    //     openSubmenuKey.push(menuSubmenuKey[0].menuUrl);
    //   }
    // }
    this.setState({ key: item.key });
    // sessionStorage.setItem(
    //   "projectKey",
    //   JSON.stringify({ key: item.key, openSubKey: openSubmenuKey })
    // );
  }

  render() {
    const { key, openSubmenuKey, openKeys, collapsed } = this.state;
    const { pjmMenuListData, match } = this.props;

    const menuKey = key;
    const submenuKey = openSubmenuKey;
    if (pjmMenuListData && pjmMenuListData.data) {
      if (pjmMenuListData.data.childMenus) {
        // console.log("pjmMenuListData", pjmMenuListData, pjmMenuListData.data);
        const menuList = pjmMenuListData.data.childMenus;
        this.menuShowList = menuList.map(menuItem => {
          if (menuItem.childMenus && menuItem.childMenus.length !== 0) {
            return (
              <SubMenu
                key={menuItem.menuUrl}
                title={
                  <span>
                    <Icon type={menuItem.menuIcon} />
                    <span>{menuItem.menuName}</span>
                  </span>
                }
              >
                {menuItem.childMenus.length !== 0
                  ? menuItem.childMenus.map(menuChild => {
                      return (
                        <Menu.Item key={menuChild.menuUrl}>
                          <Icon type={menuChild.menuIcon} />
                          <span>{menuChild.menuName}</span>
                        </Menu.Item>
                      );
                    })
                  : ""}
              </SubMenu>
            );
          } else if (menuItem.childMenus === "undefind" || menuItem.childMenus.length === 0) {
            return (
              <Menu.Item key={menuItem.menuUrl}>
                <Icon type={menuItem.menuIcon} />
                <span>{menuItem.menuName}</span>
              </Menu.Item>
            );
          }
        });
      } else {
        this.menuShowList = "";
      }
    }
    const projectIdTransform = uncompileStr(match.params.projectId.toString());
    return (
      <div className="right-body-container" style={{ minHeight: "100vh" }}>
        <Sider collapsible collapsed={this.state.collapsed} onCollapse={this.onCollapse}>
          <Menu
            defaultSelectedKeys={menuKey != "project/sub1" ? [menuKey] : ["project/sub1"]}
            defaultOpenKeys={submenuKey != ["project/sub1"] ? submenuKey : ["project/sub1"]}
            selectedKeys={[menuKey]}
            // openKeys={openKeys} // 暂时注释（影响左侧菜单展开布局）
            onOpenChange={this.onOpenChange.bind(this)}
            onClick={this.getData}
            mode="inline"
            theme="dark"
            inlineCollapsed={collapsed}
          >
            {this.menuShowList}
            <Menu.Item key="display">
              <Icon type="dashboard" />
              <span>大屏展示</span>
            </Menu.Item>
            {/* <Menu.Item key="display11">
              <Icon type="dashboard" />
              <span>test---demo</span>
            </Menu.Item> */}
            <Menu.Item key="display1">
              <Icon type="dashboard" />
              <span>持续反馈</span>
            </Menu.Item>
          </Menu>
        </Sider>
        <div
          className="right-div-body"
          style={{ background: key === "display" || key === "display1" ? "#172a6a" : "#e5eaef" }}
        >
          <Content style={{ margin: "0 16px" }}>
            <Breadcrumb style={{ margin: "16px 0" }}>
              {/* <Breadcrumb.Item>项目管理</Breadcrumb.Item>
              <Breadcrumb.Item>{this.set[this.state.key - 1]}</Breadcrumb.Item> */}
            </Breadcrumb>
            <div
              style={{
                padding: key === "display" || key === "display1" ? "0px 10px" : 20,
                background: key === "display" || key === "display1" ? "#172a6a" : "#fff",
                minHeight: 360
              }}
            >
              {key === "project/sub1" ? (
                <Overview
                  projectId={projectIdTransform}
                  projectName={match.params.projectName}
                  width={this.state.width}
                />
              ) : key === "project/2" ? (
                <Components
                  projectId={
                    projectIdTransform //   <CodeQuality /> // ) : this.state.key === "project/1" ? (
                  }
                />
              ) : key === "project/3" ? (
                <CodeRelaction projectId={projectIdTransform} />
              ) : key === "project/13" ? (
                <Maitanance projectId={projectIdTransform} />
              ) : key === "project/14" ? (
                <Environment projectId={projectIdTransform} />
              ) : key === "project/15" ? (
                <Resource projectId={projectIdTransform} />
              ) : key === "project/16" ? (
                <Team projectId={projectIdTransform} />
              ) : key === "project/17" ? (
                <Role projectId={projectIdTransform} />
              ) : key === "project/6" ? (
                <Build projectId={projectIdTransform} projectName={match.params.projectName} />
              ) : key === "project/10" ? (
                <Efficiency projectId={projectIdTransform} />
              ) : key === "project/11" ? (
                <Quailty projectId={projectIdTransform} />
              ) : key === "project/9" ? (
                <Repository projectId={projectIdTransform} />
              ) : key === "project/24" ? (
                <HarborStore
                  projectId={projectIdTransform}
                  projectCode={match.params.projectCode}
                />
              ) : key === "project/25" ? (
                <AppMarket projectId={projectIdTransform} projectName={match.params.projectName} />
              ) : key === "project/7" ? (
                <DeploymentManage
                  projectId={projectIdTransform}
                  projectName={match.params.projectName}
                  projectCode={match.params.projectCode}
                />
              ) : key === "display" ? (
                <ScreenDisplay
                  projectId={projectIdTransform}
                  projectName={match.params.projectName}
                  width={this.state.width}
                />
              ) : key === "display1" ? (
                <FeedBack
                  projectId={projectIdTransform}
                  projectName={match.params.projectName}
                  width={this.state.width}
                />
              ) : (
                <NotFound />
              ) //   <Test projectId={projectIdTransform} projectName={match.params.projectName} /> // ) : key === "display11" ? (
              }
            </div>
          </Content>
          {/* <Footer style={{ textAlign: "center" }} /> */}
        </div>
      </div>
    );
  }
}

// export default LayoutComponent;
const mapStateToProps = state => {
  return {
    pjmMenuListData: state.SystemManage.get("pjmMenuListData"),

    updateStatus: state.SystemManage.get("updateStatus"),
    delStatus: state.SystemManage.get("delStatus"),
    addStatus: state.SystemManage.get("addStatus"),
    otherStatus: state.SystemManage.get("otherStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(
      Object.assign({}, action, projectAction, DeploymentManageActions, BuildActions),
      dispatch
    )
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LayoutComponent);
