import React from "react";

import {Controlled as CodeMirror} from "react-codemirror2";
require("codemirror/lib/codemirror.css");
require("codemirror/mode/javascript/javascript");

class Test extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      code:
        'var component = {\n\tname: "react-codemirror",\n\tauthor: "Jed Watson",\n\trepo: "https://github.com/JedWatson/react-codemirror"\n};',
      java:
        "public class Main {public static void main(String[] args) {System.out.println('Hello World!');}}"
    };
  }

  componentDidMount() {}

  componentWillReceiveProps(nextProps) {}
  render() {
    let options2 = {
      mode: "javascript",
      lineNumbers: true
    };
    return (
      <div>
        <div>{/* <CodeMirror value={this.state.code} options={options} /> */}</div>
        <div>
          <CodeMirror
            value={this.state.code}
            options={options2}
            onBeforeChange={(editor, data, value) => {
              this.setState({value});
            }}
            onChange={(editor, data, value) => {}}
          />
        </div>
      </div>
    );
  }
}

export default Test;
