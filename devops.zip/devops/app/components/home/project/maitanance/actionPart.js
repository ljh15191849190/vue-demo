import React from "react";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  Popconfirm,
  Row,
  Col,
  message,
  Tabs,
  TreeSelect
} from "antd";
import RULES from "../../../utils/Validation";

const FormItem = Form.Item;
const { Option } = Select;

export const CommonForm = Form.create()(props => {
  const { commonVisible, onCreate, onCancel, form } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 14 }
  };
  return (
    <Modal maskClosable={false}
      visible={commonVisible}
      title={actionTitle}
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem {...formItemLayout} label="Slider">
          {getFieldDecorator("slider")(
            <Row>
              <Col span={12}>
                <Slider
                  min={1}
                  max={20}
                  onChange={this.onChange}
                  value={typeof inputValue === "number" ? inputValue : 0}
                />
              </Col>
              <Col span={4}>
                <InputNumber
                  min={1}
                  max={20}
                  style={{ marginLeft: 16 }}
                  value={inputValue}
                  onChange={this.onChange}
                />
              </Col>
            </Row>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

export const StretchForm = Form.create()(props => {
  const {
    addVisible,
    onCreate,
    onCancel,
    form,
    onSecondChange,
    renderTreeNodes,
    onLoadData,
    that,
    onTreeChange,
    onNewFormFocus
  } = props;
  const { getFieldDecorator } = form;

  //角色授权选项
  const optionRoleChildren = [];
  if (chooseRoleOption.length !== 0) {
    for (let i = 0; i < chooseRoleOption.length; i++) {
      optionRoleChildren.push(
        <Option value={chooseRoleOption[i].roleId} key={"roles" + Math.random()}>
          {chooseRoleOption[i].roleName}
        </Option>
      );
    }
  }
  return (
    <Modal maskClosable={false}
      visible={addVisible}
      title="新增人员"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="用户名：">
          {getFieldDecorator("userName", {
            rules: RULES.Rule_code
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入字母、数字、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_]+$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>

        <FormItem label="用户密码：">
          {getFieldDecorator("password", {
            rules: RULES.Rule_password
            // rules: [
            //   {
            //     required: true,
            //     message: "密码应为6到16位，至少包含字母、数字、符号两种",
            //     pattern: /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?![,\.#%'\+@!\$&\*\-:;^_`]+$)[,\.#%@!'\+\$&\*\-:;^_`0-9A-Za-z]{6,16}$/gm
            //   }
            // ]
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem label="真实姓名：">
          {getFieldDecorator("realName", {
            rules: RULES.Rule_name
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入字母、数字、中文、下划线，不能以下划线开头或结尾",
            //     pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="邮箱地址：">
          {getFieldDecorator("email", {
            rules: RULES.Rule_mail
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入正确的邮箱地址",
            //     pattern: /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="手机号码：">
          {getFieldDecorator("phone", {
            rules: RULES.Rule_tel
            // rules: [
            //   {
            //     required: true,
            //     message: "请输入正确的手机号码",
            //     pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
            //   }
            // ]
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="状态：">
          {getFieldDecorator("userStatus", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ],
            initialValue: "1"
          })(
            <Select style={{ width: "100%" }}>
              <Option value="1">启用</Option>
              <Option value="0">禁用</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="所属机构：">
          {getFieldDecorator("orgId", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ]
          })(
            <TreeSelect
              dropdownStyle={{ maxHeight: "56vh" }}
              loadData={onLoadData}
              onChange={onTreeChange}
              treeDefaultExpandedKeys={treeDefaultExpandedKeysUpdate}
              // treeExpandedKeys = {treeExpandedKeysUpdate}
            >
              {that.state.treeData ? renderTreeNodes(that.state.treeData) : null}
            </TreeSelect>
          )}
        </FormItem>
        <FormItem label="角色授权：">
          {getFieldDecorator("roles", {
            rules: [
              {
                required: true,
                message: "不能为空"
              }
            ]
          })(
            <Select
              className="hide-searchSelect"
              style={{ width: "100%" }}
              onFocus={onNewFormFocus}
              mode="multiple"
              onSelect={value => {
                onSecondChange(value);
              }}
            >
              {optionRoleChildren}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});
