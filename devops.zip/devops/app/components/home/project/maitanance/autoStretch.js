import React from "react";
import { Modal, Form, Switch, Icon } from "antd";
import { SliderInput } from "./sliderInput";
import "./maitanance.css";

const FormItem = Form.Item;
class CustomTitle extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: props.checkedBoolean,
      setParams: false
    };

    this.onChangeSwitch = this.onChangeSwitch.bind(this);
    this.setParams = this.setParams.bind(this);
    this.saveParams = this.saveParams.bind(this);
    this.cancelParams = this.cancelParams.bind(this);
  }

  onChangeSwitch(checked) {
    const { caasServicesDeploymentEnableHpa, caasServicesHpa } = this.props;
    if (checked === false) {
      caasServicesDeploymentEnableHpa(checked);
    } else if (checked === true) {
      caasServicesHpa(checked);
    }
  }

  setParams(parmas, apiParams) {
    const { setBoolenAction } = this.props;
    // 展示部分
    this.setState({ setParams: true });
    setBoolenAction(true);
    // 请求接口  parmas
  }

  saveParams(parmas, apiParams) {
    const { caasServicesHpa, setBoolenAction } = this.props;
    // 展示部分
    this.setState({
      checked: true,
      setParams: false
    });
    caasServicesHpa(true);
    setBoolenAction(false); // 设置不可编辑
    // this.props.onAutoStretchFormCancel(); // 关闭视窗
    // 请求接口  parmas
  }

  cancelParams() {
    const { form, setBoolenAction, caasServicesConfigListDataContainer } = this.props;
    // 展示部分
    this.setState({ checked: true, setParams: false });

    form.setFieldsValue({
      clevel: caasServicesConfigListDataContainer.deploymentHpaStepsize,
      deploymentHpaMin: caasServicesConfigListDataContainer.deploymentHpaMin,
      deploymentHpaMax: caasServicesConfigListDataContainer.deploymentHpaMax,
      deploymentHpaTrigger: caasServicesConfigListDataContainer.deploymentHpaTrigger
    });

    setBoolenAction(false);
    // 请求接口  parmas
  }

  // componentWillReceiveProps(nextProps) {
  //   if (this.props.checkedBoolean === "undefined") {
  //     if (nextProps.checkedBoolean === true) {
  //       this.onChangeSwitch(true);
  //       // this.setState({
  //       //   checked: true
  //       // });
  //     } else if (nextProps.checkedBoolean === false) {
  //       this.onChangeSwitch(false);
  //       // this.setState({
  //       //   checked: false
  //       // });
  //     }
  //   }
  // }

  render() {
    const { setParams } = this.state;
    const { actionContent, checkedBoolean } = this.props;

    if (setParams === true) {
      return (
        <div className="autoStretch-CustomTitle">
          <p className="autoStretch-CustomTitle-titleName">{actionContent.actionTitle}</p>
          <p className="autoStretch-CustomTitle-actionName">
            <span
              className="autoStretch-CustomTitle-actionName-button saveButton"
              onClick={() => {
                this.saveParams();
              }}
            >
              开启并保存
            </span>
            <span
              className="autoStretch-CustomTitle-actionName-button"
              onClick={() => {
                this.cancelParams();
              }}
            >
              取消
            </span>
          </p>
        </div>
      );
    } else if (checkedBoolean === true) {
      return (
        <div className="autoStretch-CustomTitle">
          <p className="autoStretch-CustomTitle-titleName">{actionContent.actionTitle}</p>
          <p className="autoStretch-CustomTitle-actionName">
            <Switch
              key="checkedTrue"
              checkedChildren="开"
              unCheckedChildren="关"
              checked={
                checkedBoolean
                // this.state.checked === undefined ? this.props.checkedBoolean : this.state.checked
              }
              // defaultChecked={this.props.checkedBoolean}
              onChange={this.onChangeSwitch}
            />
            <span
              className="autoStretch-CustomTitle-actionName-icon"
              onClick={() => {
                this.setParams();
              }}
            >
              <Icon type="setting" theme="filled" style={{ fontSize: "18px", color: "#1890ff" }} />
            </span>
          </p>
        </div>
      );
    } else if (checkedBoolean === false || setParams === false) {
      return (
        <div className=" autoStretch-CustomTitle">
          <p className="autoStretch-CustomTitle-titleName">{actionContent.actionTitle}</p>
          <p className="autoStretch-CustomTitle-actionName">
            <Switch
              key="checkedFalseAndSetParamsFalse"
              checkedChildren="开"
              unCheckedChildren="关"
              checked={
                checkedBoolean
                // this.state.checked === undefined ? this.props.checkedBoolean : this.state.checked
              }
              // defaultChecked={this.props.checkedBoolean}
              onChange={this.onChangeSwitch}
            />
          </p>
        </div>
      );
    }
  }
}

// const mapStateToProps = state => {
//   return {
//     allPartListData: state.MaitananceManage.get("allPartListData"),
//     caasServicesConfigListData: state.MaitananceManage.get("caasServicesConfigListData"),
//     caasServicesTagsListData: state.MaitananceManage.get("caasServicesTagsListData")
//   };
// };

// const mapDispatchToProps = dispatch => {
//   return { actions: bindActionCreators(action, dispatch) };
// };
// export default connect(
//   mapStateToProps,
//   mapDispatchToProps
// )(Maitanance);
const AutoStretchForm = Form.create()(props => {
  const {
    setBoolenAction,
    setBoolen,
    messageMaxTextError,
    autoStretchVisible,
    actionContent,
    initialData,
    onCreateCommonForm,
    onCancel,
    form,
    caasServicesConfigListDataContainer,
    caasServicesDeploymentEnableHpa,
    caasServicesHpa
  } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 14 }
  };
  let checkedBooleanEnableHpa = null;
  if (caasServicesConfigListDataContainer && caasServicesConfigListDataContainer.id) {
    checkedBooleanEnableHpa =
      parseInt(caasServicesConfigListDataContainer.deploymentEnableHpa, 0) === 1 ? true : false;
  }

  let maxStep = null;
  if (initialData.serviceInstanceGroup) {
    const serviceInstanceGroup = initialData.serviceInstanceGroup.split("/");
    maxStep =
      serviceInstanceGroup[0] > 4
        ? Math.floor(serviceInstanceGroup[0] * 0.75)
        : serviceInstanceGroup[0] > 1
        ? serviceInstanceGroup[0] - 1
        : 1;
  }

  return (
    <Modal maskClosable={false}
      visible={autoStretchVisible}
      title={
        <CustomTitle
          form={form}
          caasServicesConfigListDataContainer={caasServicesConfigListDataContainer}
          onAutoStretchFormCancel={onCancel}
          checkedBoolean={checkedBooleanEnableHpa}
          actionContent={actionContent}
          caasServicesDeploymentEnableHpa={caasServicesDeploymentEnableHpa}
          caasServicesHpa={caasServicesHpa}
          setBoolenAction={setBoolenAction}
        />
      }
      footer={null}
      // okText="确定"
      // cancelText="取消"
      onCancel={onCancel}
      onOk={onCreateCommonForm}
    >
      <Form layout="horizontal">
        <Form.Item>{actionContent.actionPrompt}</Form.Item>
        <FormItem {...formItemLayout} label="服务名称">
          <span className="ant-form-text">{initialData.serviceName}</span>
        </FormItem>
        <Form.Item {...formItemLayout} label="伸缩步长：">
          {getFieldDecorator("deploymentHpaStepsize", {
            rules: [
              {
                required: true
              }
            ],
            initialValue: caasServicesConfigListDataContainer.deploymentHpaStepsize
              ? caasServicesConfigListDataContainer.deploymentHpaStepsize
              : 1,
            trigger: "onChange"
          })(
            <SliderInput
              styleName="deploymentHpaStepsize"
              form={form}
              marks={{ 1: "1", 2: "2", 3: "3", 4: "4", 5: "5" }}
              // min={actionContent.minNumber}
              // max={actionContent.maxNumber}
              min={1}
              max={maxStep}
              unit={actionContent.actionUnit}
              checkedBooleanEnableHpa={setBoolen}
            />
          )}
        </Form.Item>
        <Form.Item {...formItemLayout} label="最小实例数量：">
          {getFieldDecorator("deploymentHpaMin", {
            rules: [
              {
                required: true
              }
            ],
            initialValue: caasServicesConfigListDataContainer.deploymentHpaMin
              ? caasServicesConfigListDataContainer.deploymentHpaMin
              : 1,
            trigger: "onChange"
          })(
            <SliderInput
              styleName="deploymentHpaMin"
              form={form}
              marks={{ 1: "1", 2: "2", 3: "3", 4: "4", 5: "5" }}
              // value = {}
              // min={actionContent.minNumber}
              // max={actionContent.maxNumber}
              min={1}
              max={9}
              unit={actionContent.actionUnit}
              checkedBooleanEnableHpa={setBoolen}
            />
          )}
        </Form.Item>
        <Form.Item {...formItemLayout} label="最大实例数量：">
          {getFieldDecorator("deploymentHpaMax", {
            rules: [
              {
                required: true
              }
            ],
            initialValue: caasServicesConfigListDataContainer.deploymentHpaMax
              ? caasServicesConfigListDataContainer.deploymentHpaMax
              : 3,
            trigger: "onChange"
          })(
            <SliderInput
              styleName="deploymentHpaMax"
              form={form}
              marks={{ 1: "1", 2: "2", 3: "3", 4: "4", 5: "5" }}
              // min={actionContent.minNumber}
              // max={actionContent.maxNumber}
              min={1}
              max={10}
              unit={actionContent.actionUnit}
              checkedBooleanEnableHpa={setBoolen}
            />
          )}
        </Form.Item>
        {messageMaxTextError !== "" ? (
          <span className="messageMaxTextError">{messageMaxTextError}</span>
        ) : (
          ""
        )}
        <Form.Item {...formItemLayout} label="CPU阈值：">
          {getFieldDecorator("deploymentHpaTrigger", {
            rules: [
              {
                required: true
              }
            ],
            initialValue: caasServicesConfigListDataContainer.deploymentHpaTrigger
              ? parseInt(caasServicesConfigListDataContainer.deploymentHpaTrigger, 0)
              : 30,
            trigger: "onChange"
          })(
            <SliderInput
              styleName="deploymentHpaTrigger"
              form={form}
              // marks={{ 10: "10", 60: "60", 7: "7", 8: "8", 9: "9", 10: "10" }}
              // min={actionContent.minNumber}
              // max={actionContent.maxNumber}
              min={10}
              max={90}
              unit="percent"
              checkedBooleanEnableHpa={setBoolen}
            />
          )}
        </Form.Item>
      </Form>
    </Modal>
  );
});

export { CustomTitle, AutoStretchForm };

// module.exports = {
//   CustomTitle,
//   AutoStretchForm
// };
