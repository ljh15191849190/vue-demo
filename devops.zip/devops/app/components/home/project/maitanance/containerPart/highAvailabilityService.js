import React from "react";
import { Table, Switch, message } from "antd";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../../actions/maitananceManageAction";
import "../maitanance.css";

class HighAvailability extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.columnsStateAvailability = [
      {
        title: "重启检查项",
        width: 100,
        dataIndex: "deploymentLivenessprobeScheme",
        render: (text, record) => this.renderColumns(text, record, "deploymentLivenessprobeScheme")
      },
      {
        title: "Path路径",
        dataIndex: "deploymentLivenessprobePath",
        render: (text, record) => this.renderColumns(text, record, "deploymentLivenessprobePath")
      },
      {
        title: "端口",
        width: 120,
        dataIndex: "deploymentLivenessprobePort",
        render: (text, record) => this.renderColumns(text, record, "deploymentLivenessprobePort")
      },
      {
        title: "首次检查延时",
        width: 120,
        dataIndex: "lpInitialdelaydeconds",
        render: (text, record) => this.renderColumns(text, record, "lpInitialdelaydeconds")
      },
      {
        title: "检查超时",
        width: 120,
        dataIndex: "lpTimeoutseconds",
        render: (text, record) => this.renderColumns(text, record, "lpTimeoutseconds")
      },
      {
        title: "检查间隔",
        width: 100,
        dataIndex: "lpPeriodseconds",
        render: (text, record) => this.renderColumns(text, record, "lpPeriodseconds")
      }
    ];

    this.switchChange = this.switchChange.bind(this);
    this.renderColumns = this.renderColumns.bind(this);
  }

  renderColumns(text, record, column) {
    if (
      column === "lpTimeoutseconds" ||
      column === "lpInitialdelaydeconds" ||
      column === "lpPeriodseconds"
    ) {
      if (text === undefined) {
        return "";
      }
      return `${text} s`;
    }
    return text;
  }

  switchChange(checked) {
    const { actions, parentData } = this.props;
    if (checked === false) {
      const params = {
        serviceId: parentData.deployServiceId,
        livenessprobe: 0
      };

      actions.get(1, params, "caasServicesLivenessprobe");
    } else if (checked === true) {
      const params = { serviceId: parentData.deployServiceId, livenessprobe: 1 };

      actions.get(1, params, "caasServicesLivenessprobe");
    }

    // 请求接口
  }
  //  ??? 思考数据更新的问题，设置完高可用，但是下面数据列表需要更新的逻辑
  // componentDidUpdate() {
  //   if (
  //     this.props.visualUpdateInstanceDisableListData.get("otherStatus") &&
  //     this.props.visualUpdateInstanceDisableListData.get("otherStatus") === 1
  //   ) {
  //     message.success("操作成功");

  //     let dataListInstanceId = "";
  //     let showCurrentDetailData = this.props.codeData;
  //     if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
  //       dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
  //     }
  //     let params = {
  //       instanceId: dataListInstanceId
  //     };
  //     this.props.actions.get(1, params, "visualHighAvailableInfo");
  //   }
  // }

  render() {
    const { caasServicesConfigListData, defaultChecked } = this.props;
    const caasServicesConfigList = [];

    if (caasServicesConfigListData) {
      if (caasServicesConfigListData.get("caasServicesConfigListContainer")) {
        const caasServicesConfigListData11 = caasServicesConfigListData.get(
          "caasServicesConfigListContainer"
        );
        caasServicesConfigList.push(caasServicesConfigListData11);
      }
    }
    return (
      <div>
        <div className="high-seeting">
          <span> 设置高可用 </span>
          <Switch
            disabled={
              caasServicesConfigList
                ? caasServicesConfigList.length !== 0
                  ? caasServicesConfigList[0].deploymentLivenessprobePath
                    ? false
                    : true
                  : true
                : true
            }
            checkedChildren="开"
            unCheckedChildren="关"
            defaultChecked={defaultChecked} // defaultChecked={
            //   caasServicesConfigListData11
            //     ? caasServicesConfigListData11.length !== 0
            //       ? parseInt(caasServicesConfigListData11.deploymentLivenessprobe) === 1
            //         ? true
            //         : false
            //       : false
            //     : false
            // }
            onChange={this.switchChange}
          />
        </div>

        <div className="tabpane-explain">
          <h4 className="tabpane-explain-title">配置信息</h4>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Table
              bordered
              size="small"
              columns={this.columnsStateAvailability}
              locale={{ emptyText: "暂无数据..." }}
              dataSource={
                caasServicesConfigList
                  ? caasServicesConfigList.length !== 0
                    ? caasServicesConfigList[0].deploymentLivenessprobePath
                      ? caasServicesConfigList
                      : []
                    : []
                  : []
              }
              pagination={false}
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    visualHighAvailableInfoListData: state.MaitananceManage.get("visualHighAvailableInfoListData"),
    visualUpdateInstanceDisableListData: state.MaitananceManage.get(
      "visualUpdateInstanceDisableListData"
    ),
    caasServicesLivenessprobeListData: state.MaitananceManage.get(
      "caasServicesLivenessprobeListData"
    ),
    caasServicesConfigListData: state.MaitananceManage.get("caasServicesConfigListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HighAvailability);
