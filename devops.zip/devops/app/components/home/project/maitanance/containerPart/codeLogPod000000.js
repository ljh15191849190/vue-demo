import React from "react";
import { Card, Icon, DatePicker, Select, message } from "antd";
import CodeMirror from "react-codemirror";
import "codemirror/lib/codemirror.css";
import "codemirror/mode/jsx/jsx";
import "codemirror/addon/hint/show-hint.css";
import "codemirror/addon/hint/show-hint.js";
import "codemirror/addon/hint/sql-hint.js";
import "codemirror/theme/ambiance.css";
import "codemirror/addon/display/fullscreen.css";
import "codemirror/addon/display/fullscreen.js";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../../actions/maitananceManageAction.js";
import "../maitanance.css";

const { Option } = Select;
class CodeLog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      logValue: "",
      searchDateValue: null,
      refresh: false,
      currentPage: 1,
      selectChangeValue: ""
    };

    this.onChangeDate = this.onChangeDate.bind(this);
    this.moreCheck = this.moreCheck.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
  }
  componentDidUpdate() {
    const editorss = this.refs.editor.getCodeMirror();

    if (
      this.props.caasPodsLogsListData.get("caasPodsLogsList")
      // &&
      // this.props.caasPodsLogsListData.get("caasPodsLogsList").length
      // this.props.caasPodsLogsListData.get("caasPodsLogsList") &&
      // this.props.caasPodsLogsListData.get("caasPodsLogsList").length
    ) {
      editorss.setValue(this.props.caasPodsLogsListData.get("caasPodsLogsList"));
      editorss.refresh();
    }
  }

  componentWillReceiveProps(nextProps, nextState) {
    const editorss = this.refs.editor.getCodeMirror();
    let logValuetest =
      nextProps.caasPodsLogsListData && nextProps.caasPodsLogsListData.get("caasPodsLogsList")
        ? nextProps.caasPodsLogsListData.get("caasPodsLogsList")
        : "";
    if (
      this.props.caasPodsLogsListData.get("caasPodsLogsList") !==
      nextProps.caasPodsLogsListData.get("caasPodsLogsList")
    ) {
      let currentPageNowInfo = nextProps.caasPodsLogsListData.get("pageBean");
      let currentPageNow = currentPageNowInfo.page;

      this.setState({
        currentPage: currentPageNow, // 获取当前请求时的页数
        refresh: true
      });
    }
    if (logValuetest.length === 0 || logValuetest === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    }
    editorss.setValue(logValuetest); //  请求接口获取新数据
    editorss.refresh();
  }
  componentDidMount() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setSize("100%", "50vh");
    editorss.setOption("readOnly", true);
  }
  componentWillUnmount() {
    this.setState({
      currentPage: 1,
      logValue: ""
    });
    // let params = {
    //   podName: this.props.codeData.podName, //开发
    //   namespaceId: this.props.codeData.namespaceId, //开发
    //   timestamp: ""
    //   // podName: "demo-spring-5dd5dcc859-mdklz", //test
    //   // namespaceId: "200" //test
    // };
    // this.props.actions.get(0, params, "caasPodsLogs");
  }
  ChangeCode() {
    const editorss = this.refs.editor.getCodeMirror();
  }
  // FullScreen
  getFullScreen() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setOption("fullScreen", "true");
  }

  // Refresh
  getRefresh() {
    if (this.props.parentStyle === "service") {
      if (this.state.selectChangeValue !== "") {
        var podNameValue = this.state.selectChangeValue;
      } else if (this.state.selectChangeValue === "") {
        let podNameValueList = this.props.tableList;
        var podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }

      if (this.state.searchDateValue === null) {
        let params = {
          podName: podNameValue, // 开发
          namespaceId: this.props.parentData.namespaceId, // 开发
          timestamp: "" // 更改后的开发逻辑
        };
        this.props.actions.get(this.state.currentPage, params, "caasPodsLogs");
      } else {
        let formatDateTZ = this.state.searchDateValue
          ? this.state.searchDateValue.replace(" ", "T") + "Z"
          : ""; // 用""  代替this.getNowFormatDate()
        let params = {
          podName: podNameValue, // 开发
          namespaceId: this.props.parentData.namespaceId, // 开发
          timestamp: formatDateTZ
        };
        this.props.actions.get(this.state.currentPage, params, "caasPodsLogs");
      }

      const editorss = this.refs.editor.getCodeMirror();
      if (this.state.logValue !== this.props.caasPodsLogsListData.get("caasPodsLogsList")) {
        editorss.setValue(this.props.caasPodsLogsListData.get("caasPodsLogsList")); //  请求接口获取新数据
        editorss.refresh();
      } else {
        editorss.refresh();
      }
    } else if (this.props.parentStyle === "pod") {
      if (this.state.searchDateValue === null) {
        let params = {
          podName: this.props.codeData.podName, // 开发
          namespaceId: this.props.codeData.namespaceId, // 开发
          timestamp: "" // 开发更改后逻辑
          // timestamp: this.getNowFormatDate()  //开发逻辑
        };
        this.props.actions.get(this.state.currentPage, params, "caasPodsLogs");
      } else {
        let formatDateTZ = this.state.searchDateValue
          ? this.state.searchDateValue.replace(" ", "T") + "Z"
          : ""; // this.getNowFormatDate()用"" 代替当前时间
        let params = {
          podName: this.props.codeData.podName, // 开发
          namespaceId: this.props.codeData.namespaceId, // 开发
          timestamp: formatDateTZ
        };
        this.props.actions.get(this.state.currentPage, params, "caasPodsLogs");
      }

      const editorss = this.refs.editor.getCodeMirror();
      if (this.state.logValue !== this.props.caasPodsLogsListData.get("caasPodsLogsList")) {
        editorss.setValue(this.props.caasPodsLogsListData.get("caasPodsLogsList")); //  请求接口获取新数据
        editorss.refresh();
      } else {
        editorss.refresh();
      }
    }
  }

  handleSelectChange(value, option) {
    this.setState({
      selectChangeValue: value
    });

    if (this.state.searchDateValue === null) {
      let params = {
        podName: value, // 开发
        namespaceId: this.props.parentData.namespaceId, // 开发
        timestamp: "" // 更改后的开发逻辑
        //timestamp: this.getNowFormatDate()   // 开发逻辑
      };
      this.props.actions.get(1, params, "caasPodsLogs");
    } else {
      let formatDateTZ = this.state.searchDateValue.replace(" ", "T") + "Z";
      let params = {
        podName: value, // 开发
        namespaceId: this.props.parentData.namespaceId, // 开发
        timestamp: formatDateTZ
      };
      this.props.actions.get(1, params, "caasPodsLogs");
    }
  }

  onChangeDate(date, dateString) {
    if (this.props.parentStyle === "service") {
      if (this.state.selectChangeValue !== "") {
        var podNameValue = this.state.selectChangeValue;
      } else if (this.state.selectChangeValue === "") {
        let podNameValueList = this.props.tableList;
        var podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }
      this.setState({
        searchDateValue: dateString,
        currentPage: 1
      });

      let formatDateTZ = dateString ? dateString.replace(" ", "T") + "Z" : ""; //  "" 代替this.getNowFormatDate()
      // let formatDateTZ = dateString.replace(" ", "T") + "Z";
      let params = {
        podName: podNameValue, // 开发
        namespaceId: this.props.parentData.namespaceId, // 开发
        timestamp: formatDateTZ
      };
      this.props.actions.get(1, params, "caasPodsLogs");
    } else if (this.props.parentStyle === "pod") {
      this.setState({
        searchDateValue: dateString,
        currentPage: 1
      });

      let formatDateTZ = dateString ? dateString.replace(" ", "T") + "Z" : ""; //  "" 代替this.getNowFormatDate()
      // let formatDateTZ = dateString.replace(" ", "T") + "Z";
      let params = {
        podName: this.props.codeData.podName, // 开发
        namespaceId: this.props.codeData.namespaceId, // 开发
        timestamp: formatDateTZ
      };
      this.props.actions.get(1, params, "caasPodsLogs");
    }
  }

  getNowFormatDate() {
    let date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    let strHours = date.getHours();
    let strMin = date.getMinutes();
    let strSeconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
      month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = "0" + strDate;
    }
    if (strHours >= 0 && strHours <= 9) {
      strHours = "0" + strHours;
    }
    if (strMin >= 0 && strMin <= 9) {
      strMin = "0" + strMin;
    }
    if (strSeconds >= 0 && strSeconds <= 9) {
      strSeconds = "0" + strSeconds;
    }

    let currentdate =
      date.getFullYear() +
      "-" +
      month +
      "-" +
      strDate +
      "T" +
      strHours +
      ":" +
      strMin +
      ":" +
      strSeconds +
      "Z";
    return currentdate;
  }

  moreCheck() {
    if (this.props.parentStyle === "service") {
      if (this.state.selectChangeValue !== "") {
        var podNameValue = this.state.selectChangeValue;
      } else if (this.state.selectChangeValue === "") {
        let podNameValueList = this.props.tableList;
        var podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }
      let currentPageNow = this.state.currentPage + 1;
      // if (currentPageNow > maxPage) {
      //   message.warn("无更多数据！");
      //   return;
      // } else {
      this.setState({
        logValue: this.state.value + this.props.caasPodsLogsListData.get("caasPodsLogsList"),
        currentPage: currentPageNow
      });
      if (this.state.searchDateValue === null) {
        let params = {
          podName: podNameValue, // 开发
          namespaceId: this.props.parentData.namespaceId, // 开发
          timestamp: "" // 更改后的开发逻辑
          //timestamp: this.getNowFormatDate()     // 开发逻辑
        };
        this.props.actions.get(currentPageNow, params, "caasPodsLogs");
      } else {
        let formatDateTZ = this.state.searchDateValue.replace(" ", "T") + "Z";
        let params = {
          podName: podNameValue, // 开发
          namespaceId: this.props.parentData.namespaceId, // 开发
          timestamp: formatDateTZ
        };
        this.props.actions.get(currentPageNow, params, "caasPodsLogs");
      }
    } else if (this.props.parentStyle === "pod") {
      let currentPageNow = this.state.currentPage + 1;
      // if (currentPageNow > maxPage) {
      //   message.warn("无更多数据！");
      //   return;
      // } else {
      this.setState({
        logValue: this.state.value + this.props.caasPodsLogsListData.get("caasPodsLogsList"),
        currentPage: currentPageNow
      });
      if (this.state.searchDateValue === null) {
        let params = {
          podName: this.props.codeData.podName, // 开发
          namespaceId: this.props.codeData.namespaceId, // 开发
          timestamp: "" // 更改后的开发逻辑
          //timestamp: this.getNowFormatDate()     // 开发逻辑
        };
        this.props.actions.get(currentPageNow, params, "caasPodsLogs");
      } else {
        let formatDateTZ = this.state.searchDateValue.replace(" ", "T") + "Z";
        let params = {
          podName: this.props.codeData.podName, // 开发
          namespaceId: this.props.codeData.namespaceId, // 开发
          timestamp: formatDateTZ
        };
        this.props.actions.get(currentPageNow, params, "caasPodsLogs");
      }
    }
    // }
  }
  render() {
    const options = {
      lineNumbers: true, // 显示行号
      mode: { name: "jsx" }, // 定义mode
      extraKeys: { Ctrl: "autocomplete" }, // 自动提示配置
      lineWrapping: true, // 自动换行
      theme: "ambiance", // 选中的theme
      extraKeys: {
        F11: function(cm) {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        Esc: function(cm) {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
    };
    if (this.props.parentStyle === "service") {
      var optionChooseList = this.props.tableList ? this.props.tableList : [];
      var optionChildren = [];
      if (optionChooseList.length !== 0) {
        for (let i = 0; i < optionChooseList.length; i++) {
          optionChildren.push(
            <Option value={optionChooseList[i].podName} key={"podsName" + Math.random()}>
              {optionChooseList[i].podName}
            </Option>
          );
        }
      }
    }
    return (
      <div>
        <Card
          className="card-title"
          title="日志详情"
          extra={
            <div className="card-actionIcon">
              {this.props.parentStyle === "service" ? (
                <Select
                  // allowClear = {true}
                  defaultValue={optionChooseList.length !== 0 ? optionChooseList[0].podName : ""}
                  style={{ width: "330px", marginRight: "100px" }}
                  onChange={this.handleSelectChange}
                >
                  {optionChildren}
                </Select>
              ) : (
                ""
              )}
              <span className="card-actionIcon-more" onClick={this.moreCheck}>
                查看更多
              </span>
              <DatePicker format="YYYY-MM-DD HH:mm:ss" onChange={this.onChangeDate} />
              <a href="#" onClick={this.getRefresh.bind(this)}>
                <Icon type="reload" className="card-title-actionIcon" />
              </a>
              <a href="#" onClick={this.getFullScreen.bind(this)}>
                <Icon type="arrows-alt" className="card-title-actionIcon" />
              </a>
            </div>
          }
        >
          <CodeMirror
            ref="editor"
            readOnly={true}
            value={this.state.logValue}
            options={options}
            // onChange={() => this.ChangeCode()}
          />
        </Card>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    caasPodsLogsListData: state.MaitananceManage.get("caasPodsLogsListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeLog);
