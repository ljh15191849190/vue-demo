import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Row, Col, Tabs, Icon } from "antd";
import LeftImg from "../../../../../assets/images/dashboard/build.png";
import * as action from "../../../../../actions/maitananceManageAction";
import CodeLog from "../componentPart/codeLogPod";
import EventInformation from "../componentPart/eventInformationPod";
import HighAvailability from "./highAvailabilityService";
import LineChart from "../dateComponent/lineChart";
import ComponentPartDetail from "../componentPart/index";
import "../maitanance.css";

const TabPane = Tabs.TabPane;
class Ports extends React.PureComponent {
  render() {
    const { columnsStatePorts, portsList } = this.props;
    return (
      <div style={{ padding: "10px", marginBottom: "10px" }}>
        <Table
          bordered
          size="small"
          columns={columnsStatePorts}
          locale={{ emptyText: "暂无数据..." }}
          dataSource={portsList}
          pagination={false}
        />
      </div>
    );
  }
}

const BasicInformation = props => {
  const {
    columnsStateBasic,
    columnsStateResource,
    columnsStateEnvironment,
    caasServicesConfigListBasic
  } = props;

  const basicContainer = caasServicesConfigListBasic.container;
  const basicInformation = basicContainer
    ? [
        {
          deloyName: basicContainer.deloyName,
          deploymentImageInfo: basicContainer.deploymentImageInfo,
          updateTime: basicContainer.updateTime
        }
      ]
    : [];

  const resourceInformation = basicContainer
    ? basicContainer.deploymentRequestCpu
      ? [
          {
            deploymentRequestCpu: basicContainer.deploymentRequestCpu,
            deploymentLimitCpu: basicContainer.deploymentLimitCpu,
            deploymentRequestMem: basicContainer.deploymentRequestMem,
            deploymentLimitMem: basicContainer.deploymentLimitMem
          }
        ]
      : []
    : [];

  return (
    <div>
      <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">基本信息</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateBasic}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              basicInformation ? (basicInformation.length !== 0 ? basicInformation : []) : []
            }
            pagination={false}
          />
        </div>
      </div>
      <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">资源配置</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateResource}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              resourceInformation
                ? resourceInformation.length !== 0
                  ? resourceInformation
                  : []
                : []
            }
            pagination={false}
          />
        </div>
      </div>
      <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">环境变量</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateEnvironment}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              caasServicesConfigListBasic.env
                ? caasServicesConfigListBasic.env.length !== 0
                  ? caasServicesConfigListBasic.env
                  : []
                : []
            }
            pagination={false}
          />
        </div>
      </div>
    </div>
  );
};

class ContainerPartDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      updateVisible: false,
      userInformation: null,
      confirmLoading: false,
      updataData: {},
      projectName: "",
      tabVisible: false,
      currentKey: "0"
    };

    this.columnsStateBasic = [
      {
        title: "名称",
        dataIndex: "deloyName",
        render: (text, record) => this.renderColumns(text, record, "deloyName")
      },
      {
        title: "镜像名称",
        dataIndex: "deploymentImageInfo",
        render: (text, record) => this.renderColumns(text, record, "deploymentImageInfo")
      },
      {
        title: "更新时间",
        dataIndex: "updateTime",
        render: (text, record) => this.renderColumns(text, record, "updateTime")
      }
    ];
    this.columnsStateResource = [
      {
        title: "请求CPU",
        dataIndex: "deploymentRequestCpu",
        render: (text, record) => this.renderColumns(text, record, "deploymentRequestCpu")
      },
      {
        title: "限制CPU",
        dataIndex: "deploymentLimitCpu",
        render: (text, record) => this.renderColumns(text, record, "deploymentLimitCpu")
      },
      {
        title: "请求内存",
        dataIndex: "deploymentRequestMem",
        render: (text, record) => this.renderColumns(text, record, "deploymentRequestMem")
      },
      {
        title: "限制内存",
        dataIndex: "deploymentLimitMem",
        render: (text, record) => this.renderColumns(text, record, "deploymentLimitMem")
      }
    ];
    this.columnsStateEnvironment = [
      {
        title: "变量名",
        dataIndex: "envName",
        render: (text, record) => this.renderColumns(text, record, "envName")
      },
      {
        title: "变量值",
        dataIndex: "envValue",
        render: (text, record) => this.renderColumns(text, record, "envValue")
      }
    ];
    this.columnsStatePorts = [
      {
        title: "名称",
        dataIndex: "portName",
        render: (text, record) => this.renderColumns(text, record, "portName")
      },
      {
        title: "协议",
        dataIndex: "serviceProtocol",
        render: (text, record) => this.renderColumns(text, record, "serviceProtocol")
      },
      {
        title: "容器端口",
        dataIndex: "targetPort",
        render: (text, record) => this.renderColumns(text, record, "targetPort")
      },
      {
        title: "集群端口",
        dataIndex: "clusterPort",
        render: (text, record) => this.renderColumns(text, record, "clusterPort")
      }
    ];

    this.goBack = this.goBack.bind(this);
    this.renderColumns = this.renderColumns.bind(this);
    this.onChangeTab = this.onChangeTab.bind(this);
    this.getNowFormatDate = this.getNowFormatDate.bind(this);
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus("AllPart");
    this.setState({
      tabVisible: false,
      currentKey: "0"
    });
  }

  renderColumns(text, record, column) {
    if (column === "userStatus") {
      return parseInt(text, 0) === 0 ? "禁用" : "启用";
    }
    return text;
  }

  getNowFormatDate() {
    const date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    let strHours = date.getHours();
    let strMin = date.getMinutes();
    let strSeconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
      month = `0${month}`;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = `0${strDate}`;
    }
    if (strHours >= 0 && strHours <= 9) {
      strHours = `0${strHours}`;
    }
    if (strMin >= 0 && strMin <= 9) {
      strMin = `0${strMin}`;
    }
    if (strSeconds >= 0 && strSeconds <= 9) {
      strSeconds = `0${strSeconds}`;
    }
    const currentdate = `${date.getFullYear()}-${month}-${strDate}T${strHours}:${strMin}:${strSeconds}Z`;
    return currentdate;
  }

  onChangeTab(key) {
    const { actions, selectedRow, caasServicesPodsListInfoListData } = this.props;
    this.setState({
      currentKey: key
    });
    const serviceInfo = selectedRow;
    if (parseInt(key, 0) === 6) {
      const params = { serviceName: serviceInfo.serviceName, namespaceId: serviceInfo.namespaceId };

      actions.get(1, params, "caasServicesEvents");
      return;
    } else if (parseInt(key, 0) === 4) {
      const params = { serviceName: serviceInfo.serviceName, namespaceId: serviceInfo.namespaceId };

      actions.get(1, params, "caasServicesMetrics");
      return;
    } else if (parseInt(key, 0) === 5) {
      const dataSourceList = caasServicesPodsListInfoListData.get("caasServicesPodsListInfoList");

      const tableList = [];
      let podsList = null;
      if (dataSourceList.length !== 0) {
        podsList = dataSourceList.pods;
        if (podsList) {
          for (let i = 0; i < podsList.length; i++) {
            const podObj = {};
            const objData = podsList[i].objectMeta;
            podObj.nodeName = podsList[i].nodeName;
            podObj.podStatus = podsList[i].podStatus.podPhase;
            podObj.creationTimestamp = objData.creationTimestamp;
            podObj.podName = objData.name;
            podObj.namespace = objData.namespace;
            podObj.namespaceId = selectedRow.namespaceId;
            tableList.push(podObj);
          }
        }
        if (tableList.length !== 0) {
          const params = {
            podName: tableList[0].podName,
            namespaceId: tableList[0].namespaceId,
            timestamp: ""
          }; // 开发 // 开发 // 更改后逻辑
          // timestamp: this.getNowFormatDate()  // 原有逻辑
          actions.get(15, params, "caasPodsLogs");
        } else {
          const params = { podName: "", namespaceId: "", timestamp: "" }; // 开发 // 开发 // 更改后逻辑
          // timestamp: this.getNowFormatDate()  // 原有逻辑
        }
      }
      return;
    } else if (parseInt(key, 0) === 3) {
      // 拿到初始的高可用状态
      // let params = {
      //   serviceId: serviceInfo.deployServiceId // 拿到初始的高可用状态
      // };
      // this.props.actions.get(1, params, "caasServicesConfig");
      // let params = {
      //   serviceId: serviceInfo.deployServiceId,
      //   // livenessprobe: serviceInfo.serviceStatus,   // 需要拿到初始的高可用状态
      //   livenessprobe: 1
      // };
      // this.props.actions.get(1, params, "caasServicesLivenessprobe");
      return;
    }
  }

  render() {
    const {
      findInstanceByInstanceIdData,
      caasServicesPodsListInfoListData,
      findInstancesByServiceIdListData,
      selectedRow,
      caasServicesConfigListData
    } = this.props;
    const { currentKey } = this.state;
    const showCurrentDetailData = findInstanceByInstanceIdData.get("findInstanceByInstanceIdInfo");
    let findInstancesByServiceIdListDataList = null;
    if (findInstancesByServiceIdListData) {
      if (findInstancesByServiceIdListData.get("findInstancesByServiceIdList")) {
        findInstancesByServiceIdListDataList = findInstancesByServiceIdListData.get(
          "findInstancesByServiceIdList"
        );

        if (findInstancesByServiceIdListDataList.length !== 0) {
          findInstancesByServiceIdListDataList.map(item => {
            item.key = item.instanceId;
          });
        }
      }
    }
    const dataSourceList = caasServicesPodsListInfoListData.get("caasServicesPodsListInfoList");
    const tableList = [];
    let podsList = null;
    if (dataSourceList.length !== 0) {
      podsList = dataSourceList.pods;

      if (podsList) {
        for (let i = 0; i < podsList.length; i++) {
          const podObj = {};
          const objData = podsList[i].objectMeta;
          podObj.nodeName = podsList[i].nodeName;
          podObj.podStatus = podsList[i].podStatus.podPhase;
          podObj.creationTimestamp = objData.creationTimestamp;
          podObj.podName = objData.name;
          podObj.namespace = objData.namespace;
          podObj.namespaceId = selectedRow.namespaceId;
          tableList.push(podObj);
        }
      }
    }

    let caasServicesConfigListDataContainer = null;
    let caasServicesConfigListPorts = null;
    let caasServicesConfigListBasic = null;
    if (caasServicesConfigListData) {
      if (caasServicesConfigListData.get("caasServicesConfigListContainer")) {
        caasServicesConfigListDataContainer = caasServicesConfigListData.get(
          "caasServicesConfigListContainer"
        );
        caasServicesConfigListPorts = caasServicesConfigListData.get("caasServicesConfigListPorts");
        caasServicesConfigListBasic = caasServicesConfigListData.get("caasServicesConfigListBasic");
      }
    }
    return (
      <div style={{ display: "flex", flexDirection: "row" }}>
        <div className="layout-right-height">
          <div className="layout-right-title">
            <span className="goback-button" onClick={this.goBack}>
              <Icon type="left" />
              返回
            </span>
            {/* <p className="page-title">容器实例</p> */}
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "20px" }} type="flex" justify="space-around">
              <Col span={3}>
                {/* <span className="leftImg">
                  <Icon type="project" />
                </span> */}
                <img className="leftImg" src={LeftImg} alt="" />
              </Col>
              <Col span={16}>
                <p className=""> 服务名称：{selectedRow.serviceName}</p>

                <p className="">
                  状态：
                  {parseInt(selectedRow.serviceStatus, 0) === -1
                    ? "停止"
                    : parseInt(selectedRow.serviceStatus, 0) === 1
                    ? "运行中"
                    : parseInt(selectedRow.serviceStatus, 0) === 0
                    ? "未知"
                    : ""}
                </p>
                <p className="">
                  地址：
                  {selectedRow.serviceUrl}
                </p>
                <p className="">
                  容器实例：
                  {selectedRow.serviceInstanceGroup}
                </p>
              </Col>
              {/* <Col span={6} style={{ textAlign: "right" }}>
                <Button type="primary" style={{ marginRight: 10 }}>
                  <Icon type="robot" />
                  登录终端
                </Button>
              </Col> */}
            </Row>
          </div>
          <Tabs
            tabPosition="left"
            defaultActiveKey="0"
            activeKey={currentKey}
            onChange={this.onChangeTab}
          >
            <TabPane tab="容器实例" key="0">
              <ComponentPartDetail
                parentData={selectedRow}
                codeData={showCurrentDetailData}
                tableList={tableList}
              />
            </TabPane>
            <TabPane tab="基本信息" key="1">
              <BasicInformation
                columnsStateBasic={this.columnsStateBasic}
                columnsStateResource={this.columnsStateResource}
                columnsStateEnvironment={this.columnsStateEnvironment}
                caasServicesConfigListBasic={
                  caasServicesConfigListBasic
                    ? caasServicesConfigListBasic.env
                      ? caasServicesConfigListBasic
                      : {}
                    : {}
                }
              />
            </TabPane>
            <TabPane tab="端口" key="2">
              <Ports
                columnsStatePorts={this.columnsStatePorts}
                portsList={
                  caasServicesConfigListPorts
                    ? caasServicesConfigListPorts.length !== 0
                      ? caasServicesConfigListPorts
                      : []
                    : []
                }
              />
            </TabPane>
            <TabPane tab="高可用" key="3">
              <HighAvailability
                parentStyle="service"
                parentData={selectedRow}
                codeData={showCurrentDetailData}
                defaultChecked={
                  caasServicesConfigListDataContainer
                    ? caasServicesConfigListDataContainer.length !== 0
                      ? parseInt(caasServicesConfigListDataContainer.deploymentLivenessprobe, 0) ===
                        1
                        ? true
                        : false
                      : false
                    : false
                }
              />
            </TabPane>
            <TabPane tab="监控" key="4">
              <LineChart
                parentStyle="service"
                parentData={selectedRow}
                codeData={showCurrentDetailData}
              />
            </TabPane>
            <TabPane tab="日志" key="5">
              <CodeLog
                parentStyle="service"
                parentData={selectedRow}
                codeData={showCurrentDetailData}
                tableList={tableList}
              />
            </TabPane>
            <TabPane tab="事件" key="6">
              <EventInformation
                parentStyle="service"
                parentData={selectedRow}
                codeData={showCurrentDetailData}
              />
            </TabPane>
          </Tabs>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    findInstancesByServiceIdListData: state.MaitananceManage.get(
      "findInstancesByServiceIdListData"
    ),
    findInstanceByInstanceIdData: state.MaitananceManage.get("findInstanceByInstanceIdData"),
    caasServicesPodsListInfoListData: state.MaitananceManage.get(
      "caasServicesPodsListInfoListData"
    ),
    caasServicesConfigListData: state.MaitananceManage.get("caasServicesConfigListData")
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ContainerPartDetail);
