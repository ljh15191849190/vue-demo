import React from "react";
import { Card, Tooltip, Icon, DatePicker } from "antd";
import CodeMirror from "react-codemirror";
import "codemirror/lib/codemirror.css";
import "codemirror/mode/jsx/jsx";
import "codemirror/addon/hint/show-hint.css";
import "codemirror/addon/hint/show-hint";
import "codemirror/addon/hint/sql-hint";
import "codemirror/theme/ambiance.css";
import "codemirror/addon/display/fullscreen.css";
import "codemirror/addon/display/fullscreen";

import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/maitananceManageAction";
import "./maitanance.css";

class CodeLog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      logValue: "",
      searchDateValue: null,
      refresh: false,
      sizeNumber: 1
    };
    this.onChangeDate = this.onChangeDate.bind(this);
    this.moreCheck = this.moreCheck.bind(this);
  }

  componentDidUpdate() {
    const { visualCheckLogListData } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    if (visualCheckLogListData.get("visualCheckLogList") === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    } else if (typeof visualCheckLogListData.get("visualCheckLogList").length === "number") {
      if (visualCheckLogListData.get("visualCheckLogList").length === 0) {
        editorss.setValue("所选容器没有更多的日志信息");
        editorss.refresh();
        return;
      }
    }
    editorss.setValue(visualCheckLogListData.get("visualCheckLogList"));
  }

  componentWillReceiveProps(nextProps) {
    const { visualCheckLogListData } = this.props;
    const logValuetest = nextProps.visualCheckLogListData
      ? nextProps.visualCheckLogListData.get("visualCheckLogList")
      : "";
    if (
      visualCheckLogListData.get("visualCheckLogList") !==
      nextProps.visualCheckLogListData.get("visualCheckLogList")
    ) {
      this.setState({
        refresh: true,
        logValue: nextProps.visualCheckLogListData.get("visualCheckLogList")
      });
    }
    const editorss = this.refs.editor.getCodeMirror();
    if (logValuetest.length === 0 || logValuetest === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    }
  }

  componentDidMount() {
    const { visualCheckLogListData } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    if (visualCheckLogListData.get("visualCheckLogList") === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    } else if (typeof visualCheckLogListData.get("visualCheckLogList").length === "number") {
      if (visualCheckLogListData.get("visualCheckLogList").length === 0) {
        editorss.setValue("所选容器没有更多的日志信息");
        editorss.refresh();
        return;
      }
    }
    editorss.setSize("100%", "50vh");
    editorss.setOption("readOnly", true);
  }

  componentWillUnmount() {
    this.setState({
      sizeNumber: 1
    });
  }

  ChangeCode() {
    const editorss = this.refs.editor.getCodeMirror();
  }

  // FullScreen
  getFullScreen() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setOption("fullScreen", "true");
  }

  // Refresh
  getRefresh() {
    const { actions, parentData, codeData, visualCheckLogListData } = this.props;
    const { searchDateValue, sizeNumber, logValue } = this.state;
    let VisualLogPath = "";
    let dataListInstanceId = "";
    const showCurrentDetailData = codeData;

    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }
    if (searchDateValue === null) {
      const VisualLogPathOrg = parentData.serviceLogPath;
      // let VisualLogPathLog = VisualLogPathOrg.split(".");
      // VisualLogPathLog[1] = this.getNowFormatDate() + "." + VisualLogPathLog[1];
      // var VisualLogPath = VisualLogPathLog.join(".");
      VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", this.getNowFormatDate()); // after
    } else {
      const VisualLogPathOrg = parentData.serviceLogPath;
      // let VisualLogPathLog = VisualLogPathOrg.split(".");
      // VisualLogPathLog[1] = this.state.searchDateValue + "." + VisualLogPathLog[1];
      // var VisualLogPath = VisualLogPathLog.join(".");
      VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", searchDateValue); // after
    }
    // let VisualLogPath = this.props.parentData.serviceLogPath;

    const params = {
      instanceId: dataListInstanceId,
      logPath: VisualLogPath,
      sizeNumber: sizeNumber * 20
    };
    actions.get(1, params, "visualCheckLog");

    const editorss = this.refs.editor.getCodeMirror();
    if (logValue !== visualCheckLogListData.get("visualCheckLogList")) {
      editorss.setValue(visualCheckLogListData.get("visualCheckLogList")); //  请求接口获取新数据
      // this.CodeMirrorEditor.setSize(width,height)
      editorss.refresh();
    } else {
      editorss.refresh();
    }
  }

  // search
  // getDateSearch() {
  //   let searchDate = this.state.searchDateValue ? new Date(this.state.searchDateValue) : "";
  //   let searchDateTime = this.state.searchDateValue ? this.state.searchDateValue : "";
  //   //   请求接口刷新界面
  //   const editorss = this.refs.editor.getCodeMirror();
  //   if (this.state.logValue !== this.props.visualCheckLogListData.get("visualCheckLogList")) {
  //     editorss.setValue(this.props.visualCheckLogListData.get("visualCheckLogList")); //  请求接口获取新数据
  //     // this.CodeMirrorEditor.setSize(width,height)
  //     editorss.refresh();
  //   } else {
  //     editorss.refresh();
  //   }
  // }

  onChangeDate(date, dateString) {
    const { actions, parentData, codeData } = this.props;
    let VisualLogPath = "";
    this.setState({
      searchDateValue: dateString,
      sizeNumber: 1
    });
    const VisualLogPathOrg = parentData.serviceLogPath;
    // let VisualLogPathLog = VisualLogPath.split(".");
    // VisualLogPathLog[1] = dateString + "." + VisualLogPathLog[1];
    // VisualLogPath = VisualLogPathLog.join(".");
    VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", dateString); // after
    let dataListInstanceId = "";
    const showCurrentDetailData = codeData;
    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }
    const params = { instanceId: dataListInstanceId, logPath: VisualLogPath, sizeNumber: 1 * 20 };
    actions.get(1, params, "visualCheckLog");
    // 请求接口  获取对应时间的信息
  }

  getNowFormatDate() {
    const date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = `0${month}`;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = `0${strDate}`;
    }
    const currentdate = `${date.getFullYear()}-${month}-${strDate}`;
    return currentdate;
  }

  moreCheck() {
    const { actions, logNum, logNumChange, codeData, parentData } = this.props;
    const { sizeNumber, searchDateValue } = this.state;
    let dataListInstanceId = "";
    const showCurrentDetailData = codeData;
    let VisualLogPath = "";
    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }
    if (logNum === 1) {
      this.setState({
        sizeNumber: 1 + 1
      });
      logNumChange(0);
    } else {
      this.setState({
        sizeNumber: sizeNumber + 1
      });
    }
    if (searchDateValue === null) {
      const VisualLogPathOrg = parentData.serviceLogPath;
      // let VisualLogPathLog = VisualLogPathOrg.split(".");
      // VisualLogPathLog[1] = this.getNowFormatDate() + "." + VisualLogPathLog[1];
      // var VisualLogPath = VisualLogPathLog.join(".");
      VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", this.getNowFormatDate()); // after
      // let sizeTotal = (this.state.sizeNumber + 1) * 20;

      const sizeTotal = logNum === 1 ? 40 : (sizeNumber + 1) * 20; // logNum
      const params = {
        instanceId: dataListInstanceId,
        logPath: VisualLogPath,
        sizeNumber: sizeTotal
      };
      actions.get(1, params, "visualCheckLog");
    } else {
      const VisualLogPathOrg = parentData.serviceLogPath;
      //  let VisualLogPathLog = VisualLogPathOrg.split(".");    // before
      //  VisualLogPathLog[1] = this.state.searchDateValue + "." + VisualLogPathLog[1];  // before
      //  var VisualLogPath = VisualLogPathLog.join(".");    // before
      VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", searchDateValue); // after
      const sizeTotal = (sizeNumber + 1) * 20;
      const params = {
        instanceId: dataListInstanceId,
        logPath: VisualLogPath,
        sizeNumber: sizeTotal
      };
      actions.get(1, params, "visualCheckLog");
    }
    //  let sizeTotal = (this.state.sizeNumber + 1) * 20;
    //  let params = {
    //    instanceId: dataListInstanceId,
    //    logPath: VisualLogPath,
    //    sizeNumber: sizeTotal
    //  };
    //  this.props.actions.get(1, params, "visualCheckLog");
  }

  render() {
    const options = {
      lineNumbers: true, // 显示行号
      mode: { name: "yaml" }, // 定义mode
      lineWrapping: true, // 自动换行
      theme: "ambiance", // 选中的theme
      extraKeys: {
        F7(cm) {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        Esc(cm) {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
    };
    const { parentData } = this.props;
    const { logValue } = this.state;
    const VisualLogPath = parentData.serviceLogPath;

    return (
      <div>
        <Card
          className="card-title"
          title="日志详情"
          extra={
            <div className="card-actionIcon  card-actionIcon-visual">
              <span className="card-actionIcon-more" onClick={this.moreCheck}>
                查看更多
              </span>
              {VisualLogPath.indexOf("${yyyy-MM-dd}") > -1 ? (
                <DatePicker format="YYYY-MM-DD" onChange={this.onChangeDate} />
              ) : (
                ""
              )}
              <Tooltip title="按键F7放大缩小">
                <Icon
                  type="question-circle"
                  theme="filled"
                  style={{ paddingLeft: "8px" }}
                  className="card-title-actionIcon"
                />
              </Tooltip>
              <a href="#" onClick={this.getRefresh.bind(this)}>
                <Icon type="reload" className="card-title-actionIcon" />
              </a>
              <a href="#" onClick={this.getFullScreen.bind(this)}>
                <Icon type="arrows-alt" className="card-title-actionIcon" />
              </a>
            </div>
          }
        >
          <CodeMirror
            ref="editor"
            readOnly={true}
            value={logValue}
            options={options}
            onChange={() => this.ChangeCode()}
          />
        </Card>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    visualCheckLogListData: state.MaitananceManage.get("visualCheckLogListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeLog);
