import React from "react";
import AllPart from "./allPart";
import ComponentPartDetail from "./componentPart";
import ContainerPartDetail from "./containerPart";
import VisualMachiceDetail from "./visualMachice";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: "AllPart",
      selectedRowData: {}
    };
    this.triggleStatus = this.triggleStatus.bind(this);
    this.selectedRow = this.selectedRow.bind(this);
  }

  triggleStatus(showName) {
    this.setState({
      showRepository: showName
    });
  }

  selectedRow(record) {
    this.setState({
      selectedRowData: record
    });
  }

  render() {
    const { projectId } = this.props;
    const { showRepository, selectedRowData } = this.state;
    return (
      <div>
        {showRepository === "AllPart" ? (
          <AllPart
            projectId={projectId}
            selectedRow={this.selectedRow}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository === "ComponentPartDetail" ? (
          <ComponentPartDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository === "ContainerPartDetail" ? (
          <ContainerPartDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository === "VisualMachiceDetail" ? (
          <VisualMachiceDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}

export default Index;
