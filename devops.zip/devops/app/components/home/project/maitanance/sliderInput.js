import React from "react";
import { Row, Col, Slider, InputNumber } from "antd";

export class SliderInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: props.value
      // minHpaMax: this.props.min
    };
  }
  // onAfterChange(value) {
  //   this.setState({
  //     value: value
  //   });
  // }

  componentWillReceiveProps(nextProps) {
    this.setState({
      value: nextProps.value
    });
  }

  onChange(value) {
    const { styleName, max, form } = this.props;
    if (typeof value !== "number") {
      return;
    }
    this.setState({
      value
    });

    if (styleName === "clevel") {
      if (value > max) {
        form.setFieldsValue({ clevel: max });
        return;
      } else {
        form.setFieldsValue({ clevel: value });
        return;
      }
    } else if (styleName === "deploymentHpaMax") {
      if (value > max) {
        form.setFieldsValue({ deploymentHpaMax: max });
        return;
      } else {
        form.setFieldsValue({ deploymentHpaMax: value });
        return;
      }
    } else if (styleName === "deploymentHpaMin") {
      if (value > max) {
        form.setFieldsValue({ deploymentHpaMin: max });
        return;
      } else {
        form.setFieldsValue({ deploymentHpaMin: value });
        return;
      }
    } else if (styleName === "deploymentHpaStepsize") {
      if (value > max) {
        form.setFieldsValue({ deploymentHpaStepsize: max });
        return;
      } else {
        form.setFieldsValue({ deploymentHpaStepsize: value });
        return;
      }
    } else if (styleName === "deploymentHpaTrigger") {
      if (value > max) {
        form.setFieldsValue({ deploymentHpaTrigger: max });
        return;
      } else {
        form.setFieldsValue({ deploymentHpaTrigger: value });
        return;
      }
    }
  }

  render() {
    const { marks, min, max, unit, checkedBooleanEnableHpa, styleName } = this.props;
    const { value } = this.state;
    if (styleName === "deploymentHpaMax") {
      return (
        <div>
          <Row>
            <Col span="16">
              <Slider
                // marks={marks}
                disabled={checkedBooleanEnableHpa === false ? true : false}
                // disabled={this.props.caasServicesDeploymentEnableHpa === 1 ? false : true}
                min={min}
                max={max}
                value={value}
                onChange={this.onChange.bind(this)}
                // onAfterChange={this.onAfterChange.bind(this)}
              />
            </Col>
            <Col span="6">
              <InputNumber
                disabled={checkedBooleanEnableHpa === false ? true : false}
                // disabled={this.props.caasServicesDeploymentEnableHpa === 1 ? false : true}

                min={min}
                max={max}
                style={{ marginLeft: "16px" }}
                value={value}
                onChange={this.onChange.bind(this)}
              />
              {/* <span>{unit === "number" ? "个" : "%"}</span> */}
            </Col>
            <Col span="2">{unit === "number" ? "个" : "%"}</Col>
          </Row>
        </div>
      );
    } else {
      return (
        <div>
          <Row>
            <Col span="16">
              <Slider
                // marks={marks}
                disabled={checkedBooleanEnableHpa === false ? true : false}
                min={min}
                max={max}
                value={value}
                onChange={this.onChange.bind(this)}
              />
            </Col>
            <Col span="6">
              <InputNumber
                disabled={checkedBooleanEnableHpa === false ? true : false}
                min={min}
                max={max}
                style={{ marginLeft: "16px" }}
                value={value}
                onChange={this.onChange.bind(this)}
              />
            </Col>
            <Col span="2">{unit === "number" ? "个" : "%"}</Col>
          </Row>
        </div>
      );
    }
  }
}
