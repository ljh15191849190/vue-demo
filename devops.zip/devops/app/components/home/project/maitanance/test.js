import React, { PropTypes, Component } from "react";
import ECharts from "react-echarts";
import { Row, Col, Modal } from "antd";
import SceneConverRateModal from "./SceneConverRateModal";
import "../../../../common/sass/public/echarts.scss";

export default class SceneConverRate extends React.Component {
  constructor(props) {
    super(props);
    let d = new Date();
    //初始化修改状态属性
    this.state = {
      visible: false,
      queryParam: {
        activityId: this.props.evaluateData.activity.activityId, //活动ID
        statisDate: d.getFullYear() + "" + (d.getMonth() + 1) + "" + d.getDate(), //查询日期默认当天
        userType: 1, //用户类型：1是全部用户，2是注册用户
        channelId: null, //渠道ID
        operpId: null, //运营位ID
        rows: 3, // 每页总条数据
        page: 1 //  当前页
      }
    };
  }
  //组件渲染之前调用方法获取数据
  componentDidMount() {
    //调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    this.props.actions.sceneEvaluateRate(this.state.queryParam);
  }
  render() {
    const sceneEvaluateRateData = this.props.evaluateData.sceneEvaluateRateData.data;
    return (
      <div>
        <h2 className="common-echart-title-mn">分场景转化率</h2>
        {/*map方法循环获取echart折线图*/}
        {sceneEvaluateRateData.map((item, index) => {
          return (
            <div>
              <EchartsCom item={item} index={index} />
            </div>
          );
        })}
      </div>
    );
  }
}

//循环的组件EchartsCom
const EchartsCom = props => {
  //提取返回数据中的每日的推荐人次转化率
  function userRateArr() {
    let userRateArr = new Array();
    props.item.recItemUsers.forEach(function(e, index) {
      userRateArr.push(e.userRate * 100);
    });
    return userRateArr;
  }

  //提取返回数据中的每日的推荐内容转化率
  function itemRateArr() {
    let itemRateArr = new Array();
    props.item.recItemUsers.forEach(function(e, index) {
      itemRateArr.push(e.itemRate * 100);
    });
    return itemRateArr;
  }
  //推荐人次转化率和推荐内容转化率数组中的最后一个数据,在echart标题上（）显示
  const userRateLast = userRateArr()[userRateArr().length - 1]
    ? userRateArr()[userRateArr().length - 1] + "%"
    : "没有数据";
  const itemRateLast = itemRateArr()[itemRateArr().length - 1]
    ? itemRateArr()[itemRateArr().length - 1] + "%"
    : "没有数据";
  //提取返回数据中的日期
  function dateArr() {
    let dateArr = new Array();
    props.item.recItemUsers.forEach(function(e, index) {
      dateArr.push(e.date.slice(4, 6) + "-" + e.date.slice(6, 8));
    });
    return dateArr;
  }
  //echart两个折线图渲染 方法
  function eachCom() {
    //推荐人次转化率折线图option设置
    const optionUsers = {
      tooltip: {
        trigger: "axis"
      },
      grid: {
        left: "5%",
        right: "5%",
        top: "10px",
        bottom: "5%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          axisTick: {
            show: false //是否显示坐标轴刻度
          },
          /*设置X轴字体样式*/
          axisLabel: {
            show: true,
            interval: 0,
            rotate: 20, //倾斜30度
            textStyle: {
              color: "#666",
              fontSize: 12,
              fontFamily: "微软雅黑"
            }
          },
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          },
          data: dateArr()
        }
      ],
      yAxis: [
        {
          type: "value",
          axisTick: {
            show: false //是否显示坐标轴刻度
          },
          //splitNumber:10,//增加Y轴刻度变多
          /*设置y轴字体样式*/
          axisLabel: {
            show: true,
            formatter: "{value}%",
            textStyle: {
              color: "#666",
              fontSize: 12,
              fontFamily: "微软雅黑"
            }
          },
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          }
        }
      ],
      series: [
        {
          name: "推荐人次转化率",
          type: "line",
          stack: "总量",
          symbol: "star", //节点性状
          itemStyle: {
            normal: {
              color: "#278BDD" //图标颜色
            }
          },
          lineStyle: {
            normal: {
              width: 2, //连线粗细
              color: "#278BDD" //连线颜色
            }
          },
          smooth: true, //折线图是趋缓的
          data: userRateArr()
        }
      ]
    };
    //推荐内容转化率折线图option设置
    const optionItems = {
      tooltip: {
        trigger: "axis"
      },
      grid: {
        left: "5%",
        right: "0",
        top: "10px",
        bottom: "5%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          axisTick: {
            show: false //是否显示坐标轴刻度
          },
          /*设置X轴字体样式*/
          axisLabel: {
            show: true,
            interval: 0,
            rotate: 20, //倾斜30度
            textStyle: {
              color: "#666",
              fontSize: 12,
              fontFamily: "微软雅黑"
            }
          },
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          },
          data: dateArr()
        }
      ],
      yAxis: [
        {
          type: "value",
          axisTick: {
            show: false //是否显示坐标轴刻度
          },
          //splitNumber:10,//增加Y轴刻度变多
          /*设置y轴字体样式*/
          axisLabel: {
            show: true,
            formatter: "{value}%",
            textStyle: {
              color: "#666",
              fontSize: 12,
              fontFamily: "微软雅黑"
            }
          },
          axisLine: {
            lineStyle: {
              color: "#999"
            }
          }
        }
      ],
      series: [
        {
          name: "推荐内容转化率",
          type: "line",
          stack: "总量",
          symbol: "star", //节点性状
          itemStyle: {
            normal: {
              color: "#278BDD" //图标颜色
            }
          },
          lineStyle: {
            normal: {
              width: 2, //连线粗细
              color: "#278BDD" //连线颜色
            }
          },
          smooth: true, //折线图是趋缓的
          data: itemRateArr()
        }
      ]
    };
    if (props.item.recItemUsers.length !== 0) {
      return (
        <div className="common-echart-body-div">
          <Col span={12} className="commont-small-ehcharts">
            <Col span={14} offset={1}>
              <h2 className="common-echart-title">
                推荐人次转化率(
                {userRateLast})
              </h2>
            </Col>
            <ECharts option={optionUsers} />
          </Col>
          <Col span={2}>
            <div className="common-echart-border" />
          </Col>
          <Col span={12} className="commont-small-ehcharts">
            <Col span={14} offset={1}>
              <h2 className="common-echart-title">
                推荐内容转化率(
                {itemRateLast})
              </h2>
            </Col>
            <ECharts option={optionItems} />
          </Col>
        </div>
      );
    } else {
      return "没有折线图";
    }
  }
  return (
    <div className="sceneEvaluateRate">
      <Row>
        <Col span={4} className="common-echart-title-mn">
          场景名称
          {(() => {
            switch (props.index + 1) {
              case 1:
                return "一";
              case 2:
                return "二";
              case 3:
                return "三";
              default:
                return props.index + 1;
            }
          })()}
          ：{props.item.sceneName}
        </Col>
        <Col span={3} className="common-text-font">
          渠道：
          {props.item.channelName}
        </Col>
        <Col span={3} className="common-text-font">
          运营位：
          {props.item.operatName}
        </Col>
        <Col span={3} className="common-text-font">
          推荐位置：
          {props.item.recPosition}
        </Col>
        <Col span={11} className="common-text-font">
          推荐策略：
          {props.item.strategyName}+{props.item.supplyStrategyName}
        </Col>
        <Col span={24} className="common-text-bgcolor">
          <Col span={4} className="common-echart-title">
            推荐人次(万次)：
            {props.item.recCount}
          </Col>
          <Col span={3} className="common-echart-title">
            用户数：
            {props.item.activityUserCnt}
          </Col>
          <Col span={5} className="common-echart-title">
            推荐且观看人次(万次)：
            {props.item.recSeeUserCount}
          </Col>
          <Col span={6} className="common-echart-title">
            推荐内容条数(万条)：
            {props.item.recItemCnt}
          </Col>
          <Col span={6} className="common-echart-title">
            推荐且观看内容条数(万条)：
            {props.item.recSeeUserCount}
          </Col>
        </Col>
        {eachCom()}
      </Row>
    </div>
  );
};
