import React from "react";
import { Card, Tooltip, Icon, DatePicker, Select, message } from "antd";
import CodeMirror from "react-codemirror";
import "codemirror/lib/codemirror.css";
import "codemirror/mode/jsx/jsx";
import "codemirror/addon/hint/show-hint.css";
import "codemirror/addon/hint/show-hint";
import "codemirror/addon/hint/sql-hint";
import "codemirror/theme/ambiance.css";
import "codemirror/addon/display/fullscreen.css";
import "codemirror/addon/display/fullscreen";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../../actions/maitananceManageAction";
import "../maitanance.css";

const { Option } = Select;
class CodeLog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      logValue: "",
      searchDateValue: null,
      refresh: false,
      currentPage: 1,
      sizeNumber: 15,
      selectChangeValue: ""
    };

    this.onChangeDate = this.onChangeDate.bind(this);
    this.moreCheck = this.moreCheck.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
  }

  componentDidUpdate() {
    const { caasPodsLogsListData } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    if (
      caasPodsLogsListData.get("caasPodsLogsList")
      // &&
      // this.props.caasPodsLogsListData.get("caasPodsLogsList").length
      // this.props.caasPodsLogsListData.get("caasPodsLogsList") &&
      // this.props.caasPodsLogsListData.get("caasPodsLogsList").length
    ) {
      if (caasPodsLogsListData.get("caasPodsLogsList") === null) {
        editorss.setValue("所选容器没有更多的日志信息");
        editorss.refresh();
        return;
      } else if (caasPodsLogsListData.get("caasPodsLogsList").length) {
        if (caasPodsLogsListData.get("caasPodsLogsList").length === 0) {
          editorss.setValue("所选容器没有更多的日志信息");
          editorss.refresh();
          return;
        }
      }

      // another logic
      // if (this.props.caasPodsLogsListData.get("caasPodsLogsList") === null) {
      //   editorss.setValue("所选容器没有更多的日志信息");
      //   editorss.refresh();
      // } else if (typeof this.props.caasPodsLogsListData.get("caasPodsLogsList").length === "number") {
      //   if (this.props.caasPodsLogsListData.get("caasPodsLogsList").length === 0) {
      //     editorss.setValue("所选容器没有更多的日志信息");
      //     editorss.refresh();
      //     return;
      //   }
      // }
      editorss.setValue(caasPodsLogsListData.get("caasPodsLogsList"));
      editorss.refresh();
    }
  }

  componentWillReceiveProps(nextProps, nextState) {
    const { caasPodsLogsListData } = this.props;

    const editorss = this.refs.editor.getCodeMirror();
    const logValuetest =
      nextProps.caasPodsLogsListData && nextProps.caasPodsLogsListData.get("caasPodsLogsList")
        ? nextProps.caasPodsLogsListData.get("caasPodsLogsList")
        : "";
    if (
      caasPodsLogsListData.get("caasPodsLogsList") !==
      nextProps.caasPodsLogsListData.get("caasPodsLogsList")
    ) {
      const currentPageNowInfo = nextProps.caasPodsLogsListData.get("pageBean");
      const currentPageNow = currentPageNowInfo.page;
      const sizeNumberNowInfo = nextProps.caasPodsLogsListData.get("pageBean");
      const sizeNumberNow = sizeNumberNowInfo.size;
      this.setState({
        currentPage: currentPageNow, // 获取当前请求时的页数
        sizeNumber: sizeNumberNow,
        refresh: true
      });
    }
    if (logValuetest.length === 0 || logValuetest === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    }
    editorss.setValue(logValuetest); //  请求接口获取新数据
    editorss.refresh();
  }

  componentDidMount() {
    const { caasPodsLogsListData } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setSize("100%", "50vh");
    editorss.setOption("readOnly", true);
    if (caasPodsLogsListData.get("caasPodsLogsList") === null) {
      editorss.setValue("所选容器没有更多的日志信息");
      editorss.refresh();
      return;
    } else if (typeof caasPodsLogsListData.get("caasPodsLogsList").length === "number") {
      if (caasPodsLogsListData.get("caasPodsLogsList").length === 0) {
        editorss.setValue("所选容器没有更多的日志信息");
        editorss.refresh();
        return;
      }
    }
  }

  componentWillUnmount() {
    this.setState({
      currentPage: 1,
      sizeNumber: 15,
      logValue: ""
    });
  }

  ChangeCode() {
    const editorss = this.refs.editor.getCodeMirror();
  }

  // FullScreen
  getFullScreen() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setOption("fullScreen", "true");
  }

  // Refresh
  getRefresh() {
    const {
      actions,
      caasPodsLogsListData,
      parentStyle,
      tableList,
      parentData,
      codeData
    } = this.props;
    const { selectChangeValue, searchDateValue, sizeNumber, logValue } = this.state;
    let podNameValue = "";
    if (parentStyle === "service") {
      if (selectChangeValue !== "") {
        podNameValue = selectChangeValue;
      } else if (selectChangeValue === "") {
        const podNameValueList = tableList;
        podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }
      if (searchDateValue === null) {
        const params = {
          podName: podNameValue,
          namespaceId: parentData.namespaceId,
          timestamp: ""
        }; // 开发 // 开发 // 更改后的开发逻辑
        // this.props.actions.get(this.state.currentPage, params, "caasPodsLogs");   // 分页逻辑
        actions.get(sizeNumber, params, "caasPodsLogs"); // 改变size逻辑
      } else {
        const formatDateTZ = searchDateValue ? `${searchDateValue.replace(" ", "T")}Z` : ""; // 用""  代替this.getNowFormatDate()
        const params = {
          podName: podNameValue,
          namespaceId: parentData.namespaceId,
          timestamp: formatDateTZ
        }; // 开发 // 开发
        // this.props.actions.get(this.state.currentPage, params, "caasPodsLogs"); // 分页逻辑
        actions.get(sizeNumber, params, "caasPodsLogs"); // 改变size逻辑
      }

      const editorss = this.refs.editor.getCodeMirror();
      if (logValue !== caasPodsLogsListData.get("caasPodsLogsList")) {
        editorss.setValue(caasPodsLogsListData.get("caasPodsLogsList")); //  请求接口获取新数据
        editorss.refresh();
      } else {
        editorss.refresh();
      }
    } else if (parentStyle === "pod") {
      if (searchDateValue === null) {
        const params = {
          podName: codeData.podName,
          namespaceId: codeData.namespaceId,
          timestamp: ""
        }; // 开发 // 开发 // 开发更改后逻辑
        // timestamp: this.getNowFormatDate()  // 开发逻辑

        // this.props.actions.get(this.state.currentPage, params, "caasPodsLogs"); // 分页逻辑
        actions.get(sizeNumber, params, "caasPodsLogs"); // 改变size逻辑
      } else {
        const formatDateTZ = searchDateValue ? `${searchDateValue.replace(" ", "T")}Z` : ""; // this.getNowFormatDate()用"" 代替当前时间
        const params = {
          podName: codeData.podName,
          namespaceId: codeData.namespaceId,
          timestamp: formatDateTZ
        }; // 开发 // 开发
        actions.get(sizeNumber, params, "caasPodsLogs"); // 改变size逻辑
      }
      const editorss = this.refs.editor.getCodeMirror();
      if (logValue !== caasPodsLogsListData.get("caasPodsLogsList")) {
        editorss.setValue(caasPodsLogsListData.get("caasPodsLogsList")); //  请求接口获取新数据
        editorss.refresh();
      } else {
        editorss.refresh();
      }
    }
  }

  handleSelectChange(value, option) {
    const { actions, parentData } = this.props;
    const { searchDateValue } = this.state;
    this.setState({
      selectChangeValue: value
    });
    if (searchDateValue === null) {
      const params = { podName: value, namespaceId: parentData.namespaceId, timestamp: "" }; // 更改后的开发逻辑
      // timestamp: this.getNowFormatDate()   // 开发逻辑
      actions.get(15, params, "caasPodsLogs"); // 更改size逻辑
    } else {
      const formatDateTZ = `${searchDateValue.replace(" ", "T")}Z`;
      const params = {
        podName: value,
        namespaceId: parentData.namespaceId,
        timestamp: formatDateTZ
      }; // 开发 // 开发
      actions.get(15, params, "caasPodsLogs"); // 更改size逻辑
    }
  }

  onChangeDate(date, dateString) {
    const { actions, parentData, parentStyle, tableList, codeData } = this.props;
    const { selectChangeValue } = this.state;
    let podNameValue = "";
    if (parentStyle === "service") {
      if (selectChangeValue !== "") {
        podNameValue = selectChangeValue;
      } else if (selectChangeValue === "") {
        const podNameValueList = tableList;
        podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }
      this.setState({
        searchDateValue: dateString,
        currentPage: 1,
        sizeNumber: 15
      });
      const formatDateTZ = dateString ? `${dateString.replace(" ", "T")}Z` : ""; //  "" 代替this.getNowFormatDate()
      // let formatDateTZ = dateString.replace(" ", "T") + "Z";
      const params = {
        podName: podNameValue, // 开发
        namespaceId: parentData.namespaceId, // 开发
        timestamp: formatDateTZ
      };
      actions.get(15, params, "caasPodsLogs"); // 更改size逻辑
    } else if (parentStyle === "pod") {
      this.setState({
        searchDateValue: dateString,
        currentPage: 1,
        sizeNumber: 15
      });

      const formatDateTZ = dateString ? `${dateString.replace(" ", "T")}Z` : ""; //  "" 代替this.getNowFormatDate()
      // let formatDateTZ = dateString.replace(" ", "T") + "Z";
      const params = {
        podName: codeData.podName,
        namespaceId: codeData.namespaceId,
        timestamp: formatDateTZ
      }; // 开发 // 开发
      actions.get(15, params, "caasPodsLogs"); // 更改size逻辑
    }
  }

  getNowFormatDate() {
    const date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    let strHours = date.getHours();
    let strMin = date.getMinutes();
    let strSeconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
      month = `0${month}`;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = `0${strDate}`;
    }
    if (strHours >= 0 && strHours <= 9) {
      strHours = `0${strHours}`;
    }
    if (strMin >= 0 && strMin <= 9) {
      strMin = `0${strMin}`;
    }
    if (strSeconds >= 0 && strSeconds <= 9) {
      strSeconds = `0${strSeconds}`;
    }
    const currentdate = `${date.getFullYear()}-${month}-${strDate}T${strHours}:${strHours}:${strSeconds}Z`;
    // date.getFullYear() +
    //   "-" +
    //   month +
    //   "-" +
    //   strDate +
    //   "T" +
    //   strHours +
    //   ":" +
    //   strMin +
    //   ":" +
    //   strSeconds +
    //   "Z";
    return currentdate;
  }

  moreCheck() {
    const {
      actions,
      parentData,
      parentStyle,
      tableList,
      codeData,
      caasPodsLogsListData
    } = this.props;
    const { selectChangeValue, searchDateValue, currentPage, sizeNumber } = this.state;
    let podNameValue = "";
    if (parentStyle === "service") {
      if (selectChangeValue !== "") {
        podNameValue = selectChangeValue;
      } else if (selectChangeValue === "") {
        const podNameValueList = tableList;
        podNameValue = podNameValueList.length !== 0 ? podNameValueList[0].podName : "";
      }

      const currentPageNow = currentPage + 1;
      const sizeNumberNow = sizeNumber + 15;
      // if (currentPageNow > maxPage) {
      //   message.warn("无更多数据！");
      //   return;
      // } else {
      this.setState({
        logValue: caasPodsLogsListData.get("caasPodsLogsList"),
        currentPage: currentPageNow,
        sizeNumber: sizeNumberNow
      });
      if (searchDateValue === null) {
        const params = {
          podName: podNameValue,
          namespaceId: parentData.namespaceId,
          timestamp: ""
        }; // 开发 // 开发 // 更改后的开发逻辑
        actions.get(sizeNumberNow, params, "caasPodsLogs"); // 改变size逻辑
      } else {
        const formatDateTZ = `${searchDateValue.replace(" ", "T")}Z`;
        const params = {
          podName: podNameValue,
          namespaceId: parentData.namespaceId,
          timestamp: formatDateTZ
        }; // 开发 // 开发
        actions.get(sizeNumberNow, params, "caasPodsLogs"); // 改变size逻辑
      }
    } else if (parentStyle === "pod") {
      const currentPageNow = currentPage + 1;
      const sizeNumberNow = sizeNumber + 15;
      // if (currentPageNow > maxPage) {
      //   message.warn("无更多数据！");
      //   return;
      // } else {
      this.setState({
        logValue: caasPodsLogsListData.get("caasPodsLogsList"),
        currentPage: currentPageNow,
        sizeNumber: sizeNumberNow
      });
      if (searchDateValue === null) {
        const params = {
          podName: codeData.podName,
          namespaceId: codeData.namespaceId,
          timestamp: ""
        }; // 开发 // 开发 // 更改后的开发逻辑
        actions.get(sizeNumberNow, params, "caasPodsLogs"); // 改变size逻辑
      } else {
        const formatDateTZ = `${searchDateValue.replace(" ", "T")}Z`;
        const params = {
          podName: codeData.podName,
          namespaceId: codeData.namespaceId,
          timestamp: formatDateTZ
        }; // 开发 // 开发
        actions.get(sizeNumberNow, params, "caasPodsLogs"); // 改变size逻辑
      }
    }
  }

  render() {
    const { parentStyle, tableList } = this.props;
    const { logValue } = this.state;
    let optionChooseList;
    let optionChildren;
    const options = {
      lineNumbers: true, // 显示行号
      mode: { name: "yaml" }, // 定义mode
      // extraKeys: { Ctrl: "autocomplete" }, // 自动提示配置
      lineWrapping: true, // 自动换行
      theme: "ambiance", // 选中的theme
      extraKeys: {
        F7(cm) {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        Esc(cm) {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
    };

    if (parentStyle === "service") {
      optionChooseList = tableList ? tableList : [];
      optionChildren = [];
      if (optionChooseList.length !== 0) {
        for (let i = 0; i < optionChooseList.length; i++) {
          optionChildren.push(
            <Option value={optionChooseList[i].podName} key={`podsName${Math.random()}`}>
              {optionChooseList[i].podName}
            </Option>
          );
        }
      }
    }

    return (
      <div style={{ padding: "0 5px" }}>
        <Card
          className="card-title"
          title="日志详情"
          extra={
            <div
              className={
                parentStyle === "service" ? "card-actionIcon" : "card-actionIcon-podsDetail"
              }
            >
              {parentStyle === "service" ? (
                <Select
                  // allowClear = {true}
                  defaultValue={optionChooseList.length !== 0 ? optionChooseList[0].podName : ""}
                  style={{ width: "310px", marginRight: "10px" }}
                  onChange={this.handleSelectChange}
                >
                  {optionChildren}
                </Select>
              ) : (
                ""
              )}
              <div>
                <span className="card-actionIcon-more" onClick={this.moreCheck}>
                  查看更多
                </span>
                <DatePicker format="YYYY-MM-DD HH:mm:ss" onChange={this.onChangeDate} />
                <Tooltip title="按键F7放大缩小">
                  <Icon
                    type="question-circle"
                    theme="filled"
                    style={{ paddingLeft: "8px" }}
                    className="card-title-actionIcon"
                  />
                </Tooltip>
                <a href="#" onClick={this.getRefresh.bind(this)}>
                  <Icon type="reload" className="card-title-actionIcon" />
                </a>
                <a href="#" onClick={this.getFullScreen.bind(this)}>
                  <Icon type="arrows-alt" className="card-title-actionIcon" />
                </a>
              </div>
            </div>
          }
        >
          <CodeMirror ref="editor" readOnly={true} value={logValue} options={options} />
        </Card>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    caasPodsLogsListData: state.MaitananceManage.get("caasPodsLogsListData")
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeLog);
