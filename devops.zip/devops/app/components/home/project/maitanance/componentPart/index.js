import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Modal, Form, Row, Col, Tabs } from "antd";
import moment from "moment";
import * as action from "../../../../../actions/maitananceManageAction";
import CodeLogPod from "./codeLogPod";
import EventInformationPod from "./eventInformationPod";
import LineChart from "../dateComponent/lineChart";
import "../maitanance.css";

const TabPane = Tabs.TabPane;
const BasicInformation = props => {
  const { showCurrentDetailData, caasPodsInfoListDataCurrent } = props;

  const instanceInfoData = [];
  const resInfoData = [];
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
    const dataList = showCurrentDetailData[0].instanceInfo;
    instanceInfoData.push(dataList);
  }
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[1]) {
    const dataListRes = showCurrentDetailData[1].resInfo;
    resInfoData.push(dataListRes);
  }
  let detailInformation = {
    namespace: "",
    labels: ""
  };
  let detailInformationspec = { nodeName: "" };
  let creationTimestamptext = "";
  let statusInformation = {
    phase: "",
    qosClass: "",
    podIP: ""
  };
  const detailInformationArr = caasPodsInfoListDataCurrent.get("caasPodsInfoList");
  const detailInformationArrItems = detailInformationArr.items;
  if (
    detailInformationArrItems &&
    detailInformationArrItems.length !== 0 &&
    detailInformationArrItems[0]
  ) {
    detailInformation = detailInformationArrItems[0].metadata;
    creationTimestamptext = moment(detailInformationArrItems[0].metadata.creationTimestamp)
      .utcOffset(480)
      .format("YYYY-MM-DD HH:mm:ss");

    statusInformation = detailInformationArrItems[0].status;
    detailInformationspec = detailInformationArrItems[0].spec;
  }

  return (
    <div>
      <div style={{ padding: "10px", marginBottom: "10px" }}>
        <Row type="flex">
          <Col span={16}>
            <p className="">
              名称：
              {detailInformation.name}
            </p>
            <p className="">
              命名空间：
              {detailInformation.namespace}
            </p>
            <p className="">
              标签：
              {detailInformation.labels && detailInformation.labels.length !== 0
                ? JSON.stringify(detailInformation.labels)
                : ""}
            </p>
            <p className="">
              创建时间：
              {creationTimestamptext}
            </p>

            <p className="">
              状态：
              {statusInformation.phase}
            </p>
            <p className="">
              QOS等级：
              {statusInformation.qosClass}
            </p>
            <p className="">
              网络节点：
              {detailInformationspec.nodeName}
            </p>
            <p className="">
              网络IP：
              {statusInformation.podIP}
            </p>
          </Col>
        </Row>
      </div>
    </div>
  );
};

const TabDetail = props => {
  const {
    tabVisible,
    columnsStateBasic,
    columnsStateResource,
    showCurrentDetailData,
    caasPodsInfoListDataCurrent,
    parentData,
    onCancel,
    currentKey,
    onChangeTab
  } = props;
  let visualInfo = null;
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
    visualInfo = showCurrentDetailData[0].instanceInfo;
  }
  return (
    <Modal maskClosable={false}
      width="980px"
      visible={tabVisible}
      title=""
      footer={null}
      destroyOnClose={true}
      // okText="确定"
      // cancelText="取消"
      onCancel={onCancel}
      // onOk={onCreate}
    >
      <Tabs defaultActiveKey="1" activeKey={currentKey} onChange={onChangeTab}>
        <TabPane tab="基本信息" key="1">
          <BasicInformation
            columnsStateBasic={columnsStateBasic}
            columnsStateResource={columnsStateResource}
            showCurrentDetailData={showCurrentDetailData}
            caasPodsInfoListDataCurrent={caasPodsInfoListDataCurrent}
          />
        </TabPane>
        <TabPane tab="监控" key="2">
          <LineChart
            paddingLeft="20px"
            parentStyle="pod"
            parentData={parentData}
            caasPodsInfoListDataCurrent={caasPodsInfoListDataCurrent}
            codeData={showCurrentDetailData}
          />
        </TabPane>
        <TabPane tab="日志" key="3">
          <CodeLogPod parentStyle="pod" parentData={parentData} codeData={showCurrentDetailData} />
        </TabPane>
        <TabPane tab="事件" key="4">
          <EventInformationPod
            paddingLeft="8px"
            parentStyle="pod"
            parentData={parentData}
            codeData={showCurrentDetailData}
          />
        </TabPane>
      </Tabs>
    </Modal>
  );
};

class ComponentPartDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      updateVisible: false,
      userInformation: null,
      confirmLoading: false,
      updataData: {},
      projectName: "",

      tabVisible: false,
      currentKey: "1"
    };
    this.columns = [
      {
        title: "名称",
        dataIndex: "podName",
        render: (text, record) => {
          return (
            <div>
              <a
                onClick={() => {
                  this.showCurrentDetail(record);
                }}
              >
                {text}
              </a>
            </div>
          );
        }
      },
      {
        title: "状态",
        dataIndex: "podStatus",
        render: (text, record) => this.renderColumns(text, record, "podStatus")
      },
      {
        title: "所属主机",
        dataIndex: "nodeName",
        render: (text, record) => this.renderColumns(text, record, "nodeName")
      },
      {
        title: "命名空间",
        dataIndex: "namespace",
        render: (text, record) => this.renderColumns(text, record, "namespace")
      },
      {
        title: "创建时间",
        dataIndex: "creationTimestamp",
        render: (text, record) => this.renderColumns(text, record, "creationTimestamp")
      }
    ];

    this.goBack = this.goBack.bind(this);
    this.renderColumns = this.renderColumns.bind(this);
    this.showCurrentDetail = this.showCurrentDetail.bind(this);
    this.closeDetail = this.closeDetail.bind(this);
    this.onChangeTab = this.onChangeTab.bind(this);
    this.getNowFormatDate = this.getNowFormatDate.bind(this);
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus("AllPart");
  }

  renderColumns(text, record, column) {
    if (column === "podStatus") {
      return (
        <div>
          <p
            className={
              record.podStatus === "Running"
                ? "runColor"
                : record.podStatus === "Pending"
                ? "pendingColor"
                : "stopColor"
            }
          >
            {text}
          </p>
        </div>
      );
    } else if (column === "creationTimestamp") {
      text = moment(text)
        .utcOffset(480)
        .format("YYYY-MM-DD HH:mm:ss");
    }

    return text;
  }

  showCurrentDetail(record) {
    const { actions } = this.props;
    this.setState({
      tabVisible: true,
      showCurrentDetailData: record
    });
    // 展示默认值
    const params = {
      podName: record.podName,
      namespaceId: record.namespaceId // 开发
    };
    actions.get(null, params, "caasPodsInfo");
  }

  closeDetail() {
    this.setState({
      tabVisible: false,
      currentKey: "1",
      showCurrentDetailData: null
    });
  }

  getNowFormatDate() {
    const date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    let strHours = date.getHours();
    let strMin = date.getMinutes();
    let strSeconds = date.getSeconds();
    if (month >= 1 && month <= 9) {
      month = `0${month}`;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = `0${strDate}`;
    }
    if (strHours >= 0 && strHours <= 9) {
      strHours = `0${strHours}`;
    }
    if (strMin >= 0 && strMin <= 9) {
      strMin = `0${strMin}`;
    }
    if (strSeconds >= 0 && strSeconds <= 9) {
      strSeconds = `0${strSeconds}`;
    }
    const currentdate = `${date.getFullYear()}-${month}-${strDate}T${strHours}:${strMin}:${strSeconds}Z`;
    // date.getFullYear() +
    // "-" +
    // month +
    // "-" +
    // strDate +
    // "T" +
    // strHours +
    // ":" +
    // strMin +
    // ":" +
    // strSeconds +
    // "Z";
    return currentdate;
  }

  onChangeTab(key) {
    const { actions } = this.props;
    const { showCurrentDetailData } = this.state;

    this.setState({
      currentKey: key
    });
    if (parseInt(key, 0) === 1) {
      const params = {
        podName: showCurrentDetailData.podName,
        namespaceId: showCurrentDetailData.namespaceId // 开发
      };

      actions.get(null, params, "caasPodsInfo");
      return;
    } else if (parseInt(key, 0) === 3) {
      const params = {
        podName: showCurrentDetailData.podName,
        namespaceId: showCurrentDetailData.namespaceId,
        timestamp: ""
      }; // 开发 // 开发 // 更改后逻辑
      actions.get(15, params, "caasPodsLogs");
      return;
    } else if (parseInt(key, 0) === 2) {
      const params = {
        podName: showCurrentDetailData.podName,
        namespaceId: showCurrentDetailData.namespaceId
      }; // 开发
      actions.get(1, params, "caasPodsInfoMonitor");
      return;
    } else if (parseInt(key, 0) === 4) {
      const params = {
        podName: showCurrentDetailData.podName,
        namespaceId: showCurrentDetailData.namespaceId
      }; // 开发 // 开发
      actions.get(1, params, "caasPodsEvents");
      return;
    }
  }

  render() {
    const { selectedRow, caasPodsInfoListData, caasPodsEventsListData, tableList } = this.props;
    const { tabVisible, showCurrentDetailData, currentKey, loading } = this.state;
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "row"
        }}
      >
        <div className="layout-right-height">
          <TabDetail
            columnsStateBasic={this.columnsStateBasic}
            columnsStateResource={this.columnsStateResource}
            parentData={selectedRow}
            tabVisible={tabVisible}
            showCurrentDetailData={showCurrentDetailData}
            caasPodsInfoListDataCurrent={caasPodsInfoListData}
            caasPodsEventsListData={caasPodsEventsListData}
            currentKey={currentKey}
            onCancel={this.closeDetail}
            onChangeTab={this.onChangeTab}
          />
          <Table
            bordered
            size="small"
            columns={this.columns}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={tableList ? tableList : []}
            pagination={false}
            loading={loading}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    findInstancesByServiceIdListData: state.MaitananceManage.get(
      "findInstancesByServiceIdListData"
    ),
    findInstanceByInstanceIdData: state.MaitananceManage.get("findInstanceByInstanceIdData"),
    caasPodsInfoListData: state.MaitananceManage.get("caasPodsInfoListData"),
    caasPodsEventsListData: state.MaitananceManage.get("caasPodsEventsListData"),
    caasPodsLogsListData: state.MaitananceManage.get("caasPodsLogsListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ComponentPartDetail);
