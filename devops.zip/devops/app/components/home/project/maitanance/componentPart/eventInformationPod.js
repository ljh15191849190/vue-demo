import React from "react";
import { Row, Col, Icon, Timeline, message } from "antd";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
// import * as action from "../../../../../actions/maitananceManageAction.js";
import * as action from "../../../../../actions/maitananceManageAction";
import "../maitanance.css";

class EachItem extends React.PureComponent {
  render() {
    const { dataItem } = this.props;

    const textArr = dataItem.time.replace("T", " ");
    const creationTimestamptext = textArr.replace("Z", " ");

    return (
      <Timeline.Item
        key={dataItem.id}
        color="green"
        dot={<Icon type="check-circle" style={{ fontSize: "16px" }} />}
      >
        <Row style={{ marginTop: "10px", marginBottom: "10px" }} type="flex" justify="space-around">
          <Col span={3}>
            <p className="time-title">{dataItem.type}</p>
          </Col>
          <Col span={10}>
            <p className="time-descripe">
              消息：
              {dataItem.message}
            </p>
          </Col>
          <Col span={6}>
            <p className="time-now">
              时间:
              {creationTimestamptext}
            </p>
          </Col>
        </Row>
      </Timeline.Item>
    );
  }
}

class EventInformation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentPage: 1 //
    };
    this.changePage = this.changePage.bind(this);
  }

  changePage(actionName) {
    const { actions, parentStyle, parentData, codeData, caasPodsEventsListData } = this.props;
    const { currentPage } = this.state;
    if (parentStyle === "pod") {
      const params = {
        podName: codeData.podName, // 开发
        namespaceId: codeData.namespaceId // 开发
      };

      if (actionName === "up") {
        actions.get(1, params, "caasPodsEvents");
      } else if (actionName === "down") {
        const totalPageData = caasPodsEventsListData.get("pageBean");
        const currentPageNow = totalPageData.page ? totalPageData.page + 1 : currentPage + 1;
        const maxPage = totalPageData.totalPage;
        if (currentPageNow > maxPage) {
          message.warn("无更多数据！");
          return;
        } else {
          this.setState({
            currentPage: currentPageNow
          });
          actions.get(currentPageNow, params, "caasPodsEvents");
        }
      }
      return;
    } else if (parentStyle === "service") {
      const params = {
        serviceName: parentData.serviceName, // 开发
        namespaceId: parentData.namespaceId // 开发
      };

      if (actionName === "up") {
        this.setState({
          currentPage: 1
        });
        actions.get(1, params, "caasServicesEvents");
      } else if (actionName === "down") {
        const totalPageData = caasPodsEventsListData.get("pageBean");
        const currentPageNow = totalPageData.page ? totalPageData.page + 1 : currentPage + 1;
        const maxPage = totalPageData.totalPage;
        if (currentPageNow > maxPage) {
          message.warn("无更多数据！");
          return;
        } else {
          this.setState({
            currentPage: currentPageNow
          });
          actions.get(currentPageNow, params, "caasServicesEvents");
        }
      }
    }
  }

  render() {
    const {
      parentStyle,
      caasPodsEventsListData,
      caasServicesEventsListData,
      paddingLeft
    } = this.props;
    let dataItems = null;
    const caasPodsEventsListDataList = caasPodsEventsListData.get("caasPodsEventsList");
    if (parentStyle === "pod") {
      if (caasPodsEventsListData) {
        if (caasPodsEventsListDataList && caasPodsEventsListDataList.length !== 0) {
          dataItems = caasPodsEventsListDataList;
        } else {
          dataItems = [];
        }
      }
    } else if (parentStyle === "service") {
      const caasServicesEventsListDataList = caasServicesEventsListData.get(
        "caasServicesEventsList"
      );
      if (caasPodsEventsListData) {
        if (caasServicesEventsListDataList && caasServicesEventsListDataList.length !== 0) {
          dataItems = caasServicesEventsListDataList;
        } else {
          dataItems = [];
        }
      }
    }
    return (
      <div className="time-line" style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        {dataItems.length !== 0 ? (
          <p className="time-line-actionIcon">
            <span onClick={() => this.changePage("up")}>
              <Icon type="up-circle" style={{ fontSize: "16px" }} />
            </span>
          </p>
        ) : (
          ""
        )}
        <div className="time-line-maxhight">
          {dataItems.length !== 0 ? (
            <Timeline>
              {dataItems.length !== 0
                ? dataItems.map((item, key) => {
                    return <EachItem dataItem={item} />;
                  })
                : ""}
            </Timeline>
          ) : (
            <p className="time-line-maxhight-nothing">暂无数据</p>
          )}
        </div>
        {dataItems.length !== 0 ? (
          <p className="time-line-actionIcon">
            <span onClick={() => this.changePage("down")}>
              <Icon type="down-circle" style={{ fontSize: "16px" }} />
            </span>
          </p>
        ) : (
          ""
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    visualEventFindByCustomizedListData: state.MaitananceManage.get(
      "visualEventFindByCustomizedListData"
    ),
    caasPodsEventsListData: state.MaitananceManage.get("caasPodsEventsListData"),
    caasServicesEventsListData: state.MaitananceManage.get("caasServicesEventsListData")
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EventInformation);
