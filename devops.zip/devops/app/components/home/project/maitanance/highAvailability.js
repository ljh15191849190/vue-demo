import React from "react";
import { Table, Switch, message } from "antd";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/maitananceManageAction";
import "./maitanance.css";

class HighAvailability extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.columnsStateAvailability = [
      {
        title: "端口",
        dataIndex: "checkPort",
        render: (text, record) => this.renderColumns(text, record, "checkPort")
      },
      {
        title: "检查超时",
        dataIndex: "timeOut",
        render: (text, record) => this.renderColumns(text, record, "timeOut")
      },
      {
        title: "重试次数",
        width: 100,
        dataIndex: "retryCount",
        render: (text, record) => this.renderColumns(text, record, "retryCount")
      }
    ];

    this.switchChange = this.switchChange.bind(this);
    this.renderColumns = this.renderColumns.bind(this);
  }

  renderColumns(text, record, column) {
    if (column === "timeOut") {
      if (text) {
        return `${text}ms`;
      }
    }
    return text;
  }

  switchChange(checked) {
    const { actions, codeData } = this.props;
    let dataListInstanceId = "";
    const showCurrentDetailData = codeData;
    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      const dataList = showCurrentDetailData[0].instanceInfo;
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }

    if (checked === false) {
      const params = { instanceId: dataListInstanceId, code: 0 };

      actions.get(1, params, "visualUpdateInstanceDisable");
    } else if (checked === true) {
      const params = { instanceId: dataListInstanceId, code: 1 };
      actions.get(1, params, "visualUpdateInstanceDisable");
    }
    // 请求接口
  }
  //   ??? 思考数据更新的问题，设置完高可用，但是下面数据列表需要更新的逻辑
  // componentDidUpdate() {
  //   if (
  //     this.props.visualUpdateInstanceDisableListData.get("otherStatus") &&
  //     this.props.visualUpdateInstanceDisableListData.get("otherStatus") === 1
  //   ) {
  //     message.success("操作成功");

  //     let dataListInstanceId = "";
  //     let showCurrentDetailData = this.props.codeData;
  //     if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
  //       dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
  //     }
  //     let params = {
  //       instanceId: dataListInstanceId
  //     };
  //     this.props.actions.get(1, params, "visualHighAvailableInfo");
  //   }
  // }
  render() {
    const { visualHighAvailableInfoListData, findInstanceByInstanceIdData } = this.props;
    const visualHighAvailableInfoList = [];
    if (visualHighAvailableInfoListData) {
      if (visualHighAvailableInfoListData.get("visualHighAvailableInfoList")) {
        const visualHighAvailableInfoList11 = visualHighAvailableInfoListData.get(
          "visualHighAvailableInfoList"
        );
        visualHighAvailableInfoList.push(visualHighAvailableInfoList11);
      }
    }
    const instanceIdInfo = findInstanceByInstanceIdData.get("findInstanceByInstanceIdInfo");
    const instanceInfo = instanceIdInfo
      ? instanceIdInfo[0]
        ? instanceIdInfo[0].instanceInfo
        : 0
      : 0;
    return (
      <div>
        <div className="high-seeting">
          <span> 设置高可用 </span>
          <Switch
            checkedChildren="开"
            unCheckedChildren="关"
            defaultChecked={
              instanceInfo
                ? parseInt(instanceInfo.instanceDisable, 0) === 1
                  ? true
                  : false
                : false
            }
            onChange={this.switchChange}
          />
        </div>

        <div className="tabpane-explain">
          <h4 className="tabpane-explain-title">配置信息</h4>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Table
              bordered
              size="small"
              columns={this.columnsStateAvailability}
              locale={{ emptyText: "暂无数据..." }}
              dataSource={
                visualHighAvailableInfoList
                  ? visualHighAvailableInfoList.length !== 0
                    ? visualHighAvailableInfoList
                    : []
                  : []
              }
              pagination={false}
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    visualHighAvailableInfoListData: state.MaitananceManage.get("visualHighAvailableInfoListData"),
    visualUpdateInstanceDisableListData: state.MaitananceManage.get(
      "visualUpdateInstanceDisableListData"
    ),
    findInstanceByInstanceIdData: state.MaitananceManage.get("findInstanceByInstanceIdData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HighAvailability);
