import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  Row,
  Col,
  message,
  Menu,
  Dropdown,
  Icon,
  Radio
} from "antd";
import * as action from "../../../../actions/maitananceManageAction";
import { AutoStretchForm } from "./autoStretch";
import { SliderInput } from "./sliderInput";
import "./maitanance.css";

const FormItem = Form.Item;
const { Option } = Select;
const RadioButton = Radio.Button;
const RadioGroup = Radio.Group;

class Reminder extends React.Component {
  constructor(props) {
    super(props);
    const { value } = this.props;
    this.state = {
      messageText: "",
      value,
      editable: false
    };
  }

  render() {
    const {
      reminderVisible,
      contentText,
      confirmAction,
      confirmCancel,
      dataValue,
      contentTextColor
    } = this.props;
    return (
      <Modal
        maskClosable={false}
        visible={reminderVisible}
        title={contentText.title}
        okText="确定"
        cancelText="取消"
        onCancel={confirmCancel}
        onOk={() => confirmAction(dataValue, contentText.title)}
      >
        <p style={contentTextColor}>
          <Icon type="question-circle" />
          <span style={{ padding: "3px" }} />
          {contentText.content}
        </p>
      </Modal>
    );
  }
}
// const ConfigCell = ({ contentData }) => (
//   <RadioButton
//     value={contentData}
//     // className="RadioButtonCss"
//     style={{ height: "auto" }}
//     buttonStyle="solid"
//     // buttonStyle="outline"
//   >
//     <div className="RadioButtonContent">
//       <p className="diploid">{contentData.diploidNum}</p>
//       <p className="storageCard">
//         {contentData.storageNum}
//         内存
//       </p>
//       <p className="cpuNum">
//         {contentData.cpuNum}
//         （共享）
//       </p>
//     </div>
//   </RadioButton>
// );

const CommonForm = Form.create()(props => {
  const {
    commonVisible,
    actionContent,
    initialData,
    onCreateCommonForm,
    onCancel,
    form,
    caasServicesConfigListDataContainer,
    caasServicesTagsList,
    caasServicesPodsCountList
  } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 14 }
  };

  let configData = null;
  if (caasServicesConfigListDataContainer.length !== 0) {
    configData = caasServicesConfigListDataContainer;
  }
  const optionChildren = [];
  if (caasServicesTagsList.length !== 0) {
    if (caasServicesTagsList[0] && caasServicesTagsList[0].length !== 0) {
      for (let i = 0; i < caasServicesTagsList.length; i++) {
        optionChildren.push(
          <Option value={caasServicesTagsList[i].tagName} key={`tagName${Math.random()}`}>
            {caasServicesTagsList[i].tagName}
          </Option>
        );
      }
    }
  }

  if (caasServicesPodsCountList !== undefined) {
    const caasServicesPodsCountList00 = caasServicesPodsCountList;
  }

  return (
    <Modal
      maskClosable={false}
      width="600px"
      visible={commonVisible}
      title={actionContent.actionTitle}
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreateCommonForm}
      destroyOnClose={true}
    >
      {actionContent.actionTitle === "手动水平扩展" ? (
        <Form layout="horizontal">
          <FormItem {...formItemLayout} label="服务名称">
            <span className="ant-form-text">{configData.deloyName}</span>
          </FormItem>
          <Form.Item {...formItemLayout} label="实际数量：">
            {getFieldDecorator("clevel", {
              rules: [
                {
                  required: true
                }
              ],
              initialValue:
                typeof caasServicesPodsCountList === "number" &&
                caasServicesPodsCountList !== undefined
                  ? caasServicesPodsCountList
                  : "",
              trigger: "onChange"
            })(
              <SliderInput
                styleName="clevel"
                form={form}
                marks={{ 1: "1", 2: "2", 3: "3", 4: "4", 5: "5" }}
                min={actionContent.minNumber}
                max={actionContent.maxNumber}
                unit={actionContent.actionUnit}
              />
            )}
          </Form.Item>
          <FormItem>{actionContent.actionPrompt}</FormItem>
        </Form>
      ) : actionContent.actionTitle === "灰度升级" ? (
        <Form layout="horizontal">
          <FormItem {...formItemLayout} label="服务名称">
            <span className="ant-form-text">{configData.deloyName}</span>
          </FormItem>
          <FormItem {...formItemLayout} label="镜像版本">
            <span className="ant-form-text">{configData.deploymentImageInfo}</span>
          </FormItem>
          <Form.Item {...formItemLayout} label="目标版本：">
            {getFieldDecorator("imageUrl", {
              rules: [
                {
                  required: true
                }
              ],
              initialValue:
                caasServicesTagsList && caasServicesTagsList.length !== 0
                  ? caasServicesTagsList[0]
                    ? caasServicesTagsList[0].length !== 0
                      ? caasServicesTagsList[0].tagName
                      : ""
                    : ""
                  : "",
              trigger: "onChange"
            })(
              <Select
                // allowClear = {true}
                style={{ width: "330px", marginRight: "100px" }}
                // onChange={this.handleSelectChange}
              >
                {optionChildren}
              </Select>
            )}
          </Form.Item>
        </Form>
      ) : actionContent.actionTitle === "更改服务配置" ? (
        <Form layout="horizontal">
          <FormItem {...formItemLayout} label="服务名称">
            <span className="ant-form-text">{configData.deloyName}</span>
          </FormItem>
          <FormItem {...formItemLayout} label="当前配置">
            <span className="ant-form-text">
              {configData.deploymentRequestCpu}(CPU)/{configData.deploymentRequestMem}(内存)
            </span>
          </FormItem>
          <Form.Item {...formItemLayout} label="选择配置：">
            {getFieldDecorator("serverConfig", {
              rules: [
                {
                  required: true
                }
              ]
            })(
              <div>
                <RadioGroup buttonStyle="solid">
                  {[
                    { diploidNum: "1x", storageNum: "256M", cpuNum: "0.5CPU" },
                    { diploidNum: "2x", storageNum: "512M", cpuNum: "1CPU" },
                    { diploidNum: "4x", storageNum: "1GB", cpuNum: "1CPU" },
                    { diploidNum: "8x", storageNum: "2GB", cpuNum: "2CPU" }
                  ].map((itemData, index) => {
                    return (
                      <RadioButton
                        // key={index}
                        value={itemData.diploidNum} // 对象时 选中的有问题  注意 所需要的值
                        // classNmane="RadioButtonCss"
                        style={{ margin: "5px", height: "auto" }}
                        // buttonStyle="outline"
                      >
                        <div className="RadioButtonContent">
                          <p className="diploid">{itemData.diploidNum}</p>
                          <p className="storageCard">
                            {itemData.storageNum}
                            内存
                          </p>
                          <p className="cpuNum">
                            {itemData.cpuNum}
                            （共享）
                          </p>
                        </div>
                      </RadioButton>
                    );
                  })}
                  {/* <RadioButton value="a">
                    torageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNumtorageNum
                    1
                  </RadioButton>
                  <span className="blank-span" />
                  <RadioButton value="b">item 2</RadioButton>
                  <span className="blank-span" />
                  <RadioButton value="c">item 3</RadioButton> */}
                </RadioGroup>
              </div>
            )}
          </Form.Item>
          <FormItem>{actionContent.actionPrompt}</FormItem>
        </Form>
      ) : (
        ""
      )}
    </Modal>
  );
});

class Maitanance extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {},
      loading: false,
      searchItem: {
        name: "",
        searchStatus: ""
      },
      updateVisible: false,
      userInformation: null,
      confirmLoading: false,
      updataData: {},
      projectName: "",
      selectValue: "",
      reminderVisible: false,
      currentData: {},
      contentText: {
        title: "",
        content: ""
      },
      commonVisible: false,
      autoStretchVisible: false,
      actionContent: {
        actionTitle: "",
        actionPrompt: "",
        actionUit: ""
      },
      initialData: {},
      setBoolen: false,
      messageMaxTextError: "",
      caasServicesPodsCountListNum: props.caasServicesPodsCountListData.get(
        "caasServicesPodsCountList"
      )
    };
    this.timer = null;
    this.caasServicesPodsCountListNum11 = null;
    this.columns = [
      {
        title: "服务名称",
        width: 195,
        dataIndex: "serviceName",
        render: (text, record) => {
          return (
            <div>
              <a
                onClick={() => {
                  this.openRepostory(record);
                }}
              >
                {text}
              </a>
            </div>
          );
        }
      },
      {
        title: "组件名称",
        width: 145,
        dataIndex: "applicationName",
        render: (text, record) => this.renderColumns(text, record, "applicationName")
      },
      {
        title: "实例地址",
        dataIndex: "serviceUrl",
        render: (text, record) => this.renderColumns(text, record, "serviceUrl")
      },
      {
        title: "状态",
        width: 95,
        dataIndex: "serviceInstanceGroup",
        render: (text, record) => this.renderColumns(text, record, "serviceInstanceGroup")
      },
      {
        title: "部署类型",
        width: 75,
        dataIndex: "serviceType",
        render: (text, record) => this.renderColumns(text, record, "serviceType")
      },
      {
        title: "创建时间",
        width: 93,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        width: 290,
        dataIndex: "operation",
        render: (text, record) => {
          const { serviceType } = record; // 当前行数据
          const menu = (
            <Menu onClick={this.handleMenuClick}>
              <Menu.Item key="1" value={record}>
                <Icon type="dash" />
                水平扩展
              </Menu.Item>
              <Menu.Item key="2" value={record}>
                <Icon type="drag" />
                自动伸缩
              </Menu.Item>
              <Menu.Item key="3" value={record}>
                <Icon type="arrow-up" />
                灰度升级
              </Menu.Item>
              <Menu.Item key="4" value={record}>
                <Icon type="setting" />
                更改配置
              </Menu.Item>
            </Menu>
          );
          const serviceInstanceGroupArr = record.serviceInstanceGroup.split("/");
          return (
            <div className="editable-row-operations">
              {/* {parseInt(userStatus) === 0 ? (
                <span>
                  <Popconfirm
                    title="确定进行启用操作吗？"
                    onConfirm={() => this.forbidden(record.userId, record.userStatus)}
                    okText="继续"
                    cancelText="取消"
                  >
                    <a className="padright">启动</a>
                  </Popconfirm>
                </span>
              ) : (
                <span>
                  <Popconfirm
                    title="确定进行禁用操作吗？"
                    onConfirm={() => this.forbidden(record.userId, record.userStatus)}
                    okText="继续"
                    cancelText="取消"
                  >
                    <a className="padright" onClick={() => this.showReminder(record, "停止")}>
                      停止
                    </a>
                  </Popconfirm>
                </span>
              )} */}
              <span
                onClick={() => this.showReminder(record, "启动")}
                className={
                  // parseInt(serviceInstanceGroupArr[0]) > parseInt(serviceInstanceGroupArr[1])  // 没有实例时0/0置灰
                  parseInt(serviceInstanceGroupArr[1], 0) === 0
                    ? "editable-row-operations-action-active"
                    : "editable-row-operations-action"
                }
              >
                <span />
                启动
              </span>
              <span
                onClick={() => this.showReminder(record, "停止")} //       ? "editable-row-operations-action" //     ? parseInt(serviceInstanceGroupArr[1]) === 0 //   parseInt(serviceInstanceGroupArr[1]) // className={
                //       : "editable-row-operations-action-active"
                //     : "editable-row-operations-action"
                // }
                className={
                  parseInt(serviceInstanceGroupArr[1], 0) === 0
                    ? "editable-row-operations-action"
                    : "editable-row-operations-action-active"
                }
              >
                <span />
                停止
              </span>
              <span
                onClick={() => this.showReminder(record, "重启")}
                className={
                  parseInt(serviceInstanceGroupArr[1], 0)
                    ? parseInt(serviceInstanceGroupArr[0], 0) ===
                        parseInt(serviceInstanceGroupArr[1], 0) &&
                      parseInt(serviceInstanceGroupArr[1], 0) === 0
                      ? "editable-row-operations-action"
                      : "editable-row-operations-action-active"
                    : "editable-row-operations-action"
                }
              >
                <span />
                重启
              </span>
              <span
                className="editable-row-operations-action-active"
                onClick={() => this.showReminder(record, "删除")}
              >
                <span />
                删除
              </span>
              {parseInt(serviceType, 0) === 1 ? (
                ""
              ) : (
                <Dropdown overlay={menu}>
                  <Button style={{ marginLeft: 8, background: "#1890ff", color: "#fff" }}>
                    更多操作 <Icon type="caret-down" />
                  </Button>
                </Dropdown>
              )}
            </div>
          );
        }
      }
    ];
    this.handleDelOk = this.handleDelOk.bind(this);
    this.handleSelectChange = this.handleSelectChange.bind(this);
    this.showReminder = this.showReminder.bind(this);
    this.confirmAction = this.confirmAction.bind(this);
    this.confirmCancel = this.confirmCancel.bind(this);
    this.handleMenuClick = this.handleMenuClick.bind(this);
    this.onCreateCommonForm = this.onCreateCommonForm.bind(this);
    this.onCommonFormCancel = this.onCommonFormCancel.bind(this);
    this.onAutoStretchFormCancel = this.onAutoStretchFormCancel.bind(this);
    this.onCreateAutoStretchForm = this.onCreateAutoStretchForm.bind(this);
    this.caasServicesDeploymentEnableHpa = this.caasServicesDeploymentEnableHpa.bind(this);
    this.caasServicesHpa = this.caasServicesHpa.bind(this);
    this.openRepostory = this.openRepostory.bind(this);
    this.setBoolenAction = this.setBoolenAction.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.allPartListData.get("pageBean")) {
      this.setState({
        caasServicesPodsCountListNum: nextProps.caasServicesPodsCountListData.get(
          "caasServicesPodsCountList"
        ),
        pagination: {
          total: nextProps.allPartListData.get("pageBean").total,
          current: nextProps.allPartListData.get("pageBean").page,
          pageSize: nextProps.allPartListData.get("pageBean").size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.add(null, { projectId }, "allPartList");
    this.timer = setInterval(() => {
      const { searchItem } = this.state;
      const { allPartListData } = this.props;
      if (searchItem.name || searchItem.searchStatus) {
        const params = {
          inputName: searchItem.name,
          inputType: searchItem.searchStatus,
          projectId // 开发
        };
        actions.search(1, params, "allPartList");
        return;
      } else {
        const params = { inputName: "", inputType: "", projectId }; // 开发
        actions.add(allPartListData.get("pageBean").page, params, "allPartList");
        return;
      }
    }, 15000); // 开发
  }

  componentDidUpdate() {
    const {
      actions,
      projectId,
      allPartListData,
      caasServicesActionListData,
      caasServicesDeploymentEnableHpaListData,
      caasServicesAutoScalingListData
    } = this.props;
    const { searchItem, initialData } = this.state;
    if (allPartListData.get("otherStatus") && allPartListData.get("otherStatus") === 1) {
      message.success("操作成功");
      if (searchItem.name || searchItem.searchStatus) {
        const params = {
          inputName: searchItem.name,
          inputType: searchItem.searchStatus,
          projectId
        }; // 开发
        actions.search(1, params, "allPartList");
        return;
      } else {
        const params = { inputName: "", inputType: "", projectId }; // 开发
        actions.add(allPartListData.get("pageBean").page, params, "allPartList");
        return;
      }
    }
    if (
      caasServicesActionListData.get("otherStatus") &&
      caasServicesActionListData.get("otherStatus") === 1
    ) {
      message.success("操作成功");
      if (searchItem.name || searchItem.searchStatus) {
        const params = {
          inputName: searchItem.name,
          inputType: searchItem.searchStatus,
          projectId
        }; // 开发
        actions.search(1, params, "allPartList");
        return;
      } else {
        const params = { inputName: "", inputType: "", projectId }; // 开发
        actions.add(allPartListData.get("pageBean").page, params, "allPartList");
        return;
      }
    }

    // 待确认关闭自动伸缩功能时是否需要 重新请求
    if (
      caasServicesDeploymentEnableHpaListData.get("otherStatus") &&
      caasServicesDeploymentEnableHpaListData.get("otherStatus") === 1
    ) {
      message.success("操作成功");
      const caasServicesConfigParams = { serviceId: initialData.deployServiceId }; // 拿到初始的高可用状态
      actions.get(1, caasServicesConfigParams, "caasServicesConfig");
    }
    // 待确认开启自动伸缩功能时是否需要 重新请求
    if (
      caasServicesAutoScalingListData.get("otherStatus") &&
      caasServicesAutoScalingListData.get("otherStatus") === 1
    ) {
      message.success("操作成功");
      const caasServicesConfigParams = {
        serviceId: initialData.deployServiceId // 拿到初始的高可用状态
      };
      actions.get(1, caasServicesConfigParams, "caasServicesConfig");
    }
  }

  componentWillUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  // show detailPage
  openRepostory(record) {
    const { actions, triggleStatus, selectedRow } = this.props;
    // 需判断跳转的页面
    if (parseInt(record.serviceType, 0) === 2) {
      // 服务
      const componentName = "ContainerPartDetail";
      const params = { serviceName: record.serviceName, namespaceId: record.namespaceId }; // 开发
      actions.get(null, params, "caasServicesPodsListInfo");

      const caasServicesConfigParams = { serviceId: record.deployServiceId }; // 拿到初始的高可用状态
      actions.get(1, caasServicesConfigParams, "caasServicesConfig");
      triggleStatus(componentName);
      selectedRow(record);
    } else if (parseInt(record.serviceType, 0) === 1) {
      // 虚机
      const componentName = "VisualMachiceDetail";
      const params = { serviceName: record.serviceName, namespaceId: record.namespaceId }; // 开发

      triggleStatus(componentName);
      selectedRow(record);
    }
  }

  handleMenuClick(e) {
    const { actions, triggleStatus, selectedRow } = this.props;

    const serviceInfo = e.item.props.value;
    // caasServicesPodsCount
    const caasServicesPodsCountParams = {
      serviceName: serviceInfo.serviceName,
      namespaceId: serviceInfo.namespaceId
    }; // 拿到初始的数据
    actions.get(1, caasServicesPodsCountParams, "caasServicesPodsCount");
    const caasServicesConfigParams = { serviceId: serviceInfo.deployServiceId }; // 拿到初始的数据
    actions.get(1, caasServicesConfigParams, "caasServicesConfig");
    // 请求镜像名称列表
    const imageUrlArr = serviceInfo.packageUrl.split(":");
    const imageUrl = imageUrlArr[0];
    const caasServicesTagsParams = { imageUrl }; // 拿到最原始的数据
    actions.get(1, caasServicesTagsParams, "caasServicesTags");

    if (parseInt(e.key, 0) === 1) {
      this.setState({
        commonVisible: true,
        actionContent: {
          actionTitle: "手动水平扩展",
          actionPrompt:
            "注：实例数量调整，保存后系统将调整实例数量至设置预期。（若自动伸缩开启，则无法手动扩展）",
          actionUnit: "number",
          maxNumber: 10,
          minNumber: 0
        },
        initialData: e.item.props.value
      });
    } else if (parseInt(e.key, 0) === 2) {
      this.setState({
        autoStretchVisible: true,
        actionContent: {
          actionTitle: "自动弹性伸缩",
          actionPrompt:
            "注：系统将根据设定的CPU阈值来自动的（扩展或减少）该服务所（缺少或冗余）的实例数量",
          actionUnit: "number",
          maxNumber: 5,
          minNumber: 1
        },
        initialData: e.item.props.value
      });
    } else if (parseInt(e.key, 0) === 3) {
      this.setState({
        commonVisible: true,
        actionContent: {
          actionTitle: "灰度升级",
          actionPrompt: "",
          actionUnit: ""
        },
        initialData: e.item.props.value
      });
    } else if (parseInt(e.key, 0) === 4) {
      this.setState({
        commonVisible: true,
        actionContent: {
          actionTitle: "更改服务配置",
          actionPrompt: "注：重新选择配置，保存后系统将重启该服务的所有实例",
          actionUnit: "number",
          maxNumber: 5
        },
        initialData: e.item.props.value
      });
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { actions, projectId } = this.props;
    const { searchItem } = this.state;
    this.setState({ loading: true });
    if (searchItem.name || searchItem.searchStatus) {
      const searchName = ReactDOM.findDOMNode(this.refs.searchName).value;
      if (searchName) {
        const params = { inputName: searchName, inputType: searchItem.searchStatus, projectId }; // 开发时
        actions.search(pagination.current, params, "allPartList");
      } else {
        const params = {
          inputName: "",
          inputType: searchItem.searchStatus,
          projectId // 开发时
        };
        actions.search(pagination.current, params, "allPartList");
      }
    } else {
      const params = { inputName: "", inputType: "", projectId }; // 开发时
      actions.add(pagination.current, params, "allPartList");
    }
  }

  handleDelOk(record) {
    const { actions } = this.props;
    const userId = record.userId;
    actions.del(userId, "allPartList");
  }

  saveCommonFormRef(form) {
    this.form = form;
  }

  onCommonFormCancel() {
    this.setState({
      commonVisible: false,
      actionContent: {
        actionTitle: "",
        actionPrompt: "",
        actionUnit: ""
      },
      initialData: {}
    });
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
  }

  onCreateCommonForm(e) {
    const { actions, caasServicesTagsListData } = this.props;
    const { initialData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      if (typeof values.clevel === "number") {
        const params = {
          serviceId: initialData.deployServiceId,
          expectCount: values.clevel,
          namespaceId: initialData.namespaceId,
          serviceName: initialData.serviceName
        };
        actions.get(1, params, "caasServicesHorizontalScaling");
        this.setState({
          commonVisible: false
        });
        form.resetFields();
        return;
      }
      if (values.imageUrl) {
        const imageUrlOrigin = initialData.packageUrl;
        const imageUrlArr = imageUrlOrigin.split(":");
        const imageUrl = `${imageUrlArr[0]}:${values.imageUrl}`;
        const caasServicesTagsList = caasServicesTagsListData.get("caasServicesTagsList");
        if (caasServicesTagsList.length === 0 || caasServicesTagsList.length === 1) {
          message.error("镜像只有唯一的版本，无需改变版本");
          return;
        }
        const params = {
          serviceId: initialData.deployServiceId,
          image: imageUrl,
          namespaceId: initialData.namespaceId,
          serviceName: initialData.serviceName
        };
        actions.get(1, params, "caasServicesGrayRelease");
        this.setState({
          commonVisible: false
        });
        form.resetFields();
        return;
      }
      if (values.serverConfig) {
        let requestMemSet = "";
        let requestCpuSet = "";
        if (values.serverConfig === "1x") {
          requestMemSet = "256Mi";
          requestCpuSet = "0.5";
        } else if (values.serverConfig === "2x") {
          requestMemSet = "512Mi";
          requestCpuSet = "1";
        } else if (values.serverConfig === "4x") {
          requestMemSet = "1024Mi";
          requestCpuSet = "1";
        } else if (values.serverConfig === "8x") {
          requestMemSet = "2048Mi";
          requestCpuSet = "2";
        }
        // TODO
        // else if (values.serverConfig === "5x") {
        //   var requestCpuSet = "4GB";
        //   var requestMemSet = "1CPU";
        // } else if (values.serverConfig === "6x") {
        //   var requestCpuSet = "8GB";
        //   var requestMemSet = "2CPU";
        // }
        const params = {
          serviceId: initialData.deployServiceId,
          requestCpu: requestCpuSet,
          requestMem: requestMemSet,
          namespaceId: initialData.namespaceId,
          serviceName: initialData.serviceName
        };
        actions.get(1, params, "caasServicesConfigSet");
        this.setState({
          commonVisible: false
        });
        form.resetFields();
        return;
      }
      // if (values.roles !== undefined) {
      //   if (values.roles.length !== 0) {
      //     let roleChoose = values.roles;
      //     let roleList = roleAllList.filter(item => roleChoose.indexOf(item.roleId) !== -1);
      //     values.roles = roleList;
      //   }
      // }
      // this.props.actions.add(values, null, "allPartList");
      // this.props.actions.addApp(values);
    });
  }

  saveAutoStretchFormRef(forms) {
    this.forms = forms;
  }

  onAutoStretchFormCancel() {
    this.setState({
      autoStretchVisible: false,
      actionContent: {
        actionTitle: "",
        actionPrompt: "",
        actionUnit: ""
      },
      initialData: {}
    });
    this.setBoolenAction(false);
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  onCreateAutoStretchForm(e) {
    const { RoleAll, actions } = this.props;
    const roleAllList = RoleAll.data;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      if (values.roles !== undefined) {
        if (values.roles.length !== 0) {
          const roleChoose = values.roles;
          const roleList = roleAllList.filter(item => roleChoose.indexOf(item.roleId) !== -1);
          values.roles = roleList;
        }
      }
      actions.add(values, null, "allPartList");
      this.setState({
        addVisible: false
      });
      forms.resetFields();
    });
  }

  search() {
    const { selectValue } = this.state;
    const { actions, projectId } = this.props;
    const searchName = ReactDOM.findDOMNode(this.refs.searchName).value;
    this.setState({
      searchItem: {
        name: searchName ? (searchName === undefined ? "" : searchName) : "",
        searchStatus: selectValue === undefined ? "" : selectValue
      }
    });
    const params = {
      inputName: searchName,
      inputType: selectValue === undefined ? "" : selectValue,
      projectId
    }; // 开发时
    actions.search(1, params, "allPartList");
  }

  // able disable  changeavailable
  handleSelectChange(value) {
    this.setState({
      selectValue: value
    });
  }

  renderColumns(text, record, column) {
    if (column === "serviceInstanceGroup") {
      let serviceStatusText = "";
      let serviceInstanceGroupText = "";
      const serviceInstanceGroupArr = record.serviceInstanceGroup.split("/");
      if (parseInt(record.serviceStatus, 0) === 1) {
        serviceStatusText = "运行中";
      } else if (parseInt(record.serviceStatus, 0) === -1) {
        serviceStatusText = "已停止";
      } else if (parseInt(record.serviceStatus, 0) === 0) {
        serviceStatusText = "未知";
      }
      if (parseInt(serviceInstanceGroupArr[1], 0) === 0) {
        serviceInstanceGroupText = "全部停止";
      } else if (serviceInstanceGroupArr[0] === serviceInstanceGroupArr[1]) {
        serviceInstanceGroupText = "全部运行";
      } else if (serviceInstanceGroupArr[0] > serviceInstanceGroupArr[1]) {
        serviceInstanceGroupText = "部分运行";
      } else {
        serviceInstanceGroupText = "未知";
      }
      return (
        <div>
          <p className={parseInt(record.serviceStatus, 0) === 1 ? "runColor" : "stopColor"}>
            {serviceStatusText}
          </p>
          <p className="">
            <span className="textFont">{record.serviceInstanceGroup}</span>
            <span className="textFont"> {serviceInstanceGroupText} </span>
          </p>
        </div>
      );
    } else if (column === "serviceType") {
      if (parseInt(record.serviceType, 0) === 1) {
        text = "shell部署";
      } else if (parseInt(record.serviceType, 0) === 2) {
        text = "容器部署";
      }
      return text;
    } else if (column === "serviceUrl") {
      if (record.serviceType != 2) {
        if (record.serviceUrl) {
          const serviceUrlArr = record.serviceUrl.split("-");
          let serviceUrlArrText = "";
          for (let i = 0; i < serviceUrlArr.length; i++) {
            if (i === serviceUrlArr.length - 1) {
              serviceUrlArrText += serviceUrlArr[i];
            } else {
              serviceUrlArrText += `${serviceUrlArr[i]}`;
            }
          }
          text = serviceUrlArrText;
          return text;
        }
      } else {
        return text;
      }
    } else {
      return text;
    }
  }

  showReminder(record, actionName) {
    if (actionName === "重启") {
      if (parseInt(record.serviceStatus, 0) === -1) {
        return;
      }
      this.setState({
        currentData: record,
        reminderVisible: true,
        contentText: {
          title: "重启操作",
          content: "您是否确定要快速重启这个可以快速重启的服务？"
        }
      });
    } else if (actionName === "删除") {
      this.setState({
        currentData: record,
        reminderVisible: true,
        contentText: {
          title: "删除操作",
          content: "您是否确定要删除这个服务？"
        }
      });
    } else if (actionName === "启动") {
      const serviceInstanceGroupArr = record.serviceInstanceGroup.split("/");
      if (parseInt(serviceInstanceGroupArr[0], 0) > parseInt(serviceInstanceGroupArr[1], 0)) {
        this.setState({
          currentData: record,
          reminderVisible: true,
          contentText: {
            title: "启动操作",
            content: "您是否确定要启动这个已停止的服务？"
          }
        });
        return;
      } else if (
        parseInt(serviceInstanceGroupArr[0], 0) === 0 &&
        parseInt(serviceInstanceGroupArr[1], 0) === 0
      ) {
        // 弹出水平扩展的弹窗让用户进行操作
        const paramsE = {
          key: 1,
          item: {
            props: {
              value: record
            }
          }
        };
        this.handleMenuClick(paramsE);
        return;
      } else {
        return;
      }
    } else if (actionName === "停止") {
      if (parseInt(record.serviceStatus, 0) === -1) {
        return;
      }
      this.setState({
        currentData: record,
        reminderVisible: true,
        contentText: {
          title: "停止操作",
          content: "您是否确定要停止这个运行中的服务？"
        }
      });
    }
  }

  confirmAction(record, actionName) {
    const { actions } = this.props;
    // 根据不同的值来进行不同的操作  传参
    if (actionName === "重启操作") {
      this.setState({
        currentData: {},
        reminderVisible: false,
        contentText: {
          title: "",
          content: ""
        }
      });

      if (parseInt(record.serviceType, 0) === 1) {
        const params = {
          deployServiceId: record.deployServiceId,
          execType: 3
        };
        actions.get(null, params, "allPartListAction");
        return;
      } else if (parseInt(record.serviceType, 0) === 2) {
        const params = {
          serviceId: record.deployServiceId,
          serviceName: record.serviceName,
          namespaceId: record.namespaceId
        };
        actions.get("restart", params, "caasServicesAction");
        return;
      }
    } else if (actionName === "删除操作") {
      this.setState({
        currentData: {},
        reminderVisible: false,
        contentText: {
          title: "",
          content: ""
        }
      });

      if (parseInt(record.serviceType, 0) === 1) {
        const params = {
          deployServiceId: record.deployServiceId,
          execType: 4
        };
        actions.get(null, params, "allPartListAction");
        return;
      } else if (parseInt(record.serviceType, 0) === 2) {
        const params = {
          serviceId: record.deployServiceId,
          serviceName: record.serviceName,
          namespaceId: record.namespaceId
        };
        actions.get("del", params, "caasServicesAction");
        return;
      }
    } else if (actionName === "启动操作") {
      this.setState({
        currentData: {},
        reminderVisible: false,
        contentText: {
          title: "",
          content: ""
        }
      });

      if (parseInt(record.serviceType, 0) === 1) {
        const params = { deployServiceId: record.deployServiceId, execType: 1 };
        actions.get(null, params, "allPartListAction");
        return;
      } else if (parseInt(record.serviceType, 0) === 2) {
        const params = {
          serviceId: record.deployServiceId,
          serviceName: record.serviceName,
          namespaceId: record.namespaceId
        };
        actions.get("start", params, "caasServicesAction");
        return;
      }
    } else if (actionName === "停止操作") {
      this.setState({
        currentData: {},
        reminderVisible: false,
        contentText: {
          title: "",
          content: ""
        }
      });
    }

    if (parseInt(record.serviceType, 0) === 1) {
      const params = { deployServiceId: record.deployServiceId, execType: 2 };

      actions.get(null, params, "allPartListAction");
      return;
    } else if (parseInt(record.serviceType, 0) === 2) {
      const params = {
        serviceId: record.deployServiceId,
        serviceName: record.serviceName,
        namespaceId: record.namespaceId
      };
      actions.get("stop", params, "caasServicesAction");
      return;
    }
  }

  confirmCancel() {
    this.setState({
      currentData: {},
      reminderVisible: false,
      contentText: {
        title: "",
        content: ""
      }
    });
  }

  handleCancel(e) {
    this.setState({
      addVisible: false,
      updateVisible: false,
      passwordText: ""
    });
    const form = this.form;
    const forms = this.forms;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    form.resetFields();
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
    });
    forms.resetFields();
  }

  // 请求关闭状态接口，改变状态，再传递给子组件  //方法传递给 孙组件进行执行
  caasServicesDeploymentEnableHpa(boolenValue) {
    const { actions } = this.props;
    const { initialData } = this.state;
    const caasServicesDeploymentEnableHpaParams = {
      serviceId: initialData.deployServiceId,
      namespaceId: initialData.namespaceId
    }; // 开发
    actions.get(1, caasServicesDeploymentEnableHpaParams, "caasServicesDeploymentEnableHpa");
    // this.setState(
    //   {
    //     switchValue: boolenValue
    //   }
    // );
  }

  // 请求提交状态数据接口，改变状态，再传递给子组件  //方法传递给 孙组件进行执行1
  caasServicesHpa() {
    const { actions } = this.props;
    const { initialData } = this.state;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      // deploymentHpaStepsize
      if (values.deploymentHpaMax > values.deploymentHpaMin) {
        const caasServicesAutoScalingParams = {
          deploymentHpaTrigger: values.deploymentHpaTrigger,
          maxreplicas: values.deploymentHpaMax,
          minreplicas: values.deploymentHpaMin,
          strategyMaxunavailable: values.deploymentHpaStepsize,
          namespaceId: initialData.namespaceId,
          serviceId: initialData.deployServiceId
        };
        actions.get(1, caasServicesAutoScalingParams, "caasServicesAutoScaling");
        forms.resetFields();

        this.setState({
          messageMaxTextError: ""
        });
        return;
      } else {
        this.setState({
          messageMaxTextError: "最大实例数量必须大于最小实例数量!"
        });
        return;
      }
    });
  }

  setBoolenAction(setBoolenParams) {
    this.setState({
      setBoolen: setBoolenParams
    });
  }

  render() {
    const {
      allPartListData,
      caasServicesConfigListData,
      caasServicesTagsListData,
      caasServicesPodsCountListData
    } = this.props;
    const {
      initialData,
      caasServicesPodsCountListNum,
      commonVisible,
      actionContent,
      autoStretchVisible,
      messageMaxTextError,
      setBoolen,
      reminderVisible,
      contentText,
      currentData,
      pagination,
      loading
    } = this.state;
    let allPartListDataList = null;
    if (allPartListData) {
      if (allPartListData.get("allPartList")) {
        allPartListDataList = allPartListData.get("allPartList");
        if (allPartListDataList.length !== 0) {
          allPartListDataList.map(item => {
            item.key = item.deployServiceId;
          });
        }
      }
    }
    let caasServicesConfigContainerListData = null;
    let caasServicesConfigListDataContainer = null;
    let caasServicesTagsList = null;
    if (caasServicesConfigListData) {
      if (caasServicesConfigListData.get("caasServicesConfigListContainer")) {
        caasServicesConfigListDataContainer = caasServicesConfigListData.get(
          "caasServicesConfigListContainer"
        );
        if (caasServicesConfigListDataContainer.length !== 0) {
          if (caasServicesConfigListDataContainer.deploymentEnableHpa) {
            caasServicesConfigContainerListData = caasServicesConfigListDataContainer;
          }
        }
      }
    }

    if (caasServicesTagsListData) {
      if (caasServicesTagsListData.get("caasServicesTagsList")) {
        caasServicesTagsList = caasServicesTagsListData.get("caasServicesTagsList");
      }
    }
    if (caasServicesPodsCountListData) {
      if (caasServicesPodsCountListData.get("caasServicesPodsCountList")) {
        this.caasServicesPodsCountListNum11 = caasServicesPodsCountListData.get(
          "caasServicesPodsCountList"
        );
      }
    }
    return (
      <div style={{ display: "flex", flexDirection: "row" }}>
        <div
          style={{
            minHeight: "78vh",
            flex: 6,
            textAlign: "left",
            padding: "5px",
            borderBottom: "1px solid #ccc"
          }}
        >
          <div
            style={{
              textAlign: "left",
              height: "38px",
              padding: "10px",
              lineHeight: "26px",
              borderBottom: "1px solid #ccc",
              marginBottom: "10px",
              marginTop: "10px"
            }}
          >
            运行实例列表
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "20px" }} type="flex" justify="space-between">
              <Col span={8}>
                组件名称：
                <Input style={{ width: "60%" }} ref="searchName" />
              </Col>
              <Col span={8}>
                资源类型：
                <Select
                  ref="searchValue"
                  allowClear={true}
                  onChange={this.handleSelectChange.bind(this)}
                  defaultValue="部署类型"
                  style={{ width: "60%" }}
                >
                  <Option value="1">shell部署</Option>
                  <Option value="2">容器部署</Option>
                </Select>
              </Col>
              <Col span={4} style={{ textAlign: "right" }}>
                <Button type="primary" onClick={this.search.bind(this)}>
                  查询
                </Button>
              </Col>
            </Row>
          </div>
          {/* &&
            caasServicesPodsCountList !== undefined */}
          {/* {typeof this.caasServicesPodsCountListNum11 === "number" ? ( */}
          <CommonForm
            ref={this.saveCommonFormRef.bind(this)}
            initialData={initialData}
            commonVisible={
              commonVisible // contentTextColor={{ color: "#1890ff" }}
            }
            actionContent={actionContent}
            onCreateCommonForm={this.onCreateCommonForm}
            onCancel={this.onCommonFormCancel}
            caasServicesConfigListDataContainer={
              caasServicesConfigListDataContainer
                ? caasServicesConfigListDataContainer.length !== 0
                  ? caasServicesConfigListDataContainer
                  : {}
                : {}
            }
            caasServicesTagsList={
              caasServicesTagsList
                ? caasServicesTagsList.length !== 0
                  ? caasServicesTagsList
                  : []
                : []
            }
            caasServicesPodsCountList={
              caasServicesPodsCountListNum ? caasServicesPodsCountListNum : 0
              // caasServicesPodsCountList !== null ? caasServicesPodsCountList : 0
            }
          />
          {caasServicesConfigListDataContainer &&
          caasServicesConfigListDataContainer.namespaceId === initialData.namespaceId ? (
            <AutoStretchForm
              ref={this.saveAutoStretchFormRef.bind(this)}
              initialData={initialData}
              autoStretchVisible={
                autoStretchVisible // contentTextColor={{ color: "#1890ff" }}
              }
              actionContent={actionContent}
              onCreateAutoStretchForm={this.onCreateAutoStretchForm}
              onCancel={this.onAutoStretchFormCancel}
              caasServicesConfigListDataContainer={
                caasServicesConfigListDataContainer
                // caasServicesConfigListDataContainer && caasServicesConfigListDataContainer.id
                //   ? caasServicesConfigContainerListData
                //   : {}
              }
              setBoolen={setBoolen}
              caasServicesDeploymentEnableHpa={this.caasServicesDeploymentEnableHpa}
              caasServicesHpa={this.caasServicesHpa}
              setBoolenAction={this.setBoolenAction}
              messageMaxTextError={messageMaxTextError}
            />
          ) : (
            ""
          )}

          <Reminder
            contentTextColor={{ color: "#1890ff" }}
            reminderVisible={reminderVisible}
            contentText={contentText}
            confirmAction={this.confirmAction}
            confirmCancel={
              this.confirmCancel // 需要传值识别是哪一种方式启动/删除过来
            }
            dataValue={currentData}
          />
          <Table
            bordered
            size="small"
            columns={this.columns}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              allPartListDataList
                ? allPartListDataList.length !== 0
                  ? allPartListDataList
                  : []
                : []
            }
            pagination={pagination}
            loading={loading}
            onChange={this.handlePageChange.bind(this)}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    allPartListData: state.MaitananceManage.get("allPartListData"),
    caasServicesConfigListData: state.MaitananceManage.get("caasServicesConfigListData"),
    caasServicesPodsCountListData: state.MaitananceManage.get("caasServicesPodsCountListData"),
    caasServicesTagsListData: state.MaitananceManage.get("caasServicesTagsListData"),
    caasServicesActionListData: state.MaitananceManage.get("caasServicesActionListData"),
    caasServicesAutoScalingListData: state.MaitananceManage.get("caasServicesAutoScalingListData"),
    caasServicesDeploymentEnableHpaListData: state.MaitananceManage.get(
      "caasServicesDeploymentEnableHpaListData"
    )
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Maitanance);
