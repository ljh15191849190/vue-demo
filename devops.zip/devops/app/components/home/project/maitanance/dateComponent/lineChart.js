import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
import Moment from "moment";
import DateTab from "./dateTab";
import * as action from "../../../../../actions/maitananceManageAction";
import "../maitanance.css";

import "./dateComponent.css";

const echarts = require("echarts");

class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryCPU = this.queryCPU.bind(this);
    this.queryMEM = this.queryMEM.bind(this);
  }

  queryCPU(xTimeValue, xTimeNumber, xSeriesValueCPU) {
    const myChart1 = echarts.init(this.refs.lineChart1);
    myChart1.setOption({
      tooltip: {
        trigger: "axis"
      },
      legend: {
        data: ["cpu"]
      },
      grid: {
        left: "11%",
        right: "4%",
        bottom: "3%",
        containLabel: true
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        axisLabel: {
          rotate: 10
        },
        data: xTimeValue
      },
      yAxis: {
        name: "CPU占用",
        type: "value",
        min: 0
      },
      series: [
        {
          type: "line",
          data: xSeriesValueCPU
        }
      ]
    });
  }

  queryMEM(xTimeValueMEM, xTimeNumber, xSeriesValueMEM) {
    const myChart2 = echarts.init(this.refs.lineChart2);
    myChart2.setOption({
      tooltip: {
        trigger: "axis"
      },
      legend: {
        data: ["MEN"]
      },
      grid: {
        left: "11%",
        right: "4%",
        bottom: "3%",
        containLabel: true
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        axisLabel: {
          rotate: 10
        },
        data: xTimeValueMEM
      },
      yAxis: {
        name: "内存占用(Mi)",
        type: "value",
        min: 0
      },
      series: [
        {
          type: "line",
          data: xSeriesValueMEM
        }
      ]
    });
  }

  componentDidUpdate() {
    const {
      actions,
      parentStyle,
      visualMonitorListDataCPU,
      visualMonitorListDataMEM,
      caasPodsInfoMonitorListData,
      caasServicesMetricsListData
    } = this.props;

    if (parentStyle === "monitor") {
      const visualMonitorListCPU = visualMonitorListDataCPU.get("visualMonitorListCPU");
      const xTimeValueCPU = [];
      const xSeriesValueCPU = [];
      const xTimeNumberCPU = visualMonitorListCPU.length;
      if (visualMonitorListCPU && visualMonitorListCPU.length !== 0) {
        for (let i = 0; i < visualMonitorListCPU.length; i++) {
          xTimeValueCPU.push(visualMonitorListCPU[i].time);
          const cpuNum = Number(visualMonitorListCPU[i].cpuStat).toFixed(3);
          xSeriesValueCPU.push(cpuNum);
        }
      }
      this.queryCPU(xTimeValueCPU, xTimeNumberCPU, xSeriesValueCPU);
      const visualMonitorListMEM = visualMonitorListDataMEM.get("visualMonitorListMEM");
      const xTimeValueMEM = [];
      const xSeriesValueMEM = [];
      const xTimeNumberMEN = visualMonitorListMEM.length;
      if (visualMonitorListMEM && visualMonitorListMEM.length !== 0) {
        for (let i = 0; i < visualMonitorListMEM.length; i++) {
          xTimeValueMEM.push(visualMonitorListMEM[i].time);
          const memNum = Number(visualMonitorListMEM[i].memStat).toFixed(1);
          xSeriesValueMEM.push(memNum);
        }
      }
      this.queryMEM(xTimeValueMEM, xTimeNumberMEN, xSeriesValueMEM);
    } else if (parentStyle === "pod") {
      const caasPodsInfoMonitorList = caasPodsInfoMonitorListData.get("caasPodsInfoMonitorList");
      const caasPodsInfoMonitorListCPU = caasPodsInfoMonitorList[0].dataPoints;
      const xTimeValueCPU = [];
      const xSeriesValueCPU = [];
      const xTimeNumberCPU = caasPodsInfoMonitorListCPU.length;
      if (caasPodsInfoMonitorListCPU && caasPodsInfoMonitorListCPU.length !== 0) {
        for (let i = 0; i < caasPodsInfoMonitorListCPU.length; i++) {
          const orginDate = Moment(caasPodsInfoMonitorListCPU[i].x * 1000).format(
            "YYYY-MM-DD HH:mm:ss"
          );
          const textArr = orginDate.replace("T", " ");
          const creationTimestamptext = textArr.replace("Z", " ");
          xTimeValueCPU.push(creationTimestamptext);
          xSeriesValueCPU.push((caasPodsInfoMonitorListCPU[i].y / 1000).toFixed(3));
        }
      }
      this.queryCPU(xTimeValueCPU, xTimeNumberCPU, xSeriesValueCPU);
      const caasPodsInfoMonitorListMEM = caasPodsInfoMonitorList[1].dataPoints;
      const xTimeValueMEM = [];
      const xSeriesValueMEM = [];
      const xTimeNumberMEN = caasPodsInfoMonitorListMEM.length;
      if (caasPodsInfoMonitorListMEM && caasPodsInfoMonitorListMEM.length !== 0) {
        for (let i = 0; i < caasPodsInfoMonitorListMEM.length; i++) {
          const orginDate = Moment(caasPodsInfoMonitorListMEM[i].x * 1000).format(
            "YYYY-MM-DD HH:mm:ss"
          );
          const textArr = orginDate.replace("T", " ");
          const creationTimestamptext = textArr.replace("Z", " ");
          const memStat = (caasPodsInfoMonitorListMEM[i].y / (1024 * 1024)).toFixed(1);
          xTimeValueMEM.push(creationTimestamptext);
          xSeriesValueMEM.push(memStat);
        }
      }
      this.queryMEM(xTimeValueMEM, xTimeNumberMEN, xSeriesValueMEM);
    } else if (parentStyle === "service") {
      const caasServicesMetricsDataInfo = caasServicesMetricsListData.get(
        "caasServicesMetricsList"
      );
      const caasServicesMetricsList = caasServicesMetricsDataInfo.cumulativeMetrics;
      const caasServicesMetricsListCPU = caasServicesMetricsList[0].dataPoints;
      const xTimeValueCPU = [];
      const xSeriesValueCPU = [];
      const xTimeNumberCPU = caasServicesMetricsListCPU.length;
      if (caasServicesMetricsListCPU && caasServicesMetricsListCPU.length !== 0) {
        for (let i = 0; i < caasServicesMetricsListCPU.length; i++) {
          const orginDate = Moment(caasServicesMetricsListCPU[i].x * 1000).format(
            "YYYY-MM-DD HH:mm:ss"
          );
          const textArr = orginDate.replace("T", " ");
          const creationTimestamptext = textArr.replace("Z", " ");

          xTimeValueCPU.push(creationTimestamptext);
          xSeriesValueCPU.push((caasServicesMetricsListCPU[i].y / 1000).toFixed(3));
        }
      }
      this.queryCPU(xTimeValueCPU, xTimeNumberCPU, xSeriesValueCPU);
      const caasServicesMetricsListMEM = caasServicesMetricsList[1].dataPoints;
      const xTimeValueMEM = [];
      const xSeriesValueMEM = [];
      const xTimeNumberMEN = caasServicesMetricsListMEM.length;
      if (caasServicesMetricsListMEM && caasServicesMetricsListMEM.length !== 0) {
        for (let i = 0; i < caasServicesMetricsListMEM.length; i++) {
          const orginDate = Moment(caasServicesMetricsListMEM[i].x * 1000).format(
            "YYYY-MM-DD HH:mm:ss"
          );
          const textArr = orginDate.replace("T", " ");
          const creationTimestamptext = textArr.replace("Z", " ");
          const memStat = (caasServicesMetricsListMEM[i].y / (1024 * 1024)).toFixed(1);
          xTimeValueMEM.push(creationTimestamptext);
          xSeriesValueMEM.push(memStat);
        }
      }
      this.queryMEM(xTimeValueMEM, xTimeNumberMEN, xSeriesValueMEM);
    }
  }

  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    // 调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    // this.props.actions.sceneEvaluateRate(this.state.queryParam);
    // let visualMonitorListCPU = this.props.visualMonitorListDataCPU.get("visualMonitorListCPU");
  }

  render() {
    const {
      paddingLeft,
      parentStyle,
      parentData,
      codeData,
      caasPodsInfoListDataCurrent
    } = this.props;
    const sceneEvaluateRateData = ["CPU", "内存"];
    const tabData = ["15分钟", "1小时", "8小时", "1天", "1周"];
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        {/* map方法循环获取echart折线图 ?????? */}
        <Row span={12} className="commont-small-ehcharts">
          <Col span={12}>
            <h3 className="common-echart-title">CPU</h3>
          </Col>
          <Col span={12}>
            {parentStyle === "monitor" ? (
              <DateTab
                dateType="CPU"
                tabData={tabData}
                parentStyle={parentStyle}
                parentData={parentData}
                codeData={codeData ? codeData : caasPodsInfoListDataCurrent}
                queryCPU={this.queryCPU}
              />
            ) : (
              ""
            )}
          </Col>
        </Row>
        <Row span={12}>
          <div id="myChart1" ref="lineChart1" style={{ width: "805px", height: "280px" }} />
        </Row>
        <Row span={12} className="commont-small-ehcharts">
          <Col span={12}>
            <h3 className="common-echart-title">内存</h3>
          </Col>
          {/* <Col span={12}>
            <DateTab
              dateType={"MEM"}
              tabData={tabData}
              parentData={this.props.parentData}
              codeData={this.props.codeData}
              queryMEM={this.queryMEM}
            />
          </Col> */}
        </Row>
        <Row span={13}>
          {/* <EchartsCom option={optionItems} index={index} /> */}
          <div id="myChart2" ref="lineChart2" style={{ width: "805px", height: "280px" }} />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    visualMonitorListDataCPU: state.MaitananceManage.get("visualMonitorListDataCPU"),
    visualMonitorListDataMEM: state.MaitananceManage.get("visualMonitorListDataMEM"),
    caasPodsInfoMonitorListData: state.MaitananceManage.get("caasPodsInfoMonitorListData"),
    caasServicesMetricsListData: state.MaitananceManage.get("caasServicesMetricsListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
