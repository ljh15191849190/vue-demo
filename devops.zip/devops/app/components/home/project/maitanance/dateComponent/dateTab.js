import React from "react";
import "./dateComponent.css";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../../actions/maitananceManageAction";

class DateTab extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentKey: 0
    };
    this.selectDate = this.selectDate.bind(this);
  }

  selectDate(selectCurrentKey) {
    const { actions, parentStyle, codeData } = this.props;
    this.setState({ currentKey: selectCurrentKey });

    if (parentStyle === "monitor") {
      let dataList = "";
      let dataListInstanceId = "";
      const showCurrentDetailData = codeData;
      if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
        dataList = showCurrentDetailData[0].instanceInfo;
        dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
      }
      const params = { code: selectCurrentKey + 1, hostIp: dataList.instanceHost };
      // if (this.props.dateType === "MEM") {
      actions.get(1, params, "visualMonitorMEM");
      // } else if (this.props.dateType === "CPU") {
      actions.get(1, params, "visualMonitorCPU");
      // }
    } else if (parentStyle === "pod") {
      const params = {
        podName: codeData.podName,
        namespaceId: codeData.namespaceId // 开发
      };
      actions.get(selectCurrentKey, params, "caasPodsInfoMonitor");
    }
    // this.props.queryCPU();
    // 请求接口
    // this.props.signDate(this.getTimeDistance(type), type);
  }

  render() {
    const { tabData } = this.props;
    const { currentKey } = this.state;
    return (
      <div className="timeTab">
        {tabData.map((itemData, itemKey) => {
          return (
            <span
              className={
                parseInt(itemKey, 0) === parseInt(currentKey, 0)
                  ? "timeTab-activeTab"
                  : "timeTab-commonTab"
              }
              onClick={() => this.selectDate(itemKey)}
            >
              {itemData}
            </span>
          );
        })}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    visualCheckLogListData: state.MaitananceManage.get("visualCheckLogListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DateTab);

// export default DateTab;
