import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { Table, Modal, Row, Col, Tabs, Icon } from "antd";
import LeftImg from "../../../../../assets/images/dashboard/build.png";
import * as action from "../../../../../actions/maitananceManageAction";
import CodeLog from "../codeLog";
import HighAvailability from "../highAvailability";
import EventInformation from "../eventInformation";
import LineChart from "../dateComponent/lineChart";
import "../maitanance.css";

const TabPane = Tabs.TabPane;
const BasicInformation = props => {
  const { columnsStateBasic, columnsStateResource, showCurrentDetailData } = props;
  const instanceInfoData = [];
  const resInfoData = [];
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
    const dataList = showCurrentDetailData[0].instanceInfo;
    instanceInfoData.push(dataList);
  }
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[1]) {
    const dataListRes = showCurrentDetailData[1].resInfo;
    resInfoData.push(dataListRes);
  }
  return (
    <div>
      <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">基本信息</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateBasic}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              showCurrentDetailData
                ? showCurrentDetailData.length !== 0
                  ? showCurrentDetailData[0]
                    ? instanceInfoData
                    : []
                  : []
                : []
            }
            pagination={false}
          />
        </div>
      </div>
      <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">资源配置</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateResource}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              showCurrentDetailData
                ? showCurrentDetailData.length !== 0
                  ? showCurrentDetailData[1]
                    ? resInfoData
                    : []
                  : []
                : []
            }
            pagination={false}
          />
        </div>
      </div>
      {/* <div className="tabpane-explain">
        <h4 className="tabpane-explain-title">环境变量</h4>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Table
            bordered
            size="small"
            columns={columnsStateEnvironment}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={dataSourceEnvironment}
            // loading={loading}
            pagination={false}
          />
        </div>
      </div> */}
    </div>
  );
};

const TabDetail = props => {
  const {
    tabVisible,
    columnsStateBasic,
    columnsStateResource,
    showCurrentDetailData,
    parentData,
    onCancel,
    currentKey,
    onChangeTab,
    logNumChange, // logNum
    logNum // logNum
  } = props;

  let visualInfo = {};
  if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
    visualInfo = showCurrentDetailData[0].instanceInfo;
  }
  return (
    <Modal maskClosable={false}
      width="980px"
      visible={tabVisible}
      title="虚拟机"
      footer={null} // cancelText="取消" // okText="确定"
      style={{ maxHeight: "830px" }}
      onCancel={onCancel}
      // onOk={onCreate}
    >
      <div style={{ padding: "1px", marginBottom: "10px" }}>
        <Row style={{ marginTop: "1px" }} type="flex" justify="space-around">
          <Col span={3}>
            {/* <span className="leftImg">
              <Icon type="project" />
            </span> */}
            <img className="leftImg" src={LeftImg} alt="" />
          </Col>
          <Col span={16}>
            <p className="visualInfo">
              服务名称：{visualInfo.instanceName ? visualInfo.instanceName : ""}
            </p>

            <p className="visualInfo">
              状态：
              {visualInfo.instanceStatus
                ? parseInt(visualInfo.instanceStatus, 0) === -1
                  ? "停止"
                  : parseInt(visualInfo.instanceStatus, 0) === 1
                  ? "运行中"
                  : parseInt(visualInfo.instanceStatus, 0) === 0
                  ? "未知"
                  : ""
                : ""}
            </p>
            <p className="visualInfo">
              地址：
              {visualInfo.instanceHost ? visualInfo.instanceHost : ""}
            </p>
          </Col>
          {/*  // TODO
          <Col span={6} style={{ textAlign: "right" }}>
                <Button type="primary" style={{ marginRight: 10 }}>
                  <Icon type="robot" />
                  登录终端
                </Button>
              </Col> */}
        </Row>
      </div>
      <Tabs tabPosition="left" defaultActiveKey="1" activeKey={currentKey} onChange={onChangeTab}>
        <TabPane tab="基本信息" key="1">
          <BasicInformation
            columnsStateBasic={columnsStateBasic}
            columnsStateResource={columnsStateResource}
            showCurrentDetailData={showCurrentDetailData}
          />
        </TabPane>
        <TabPane tab="高可用" key="2">
          <HighAvailability parentData={parentData} codeData={showCurrentDetailData} />
        </TabPane>
        <TabPane tab="监控" key="3">
          <LineChart
            parentStyle="monitor"
            parentData={parentData}
            codeData={showCurrentDetailData}
          />
        </TabPane>
        <TabPane tab="日志" key="4">
          <CodeLog
            parentData={parentData}
            codeData={showCurrentDetailData}
            logNumChange={logNumChange}
            logNum={logNum}
          />
        </TabPane>
        <TabPane tab="事件" key="5">
          <EventInformation parentData={parentData} codeData={showCurrentDetailData} />
        </TabPane>
      </Tabs>
    </Modal>
  );
};
class VisualMachiceDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,

      updateVisible: false,
      userInformation: null,
      confirmLoading: false,
      updataData: {},
      projectName: "",

      tabVisible: false,
      currentKey: "1",
      logNum: null // tab切换改变codelog页码用
    };
    this.columns = [
      {
        title: "名称",
        width: 100,
        dataIndex: "instanceName",
        render: (text, record) => {
          return (
            <div>
              <a
                onClick={() => {
                  this.showCurrentDetail(record);
                }}
              >
                {text}
              </a>
            </div>
          );
        }
      },
      {
        title: "状态",
        width: 70,
        dataIndex: "instanceStatus",
        render: (text, record) => this.renderColumns(text, record, "instanceStatus")
      },
      {
        title: "介质",
        dataIndex: "packageUrl",
        render: (text, record) => this.renderColumns(text, record, "packageUrl")
      },
      {
        title: "地址",
        width: 215,
        dataIndex: "instanceUrl",
        render: (text, record) => this.renderColumns(text, record, "instanceUrl")
      },
      {
        title: "创建时间",
        width: 145,
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      }
    ];

    this.columnsStateBasic = [
      {
        title: "名称",
        dataIndex: "instanceName",
        render: (text, record) => this.renderColumns(text, record, "instanceName")
      },
      {
        title: "介质名称",
        dataIndex: "packageUrl",
        render: (text, record) => this.renderColumns(text, record, "packageUrl")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      }
    ];
    this.columnsStateResource = [
      {
        title: "CPU",
        dataIndex: "cpu",
        render: (text, record) => this.renderColumns(text, record, "cpu")
      },
      {
        title: "内存",
        dataIndex: "mem",
        render: (text, record) => this.renderColumns(text, record, "mem")
      },
      {
        title: "系统盘",
        dataIndex: "disk",
        render: (text, record) => this.renderColumns(text, record, "disk")
      }
    ];

    this.goBack = this.goBack.bind(this);
    this.renderColumns = this.renderColumns.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.showCurrentDetail = this.showCurrentDetail.bind(this);
    this.closeDetail = this.closeDetail.bind(this);
    this.onChangeTab = this.onChangeTab.bind(this);
    this.getNowFormatDate = this.getNowFormatDate.bind(this);
    this.logNumChange = this.logNumChange.bind(this);
  }

  componentDidMount() {
    const { actions, selectedRow } = this.props;
    const params = {
      deployServiceId: selectedRow.deployServiceId
    };
    actions.get(1, params, "findInstancesByServiceId");
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus("AllPart");
  }

  renderColumns(text, record, column) {
    let instanceStatusText = "";
    if (parseInt(record.instanceStatus, 0) === 1) {
      instanceStatusText = "运行中";
    } else if (parseInt(record.instanceStatus, 0) === -1) {
      instanceStatusText = "已停止";
    } else if (parseInt(record.instanceStatus, 0) === 0) {
      instanceStatusText = "未知";
    }
    if (column === "instanceStatus") {
      return (
        <div>
          <p className={parseInt(record.instanceStatus, 0) === 1 ? "runColor" : "stopColor"}>
            {instanceStatusText}
          </p>
          {/* <p className="">
            <span className="textFont">{record.serviceInstanceGroup}</span>
            <span className="textFont"> {serviceInstanceGroupText} </span>
          </p> */}
        </div>
      );
    } else if (column === "cpu") {
      return `${text}CPU(共享)`;
    } else if (column === "mem") {
      return `${text}Mib`;
    } else if (column === "disk") {
      return `${text}G`;
    }
    return text;
  }

  showCurrentDetail(record) {
    const { actions } = this.props;
    this.setState({
      tabVisible: true,
      showCurrentDetailData: record
    });
    const params = {
      instanceId: record.instanceId
    };
    actions.get(1, params, "findInstanceByInstanceId");
  }

  closeDetail() {
    this.setState({
      tabVisible: false,
      currentKey: "1"
    });
  }

  getNowFormatDate() {
    const date = new Date();
    let month = date.getMonth() + 1;
    let strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = `0${month}`;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = `0${strDate}`;
    }
    const currentdate = `${date.getFullYear()}-${month}-${strDate}`;
    return currentdate;
  }

  logNumChange(num) {
    this.setState({
      logNum: num
    });
  }

  onChangeTab(key) {
    const {
      actions,
      findInstanceByInstanceIdData,
      selectedRow,
      visualCheckLogListData
    } = this.props;

    this.setState({
      currentKey: key
    });
    let dataList = "";
    let dataListInstanceId = "";
    const showCurrentDetailData = findInstanceByInstanceIdData.get("findInstanceByInstanceIdInfo");
    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      dataList = showCurrentDetailData[0].instanceInfo;
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }
    let VisualLogPath = "";
    if (parseInt(key, 0) === 4) {
      const VisualLogPathOrg = selectedRow.serviceLogPath;
      // let VisualLogPathLog = VisualLogPathOrg.split("."); // before
      // VisualLogPathLog[1] = this.getNowFormatDate() + "." + VisualLogPathLog[1]; // before
      // var VisualLogPath = VisualLogPathLog.join("."); // before

      // if (VisualLogPathOrg.indexOf("${yyyy-MM-dd}") > -1) {
      //   var VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", this.getNowFormatDate());
      // }
      VisualLogPath = VisualLogPathOrg.replace("${yyyy-MM-dd}", this.getNowFormatDate()); // after
      const params = {
        instanceId: dataListInstanceId,
        logPath: VisualLogPath,
        sizeNumber: "20"
      };
      this.logNumChange(1); // logNum
      if (visualCheckLogListData.get("visualCheckLogList") === null) {
        actions.get(1, params, "visualCheckLog"); // 刚进入为空时，请求
        return;
      } else {
        actions.get(1, params, "visualCheckLog"); // 请求后有数据就不在请求，以便下次进入时页面的size不会异常
        return;
      }
    } else if (parseInt(key, 0) === 3) {
      const params = { code: 1, hostIp: dataList.instanceHost };
      actions.get(1, params, "visualMonitorCPU");
      actions.get(1, params, "visualMonitorMEM");
      return;
    } else if (parseInt(key, 0) === 2) {
      const params = { instanceId: dataListInstanceId };
      actions.get(1, params, "visualHighAvailableInfo");
      return;
    } else if (parseInt(key, 0) === 5) {
      const params = { instanceId: dataListInstanceId };
      actions.add(1, params, "visualEventFindByCustomized");
      return;
    }
  }

  // 分页效果
  handlePageChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const { searchItem } = this.state;
    this.setState({ loading: true });
    if (searchItem.name || searchItem.userStatus) {
      const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
      if (roleName) {
        actions.search(pagination.current, searchItem, "userManage");
      } else {
        actions.search(
          pagination.current,
          { name: "", userStatus: searchItem.userStatus },
          "userManage"
        );
      }
    } else {
      actions.get(pagination.current, null, "userManage");
    }
  }

  render() {
    const {
      selectedRow,
      findInstancesByServiceIdListData,
      findInstanceByInstanceIdData
    } = this.props;
    const { tabVisible, currentKey, logNum, pagination, loading } = this.state;
    let findInstancesByServiceIdListDataList = null;
    if (findInstancesByServiceIdListData) {
      if (findInstancesByServiceIdListData.get("findInstancesByServiceIdList")) {
        findInstancesByServiceIdListDataList = findInstancesByServiceIdListData.get(
          "findInstancesByServiceIdList"
        );

        if (findInstancesByServiceIdListDataList.length !== 0) {
          findInstancesByServiceIdListDataList.map(item => {
            item.key = item.instanceId;
          });
        }
      }
    }
    return (
      <div style={{ display: "flex", flexDirection: "row" }}>
        <div className="layout-right-height">
          <div className="goback-button">
            <span onClick={this.goBack}>
              <Icon type="left" />
              返回
            </span>
          </div>
          <div style={{ padding: "10px", marginBottom: "10px" }}>
            <Row style={{ marginTop: "20px" }} type="flex" justify="space-around">
              <Col span={3}>
                {/* <span className="leftImg">
                  <Icon type="project" />
                </span> */}
                <img className="leftImg" src={LeftImg} alt="" />
              </Col>
              <Col span={16}>
                <p className=""> 服务名称：{selectedRow.serviceName}</p>

                <p className="">
                  状态：
                  {parseInt(selectedRow.serviceStatus, 0) === -1
                    ? "停止"
                    : parseInt(selectedRow.serviceStatus, 0) === 1
                    ? "运行中"
                    : parseInt(selectedRow.serviceStatus, 0) === 0
                    ? "未知"
                    : ""}
                </p>
                <p className="address-url">
                  地址：
                  {selectedRow.serviceUrl}
                </p>
                <p className="">
                  实例：
                  {selectedRow.serviceInstanceGroup}
                </p>
              </Col>
              {/* <Col span={6} style={{ textAlign: "right" }}>
                <Button type="primary" style={{ marginRight: 10 }}>
                  <Icon type="robot" />
                  登录终端
                </Button>
              </Col> */}
            </Row>
          </div>
          <TabDetail
            columnsStateBasic={this.columnsStateBasic}
            columnsStateResource={this.columnsStateResource}
            parentData={selectedRow}
            tabVisible={tabVisible}
            showCurrentDetailData={findInstanceByInstanceIdData.get("findInstanceByInstanceIdInfo")}
            currentKey={currentKey}
            onCancel={this.closeDetail}
            onChangeTab={this.onChangeTab}
            logNumChange={this.logNumChange}
            logNum={logNum}
          />
          <Table
            bordered
            size="small"
            columns={this.columns}
            locale={{ emptyText: "暂无数据..." }}
            dataSource={
              findInstancesByServiceIdListDataList
                ? findInstancesByServiceIdListDataList.length !== 0
                  ? findInstancesByServiceIdListDataList
                  : []
                : []
            }
            pagination={pagination}
            loading={loading}
            onChange={this.handlePageChange}
          />
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    findInstancesByServiceIdListData: state.MaitananceManage.get(
      "findInstancesByServiceIdListData"
    ),
    findInstanceByInstanceIdData: state.MaitananceManage.get("findInstanceByInstanceIdData"),
    visualCheckLogListData: state.MaitananceManage.get("visualCheckLogListData")
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(VisualMachiceDetail);
