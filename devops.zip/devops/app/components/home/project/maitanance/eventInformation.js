import React from "react";
import { Row, Col, Icon, Timeline, message } from "antd";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/maitananceManageAction";
import "./maitanance.css";

class EachItem extends React.PureComponent {
  render() {
    const { dataItem } = this.props;
    return (
      <Timeline.Item
        key={dataItem.id}
        color="green"
        dot={<Icon type="check-circle" style={{ fontSize: "16px" }} />}
      >
        <Row style={{ marginTop: "20px", marginBottom: "20px" }} type="flex" justify="space-around">
          {/* <Col span={3}>
            <p className="time-title">名称: {dataItem.name}</p>
          </Col> */}
          <Col span={6}>
            <span className="time-descripe">{dataItem.eventName}</span>
          </Col>
          <Col span={6}>
            <p className="time-now">
              时间:
              {dataItem.createTime}
            </p>
          </Col>
        </Row>
      </Timeline.Item>
    );
  }
}

class EventInformation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentPage: 1
    };

    this.changePage = this.changePage.bind(this);
  }

  changePage(actionName) {
    const { actions, codeData, visualEventFindByCustomizedListData } = this.props;
    const { currentPage } = this.state;
    let dataListInstanceId = "";
    const showCurrentDetailData = codeData;
    if (showCurrentDetailData && showCurrentDetailData.length !== 0 && showCurrentDetailData[0]) {
      dataListInstanceId = showCurrentDetailData[0].instanceInfo.instanceId;
    }

    const params = { instanceId: dataListInstanceId };
    if (actionName === "up") {
      this.setState({
        currentPage: 1
      });
      actions.add(null, params, "visualEventFindByCustomized");
    } else if (actionName === "down") {
      const currentPageNow = currentPage + 1;
      const totalPageData = visualEventFindByCustomizedListData.get("pageBean");
      const maxPage = totalPageData.totalPage;
      if (currentPageNow > maxPage) {
        message.warn("无更多数据！");
        return;
      } else {
        this.setState({
          currentPage: currentPageNow
        });
        actions.add(currentPageNow, params, "visualEventFindByCustomized");
      }
    }
  }

  render() {
    const { visualEventFindByCustomizedListData } = this.props;
    const visualEventFindByCustomizedListDataList = visualEventFindByCustomizedListData.get(
      "visualEventFindByCustomizedList"
    );
    let dataItems = null;
    if (visualEventFindByCustomizedListData) {
      if (
        visualEventFindByCustomizedListDataList &&
        visualEventFindByCustomizedListDataList.length !== 0
      ) {
        dataItems = visualEventFindByCustomizedListDataList;
      } else {
        dataItems = [];
      }
    }
    return (
      <div className="time-line">
        {dataItems.length !== 0 ? (
          <p className="time-line-actionIcon">
            <span onClick={() => this.changePage("up")}>
              <Icon type="up-circle" style={{ fontSize: "16px" }} />
            </span>
          </p>
        ) : (
          ""
        )}
        <div className="time-line-maxhight">
          {/* <Timeline>
            {dataItems.length !== 0
              ? dataItems.map(item => {
                  return <EachItem dataItem={item} />;
                })
              : ""}
          </Timeline> */}
          {dataItems.length !== 0 ? (
            <Timeline>
              {dataItems.length !== 0
                ? dataItems.map((item, key) => {
                    return <EachItem dataItem={item} />;
                  })
                : ""}
            </Timeline>
          ) : (
            <p className="time-line-maxhight-nothing">暂无数据</p>
          )}
        </div>
        {dataItems.length !== 0 ? (
          <p className="time-line-actionIcon">
            <span onClick={() => this.changePage("down")}>
              <Icon type="down-circle" style={{ fontSize: "16px" }} />
            </span>
          </p>
        ) : (
          ""
        )}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    visualEventFindByCustomizedListData: state.MaitananceManage.get(
      "visualEventFindByCustomizedListData"
    )
  };
};
const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EventInformation);
