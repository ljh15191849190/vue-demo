import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, Popconfirm, Row, Col } from "antd";
import * as crAction from "../../../../actions/CodeRelation";
import * as branchAction from "../../../../actions/Branches";
import "antd/dist/antd.css";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;
const { TextArea } = Input;
const NewForm = Form.create()(props => {
  const {
    visible,
    onCreate,
    onCancel,
    handleChange,
    form,
    handleSubmit,
    onChangeBranch,
    branchList,
    newKey,
    onChangeSelect
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      maskClosable={false}
      visible={visible}
      title="新增标签"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
      footer={null}
      key={newKey}
    >
      <Form layout="vertical" onSubmit={handleSubmit}>
        <FormItem label="标签名称:">
          {getFieldDecorator("tagNames", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="基于分支:">
          {getFieldDecorator("branchName", {
            rules: Validation.Rule_select
          })(
            <Select allowClear onChange={onChangeSelect}>
              {branchList
                ? branchList.map(v => {
                    return (
                      <Option value={v.branchName} key={v.branchId}>
                        {v.branchName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <FormItem style={{ textAlign: "right" }}>
          <Button style={{ marginRight: "10px" }} onClick={onCancel}>
            取消
          </Button>
          <Button type="primary" htmlType="submit">
            确定
          </Button>
        </FormItem>
      </Form>
    </Modal>
  );
});

class Tags extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      confirmLoading: false,
      projectName: "",
      branchId: ""
    };
    this.columns = [
      {
        title: "名称",
        dataIndex: "tagName",
        render: (text, record) => this.renderColumns(text, record, "tagName")
      },
      {
        title: "创建时间",
        dataIndex: "authoredDate",
        render: (text, record) => this.renderColumns(text, record, "authoredDate")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
              <a
                // href={
                //   "/webpjm/code/download?repoId=" +
                //   record.repoId +
                //   "&ref=" +
                //   record.tagName +
                //   "&fileFormat=zip"
                // }
                href={`/webpjm/code/download?repoId=${record.repoId}&ref=${
                  record.tagName
                }&fileFormat=zip`}
                className="padright"
              >
                <span />
                下载
              </a>
              <a
                disabled={record.lockedStatus == 1}
                // href={
                //   "/webpjm/code/download?repoId=" +
                //   record.repoId +
                //   "&ref=" +
                //   record.tagName +
                //   "&fileFormat=tar"
                // }
                href={`/webpjm/code/download?repoId=${record.repoId}&ref=${
                  record.tagName
                }&fileFormat=tar`}
                className="padright"
              >
                <span />
                下载tar包
              </a>
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
  }

  renderColumns(text, record, column) {
    return text;
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.tagAddFlag === 1) {
      this.forms.resetFields();
      this.query();
    }
    if (nextProps.deleteTagFlag === 1) {
      this.query();
    }
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    this.query();
  }

  query() {
    const { repOidData, actions } = this.props;
    const repoId = repOidData.repoId;
    const payload = {
      repoId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "repoId", sopt: "eq", value: repoId }]
    };
    actions.getTagList(payload);
  }

  /**
   * 新增TAG提交
   */
  handleSubmit(e) {
    const { actions, repOidData } = this.props;
    const { branchId } = this.state;
    e.preventDefault();
    this.forms.validateFields((err, values) => {
      if (!err) {
        actions.createTag({
          repoId: repOidData.repoId,
          branchId,
          tagName: values.tagNames,
          ref: values.branchName
        });
        this.setState({ visible: false });
      }
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  handleUpdataOk(e) {
    const { actions } = this.props;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      actions.updateComponent(values);
      this.setState({ updatavisible: false });
    });
  }

  showModal() {
    const { newKey } = this.state;
    this.setState({
      visible: true,
      newKey: newKey + 1
    });
  }

  handleOk(e) {
    const { projectId, actions } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      // 默认项目id 后期重新传值
      values.projectId = projectId;
      actions.addComponentList(values);
      this.setState({ visible: false });
    });
  }

  handleCancel(e) {
    const forms = this.forms;
    forms.resetFields();
    this.setState({
      visible: false
    });
  }

  changeSearch(e) {
    this.setState({
      projectName: e.target.value
    });
  }

  /**
   * 选择分支
   */
  onChangeSelect(v, option) {
    this.setState({
      branchId: option.key
    });
  }

  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteTag({
      repoId: record.repoId,
      tagId: record.tagId,
      tagName: record.tagName
    });
  }

  /**
   * 回车事件
   */
  onKeyDown(e) {
    const { repOidData, actions } = this.props;
    const repoId = repOidData.repoId;
    const tagName = ReactDOM.findDOMNode(this.refs.tagName).value;
    const payload = {
      repoId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: [
        { name: "repoId", sopt: "eq", value: repoId },
        { name: "tagName", sopt: "cn", value: tagName }
      ]
    };
    if (tagName) {
      actions.getTagList(payload);
    } else {
      this.query();
    }
  }

  handlePageChange(pagination) {
    const { actions, repOidData } = this.props;
    this.setState({ loading: true });
    const payload = {
      repoId: repOidData.repoId,
      page: pagination.current,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    };
    actions.getTagList(payload);
  }

  render() {
    const { resData, branchList, tagListData } = this.props;
    const { visible, newKey, pagination, loading } = this.state;
    if (resData) {
      resData.map(item => {
        item.key = item.applicationId + Math.random();
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={5}>
              <span style={{ marginRight: 20 }}>Tag:</span>
              <Input style={{ width: "70%" }} ref="tagName" />
            </Col>
            <Col span={4} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.onKeyDown.bind(this)}
                style={{ marginRight: "15px" }}
                className="padleft"
              >
                搜索
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
              {/* <Button onClick={this.query.bind(this)}>查询</Button> */}
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            visible={visible}
            newKey={newKey}
            branchList={branchList}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
            handleSubmit={this.handleSubmit.bind(this)}
            onChangeSelect={this.onChangeSelect.bind(this)}
          />
        </div>
        <div />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={tagListData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    tagListData: state.codeRelation.get("tagListData"),
    tagAddFlag: state.codeRelation.get("tagAddFlag"),
    deleteTagFlag: state.codeRelation.get("deleteTagFlag"),
    branchList: state.branch.get("resData"),
    pageConfig: state.codeRelation.get("tagPageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, crAction, branchAction);
  // return {actions: bindActionCreators(action, dispatch)};
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Tags);
