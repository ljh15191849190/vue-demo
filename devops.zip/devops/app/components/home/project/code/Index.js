import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import CodeRelaction from "./CodeRelation";
import Repository from "./Repository";
import * as action from "../../../../actions/CodeRelation";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: false,
      ecList: [],
      repOidData: []
    };
    this.triggleStatus = this.triggleStatus.bind(this);
    this.renderCodeList = this.renderCodeList.bind(this);
    this.openRepostory = this.openRepostory.bind(this);
    this.openApp = this.openApp.bind(this);
    this.getDeepFile = this.getDeepFile.bind(this);
    this.getFileContent = this.getFileContent.bind(this);
  }

  triggleStatus(show) {
    this.setState({
      showRepository: show
    });
  }

  openRepostory(record) {
    const { actions } = this.props;
    this.setState({
      showRepository: true,
      repOidData: record
    });
    const req = {
      // repoId: record.repoId,
      repoId: record.repoId,
      path: "",
      ref: "master"
    };
    actions.enterRCRep(req);
  }

  openApp(value, repoId) {
    const { actions } = this.props;
    const req = {
      // repoId: record.repoId,
      repoId,
      path: "",
      ref: value
    };
    actions.enterRCRep(req);
  }

  renderCodeList(list) {
    this.setState({
      ecList: list
    });
  }

  componentDidMount() {}

  getDeepFile(repo) {
    const { actions } = this.props;
    const req = {
      // repoId: record.repoId,
      repoId: repo.repoId,
      path: repo.path,
      ref: "master"
    };
    actions.enterRCRep(req);
  }

  getFileContent(repo) {
    const { actions } = this.props;
    const req = {
      // repoId: record.repoId,
      repoId: repo.repoId,
      path: repo.path,
      ref: "master"
    };
    actions.getFileContent(req);
  }

  render() {
    const { projectId, enterCodeList, fileContent } = this.props;
    const { repOidData, showRepository } = this.state;
    return (
      <div>
        {showRepository ? (
          <Repository
            projectId={projectId}
            ecList={enterCodeList}
            triggleStatus={this.triggleStatus}
            getDeepFile={this.getDeepFile}
            fileContent={fileContent}
            getFileContent={this.getFileContent}
            repOidData={repOidData}
            openApp={this.openApp}
          />
        ) : (
          <CodeRelaction
            projectId={projectId}
            openRepostory={this.openRepostory}
            renderCodeList={this.renderCodeList}
          />
        )}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    enterCodeList: state.codeRelation.get("enterCodeList"),
    fileContent: state.codeRelation.get("fileContent")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Index);
