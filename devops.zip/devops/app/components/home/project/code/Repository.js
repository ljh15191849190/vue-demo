import React from "react";
import { Icon, Menu, Row, Form, Col, Select } from "antd";
import "./styles.css";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import CodeViewer from "../../../commons/CodeViewer";
import MonacoEditor from "../../../commons/MonacoEditor";
import Branches from "./Branches";
import * as branchAction from "../../../../actions/Branches";

import Tags from "./Tags";

const { Option } = Select;
const FormItem = Form.Item;

class Repository extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      MenuKey: "1",
      MenuName: "代码",
      MenuType: "1",
      codeStyle: "table",
      fileExtension: "",
      selectBranch: "",
      selectVlaue: "master"
    };
    this.goBack = this.goBack.bind(this);
    this.getDeepFile = this.getDeepFile.bind(this);
    this.getFileContent = this.getFileContent.bind(this);
    this.DirectoryData = [];
    this.timeout = null;
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(false);
  }

  menuClick(v, i, e) {
    this.setState({
      MenuKey: e.key,
      MenuName: v.menuTitle,
      MenuType: v.id
    });
  }
  // 进入目录
  // getDeepFile(repo) {
  //   console.log(repo);
  //   const { repOidData, getDeepFile } = this.props;
  //   this.setState({
  //     codeStyle: "table"
  //   });
  //   this.DirectoryData.push(repo);
  //   repo.repoId = repOidData.repoId;
  //   getDeepFile.call(null, repo);
  // }
  // 进入目录（防抖）
  getDeepFile(repo) {
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      console.log("防抖");
      const { repOidData, getDeepFile } = this.props;
      this.setState({
        codeStyle: "table"
      });
      this.DirectoryData.push(repo);
      repo.repoId = repOidData.repoId;
      getDeepFile.call(null, repo);
    }, 1000);
  }

  // 目录
  getDeepFileback(repo) {
    const { repOidData, getDeepFile } = this.props;
    const index = this.DirectoryData.indexOf(repo);
    this.DirectoryData.splice(index + 1);
    repo.repoId = repOidData.repoId;
    getDeepFile.call(null, repo);
  }

  getFileContent(repo) {
    const { repOidData, getFileContent } = this.props;
    this.DirectoryData.push(repo);
    const filePath = repo.path;
    const index = filePath.lastIndexOf(".");
    const extention = filePath.substr(index + 1);
    repo.repoId = repOidData.repoId;
    this.setState({
      codeStyle: "code",
      extention
    });

    getFileContent.call(null, repo);
  }

  handleChange(value) {
    const { repOidData, openApp, openRepostory } = this.props;
    this.setState({
      selectVlaue: value
    });

    const repoId = repOidData.repoId;
    // openRepostory( value);
    openApp(value, repoId);
  }

  componentDidMount() {
    const { actions, repOidData } = this.props;
    // this.props.openRepostory({}, "1");
    const repoId = repOidData.repoId;

    const payload = {
      repoId,
      page: 1,
      size: 30,
      sortid: "id",
      sortvalue: "asc",
      conditions: [{ name: "repoId", sopt: "eq", value: repoId }]
    };

    actions.getRepoBranches(payload);
  }

  componentDidUpdate() {
    // let haha = document.getElementById("Stringlengthchange").innerText;
  }

  render() {
    const { MenuList, repOidData, branchList, openApp, ecList, fileContent } = this.props;
    const { selectVlaue, codeStyle, extention, MenuKey } = this.state;
    if (MenuList && MenuList.length > 0) {
      MenuList.map(item => {
        item.key = item.id;
      });
    }

    const CV = () => {
      return (
        <div>
          <Select
            placeholder="请选择"
            style={{ marginLeft: "20px", width: "160px" }}
            onChange={this.handleChange.bind(this)}
            value={selectVlaue}
          >
            {branchList
              ? branchList.map(v => {
                  return (
                    <Option value={v.branchName} key={v.branchId + Math.random()}>
                      {v.branchName}
                    </Option>
                  );
                })
              : []}
          </Select>
          {/* <span style={{padding: "8px"}}>{this.state.selectVlaue}</span> */}

          <span id="Stringlengthchange">
            <a
              style={{ marginLeft: "20px" }}
              onClick={() => {
                const repoId = repOidData.repoId;
                openApp("master", repoId);
                this.setState({
                  codeStyle: "table"
                });
                this.DirectoryData.splice(0);
              }}
            >
              {selectVlaue}
            </a>
            {this.DirectoryData.map(resp => {
              return (
                <a
                  key={resp.id + Math.random()}
                  style={{ padding: "3px", cursor: "pointer" }}
                  onClick={() => {
                    if (resp.type == "tree") {
                      this.setState({
                        codeStyle: "table"
                      });
                      this.getDeepFileback(resp);
                    } else if (resp.type == "blob") {
                      //
                    }
                  }}
                >
                  {/* {"/ " + resp.name} */}
                  {`/ ${resp.name}`}
                </a>
              );
            })}
          </span>
          {codeStyle == "table" ? (
            <CodeViewer
              getDeepFile={this.getDeepFile}
              getFileContent={this.getFileContent}
              ecList={ecList}
            />
          ) : (
            <MonacoEditor code={fileContent} extention={extention} />
          )}
        </div>
      );
    };
    return (
      <div>
        <span className="cr-returnCode">
          <Icon type="backward" style={{ height: "40px", width: "40px" }} onClick={this.goBack} />
          <span style={{ fontSize: "16px" }}>返回关联代码</span>
        </span>
        <Row style={{ height: "76vh", marginTop: "20px", overflow: "auto" }}>
          <Col span={4} style={{ borderRight: "1px solid rgba(228, 228, 228, 1)", height: "100%" }}>
            <span>
              当前代码库：
              {repOidData.repoName}
            </span>
            {MenuList.map((v, i) => {
              return (
                <Menu
                  key={v.id}
                  onSelect={this.menuClick.bind(this, v, i)}
                  selectedKeys={[MenuKey]}
                >
                  <Menu.Item key={v.id}>{v.menuTitle}</Menu.Item>
                </Menu>
              );
            })}
          </Col>
          <Col span={20} style={{ height: "100%" }}>
            {MenuKey == 1 ? (
              <CV />
            ) : MenuKey == 2 ? (
              <Branches repOidData={repOidData} />
            ) : MenuKey == 3 ? (
              <Tags repOidData={repOidData} />
            ) : (
              ""
            )}
          </Col>
        </Row>
      </div>
    );
  }
}
Repository.defaultProps = {
  MenuList: [
    {
      id: "1",
      name: "code",
      value: "代码",
      menuTitle: "代码"
    },
    {
      id: "2",
      name: "branch",
      value: "分支",
      menuTitle: "分支"
    },
    {
      id: "3",
      name: "tag",
      value: "标签",
      menuTitle: "标签"
    }
  ]
};

const mapStateToProps = state => {
  return {
    branchList: state.branch.get("resData")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, branchAction);
  // return {actions: bindActionCreators(action, dispatch)};
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Repository);
