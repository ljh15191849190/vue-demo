import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, Popconfirm, Row, Col, message } from "antd";
import * as action from "../../../../actions/Branches";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;
const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form, branchList, onChangeSelect } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增分支"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="名称:">
          {getFieldDecorator("branchName", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="基于分支:">
          {getFieldDecorator("ref", {
            rules: Validation.Rule_select
          })(
            <Select allowClear>
              {branchList
                ? branchList.map(v => {
                    return (
                      <Option value={v.branchName} key={v.branchId}>
                        {v.branchName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class Branch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      confirmLoading: false,
      projectName: "",
      isProtect: true
    };

    this.handleDelOk = this.handleDelOk.bind(this);
    this.handleIsProtect = this.handleIsProtect.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.handlekeyDown = this.handlekeyDown.bind(this);

    this.columns = [
      {
        title: "名称",
        dataIndex: "branchName",
        render: (text, record) => this.renderColumns(text, record, "branchName")
      },
      {
        title: "创建时间",
        dataIndex: "authoredDate",
        render: (text, record) => this.renderColumns(text, record, "authoredDate")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          const isLocked = record.lockedStatus;
          return (
            <div className="editable-row-operations">
              <Popconfirm
                title="确定删除吗？"
                okText="确定"
                cancelText="取消"
                onConfirm={this.handleDelOk.bind(this, record)}
              >
                <a className="padright" disabled={record.isDefault == 1}>
                  <span />
                  删除
                </a>
              </Popconfirm>
              <a
                // disabled={record.lockedStatus == 1}
                // href={
                //   "/webpjm/code/download?repoId=" +
                //   record.repoId +
                //   "&ref=" +
                //   record.branchName +
                //   "&fileFormat=zip"
                // }
                href={`/webpjm/code/download?repoId=${record.repoId}&ref=${
                  record.branchName
                }&fileFormat=zip`}
                className="padright"
              >
                <span />
                下载
              </a>
              <a
                // disabled={record.lockedStatus == 1}
                // href={
                //   "/webpjm/code/download?repoId=" +
                //   record.repoId +
                //   "&ref=" +
                //   record.branchName +
                //   "&fileFormat=tar"
                // }
                href={`/webpjm/code/download?repoId=${record.repoId}&ref=${
                  record.branchName
                }&fileFormat=tar`}
                className="padright"
              >
                <span />
                下载tar包
              </a>

              <a className="padright" onClick={() => this.handleIsProtect(record)}>
                <span />
                {record.lockedStatus == 1 ? "解锁" : "锁定"}
              </a>
            </div>
          );
        }
      }
    ];
  }

  renderColumns(text, record, column) {
    if (record.isDefault == 1 && column == "branchName") {
      // text = text + "（默认分支）";
      text = `${text}（默认分支）`;
    }
    return text;
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.createStatus && nextProps.createStatus === 1) {
      message.info("创建成功");
      this.getPepoBranchesList();
    }
    if (nextProps.delBranStatus && nextProps.delBranStatus === 1) {
      message.info("删除成功");
      this.getPepoBranchesList();
    }
    if (nextProps.protectStatus && nextProps.protectStatus === 1) {
      message.info("锁定成功");
      this.getPepoBranchesList();
    }
    if (nextProps.unprotectStatus && nextProps.unprotectStatus === 1) {
      message.info("解锁成功");
      this.getPepoBranchesList();
    }
  }

  componentDidMount() {
    this.getPepoBranchesList();
  }

  handlePageChange(pagination) {
    const { actions, repOidData } = this.props;
    const repoId = String(repOidData.repoId);

    this.setState({ loading: true });
    const payload = {
      repoId,
      page: pagination.current,
      size: 10,
      sortid: "id",
      sortvalue: "asc",
      conditions: [{ name: "repoId", sopt: "eq", value: repoId }]
    };
    actions.getRepoBranches(payload);
  }
  // onShowSizeChange(current, pageSize) {
  //   this.setState({
  //     current: 1,
  //     pageSize: pageSize
  //   });
  //   let payload = {
  //     repoId: "16",
  //     page: 1,
  //     size: 10,
  //     sortid: "id",
  //     sortvalue: "asc",
  //     conditions: [{name: "repoId", sopt: "eq", value: "16"}]
  //   };
  //   this.props.actions.getRepoBranches(payload);
  // }

  getPepoBranchesList() {
    const { actions, repOidData } = this.props;
    const repoId = String(repOidData.repoId);
    const payload = {
      repoId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "asc",
      conditions: [{ name: "repoId", sopt: "eq", value: repoId }]
    };

    actions.getRepoBranches(payload);
  }

  handleDelOk(record) {
    const { actions } = this.props;
    const payload = {
      repoId: record.repoId,
      branchId: record.branchId,
      branchName: record.branchName
    };

    actions.branchDel(payload);
  }

  handleIsProtect(record) {
    const { actions } = this.props;
    const payload = {
      repoId: record.repoId,
      branchId: record.branchId,
      branchName: record.branchName
    };
    if (record.lockedStatus == 1) {
      actions.branchUnprotect(payload);
    } else {
      actions.branchProtect(payload);
    }
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  handleUpdataOk(e) {
    const { actions } = this.props;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      actions.updateComponent(values);
      this.setState({ updatavisible: false });
    });
  }

  showModal() {
    this.setState({
      visible: true
    });
  }

  handlekeyDown(e) {
    const { repOidData, actions } = this.props;
    const repoId = String(repOidData.repoId);
    const branchName = ReactDOM.findDOMNode(this.refs.branchName).value;
    actions.getRepoBranches({
      repoId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "asc",
      conditions: [
        { name: "repoId", sopt: "eq", value: repoId },
        { name: "branchName", sopt: "cn", value: branchName }
      ]
    });
  }

  handleOk(e) {
    const { actions, resData } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.repoId = resData[0].repoId;

      forms.resetFields();
      actions.branchCreate(values);
      this.setState({ visible: false });
    });
    this.getPepoBranchesList();
  }

  handleCancel(e) {
    const forms = this.forms;
    forms.resetFields();
    this.setState({
      visible: false
    });
  }

  changeSearch(e) {
    this.setState({
      projectName: e.target.value
    });
  }

  render() {
    // const pagination = {
    //   total: this.state.pagination.total,
    //   pageSize: this.state.pagination.pageSize,
    //   current: this.state.pagination.current
    // };
    const { resData } = this.props;
    const { visible, pagination, loading } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.branchId + Math.random();
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={5}>
              <span style={{ marginRight: 20 }}>分支:</span>
              <Input ref="branchName" style={{ width: "70%" }} />
            </Col>
            <Col span={4} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.handlekeyDown}
                style={{ marginRight: "15px" }}
                className="padleft"
              >
                搜索
              </Button>

              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
            branchList={resData}
          />
        </div>
        <div />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.branch.get("resData"),
    pageConfig: state.branch.get("pageConfig"),
    createStatus: state.branch.get("createStatus"),
    delBranStatus: state.branch.get("delBranStatus"),
    protectStatus: state.branch.get("protectStatus"),
    unprotectStatus: state.branch.get("unprotectStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Branch);
