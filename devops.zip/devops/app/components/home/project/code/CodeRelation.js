import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { Table, Input, Select, Modal, Button, Form, Popconfirm, Row, Col, message } from "antd";
import _ from "lodash";
import * as action from "../../../../actions/CodeRelation";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Search = Input.Search;
const { Option } = Select;

const UpdateForm = Form.create()(props => {
  const { visible, onCreate, onCancel, form, components } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="修改仓库"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="代码库类型 :">
          {getFieldDecorator("repoTypeId")(<Input disabled />)}
        </FormItem>
        <FormItem label="代码库地址 :">{getFieldDecorator("repoUrl")(<Input disabled />)}</FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem label="组件：">
          {getFieldDecorator("applicationId", {
            rules: Validation.Rule_select
          })(
            <Select disabled initialValue="请选择组件">
              {_.map(components, ele => {
                return (
                  <Option value={ele.applicationId} key={ele.applicationCode + Math.random()}>
                    {ele.applicationName}
                  </Option>
                );
              })}
            </Select>
          )}
        </FormItem>
        <FormItem label="分支使用策略：">
          {getFieldDecorator("branchPolicy", {
            rules: Validation.Rule_select
          })(
            <Select allowClear initialValue="TBD">
              <Option value="tbd">TBD</Option>
              <Option value="github-flow">Github-Flow</Option>
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});
const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form, repoType, components } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增仓库"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="代码库类型 :">
          {getFieldDecorator("repoTypeId", {
            initialValue: "gitlab",
            rules: Validation.Rule_select
          })(
            <Select
              showSearch
              allowClear
              // value={repoType[0].repoTypeName}
              optionFilterProp="children"
              filterOption={(input, option) =>
                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {_.map(repoType, ele => {
                return (
                  <Option value={ele.repoTypeId} key={ele.repoTypeId + Math.random()}>
                    {ele.repoTypeName}
                  </Option>
                );
              })}
            </Select>
          )}
        </FormItem>
        <FormItem label="代码库地址 :">
          {getFieldDecorator("repoUrl", {
            rules: Validation.Rule_url
          })(<Input maxLength={128} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("username", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("password", {
            rules: Validation.Rule_nochinese
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <FormItem label="组件：">
          {getFieldDecorator("applicationId", {
            rules: Validation.Rule_select
          })(
            <Select allowClear initialValue="请选择组件">
              {_.map(components, ele => {
                return (
                  <Option value={ele.applicationId} key={ele.applicationCode + Math.random()}>
                    {ele.applicationName}
                  </Option>
                );
              })}
            </Select>
          )}
        </FormItem>
        <FormItem label="分支使用策略：">
          {getFieldDecorator("branchPolicy", {
            initialValue: "tbd",
            rules: Validation.Rule_select
          })(
            <Select allowClear>
              <Option value="tbd">TBD</Option>
              <Option value="github-flow">Github-Flow</Option>
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class CodeRelation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updateVisible: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: ""
    };
    const { TextArea } = Input;
    this.columns = [
      {
        title: "名称",
        dataIndex: "repoName",
        render: (text, record) => this.renderColumns(text, record, "applicationName")
      },
      {
        title: "URL",
        dataIndex: "repoUrl",
        render: (text, record) => this.renderColumns(text, record, "repoUrl")
      },
      {
        title: "组件",
        dataIndex: "applicationName",
        render: (text, record) => this.renderColumns(text, record, "repoName")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.openRepostory(record);
                }}
                className="padright"
              >
                <span />
                进入代码库
              </a>
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定解除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  解除关联
                </a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.handleDelOk = this.handleDelOk.bind(this);
  }

  openRepostory(record) {
    const { openRepostory } = this.props;
    openRepostory(record);
  }

  componentWillReceiveProps(nextProps) {
    const { projectId, actions } = this.props;
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.saveStatus && nextProps.saveStatus === 1) {
      message.success("新增成功");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.saveStatus && nextProps.saveStatus === 2) {
      message.error("账号或者密码不正确");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.saveStatus && nextProps.saveStatus === 3) {
      message.error("代码库已存在");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.saveStatus && nextProps.saveStatus === 4) {
      message.error("组件已存在");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.saveStatus && nextProps.saveStatus === 5) {
      message.error("添加失败");
      actions.getRCComponentsList(projectId);
    }
    if (nextProps.updateStatus && nextProps.updateStatus === 1) {
      message.success("更新组件成功");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.updateStatus && nextProps.updateStatus === 2) {
      message.error("账号或者密码不正确");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.updateStatus && nextProps.updateStatus === 3) {
      message.error("组件已存在");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.updateStatus && nextProps.updateStatus === 4) {
      message.error("更新组件失败");
      actions.getRCComponentsList(projectId);
    }
    if (nextProps.delStatus && nextProps.delStatus === 1) {
      message.success("解除关联成功");
      actions.getRCComponentsList(projectId);
    } else if (nextProps.delStatus && nextProps.delStatus === 2) {
      message.error("解除关联失败");
      actions.getRCComponentsList(projectId);
    }
  }

  componentDidMount() {
    const { projectId, actions } = this.props;
    actions.getRepoType();
    actions.getComponentList(projectId);
    actions.getRCComponentsList(projectId);
  }

  componentDidUpdate() {}

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { searchItem } = this.state;
    const { actions } = this.props;
    this.setState({ loading: true });
    if (searchItem.name) {
      actions.getProjects(pagination.current, searchItem);
    } else {
      actions.getProjects(pagination.current);
    }
  }

  renderColumns(text, record, column) {
    return text;
  }

  handleDelOk(record) {
    const { actions } = this.props;
    const repoId = record.repoId;
    actions.delRCRelation(repoId);
  }

  handleChange(value) {}

  saveFormRef(form) {
    this.form = form;
  }

  saveUpdateFormRef(forms) {
    this.forms = forms;
  }

  // 点击修改弹框
  showEditModal(record) {
    // this.record = record;
    this.forms.setFieldsValue({
      repoTypeId: record.repoTypeId == 0 ? "gitlab" : "github",
      repoUrl: record.repoUrl,
      username: record.username,
      password: record.password,
      branchPolicy: record.branchPolicy,
      applicationId: record.applicationId
    });
    this.setState({
      updateVisible: true,
      updataData: {
        repoId: record.repoId,
        repoTypeId: record.repoTypeId
      }
    });
  }

  // update
  handleUpdataOk(e) {
    const forms = this.forms;
    const { projectId, actions } = this.props;
    const { updataData } = this.state;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.projectId = projectId;
      values.repoId = updataData.repoId;
      values.repoTypeId = updataData.repoTypeId;
      actions.updateRCRelation(values);
      this.setState({ updateVisible: false });
    });
  }

  search() {
    const { projectId, actions } = this.props;
    const searchValue = ReactDOM.findDOMNode(this.refs.codeName).value;
    if (searchValue == "") {
      actions.getRCComponentsList(projectId);
    } else {
      actions.searchRep({ projectId, searchValue });
    }
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  handleOk(e) {
    const { projectId, actions } = this.props;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.repoTypeId = "gitlab" ? "0" : "1";
      values.projectId = projectId;
      actions.saveRCComponent(values);
      this.setState({ visible: false });
    });
  }

  handleCancel(e) {
    this.forms.resetFields();
    this.form.resetFields();
    this.setState({
      visible: false,
      updateVisible: false
    });
  }

  render() {
    const { rcComponents, resTypes, components } = this.props;
    const { visible, updateVisible, pagination, loading } = this.state;
    if (rcComponents.length > 0) {
      rcComponents.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>代码名称:</span>
              <Input placeholder="请输入代码名称" style={{ width: "70%" }} ref="codeName" />
            </Col>
            <Col span={14} style={{ textAlign: "right" }}>
              <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: 10 }}>
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)}>
                新增
              </Button>
            </Col>
          </Row>
        </div>
        <NewForm
          ref={this.saveFormRef.bind(this)}
          visible={visible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.handleOk.bind(this)}
          repoType={resTypes}
          components={components}
        />
        <UpdateForm
          ref={this.saveUpdateFormRef.bind(this)}
          visible={updateVisible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.handleUpdataOk.bind(this)}
          components={components}
        />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={rcComponents}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resTypes: state.codeRelation.get("repoTypes"),
    components: state.codeRelation.get("components"),
    rcComponents: state.codeRelation.get("rcComponents"),
    delStatus: state.codeRelation.get("delStatus"),
    saveStatus: state.codeRelation.get("saveStatus"),
    updateStatus: state.codeRelation.get("updateStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeRelation);
