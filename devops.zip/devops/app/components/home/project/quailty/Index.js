import React from "react";
import { Row, Col, Card, Tabs, DatePicker } from "antd";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/ListProjects";
import ColumnLineChart from "../../../commons/ColumnChart/ColumnLineChart";
import ChooseType from "../../../commons/ChooseType/Index";

const TabPane = Tabs.TabPane;
class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  getValue() {}

  callback(key) {
    const { projectId, actions } = this.props;
    if (key == 1) {
      actions.getBuildstatement({
        projectId,
        code: 3
      });
    } else if (key == 2) {
      actions.getdeploystatement({
        projectId,
        code: 3
      });
    } else if (key == 3) {
      actions.getcodequality({
        projectId
      });
    }
  }

  signDateBuild(type) {
    const { projectId, actions } = this.props;
    actions.getBuildstatement({
      projectId,
      code: type
    });
  }

  signDateDeploy(type) {
    const { projectId, actions } = this.props;
    actions.getdeploystatement({
      projectId,
      code: type
    });
  }

  componentDidMount() {
    const { projectId, actions } = this.props;
    actions.getBuildstatement({
      projectId,
      code: 3
    });
    actions.getdeploystatement({
      projectId,
      code: 3
    });
    actions.getcodequality({
      projectId
    });
  }

  // 数据结构
  getEchartData(propsdata, lengend, xA, yA, codetype) {
    if (propsdata && propsdata.length > 0) {
      if (codetype == 1) {
        propsdata[0].time.map(result => {
          xA.push(result.substr(11, 2));
        });
      } else {
        propsdata[0].time.map(result => {
          xA.push(result);
        });
      }
      propsdata.map(item => {
        lengend.push(item.applicationName);
        const obj = {};
        obj.name = item.applicationName;
        obj.type = "bar";
        obj.stack = "haha";
        obj.data = item.successRate;
        yA.push(obj);
      });
    } else {
      lengend = [];
      xA = [];
      yA = [];
    }
  }

  // 质量标题
  getState(state) {
    return {
      bugs: "BUG",
      vulnerabilities: "漏洞",
      code_smells: "坏味道",
      duplicated_lines_density: "重复率"
    }[state];
  }

  render() {
    const { buildData, deployData, qualityData, buildcode, deploycode } = this.props;

    // 构建
    const buildlegend = [];
    const buildx = [];
    const buildy = [];
    this.getEchartData(buildData, buildlegend, buildx, buildy, buildcode);
    // 部署
    const deploylegend = [];
    const deployx = [];
    const deployy = [];
    this.getEchartData(deployData, deploylegend, deployx, deployy, deploycode);
    // 代码质量
    // qualityData数据
    let quailtylegend = [];
    let quailtyx = [];
    let quailtyy = [];
    // this.getEchartData(qualityData, quailtylegend, quailtyx, quailtyy, 2);
    if (qualityData && qualityData.length > 0) {
      qualityData[0].time.map(result => {
        quailtyx.push(result);
      });
      qualityData.map(item => {
        const lengendName = this.getState(item.applicationName);
        quailtylegend.push(lengendName);
        const obj = {};
        obj.name = lengendName;
        obj.type = "bar";
        obj.data = item.successRate;
        quailtyy.push(obj);
      });
    } else {
      quailtylegend = [];
      quailtyx = [];
      quailtyy = [];
    }

    return (
      <div>
        <Tabs
          defaultActiveKey="1"
          onChange={this.callback.bind(this)}
          type="card"
          tabPosition="left"
        >
          <TabPane tab="构建成功率" key="1">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card
                  title="构建成功率"
                  extra={<ChooseType signDate={this.signDateBuild.bind(this)} />}
                >
                  <ColumnLineChart
                    unit="单位/百分比"
                    height="60vh"
                    x={buildx}
                    y={buildy}
                    legendData={buildlegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab="部署成功率" key="2">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card
                  title="部署成功率"
                  extra={<ChooseType signDate={this.signDateDeploy.bind(this)} />}
                >
                  <ColumnLineChart
                    unit="单位/百分比"
                    height="60vh"
                    x={deployx}
                    y={deployy}
                    legendData={deploylegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab="代码质量分析" key="3">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card title="代码质量分析">
                  <ColumnLineChart
                    unit="单位/个"
                    height="60vh"
                    x={quailtyx}
                    y={quailtyy}
                    legendData={quailtylegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    buildData: state.listProjects.get("buildData"),
    deployData: state.listProjects.get("deployData"),
    qualityData: state.listProjects.get("qualityData"),
    commitData: state.listProjects.get("commitData"),

    buildcode: state.listProjects.get("buildcode"),
    deploycode: state.listProjects.get("deploycode"),
    qualitycode: state.listProjects.get("qualitycode")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Index);
