import React from "react";
import "./overview.css";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Carousel } from "antd";
import moment from "moment";
import TimeChange from "../../../commons/Borad/TimeChange/TimeChange";
import PieChart from "../../../commons/Borad/PieChart";
import ColumndashChart from "../../../commons/Borad/ColumndashChart";
import ColumnChart from "../../../commons/Borad/ColumnChart";
import CardItem from "../../../commons/Borad/CardItem";
import CardPie from "../../../commons/Borad/CardPie";
import CardRing from "../../../commons/Borad/CardRing";
import CardBar from "../../../commons/Borad/CardBar";
import CardLine from "../../../commons/Borad/CardLine";
import * as projectAction from "../../../../actions/ListProjects";
import CardArea from "../../../commons/Borad/CardArea";

class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "200",
      thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,
      // thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,

      thissDate: `${moment(new Date())
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    };
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    const mouthstart = `${moment()
      .add("month", 0)
      .format("YYYY-MM")}-01 00:00:00`;
    const mouthend = `${moment(mouthstart)
      .add("month", 1)
      .add("days", -1)
      .format("YYYY-MM-DD")} 23:59:59`;
    const todaystart = `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`;
    const todayend = `${moment(new Date())
      .add("days", 1)
      .format("YYYY-MM-DD")} 00:00:00`;
    actions.getProjectsOvewview({
      projectId,
      date: todaystart,
      sDate: todayend
    });
    actions.getProjectsbuildtop({
      projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsdeploytop({
      projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsRate({ projectId });
  }

  query(Date, type) {
    const { actions, projectId } = this.props;
    actions.getProjectsbuildtop({
      projectId,
      dataJson: {
        type,
        start: moment(Date[0]).format("YYYY-MM-DD HH:mm:ss"),
        end: moment(Date[1]).format("YYYY-MM-DD HH:mm:ss")
      }
    });
  }

  deploytop(Date, type) {
    const { actions, projectId } = this.props;
    actions.getProjectsdeploytop({
      projectId,
      dataJson: {
        type,
        start: moment(Date[0]).format("YYYY-MM-DD HH:mm:ss"),
        end: moment(Date[1]).format("YYYY-MM-DD HH:mm:ss")
      }
    });
  }

  // 单选日期1
  onChangeDate(date, dateString) {
    const { actions, projectId } = this.props;
    this.setState({
      thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,
      thissDate: `${moment(new Date())
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    });
    actions.getProjectsOvewview({
      projectId,
      date: `${moment(date).format("YYYY-MM-DD")} 00:00:00`,
      sDate: `${moment(date)
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    });
  }

  // 构建选择1
  builddbDate(Date) {
    const type = "self";
    this.query(Date, type);
  }

  // 构建点击
  buildsignDate(Date, type) {
    this.query(Date, type);
  }

  deploydbDate(Date) {
    const type = "self";
    this.deploytop(Date, type);
  }

  deploysignDate(Date, type) {
    this.deploytop(Date, type);
  }

  render() {
    const topColResponsiveProps = {
      xs: 24,
      sm: 24,
      md: 12,
      lg: 12,
      xl: 12
    };
    const { topData, topbuildData, resData, rateData, projectName } = this.props;
    if (topData == undefined || topData.rtn_code == "-1") {
      return false;
    }
    if (topbuildData == undefined || topbuildData.rtn_code == "-1") {
      return false;
    }
    // 构建Top5
    const buildx = [];
    const buildy = [];
    if (topbuildData && topbuildData.length > 0) {
      topbuildData.map(item => {
        if (item.type == "today") {
          // buildx.push(item.hours + "点");
          buildx.push(`${item.hours}点`);
        } else {
          // buildx.push(item.days + "日");
          buildx.push(`${item.days}日`);
        }
        buildy.push((item.durationTime / 1000).toFixed(0));
      });
    }
    // 部署Top5
    const deployx = [];
    const deployy = [];
    if (topData && topData.length > 0) {
      topData.map(item => {
        if (item.type == "today") {
          // deployx.push(item.hours + "点");
          deployx.push(`${item.hours}点`);
        } else {
          // deployx.push(item.days + "日");
          deployx.push(`${item.days}日`);
        }
        deployy.push((item.durationTime / 1000).toFixed(0));
      });
    }
    const vms = [{ value: 15, name: "当前迭代" }, { value: 23, name: "总迭代数" }];
    const stories = [{ value: 25, name: "总迭代故事" }, { value: 20, name: "当前已完成" }];
    const bugs = [{ value: 55, name: "总Bug" }, { value: 23, name: "已关闭" }];
    const yongli = [{ value: 55, name: "总用例" }, { value: 23, name: "总迭已通过" }];
    return (
      <div
        id="Main"
        style={{
          width: this.props.width ? this.props.width : "calc(100vw - 250px)",
          backgroundColor: "#172a6a"
        }}
      >
        <Row>
          <Col>
            <span style={{ fontSize: 16, color: "#fff", marginLeft: 10 }}>
              项目名称：
              {projectName}
            </span>
          </Col>
        </Row>
        <Row>
          <Col span={24}>
            <Card style={{ height: 160, backgroundColor: "#172a6a" }}>
              {/* dots={false} autoplay */}
              <Carousel effect="fade" dots={false} autoplay>
                <div>
                  <Row>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardItem
                        title="组件数量(个)"
                        count={65}
                        colors={["#473ac5", "#7a80f1"]}
                        picUrl="/images/bigScreen/component.png"
                        backgroundImg="/images/bigScreen/01.png"
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardItem
                        title="运行组件实例数"
                        count={43}
                        colors={["#ef7f3e", "#ffc35e"]}
                        picUrl="/images/bigScreen/run_instance.png"
                        backgroundImg="/images/bigScreen/02.png"
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardLine
                        title="构建次数"
                        count={65}
                        colors={["#297bfb", "#7aacfa"]}
                        picUrl="/images/bigScreen/build.png"
                        backgroundImg="/images/bigScreen/03.png"
                        x={buildx}
                        y={buildy}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardArea
                        title="部署次数"
                        count={178}
                        colors={["#30ca75", "#84e9bf"]}
                        picUrl="/images/bigScreen/deploy.png"
                        backgroundImg="/images/bigScreen/04.png"
                        x={buildx}
                        y={buildy}
                      />
                    </Col>
                  </Row>
                </div>
                <div style={{ paddingTop: 30 }}>
                  <Row>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardItem
                        count={65}
                        title="项目成员(个)"
                        colors={["#297bfb", "#7aacfa"]}
                        picUrl="/images/bigScreen/member.png"
                        backgroundImg="/images/bigScreen/05.png"
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardPie
                        colors={["#f86b6b", "#fa9f9f"]}
                        backgroundImg="/images/bigScreen/06.png"
                        value={vms}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardItem
                        count={65}
                        title="关联仓库数"
                        colors={["#7c55fc", "#a890f4"]}
                        picUrl="/images/bigScreen/library.png"
                        backgroundImg="/images/bigScreen/07.png"
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardBar
                        title="代码行数"
                        count={6535}
                        colors={["#ffc106", "#f0e0b0"]}
                        backgroundImg="/images/bigScreen/08.png"
                        x={buildx}
                        y={buildy}
                      />
                    </Col>
                  </Row>
                </div>
                <div>
                  <Row>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardRing
                        count={65}
                        colors={["#ef7f3e", "#ffc35e"]}
                        backgroundImg="/images/bigScreen/09.png"
                        value={vms}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardRing
                        colors={["#30ca75", "#5ddaac"]}
                        backgroundImg="/images/bigScreen/10.png"
                        value={stories}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardPie
                        colors={["#f86b6b", "#fa9f9f"]}
                        backgroundImg="/images/bigScreen/11.png"
                        value={bugs}
                      />
                    </Col>
                    <Col xs={12} sm={12} md={12} lg={12} xxl={6} xl={6}>
                      <CardRing
                        colors={["#297bfb", "#7aacfa"]}
                        backgroundImg="/images/bigScreen/12.png"
                        value={yongli}
                      />
                    </Col>
                  </Row>
                </div>
              </Carousel>
            </Card>
          </Col>
        </Row>
        <Row gutter={20}>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ paddingLeft: 15 }}>
            <Card
              style={{ backgroundColor: "#24397e", borderRadius: 8, border: "0px", height: "46vh" }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "10px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "center",
                  lineHeight: 1
                }}
              >
                构建时长趋势TOP5
              </div>
              <Row>
                <TimeChange
                  signDate={this.buildsignDate.bind(this)}
                  dbDate={this.builddbDate.bind(this)}
                />
                <Col span={24}>
                  <ColumndashChart height="37vh" x={buildx} y={buildy} />
                </Col>
              </Row>
            </Card>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ paddingRight: 15 }}>
            <Card
              style={{ backgroundColor: "#24397e", borderRadius: 8, border: "0px", height: "46vh" }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "10px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "center",
                  lineHeight: 1
                }}
              >
                部署时长趋势TOP5
              </div>
              <Row>
                <TimeChange
                  signDate={this.deploysignDate.bind(this)}
                  dbDate={this.deploydbDate.bind(this)}
                />
                <Col span={24}>
                  <ColumnChart height="37vh" x={deployx} y={deployy} />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
        {/* 饼图 */}
        <Row gutter={20} style={{ marginTop: 10 }}>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ paddingLeft: 15 }}>
            <Card
              style={{ backgroundColor: "#24397e", borderRadius: 8, border: "0px", height: "20vh" }}
            >
              <div
                style={{
                  color: "#fff",
                  marginLeft: "10px",
                  width: "90px",
                  borderLeft: "3px solid",
                  textAlign: "center",
                  lineHeight: 1
                }}
              >
                构建成功率
              </div>
              <PieChart
                height="150px"
                Times={rateData && rateData.buildInfo ? rateData.buildInfo : {}}
              />
            </Card>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24} style={{ paddingRight: 15 }}>
            <Card
              style={{ backgroundColor: "#24397e", borderRadius: 8, border: "0px", height: "20vh" }}
            >
              <div
                style={{
                  color: "#fff",
                  marginLeft: "10px",
                  width: "90px",
                  borderLeft: "3px solid",
                  textAlign: "center",
                  lineHeight: 1
                }}
              >
                部署成功率
              </div>
              <PieChart
                height="150px"
                Times={rateData && rateData.depolyInfo ? rateData.depolyInfo : {}}
              />
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.listProjects.get("resData"),
    topData: state.listProjects.get("topData"),
    topbuildData: state.listProjects.get("topbuildData"),
    rateData: state.listProjects.get("rateData"),
    instanceNum: state.listProjects.get("instanceNum")
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(projectAction, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Main);
