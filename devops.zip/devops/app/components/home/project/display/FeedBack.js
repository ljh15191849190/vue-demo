import React from "react";
import "./overview.css";
import "./FeedBack.css";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Carousel, Divider, Dropdown, Icon, Menu, Button, Table } from "antd";

import * as projectAction from "../../../../actions/ListProjects";
import PieChart from "../../../commons/Borad/PieChart";

import FeedBackPieChart from "../../../commons/Borad/feedBackPieChart";
import LineAreaStyle from "../../../commons/Borad/lineAreaStyle";
import LineSetInterval from "../../../commons/Borad/lineSetInterval";
import ColumnSetInterval from "../../../commons/Borad/columnSetInterval";

import Test1 from "../../../commons/test1";
import LineCharts from "../../../commons/Borad/LineCharts";
import LineAreaDoubleCharts from "../../../commons/Borad/LineAreaDoubleCharts";

class FeedBack extends React.Component {
  constructor(props) {
    super(props);
    this.state = { loading: false };
    this.renderColumns = this.renderColumns.bind(this);
    this.columns = [
      {
        title: "提交人",
        align: "center",
        dataIndex: "pushName",
        width: "50%",
        render: (text, record) => this.renderColumns(text, record, "pushName")
      },
      {
        title: "提交次数",
        align: "center",
        dataIndex: "pushValue",
        width: "50%",
        render: (text, record) => this.renderColumns(text, record, "pushValue")
      }
    ];
  }
  // 生命周期开始
  componentDidMount() {}
  componentWillReceiveProps() {}
  // 生命周期结束
  // 实例方法开始
  // 实例方法结束
  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  render() {
    const { projectName } = this.props;
    const { loading } = this.state;
    const resData = [
      { pushName: "魏晓悦", pushValue: 89 },
      { pushName: "李京豪", pushValue: 85 },
      { pushName: "王智", pushValue: 83 }
    ];
    const menu = (
      <Menu>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="##">
            迭代一
          </a>
        </Menu.Item>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="##">
            迭代二
          </a>
        </Menu.Item>
        <Menu.Item>
          <a target="_blank" rel="noopener noreferrer" href="##">
            迭代三
          </a>
        </Menu.Item>
      </Menu>
    );
    return (
      <div
        id="feedBack"
        style={{
          width: this.props.width ? this.props.width : "calc(100vw - 250px)",
          backgroundColor: "#172a6a",
          padding: "0 18px 0px 0",
          marginBottom: "10px"
        }}
      >
        <Row
          type="flex"
          gutter={3}
          style={{ fontSize: 16, color: "#fff", marginLeft: 5, marginBottom: 10 }}
          justify="space-between"
        >
          <Col span={5}>
            项目名称：
            {projectName}
          </Col>
          <Col span={8}>迭代周期：2018年12月03日-2018年12月09日</Col>
          <Col span={3}>
            <Dropdown overlay={menu}>
              <Button style={{ backgroundColor: "#24397e", borderColor: "#24397e", color: "#fff" }}>
                迭代一 <Icon type="down" />
              </Button>
            </Dropdown>
          </Col>
          <Col span={8} style={{ textAlign: "right", paddingRight: "5px" }}>
            最后更新时间：2018年12月09日
          </Col>
        </Row>
        <Row gutter={10} type="flex" justify="space-around" style={{ marginBottom: 20 }}>
          <Col xxl={9} xl={9} lg={9} md={24} sm={24} xs={24}>
            <Card
              style={{
                backgroundColor: "#24397e",
                margin: 0,
                padding: 0,
                borderRadius: 8,
                border: "0px"
              }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "20px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "left",
                  paddingLeft: 10,
                  lineHeight: 1
                }}
              >
                需求
              </div>
              <p style={{ height: "1px", backgroundColor: "#6777a8" }} />
              <Row gutter={10} type="flex" justify="space-between" style={{}}>
                <Col xxl={16} xl={16} lg={16} md={16} sm={16} xs={16}>
                  <h4
                    style={{
                      lineHeight: "20px",
                      textAlign: "left",
                      fontSize: "14px",
                      color: "#8bebf9",
                      margin: 0,
                      padding: "10px 20px"
                    }}
                  >
                    数量统计
                  </h4>
                  <FeedBackPieChart height="150px" typeData="dataJsonComplete" />
                </Col>
                <Col xxl={8} xl={8} lg={8} md={8} sm={8} xs={8}>
                  <div style={{ padding: "0 20px 0 0" }}>
                    <h4
                      style={{
                        lineHeight: "20px",
                        padding: "10px 0",
                        textAlign: "left",
                        fontSize: "14px",
                        color: "#8bebf9",
                        margin: 0
                      }}
                    >
                      耗费工时
                    </h4>
                    <div
                      style={{
                        borderRadius: "4px",
                        marginBottom: "20px",
                        backgroundColor: "rgba(255,255,255,0.2)"
                      }}
                    >
                      <p
                        style={{
                          textAlign: "center",
                          fontSize: "20px",
                          padding: "5px 0 0",
                          color: "#a3c0fc",
                          margin: 0
                        }}
                      >
                        <span style={{ textAlign: "center", fontSize: "20px", color: "#a3c0fc" }}>
                          235
                        </span>
                        <span style={{ textAlign: "center", fontSize: "18px", color: "#a3c0fc" }}>
                          h
                        </span>
                      </p>
                      <p
                        style={{
                          textAlign: "center",
                          fontSize: "16px",
                          color: "#fff",
                          padding: "0px 0px 10px"
                        }}
                      >
                        <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                          总预估时间
                        </span>
                      </p>
                    </div>
                    <div
                      style={{
                        borderRadius: "4px",
                        marginBottom: "20px",
                        backgroundColor: "rgba(255,255,255,0.2)"
                      }}
                    >
                      <p
                        style={{
                          textAlign: "center",
                          fontSize: "20px",
                          padding: "5px 0 0",
                          color: "#a3c0fc",
                          margin: 0
                        }}
                      >
                        <span
                          style={{
                            textAlign: "center",
                            padding: "16px, 0",
                            fontSize: "20px",
                            color: "#fa9797"
                          }}
                        >
                          235
                        </span>
                        <span style={{ textAlign: "center", fontSize: "18px", color: "#fa9797" }}>
                          h
                        </span>
                      </p>
                      <p
                        style={{
                          textAlign: "center",
                          fontSize: "16px",
                          color: "#fff",
                          padding: "0px 0px 10px"
                        }}
                      >
                        <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                          已使用时间
                        </span>
                      </p>
                    </div>
                  </div>
                </Col>
              </Row>
              <Row gutter={10} type="flex" justify="space-between" style={{ width: "100%" }}>
                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                  <div>
                    <LineAreaStyle height="200px" />
                  </div>
                </Col>
              </Row>
            </Card>
          </Col>
          <Col xxl={9} xl={9} lg={9} md={24} sm={24} xs={24}>
            <Card
              style={{
                backgroundColor: "#24397e",
                margin: 0,
                padding: 0,
                borderRadius: 8,
                border: "0px"
              }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "20px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "left",
                  paddingLeft: 10,
                  lineHeight: 1
                }}
              >
                缺陷
              </div>
              <p style={{ height: "1px", backgroundColor: "#6777a8" }} />
              <Row gutter={10} type="flex" justify="space-between" style={{}}>
                <Col xxl={15} xl={15} lg={15} md={15} sm={15} xs={15}>
                  <h4
                    style={{
                      lineHeight: "20px",
                      textAlign: "left",
                      fontSize: "14px",
                      color: "#8bebf9",
                      margin: 0,
                      padding: "10px 20px"
                    }}
                  >
                    数量统计
                  </h4>
                  <FeedBackPieChart height="150px" typeData="dataJsonDefective" />
                </Col>
                <Col xxl={9} xl={9} lg={9} md={9} sm={9} xs={9}>
                  <div style={{ padding: "0 20px 0 0" }}>
                    <h4
                      style={{
                        lineHeight: "20px",
                        padding: "10px 0",
                        textAlign: "left",
                        fontSize: "14px",
                        color: "#8bebf9",
                        margin: 0
                      }}
                    >
                      解决效率
                    </h4>
                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <div
                        style={{
                          flex: 1,
                          marginRight: "5px",
                          borderRadius: "4px",
                          marginBottom: "20px",
                          backgroundColor: "rgba(255,255,255,0.2)"
                        }}
                      >
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "20px",
                            padding: "5px 0 0",
                            color: "#a3c0fc",
                            margin: 0
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "20px", color: "#a3c0fc" }}>
                            235
                          </span>
                          <span style={{ textAlign: "center", fontSize: "18px", color: "#a3c0fc" }}>
                            h
                          </span>
                        </p>
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "16px",
                            color: "#fff",
                            padding: "0px 0px 10px"
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                            总预估时间
                          </span>
                        </p>
                      </div>
                      <div
                        style={{
                          flex: 1,
                          marginLeft: "5px",
                          borderRadius: "4px",
                          marginBottom: "20px",
                          backgroundColor: "rgba(255,255,255,0.2)"
                        }}
                      >
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "20px",
                            padding: "5px 0 0",
                            color: "#a3c0fc",
                            margin: 0
                          }}
                        >
                          <span
                            style={{
                              textAlign: "center",
                              padding: "16px, 0",
                              fontSize: "20px",
                              color: "#fcbd4d"
                            }}
                          >
                            235
                          </span>
                          <span style={{ textAlign: "center", fontSize: "18px", color: "#fcbd4d" }}>
                            h
                          </span>
                        </p>
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "16px",
                            color: "#fff",
                            padding: "0px 0px 10px"
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                            实际解决时间
                          </span>
                        </p>
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "row" }}>
                      <div
                        style={{
                          flex: 1,
                          marginRight: "5px",
                          borderRadius: "4px",
                          marginBottom: "20px",
                          backgroundColor: "rgba(255,255,255,0.2)"
                        }}
                      >
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "20px",
                            padding: "5px 0 0",
                            color: "#a3c0fc",
                            margin: 0
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "20px", color: "#2ef5c4" }}>
                            2.5
                          </span>
                          <span style={{ textAlign: "center", fontSize: "18px", color: "#2ef5c4" }}>
                            h
                          </span>
                        </p>
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "16px",
                            color: "#fff",
                            padding: "0px 0px 10px"
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                            平均解决时间
                          </span>
                        </p>
                      </div>
                      <div
                        style={{
                          flex: 1,
                          marginLeft: "5px",
                          borderRadius: "4px",
                          marginBottom: "20px",
                          backgroundColor: "rgba(255,255,255,0.2)"
                        }}
                      >
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "20px",
                            padding: "5px 0 0",
                            color: "#a3c0fc",
                            margin: 0
                          }}
                        >
                          <span
                            style={{
                              textAlign: "center",
                              padding: "16px, 0",
                              fontSize: "20px",
                              color: "#fa9797"
                            }}
                          >
                            9.8%
                          </span>
                          {/* <span style={{ textAlign: "center", fontSize: "18px", color: "#fa9797" }}>
                            h
                          </span> */}
                        </p>
                        <p
                          style={{
                            textAlign: "center",
                            fontSize: "16px",
                            color: "#fff",
                            padding: "0px 0px 10px"
                          }}
                        >
                          <span style={{ textAlign: "center", fontSize: "14px", color: "#fff" }}>
                            严重缺陷占比
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
              <Row type="flex" justify="space-between" style={{ width: "100%" }}>
                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                  <div>
                    <ColumnSetInterval height="200px" />
                  </div>
                </Col>
              </Row>
            </Card>
          </Col>
          <Col xxl={6} xl={6} lg={6} md={24} sm={24} xs={24}>
            <Card
              style={{
                backgroundColor: "#24397e",
                margin: 0,
                padding: 0,
                borderRadius: 8,
                border: "0px"
              }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "20px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "left",
                  paddingLeft: 10,
                  lineHeight: 1
                }}
              >
                代码
              </div>
              <p style={{ height: "1px", backgroundColor: "#6777a8" }} />
              <Row type="flex" justify="space-between" style={{ width: "100%" }}>
                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                  <div>
                    <LineSetInterval height="200px" />
                  </div>
                </Col>
              </Row>
              <Row type="flex" justify="space-between" style={{ width: "100%" }}>
                <Col xxl={24} xl={24} lg={24} md={24} sm={24} xs={24}>
                  <div
                    style={{
                      paddingBottom: "5px"
                    }}
                  >
                    <h4
                      style={{
                        lineHeight: "18px",
                        textAlign: "left",
                        fontSize: "14px",
                        color: "#8bebf9",
                        padding: "1px 20px 12px",
                        margin: 0
                      }}
                    >
                      TOP3提交人
                    </h4>
                    <div style={{ width: "100%", padding: "0 20px" }}>
                      <p
                        style={{
                          lineHeight: "40px",
                          display: "flex",
                          flexDirection: "row",
                          color: "#ccc",
                          background: "rgba(135,235, 249, 0.25)"
                        }}
                      >
                        <span style={{ display: "flex", flex: 1, justifyContent: "center" }}>
                          提交人
                        </span>
                        <span style={{ display: "flex", flex: 1, justifyContent: "center" }}>
                          提交次数
                        </span>
                      </p>
                      {resData.map((item, index) => {
                        return (
                          <p
                            key={index}
                            style={{
                              lineHeight: "40px",
                              display: "flex",
                              flexDirection: "row",
                              color: "#ccc",
                              borderBottom: "1px solid rgba(135,235, 249, 0.25)"
                            }}
                          >
                            <span style={{ display: "flex", flex: 1, justifyContent: "center" }}>
                              {item.pushName}
                            </span>
                            <span style={{ display: "flex", flex: 1, justifyContent: "center" }}>
                              {item.pushValue}
                            </span>
                          </p>
                        );
                      })}
                    </div>
                  </div>
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
        <Row
          style={{
            flexWrap: "nowrap",
            height: "140px",
            marginTop: "20px",
            marginBottom: "10px"
          }}
          type="flex"
          justify="space-around"
        >
          {/* <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24} offset={2}> */}
          <Col
            className="card1"
            style={{
              backgroundColor: "#172a6a",
              border: "0px",
              margin: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff"
            }}
          >
            <div>
              <span>团队速率</span>
              <span style={{ fontSize: "24px", marginLeft: "24px" }}>1.7</span>
            </div>
          </Col>
          {/* <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}> */}
          <Col
            className="card2"
            style={{
              backgroundColor: "#172a6a",
              border: "0px",
              margin: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff"
            }}
          >
            <div>
              <span>耗费工时(人天)</span>
              <span style={{ fontSize: "24px", marginLeft: "24px" }}>167</span>
            </div>
          </Col>
          <Col
            className="card3"
            style={{
              backgroundColor: "#172a6a",
              border: "0px",
              margin: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff"
            }}
          >
            <div>
              <span>构建成功率</span>
              <span style={{ fontSize: "24px", marginLeft: "24px" }}>80%</span>
            </div>
          </Col>
          <Col
            className="card4"
            style={{
              backgroundColor: "#172a6a",
              border: "0px",
              margin: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff"
            }}
          >
            <div>
              <span>部署成功率</span>
              <span style={{ fontSize: "24px", marginLeft: "24px" }}>72%</span>
            </div>
          </Col>
          {/* <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}> */}
          <Col
            className="card5"
            style={{
              backgroundColor: "#172a6a",
              border: "0px",
              margin: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff"
            }}
          >
            <div>
              <span>遗留DI值</span>
              <span style={{ fontSize: "24px", marginLeft: "24px" }}>12</span>
            </div>
          </Col>
        </Row>
        <Row gutter={30}>
          <Col xxl={14} xl={14} lg={14} md={24} sm={24} xs={24}>
            <Card style={{ backgroundColor: "#24397e", borderRadius: 8, border: "0px", margin: 0 }}>
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "10px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "left",
                  padding: "0 0 0 10px",
                  lineHeight: 1
                }}
              >
                构建与部署
              </div>
              <p style={{ height: "1px", backgroundColor: "#6777a8" }} />
              <Row>
                <Col xxl={20} xl={20} lg={20} md={24} sm={24} xs={24} style={{ height: "100%" }}>
                  <Row style={{ padding: "0 10px 0 18px" }}>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <Card
                        style={{
                          backgroundColor: "#2f427f",
                          borderRadius: 3,
                          border: "0px",
                          color: "#fff",
                          textAlign: "center",
                          fontSize: "16px"
                        }}
                      >
                        <Row>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>116</div>
                            <div style={{ fontSize: "13px" }}>构建数量</div>
                          </Col>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>56</div>
                            <div style={{ fontSize: "13px" }}>构建次数</div>
                          </Col>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>80</div>
                            <div style={{ fontSize: "13px" }}>构建频率</div>
                          </Col>
                        </Row>
                      </Card>
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <Card
                        style={{
                          backgroundColor: "#2f427f",
                          borderRadius: 3,
                          border: "0px",
                          color: "#fff",
                          textAlign: "center",
                          fontSize: "16px"
                        }}
                      >
                        <Row>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>96</div>
                            <div style={{ fontSize: "13px" }}>部署数量</div>
                          </Col>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>50</div>
                            <div style={{ fontSize: "13px" }}>部署次数</div>
                          </Col>
                          <Col span={8}>
                            <div style={{ color: "#a3c0fc", fontSize: "24px" }}>78</div>
                            <div style={{ fontSize: "13px" }}>部署频率</div>
                          </Col>
                        </Row>
                      </Card>
                    </Col>
                  </Row>
                  <Row gutter={20} style={{ padding: "0 20px 0 30px" }}>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <LineCharts
                        width="370px"
                        height="170px"
                        text="平均构建时长/秒"
                        Linecolor={{ topColor: "#93ec8d", bottomColor: "#1cb19a" }}
                      />
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <LineCharts
                        width="370px"
                        height="170px"
                        text="平均部署时长/秒"
                        Linecolor={{ topColor: "#8b9dfb", bottomColor: "#53aefc" }}
                      />
                    </Col>
                  </Row>
                  <Row gutter={20} style={{ padding: "0 20px 0 30px" }}>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <LineAreaDoubleCharts
                        width="370px"
                        height="170px"
                        text="平均构建次数/成功率"
                        Linecolor={{ topColor: "#ffff9d", bottomColor: "#daa51d" }}
                      />
                    </Col>
                    <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
                      <LineAreaDoubleCharts
                        width="370px"
                        height="170px"
                        text="平均部署次数/秒"
                        Linecolor={{ topColor: "#fa9f9f", bottomColor: "#f86b6b" }}
                      />
                    </Col>
                  </Row>
                </Col>
                <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}>
                  <Card
                    style={{
                      backgroundColor: "#2f427f",
                      borderRadius: 2,
                      border: "0px",
                      color: "#fff",
                      textAlign: "center",
                      paddingBottom: "10px"
                    }}
                  >
                    <Row>
                      <Col xxl={24} xl={24} lg={24} md={6} sm={6} xs={6}>
                        <div style={{ color: "#a3c0fc", fontSize: "24px" }}>
                          <img src="/images/bigScreen/pipelineAccount.png" alt="" />
                        </div>
                        <div style={{ fontSize: "13px", marginTop: "12px" }}>流水线数量</div>
                        <div style={{ color: "#8addfc", fontSize: "18px" }}>18</div>
                      </Col>
                      <Col xxl={24} xl={24} lg={24} md={6} sm={6} xs={6}>
                        <div style={{ color: "#a3c0fc", fontSize: "24px" }}>
                          <img src="/images/bigScreen/pipelineTimes.png" alt="" />
                        </div>
                        <div style={{ fontSize: "13px", marginTop: "12px" }}>流水线次数</div>
                        <div style={{ color: "#8addfc", fontSize: "18px" }}>18</div>
                      </Col>
                      <Col xxl={24} xl={24} lg={24} md={6} sm={6} xs={6}>
                        <div style={{ color: "#a3c0fc", fontSize: "20px" }}>
                          <img src="/images/bigScreen/pipelineFrequency.png" alt="" />
                        </div>
                        <div style={{ fontSize: "13px", marginTop: "12px" }}>流水线频率</div>
                        <div style={{ color: "#8addfc", fontSize: "18px" }}>1.8</div>
                      </Col>
                      <Col xxl={24} xl={24} lg={24} md={6} sm={6} xs={6}>
                        <div style={{ color: "#a3c0fc", fontSize: "24px" }}>
                          <img src="/images/bigScreen/pipelineAvgTime.png" alt="" />
                        </div>
                        <div style={{ fontSize: "13px", marginTop: "12px" }}>流水平均时长</div>
                        <div style={{ color: "#8addfc", fontSize: "18px" }}>10min</div>
                      </Col>
                    </Row>
                  </Card>
                </Col>
              </Row>
            </Card>
          </Col>
          <Col
            xxl={10}
            xl={10}
            lg={10}
            md={24}
            sm={24}
            xs={24}
            style={{ height: "100%", paddingRight: "20px" }}
          >
            <Card
              style={{
                backgroundColor: "#24397e",
                borderRadius: 8,
                border: "0px",
                color: "#fff",
                margin: 0
              }}
            >
              <div
                style={{
                  marginBottom: 10,
                  color: "#fff",
                  marginLeft: "10px",
                  width: "140px",
                  borderLeft: "3px solid",
                  textAlign: "left",
                  paddingLeft: 10,
                  lineHeight: 1
                }}
              >
                质量
              </div>
              <p style={{ height: "1px", backgroundColor: "#6777a8" }} />
              <Row
                style={{
                  padding: "20px 26px 20px 20px",
                  borderBottom: "1px solid rgba(255,255,255,0.15)"
                }}
              >
                <Row type="flex" style={{ color: "#fff", fontSize: "13px", marginTop: "10px" }}>
                  <Col span={18}>
                    <span style={{ color: "#8bf9e6" }}>代码质量</span>
                    <span style={{ marginLeft: "20px" }}>(最后一次分析：2019-01-22 17:55:12)</span>
                  </Col>
                  <Col span={6} style={{ textAlign: "right", color: "#8bf9e6" }}>
                    更多
                  </Col>
                </Row>
                <Row
                  type="flex"
                  style={{
                    marginTop: "40px",
                    marginBottom: "38px",
                    fontSize: "13px",
                    textAlign: "center"
                  }}
                >
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/inSum.png" alt="" />
                    </div>
                    <div>总计</div>
                    <div style={{ color: "#8addfc", fontSize: "24px" }}>7.7K</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/repetitionRate.png" alt="" />
                    </div>
                    <div>重复率</div>
                    <div style={{ color: "#8addfc", fontSize: "24px" }}>18%</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/coverageRate.png" alt="" />
                    </div>
                    <div>覆盖率</div>
                    <div style={{ color: "#8addfc", fontSize: "24px" }}>60%</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/Bugs.png" alt="" />
                    </div>
                    <div>Bugs</div>
                    <div style={{ color: "#fa9797", fontSize: "24px" }}>10</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/leaks.png" alt="" />
                    </div>
                    <div>漏洞</div>
                    <div style={{ color: "#fbc25c", fontSize: "24px" }}>8</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/badTaste.png" alt="" />
                    </div>
                    <div>坏味道</div>
                    <div style={{ color: "#fa9797", fontSize: "24px" }}>11</div>
                  </Col>
                </Row>
              </Row>
              <Row style={{ padding: "20px 26px 20px 20px" }}>
                <Row type="flex" style={{ color: "#fff", fontSize: "13px" }}>
                  <Col span={18}>
                    <span style={{ color: "#8bf9e6" }}>自动化测试</span>
                    <span style={{ marginLeft: "20px" }}>(最后一次分析：2019-01-22 17:55:12)</span>
                  </Col>
                  <Col span={6} style={{ textAlign: "right", color: "#8bf9e6" }}>
                    更多
                  </Col>
                </Row>
                <Row
                  type="flex"
                  style={{
                    marginTop: "29px",
                    marginBottom: "28px",
                    fontSize: "13px",
                    textAlign: "center"
                  }}
                >
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/inSum.png" alt="" />
                    </div>
                    <div>总计</div>
                    <div style={{ color: "#8addfc", fontSize: "24px" }}>190</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/executeTime.png" alt="" />
                    </div>
                    <div>执行时间</div>
                    <div style={{ color: "#8addfc", fontSize: "24px" }}>30min</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/passRate.png" alt="" />
                    </div>
                    <div>通过率</div>
                    <div style={{ color: "#2decc0", fontSize: "24px" }}>83%</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/pass.png" alt="" />
                    </div>
                    <div>通过</div>
                    <div style={{ color: "#2decc0", fontSize: "24px" }}>70</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/failure.png" alt="" />
                    </div>
                    <div>失败</div>
                    <div style={{ color: "#fa9797", fontSize: "24px" }}>12</div>
                  </Col>
                  <Col span={4}>
                    <div style={{ marginBottom: "12px" }}>
                      <img src="/images/bigScreen/error.png" alt="" />
                    </div>
                    <div>错误</div>
                    <div style={{ color: "#fa9797", fontSize: "24px" }}>6</div>
                  </Col>
                </Row>
              </Row>
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.listProjects.get("resData"),
    topData: state.listProjects.get("topData"),
    topbuildData: state.listProjects.get("topbuildData"),
    rateData: state.listProjects.get("rateData"),
    instanceNum: state.listProjects.get("instanceNum")
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(projectAction, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(FeedBack);
