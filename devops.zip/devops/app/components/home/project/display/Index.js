import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
import * as action from "../../../../actions/ListProjects";
import ColumnLineChart from "../../../commons/ColumnChart/ColumnLineChart";
import "./Index.css";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.colors = ["#05BFF1", "#FF6347"];
  }
  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getBuildstatement({
      projectId,
      code: 2
    });
    actions.getdeploystatement({
      projectId,
      code: 2
    });
    actions.getcodeCommit({
      projectId,
      code: 2
    });
  }

  getEchartData(propsdata, lengend, xA, yA, codetype) {
    if (propsdata && propsdata.length > 0) {
      if (codetype == 1) {
        propsdata[0].time.map(result => {
          xA.push(result.substr(11, 2));
        });
      } else {
        propsdata[0].time.map(result => {
          xA.push(result);
        });
      }
      propsdata.map(item => {
        lengend.push(item.applicationName);
        const obj = {};
        obj.name = item.applicationName;
        obj.type = "bar";
        // obj.stack = "haha";
        obj.data = item.counts;
        obj.label = {
          normal: {
            show: true,
            position: "inside"
          }
        };
        yA.push(obj);
      });
    } else {
      lengend = [];
      xA = [];
      yA = [];
    }
  }

  render() {
    const { buildData, deployData, commitData, buildcode, deploycode, commitcode } = this.props;

    // 部署
    const buildlegend = [];
    const buildx = [];
    const buildy = [];
    this.getEchartData(buildData, buildlegend, buildx, buildy, buildcode);
    // 部署
    const deploylegend = [];
    const deployx = [];
    const deployy = [];
    this.getEchartData(deployData, deploylegend, deployx, deployy, deploycode);

    // 代码提交树
    const commitlegend = [];
    const commitx = [];
    const commity = [];
    this.getEchartData(commitData, commitlegend, commitx, commity, commitcode);

    return (
      <div>
        <Row gutter={24}>
          <Col md={8} lg={12} xl={12} className="col-height">
            <ColumnLineChart
              unit="构建时长"
              height="40vh"
              x={buildx}
              y={buildy}
              legendData={buildlegend}
              key={Math.random()}
            />
          </Col>
          <Col md={8} lg={12} xl={12}>
            <ColumnLineChart
              unit="部署时长"
              height="40vh"
              x={deployx}
              y={deployy}
              legendData={deploylegend}
              key={Math.random()}
            />
          </Col>
          {/* <Col md={8} lg={8} xl={8}>
            <ColumnLineChart
              unit="单位/次"
              height="40vh"
              x={commitx}
              y={commity}
              legendData={commitlegend}
              key={Math.random()}
            />
          </Col> */}
        </Row>
        <Row gutter={24}>
          <Col md={8} lg={12} xl={12}>
            <ColumnLineChart
              unit="代码提交次数"
              height="40vh"
              x={commitx}
              y={commity}
              legendData={commitlegend}
              key={Math.random()}
            />
          </Col>
          <Col md={8} lg={12} xl={12}>
            <ColumnLineChart
              unit="单位/次"
              height="40vh"
              x={commitx}
              y={commity}
              legendData={commitlegend}
              key={Math.random()}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    buildData: state.listProjects.get("buildData"),
    deployData: state.listProjects.get("deployData"),
    commitData: state.listProjects.get("commitData"),

    //时间类型
    buildcode: state.listProjects.get("buildcode"),
    deploycode: state.listProjects.get("deploycode"),
    commitcode: state.listProjects.get("commitcode")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Index);
