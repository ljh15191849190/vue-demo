import React, { Component } from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Upload, Row, Col } from "antd";
import * as crAction from "../../../../actions/CodeRelation";
import * as mdactions from "../../../../actions/MediumWarehouse";
import Validation from "../../../../utils/Validation";
import "./Index.css";

const FormItem = Form.Item;
const { Option } = Select;

// 上传介质的窗口
const CreateForm = Form.create()(props => {
  const {
    visible,
    loading,
    onCancel,
    onCreate,
    form,
    fileUpload,
    handleConfirm,
    systemTypeData,
    repListData,
    getrepList,
    components
  } = props;
  const formItemLayout = {
    labelCol: {
      xs: { span: 18 },
      sm: { span: 6 }
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 }
    }
  };
  const { getFieldDecorator } = form;

  return (
    <Modal maskClosable={false}
      visible={visible}
      loading={loading}
      title="上传介质"
      okText="上传"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form>
        <div
          style={{
            textAlign: "left",
            fontSize: "14px",
            lineHeight: "14px",
            padding: "0px 0px 10px 0px",
            borderBottom: "1px solid #ccc",
            marginBottom: "10px"
          }}
        >
          仓库信息
        </div>
        <FormItem label="NEXUS:" {...formItemLayout}>
          {getFieldDecorator("nexusName", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择" onChange={getrepList}>
              {systemTypeData
                ? systemTypeData.map(ele => {
                    return (
                      <Option value={`${ele.alias},${ele.address}`} key={ele.address}>
                        {ele.alias}
                      </Option>
                    );
                  })
                : []}
            </Select>
          )}
        </FormItem>
        <FormItem label="仓库名称：" {...formItemLayout}>
          {getFieldDecorator("repName", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择">
              {repListData
                ? JSON.parse(repListData).map(ele => {
                    return (
                      <Option value={ele.name} key={Math.random()}>
                        {ele.name}
                      </Option>
                    );
                  })
                : []}
            </Select>
          )}
        </FormItem>
        <div
          style={{
            textAlign: "left",
            fontSize: "14px",
            lineHeight: "14px",
            padding: "0px 0px 10px 0px",
            borderBottom: "1px solid #ccc",
            marginBottom: "10px"
          }}
        >
          基本信息
        </div>
        <FormItem label="GroupId" {...formItemLayout}>
          {getFieldDecorator("groupId", {
            rules: Validation.Rule_groupId
          })(<Input maxLength={128} />)}
        </FormItem>
        <FormItem label="artifactId" {...formItemLayout}>
          {getFieldDecorator("artifactId", {
            rules: Validation.Rule_artifactId
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="version" {...formItemLayout}>
          {getFieldDecorator("version", {
            rules: Validation.Rule_params
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="别名" {...formItemLayout}>
          {getFieldDecorator("alliasName", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="Classifier" {...formItemLayout}>
          {getFieldDecorator("classfier", {
            rules: Validation.Rule_params
          })(<Input maxLength={128} />)}
        </FormItem>
        <FormItem label="组件：" {...formItemLayout}>
          {getFieldDecorator("componentName", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择">
              {components
                ? components.map(ele => {
                    return (
                      <Option
                        // value={ele.applicationName + "," + ele.applicationId}
                        value={`${ele.applicationName},${ele.applicationId}`}
                        key={ele.applicationId}
                      >
                        {ele.applicationName}
                      </Option>
                    );
                  })
                : []}
            </Select>
          )}
        </FormItem>
        <div
          style={{
            textAlign: "left",
            fontSize: "14px",
            lineHeight: "14px",
            padding: "0px 0px 10px 0px",
            borderBottom: "1px solid #ccc",
            marginBottom: "10px"
          }}
        >
          上传介质
        </div>
        <FormItem label="上传介质：" {...formItemLayout}>
          {getFieldDecorator("fileObj", {
            rules: [
              {
                validator: handleConfirm
              }
            ]
          })(
            <Input
              className="deploy-searh-input-img"
              type="file"
              // title="上传介质"
              onChange={fileUpload}
            />
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class MediumWarehouse extends Component {
  constructor(props) {
    super(props);
    this.state = {
      inputValue: "111",
      visible: false,
      loading: false,
      pagination: {},
      fileList: [],
      uploading: false,
      nexusId: "",
      nexusName: "",
      componentId: "",
      componentName: ""
    };
    this.showModal = this.showModal.bind(this);
    this.hideModal = this.hideModal.bind(this);
    this.handleCreate = this.handleCreate.bind(this);
    this.getForm = this.getForm.bind(this);
    this.fileUpload = this.fileUpload.bind(this);
    this.handleConfirm = this.handleConfirm.bind(this);

    this.columns = [
      {
        title: "组件名称",
        dataIndex: "componentName",
        render: (text, record) => this.renderColumns(text, record, "componentName")
      },

      {
        title: "介质名称",
        dataIndex: "artifactName",
        render: (text, record) => this.renderColumns(text, record, "artifactName")
      },
      {
        title: "介质版本",
        dataIndex: "artifactVersion",
        render: (text, record) => this.renderColumns(text, record, "artifactVersion")
      },
      // {
      //   title: "分支/tag",
      //   dataIndex: "branchName",
      //   render: (text, record) => this.renderColumns(text, record, "branchName")
      // },

      {
        title: "介质类型",
        dataIndex: "artifactType",
        render: (text, record) => {
          if (record.artifactUrl) {
            const filePath = record.artifactUrl;
            const index = filePath.lastIndexOf(".");
            const extention = filePath.substr(index + 1);
            return extention;
          }
        }
      },
      {
        title: "介质地址",
        width: "20%",
        dataIndex: "artifactUrl",
        render: (text, record) => this.renderColumns(text, record, "artifactUrl")
      },
      {
        title: "生成时间",
        dataIndex: "updateTime",
        render: (text, record) => this.renderColumns(text, record, "updateTime")
      },
      {
        title: "构建定义",
        dataIndex: "definitionName",
        render: (text, record) => this.renderColumns(text, record, "definitionName")
      },

      {
        title: "别名",
        dataIndex: "alliasName",
        render: (text, record) => this.renderColumns(text, record, "alliasName")
      },
      // {
      //   title: "文件大小",
      //   dataIndex: "artifactSize",
      //   render: (text, record) => this.renderColumns(text, record, "artifactSize")
      // },
      // {
      //   title: "来源",
      //   dataIndex: "group",
      //   render: (text, record) => this.renderColumns(text, record, "group")
      // },
      {
        title: "下载",
        dataIndex: "操作",
        render: (text, record) => {
          this.online = record;
          return (
            <a
              disabled={record.artifactUrl ? false : true}
              className="padright"
              href={record.artifactUrl ? record.artifactUrl : ""}
            >
              <span />
              下载
            </a>
          );
        }
      }
    ];
  }

  showModal() {
    this.setState({
      visible: true
    });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "artifactUrl") {
      return (
        <span
          style={{
            overflow: "hidden",
            textOverflow: "ellipsis"
          }}
        >
          {text}
        </span>
      );
    }

    return text;
  }

  hideModal() {
    this.form.resetFields();
    this.setState({
      visible: false
    });
  }

  handleCreate(e) {
    const { actions, projectId } = this.props;
    const { nexusId, nexusName } = this.state;
    const form = this.form;
    const fileObj = this.fileObj;
    if (this.fileObj && fileObj.size >= 204800000) {
      message.info("上传文件不能超过200M");
      return;
    }
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      const formData = new FormData();
      formData.append("file", fileObj);
      values.file = formData;

      const component = values.componentName;

      const index = fileObj.name.lastIndexOf(".");
      const extention = fileObj.name.substr(index + 1);

      values.extension = extention;
      values.nexusId = nexusId;
      values.nexusName = nexusName;
      values.componentName = component.split(",")[0];
      values.componentId = component.split(",")[1];
      values.projectId = projectId;
      form.resetFields();
      actions.uploadMedium(values);
      this.setState({ loading: true, visible: false });
    });
  }

  // 获取表单数据
  getForm(form) {
    this.form = form;
  }

  getrepList(result) {
    const { actions } = this.props;
    if (result) {
      const nexusName = result.split(",")[0];
      const nexusId = result.split(",")[1];
      this.setState({
        nexusId,
        nexusName
      });
      actions.repListByName({ aliasName: nexusName });
    }
  }

  fileUpload(e) {
    this.fileObj = e.target.files[0];
  }

  // 验证上传格式
  handleConfirm(rule, value, callback) {
    if (value) {
      const index = value.lastIndexOf(".");
      const extention = value.substr(index + 1);
      if (extention != "jar" && extention != "war") {
        callback("请上传jar,war格式的文件,文件不超过200M");
      }
      callback();
    }
  }

  getMediumList(searchCon) {
    const { actions } = this.props;
    const payload = {
      page: 1,
      conditions: searchCon ? searchCon : []
    };
    actions.findMedium(payload);
  }

  // 编号项目名称控件搜索
  search() {
    const { projectId } = this.props;
    const artifactVersion = ReactDOM.findDOMNode(this.refs.searchValue).value;
    const artifactName = ReactDOM.findDOMNode(this.refs.meduimName).value; // 介质名称
    const componentName = ReactDOM.findDOMNode(this.refs.repName).value;

    const searchCon = [];
    searchCon.push({ name: "projectId", sopt: "eq", value: projectId });
    if (artifactVersion) {
      searchCon.push({ name: "artifactVersion", sopt: "cn", value: artifactVersion });
    }
    if (artifactName) {
      searchCon.push({ name: "artifactName", sopt: "cn", value: artifactName });
    }
    if (componentName) {
      searchCon.push({ name: "componentName", sopt: "cn", value: componentName });
    }

    this.getMediumList(searchCon);
  }

  componentDidMount() {
    const { projectId, actions } = this.props;
    const searchCon = [];
    searchCon.push({ name: "projectId", sopt: "eq", value: projectId });
    this.getMediumList(searchCon);
    actions.searchNameSystemType({
      systemType: 2
    });

    actions.getComponentList(projectId);
  }

  componentWillReceiveProps(nextProps) {
    const { projectId } = this.props;
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.uploadStatus && nextProps.uploadStatus === 1) {
      message.info("上传成功");
      const searchCon = [];
      searchCon.push({ name: "projectId", sopt: "eq", value: projectId });
      this.getMediumList(searchCon);
    } else if (nextProps.uploadStatus && nextProps.uploadStatus === 2) {
      message.error("上传介质失败");
      const searchCon = [];
      searchCon.push({ name: "projectId", sopt: "eq", value: projectId });
      this.getMediumList(searchCon);
    }
  }

  handlePageChange(pagination) {
    const { actions } = this.props;
    this.setState({ loading: true });
    const payload = {
      page: pagination.current,
      conditions: []
    };
    actions.findMedium(payload);
  }

  render() {
    const { systemTypeData, resData, repListData, components } = this.props;
    const { pagination, loading, visible, uploading } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }

    return (
      <div style={{ width: "calc(100vw - 300px)" }}>
        <Row style={{ marginTop: "10px", padding: "0 20px" }}>
          <Col span={6}>
            <span style={{ marginRight: 10 }}>组件名称:</span>
            <Input placeholder="组件名称" style={{ width: "65%" }} ref="repName" />
          </Col>
          <Col span={6}>
            <span style={{ marginRight: 10 }}>介质名称:</span>
            <Input placeholder="介质名称" style={{ width: "65%" }} ref="meduimName" />
          </Col>
          <Col span={6}>
            <span style={{ marginRight: 10 }}>介质版本:</span>
            <Input placeholder="介质版本" style={{ width: "65%" }} ref="searchValue" />
          </Col>
          <Col span={5} style={{ textAlign: "right" }}>
            <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: "10px" }}>
              查询
            </Button>
            <Button type="primary" onClick={this.showModal} loading={uploading}>
              上传介质
            </Button>
          </Col>
          <CreateForm
            ref={this.getForm}
            title="Modal"
            visible={visible}
            loading={loading}
            onCreate={this.handleCreate}
            onCancel={this.hideModal}
            okText="确认"
            cancelText="取消"
            fileUpload={this.fileUpload}
            handleConfirm={this.handleConfirm}
            systemTypeData={systemTypeData}
            repListData={repListData}
            getrepList={this.getrepList.bind(this)}
            components={components}
          />
        </Row>

        <Table
          style={{ marginTop: 20 }}
          columns={this.columns}
          bordered
          size="small"
          dataSource={resData ? resData : []}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    resData: state.MediumWarehouse.get("resData"),
    pageConfig: state.MediumWarehouse.get("pageConfig"),
    uploadStatus: state.MediumWarehouse.get("uploadStatus"),
    systemTypeData: state.MediumWarehouse.get("systemTypeData"),
    repListData: state.MediumWarehouse.get("repListData"),
    components: state.codeRelation.get("components")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, crAction, mdactions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MediumWarehouse);
