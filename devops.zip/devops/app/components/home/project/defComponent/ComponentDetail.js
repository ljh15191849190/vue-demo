import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Card, Row, Col, Table, Icon } from "antd";
import "antd/dist/antd.css";
import * as action from "../../../../actions/build/BuildManage";
import * as actionsfetch from "../../../../actions/ComponentList";

class ComponentDetail extends React.Component {
  constructor(props) {
    super(props);
    this.goBack = this.goBack.bind(this);
  }

  // 生命周期
  componentWillMount() {}

  componentDidMount() {
    const { actions, projectId, selectedRow } = this.props;
    // 下载地址
    actions.repositoryAddress({
      projectId,
      applicationId: selectedRow.applicationId
    });
    // 组件详情信息
    actions.getModuleDetail({
      projectId,
      applicationId: selectedRow.applicationId,
      applicationName: selectedRow.applicationName
    });
    // actions.getModuleDetail({
    //   projectId: "30",
    //   applicationId: "1",
    //   applicationName: "乘客服务"
    // });
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(false);
  }

  render() {
    const gridStyle = {
      width: "50%",
      height: "40px",
      padding: "10px",
      textAlign: "center",
      overflow: "hidden"
    };
    const {
      selectedRow,
      lastBuildInfo,
      lastDeployReleaseInfo,
      addressData,
      buildDef,
      deployDefInfo
    } = this.props;
    return (
      <div>
        <div>
          <span onClick={this.goBack}>
            <Icon type="left" style={{ fontSize: 16, color: "#08c" }} />
            返回
          </span>
          <span> /组件</span>
        </div>
        <Row style={{ height: "700px" }}>
          <div
            style={{
              textAlign: "left",
              height: "60px",
              lineHeight: "60px",
              padding: "8px",
              marginLeft: "20px",
              borderBottom: "1px solid #ccc"
            }}
          >
            基本信息
          </div>
          <Col span={14} style={{ height: "100%" }}>
            <Row style={{ padding: "0 10px" }} type="flex">
              <Card bordered={false} style={{ width: "100%", padding: "0px 0px 0px 0px" }}>
                <Row>
                  <Col span={8}>
                    <p>
                      <span>组件编号:</span>
                      {selectedRow.applicationCode}
                    </p>
                    <p>
                      <span>组件分类:</span>
                      {selectedRow.applicationName}
                    </p>
                  </Col>
                  <Col span={16}>
                    <p>
                      <span>组件名称:</span>
                      {selectedRow.applicationName}
                      <span style={{ marginLeft: 200 }}>组件类型:</span>
                      {selectedRow.applicationType}
                    </p>
                    <p>
                      <span>组件描述:</span>
                      {selectedRow.applicationDesc}
                    </p>
                  </Col>
                </Row>
              </Card>
              <Col span={24}>
                <div>
                  <Card
                    title="最新构建介质信息"
                    style={{ width: "100%", padding: "0px 0px 0px 0px" }}
                  >
                    <Row>
                      <Col span={8}>
                        <p>
                          介质名称：
                          {lastBuildInfo && lastBuildInfo.data
                            ? lastBuildInfo.data.artifactName
                            : ""}
                        </p>
                        <p>构建定义：无 </p>
                      </Col>
                      <Col span={8}>
                        <p>
                          介质版本：
                          {lastBuildInfo && lastBuildInfo.data
                            ? lastBuildInfo.data.artifactVersion
                            : ""}
                        </p>
                        <p>
                          生成时间：
                          {lastBuildInfo && lastBuildInfo.data ? lastBuildInfo.data.createTime : ""}
                        </p>
                      </Col>
                      <Col span={8}>
                        <p>
                          介质别名：
                          {lastBuildInfo && lastBuildInfo.data ? lastBuildInfo.data.alliasName : ""}
                        </p>
                        <p>
                          分支/tag:
                          {lastBuildInfo && lastBuildInfo.data
                            ? lastBuildInfo.data.aaaaaaaaaaaaaaaa
                            : ""}
                        </p>
                      </Col>
                    </Row>
                    <p>
                      下载地址:
                      {lastBuildInfo && lastBuildInfo.data ? lastBuildInfo.data.artifactUrl : ""}
                    </p>
                  </Card>
                </div>
              </Col>
              <Col span={24}>
                <Card
                  title="最新组件发布信息"
                  style={{ width: "100%", padding: "0px 0px 0px 0px" }}
                >
                  <Row>
                    <Col span={16}>
                      <p>
                        访问地址：
                        {lastDeployReleaseInfo && lastDeployReleaseInfo.length > 0
                          ? lastDeployReleaseInfo[0].verifyUrl
                          : ""}
                      </p>
                      <p>
                        部署时间：
                        {lastDeployReleaseInfo && lastDeployReleaseInfo.length > 0
                          ? lastDeployReleaseInfo[0].deployCreateTime
                          : ""}
                      </p>
                    </Col>
                    <Col span={8}>
                      <p>
                        状态：
                        {lastDeployReleaseInfo && lastDeployReleaseInfo.length > 0
                          ? lastDeployReleaseInfo[0].deployStatus == "SUCCESS"
                            ? "启动"
                            : "未启动"
                          : ""}
                      </p>
                      <p>
                        环境类型：
                        {lastDeployReleaseInfo && lastDeployReleaseInfo.length > 0
                          ? lastDeployReleaseInfo[0].deployType == "1"
                            ? "shell"
                            : lastDeployReleaseInfo[0].deployType == "2"
                            ? "容器云"
                            : "ansible"
                          : ""}
                      </p>
                    </Col>
                  </Row>
                </Card>
              </Col>
            </Row>
          </Col>
          <Col span={10} style={{ height: "100%" }}>
            <Row style={{ padding: "0 10px" }} type="flex">
              <Col span={24}>
                <Card
                  title="关联代码仓库名称"
                  style={{ width: "100%", padding: "0px 0px 0px 0px" }}
                >
                  <Card.Grid style={gridStyle}>代码库名称</Card.Grid>
                  <Card.Grid style={gridStyle}>下载地址</Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {addressData ? addressData.repoName : " "}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>{addressData ? addressData.repoUrl : " "}</Card.Grid>
                </Card>
              </Col>
              <Col span={24}>
                <Card title="构建定义名称" style={{ width: "100%", padding: "0px 0px 0px 0px" }}>
                  <Card.Grid style={gridStyle}>名称</Card.Grid>
                  <Card.Grid style={gridStyle}>最后修改时间</Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {buildDef && buildDef.length > 0 ? buildDef[0].definitionName : ""}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {buildDef && buildDef.length > 0 ? buildDef[0].lastDurationTime : ""}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {buildDef && buildDef.length > 0 ? buildDef[1].definitionName : ""}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {buildDef && buildDef.length > 0 ? buildDef[1].lastDurationTime : ""}
                  </Card.Grid>
                </Card>
              </Col>
              <Col span={24}>
                <Card
                  title="部署架构设计名称"
                  style={{ width: "100%", padding: "0px 0px 0px 0px" }}
                >
                  <Card.Grid style={gridStyle}>名称</Card.Grid>
                  <Card.Grid style={gridStyle}>最后修改时间</Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {deployDefInfo && deployDefInfo.length > 0
                      ? deployDefInfo[0].deployDfName
                      : " "}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {deployDefInfo && deployDefInfo.length > 0
                      ? deployDefInfo[0].deployCreateTime
                      : " "}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {deployDefInfo && deployDefInfo.length > 1
                      ? deployDefInfo[1].deployDfName
                      : " "}
                  </Card.Grid>
                  <Card.Grid style={gridStyle}>
                    {deployDefInfo && deployDefInfo.length > 1
                      ? deployDefInfo[1].deployCreateTime
                      : " "}
                  </Card.Grid>
                </Card>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    lastBuildInfo: state.PjmComponent.get("lastBuildInfo"),
    lastDeployReleaseInfo: state.PjmComponent.get("lastDeployReleaseInfo"),
    deployDefInfo: state.PjmComponent.get("deployDefInfo"),
    addressData: state.PjmComponent.get("addressData"),
    pageConfig: state.PjmComponent.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(actionsfetch, dispatch),
    action: bindActionCreators(action, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ComponentDetail);
