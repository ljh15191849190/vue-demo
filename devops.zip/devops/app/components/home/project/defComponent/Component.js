import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Popconfirm, Row, Col } from "antd";
import * as action from "../../../../actions/ComponentList";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const { TextArea } = Input;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增组件申请"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="组件编号:">
          {getFieldDecorator("applicationCode", {
            rules: Validation.Rule_Componentcode
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="组件名称:">
          {getFieldDecorator("applicationName", {
            rules: Validation.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="版本编号:">
          {getFieldDecorator("versionCode", {
            rules: Validation.Rule_params
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="组件描述">
          {getFieldDecorator("applicationDesc")(<TextArea rows={4} maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onCancel, handleChange, form } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={updatavisible}
      title="修改组件申请"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onUpdata}
    >
      <Form layout="vertical">
        <FormItem label="组件编号:">
          {getFieldDecorator("applicationCode")(<Input disabled />)}
        </FormItem>
        <FormItem label="组件名称:">
          {getFieldDecorator("applicationName", {
            rules: Validation.Rule_name
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="版本编号:">
          {getFieldDecorator("versionCode", {
            rules: Validation.Rule_params
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="组件描述">
          {getFieldDecorator("applicationDesc")(<TextArea rows={4} maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

class Component extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      ModalText: "您确定要删除么？",
      confirmLoading: false,
      updataData: {},
      projectName: ""
    };
    this.columns = [
      {
        title: "组件编号",
        dataIndex: "applicationCode",
        width: "15%"
        // 别删
        // render: (text, record) => {
        //   return (
        //     <div>
        //       <a
        //         onClick={() => {
        //           this.openRepostory(record);
        //         }}
        //       >
        //         {text}
        //       </a>
        //     </div>
        //   );
        // }
      },
      {
        title: "组件名称",
        dataIndex: "applicationName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "applicationName")
      },

      {
        title: "版本编号",
        dataIndex: "versionCode",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "versionCode")
      },
      {
        title: "状态",
        dataIndex: "applicationStatus",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "applicationStatus")
      },
      {
        title: "组件描述",
        width: "25%",
        dataIndex: "applicationDesc",
        render: (text, record) => this.renderColumns(text, record, "applicationDesc")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        width: "15%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                <span />
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">
                  <span />
                  删除
                </a>
              </Popconfirm>
              {/* <a
                onClick={() => {
                  this.openRepostory(record);
                }}
                className="padright"
              >
                <span />
                详情
              </a> */}
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
    this.openRepostory = this.openRepostory.bind(this);
  }

  openRepostory(record) {
    const { triggleStatus, selectedRow } = this.props;
    triggleStatus(true);
    selectedRow(record);
  }

  //   确认删除projectId
  handleDelOk(record) {
    const { actions, projectId } = this.props;
    actions.deleteComponent(record.applicationId);
    // actions.getComponentList({
    //   projectId,
    //   page: 1,
    //   size: 10,
    //   sortid: "id",
    //   sortvalue: "desc",
    //   conditions: []
    // });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "applicationStatus") {
      return text == "0" ? "已启用" : "未启用";
    } else {
      return text;
    }
  }

  search() {
    const applicationCode = ReactDOM.findDOMNode(this.refs.applicationCode).value;
    const applicationName = ReactDOM.findDOMNode(this.refs.applicationName).value;
    const { actions, projectId } = this.props;
    if (applicationCode == "" && applicationName == "") {
      actions.getComponentList({
        projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      });
    } else {
      actions.getComponentList({
        projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        applicationCode,
        applicationName
      });
    }
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getComponentList({
      projectId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    });
  }

  componentDidUpdate() {
    const { delStatus, actions, projectId, addStatus, updataStatus } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      actions.getComponentList({
        projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      });
    } else if (delStatus && delStatus === 2) {
      message.error("删除前请先解除关联代码");
      this.query();
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      actions.getComponentList({
        projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      });
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      this.query();
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      actions.getComponentList({
        projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      });
    } else if (updataStatus && updataStatus === 2) {
      message.error("修改失败");
      this.query();
    }
  }

  query() {
    const { actions, projectId } = this.props;
    actions.getComponentList({
      projectId,
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    });
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { actions, projectId } = this.props;
    this.setState({ loading: true });
    actions.getComponentList({
      projectId,
      page: pagination.current,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击修改弹框
  showEditModal(record) {
    this.form.setFieldsValue({
      applicationCode: record.applicationCode,
      applicationName: record.applicationName,
      versionCode: record.versionCode,
      applicationDesc: record.applicationDesc
    });
    this.setState({
      updataData: {
        applicationId: record.applicationId
      },
      loading: false
    });
    this.setState({
      updatavisible: true
    });
  }

  // 确认修改updata
  handleUpdataOk(e) {
    const { projectId, actions } = this.props;
    const { updataData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      // 默认项目id 后期重新传值
      values.projectId = projectId;
      values.applicationId = updataData.applicationId;
      actions.updateComponent(values);
      this.setState({ updatavisible: false });
    });
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const forms = this.forms;
    const { projectId, actions } = this.props;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      // 默认项目id 后期重新传值
      values.projectId = projectId;
      actions.addComponentList(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.form.resetFields();
    this.setState({
      visible: false,
      updatavisible: false
    });
  }

  changeSearch(e) {
    this.setState({
      projectName: e.target.value
    });
  }

  render() {
    const { resData } = this.props;
    const { pagination, loading, visible, updatavisible } = this.state;
    if (resData) {
      resData.map(item => {
        item.key = item.applicationId + Math.random();
      });
    }
    return (
      <div>
        <div>
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={7}>
              <span style={{ marginRight: 20 }}>组件编号:</span>
              <Input style={{ width: "60%" }} ref="applicationCode" />
            </Col>
            <Col span={7}>
              <span style={{ marginRight: 20 }}>组件名称:</span>
              <Input style={{ width: "60%" }} ref="applicationName" />
            </Col>

            <Col span={8} style={{ textAlign: "right" }}>
              <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: 10 }}>
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)}>
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
          />
        </div>
        <div />
        <Table
          style={{ marginTop: 20 }}
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.PjmComponent.get("resData"),
    pageConfig: state.PjmComponent.get("pageConfig"),
    addStatus: state.PjmComponent.get("AddStatus"),
    delStatus: state.PjmComponent.get("delStatus"),
    updataStatus: state.PjmComponent.get("UpdataStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Component);
