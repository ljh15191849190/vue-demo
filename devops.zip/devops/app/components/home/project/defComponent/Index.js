import React from "react";
import Component from "./Component";
import ComponentDetail from "./ComponentDetail";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: false,
      selectedRowData: {}
    };
    this.triggleStatus = this.triggleStatus.bind(this);
  }

  triggleStatus(show) {
    this.setState({
      showRepository: show
    });
  }

  selectedRow(record) {
    this.setState({
      selectedRowData: record
    });
  }

  componentDidMount() {}

  render() {
    const { projectId } = this.props;
    const { selectedRowData, showRepository } = this.state;
    return (
      <div>
        {showRepository ? (
          <ComponentDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : (
          <Component
            projectId={projectId}
            selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        )}
      </div>
    );
  }
}

export default Index;
