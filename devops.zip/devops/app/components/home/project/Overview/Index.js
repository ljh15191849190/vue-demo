import React from "react";
import "./overview.css";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, DatePicker } from "antd";
import moment from "moment";
import TimeChange from "../../../commons/TimeChange/TimeChange";
import PieChart from "../../../commons/PieChart/PieChart";
import ColumnChart from "../../../commons/ColumnChart/ColumnChart";
import Board from "../../../commons/Borad/Board";
import * as projectAction from "../../../../actions/ListProjects";

class Overview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "200",
      thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,
      // thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,

      thissDate: `${moment(new Date())
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    };
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    const mouthstart = `${moment()
      .add("month", 0)
      .format("YYYY-MM")}-01 00:00:00`;
    const mouthend = `${moment(mouthstart)
      .add("month", 1)
      .add("days", -1)
      .format("YYYY-MM-DD")} 23:59:59`;
    const todaystart = `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`;
    const todayend = `${moment(new Date())
      .add("days", 1)
      .format("YYYY-MM-DD")} 00:00:00`;
    actions.getProjectsOvewview({
      projectId,
      date: todaystart,
      sDate: todayend
    });
    actions.getProjectsbuildtop({
      projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsdeploytop({
      projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsRate({ projectId });
  }

  query(Date, type) {
    const { actions, projectId } = this.props;
    actions.getProjectsbuildtop({
      projectId,
      dataJson: {
        type,
        start: moment(Date[0]).format("YYYY-MM-DD HH:mm:ss"),
        end: moment(Date[1]).format("YYYY-MM-DD HH:mm:ss")
      }
    });
  }

  deploytop(Date, type) {
    const { actions, projectId } = this.props;
    actions.getProjectsdeploytop({
      projectId,
      dataJson: {
        type,
        start: moment(Date[0]).format("YYYY-MM-DD HH:mm:ss"),
        end: moment(Date[1]).format("YYYY-MM-DD HH:mm:ss")
      }
    });
  }

  // 单选日期1
  onChangeDate(date, dateString) {
    const { actions, projectId } = this.props;
    this.setState({
      thisDate: `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`,
      thissDate: `${moment(new Date())
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    });
    actions.getProjectsOvewview({
      projectId,
      date: `${moment(date).format("YYYY-MM-DD")} 00:00:00`,
      sDate: `${moment(date)
        .add("days", 1)
        .format("YYYY-MM-DD")} 00:00:00`
    });
  }

  // 构建选择1
  builddbDate(Date) {
    const type = "self";
    this.query(Date, type);
  }

  // 构建点击
  buildsignDate(Date, type) {
    this.query(Date, type);
  }

  deploydbDate(Date) {
    const type = "self";
    this.deploytop(Date, type);
  }

  deploysignDate(Date, type) {
    this.deploytop(Date, type);
  }

  render() {
    const topColResponsiveProps = {
      xs: 24,
      sm: 24,
      md: 12,
      lg: 12,
      xl: 12
    };
    const { topData, topbuildData, resData, rateData, projectName } = this.props;
    if (topData == undefined || topData.rtn_code == "-1") {
      return false;
    }
    if (topbuildData == undefined || topbuildData.rtn_code == "-1") {
      return false;
    }
    // 构建Top5
    const buildx = [];
    const buildy = [];
    if (topbuildData && topbuildData.length > 0) {
      topbuildData.map(item => {
        if (item.type == "today") {
          // buildx.push(item.hours + "点");
          buildx.push(`${item.hours}点`);
        } else {
          // buildx.push(item.days + "日");
          buildx.push(`${item.days}日`);
        }
        buildy.push((item.durationTime / 1000).toFixed(0));
      });
    }
    // 部署Top5
    const deployx = [];
    const deployy = [];
    if (topData && topData.length > 0) {
      topData.map(item => {
        if (item.type == "today") {
          // deployx.push(item.hours + "点");
          deployx.push(`${item.hours}点`);
        } else {
          // deployx.push(item.days + "日");
          deployx.push(`${item.days}日`);
        }
        deployy.push((item.durationTime / 1000).toFixed(0));
      });
    }
    const navigations = [
      {
        img: "/images/dashboard/component.png",
        title: "组件数量",
        color: "#f8623b",
        count: resData ? resData.appCount : "0"
      },
      {
        img: "/images/dashboard/seviceInstance.png",
        title: "运行组件实例数",
        color: "#37D1AB",
        count: resData ? resData.appRunningCount : "0"
      },
      {
        img: "/images/dashboard/build.png",
        title: "构建次数",
        color: "#ffa001",
        count: resData ? resData.buildCount : "0"
      },
      {
        img: "/images/dashboard/deploy.png",
        title: "部署次数",
        color: "#42C0EA",
        count: resData ? resData.depolyCount : "0"
      }
    ];
    return (
      <div
        id="Dashboard"
        style={{ width: this.props.width ? this.props.width : "calc(100vw - 270px)" }}
      >
        <span style={{ fontSize: 18 }}>
          项目名称：
          {projectName}
        </span>
        <Card>
          <Row>
            <Col span={24}>
              <span style={{ float: "right", marginRight: 30, marginBottom: 10 }}>
                <span style={{ marginRight: 20 }}>选择日期</span>
                <DatePicker
                  onChange={this.onChangeDate.bind(this)}
                  defaultValue={moment(new Date())}
                />
              </span>
            </Col>
          </Row>
          <Row>
            <Board navigation={navigations} />
          </Row>
        </Card>
        <Row>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <Card>
              <div style={{ marginBottom: 10 }}>构建时长趋势TOP5</div>
              <Row>
                <TimeChange
                  signDate={this.buildsignDate.bind(this)}
                  dbDate={this.builddbDate.bind(this)}
                />
                <Col span={24}>
                  <ColumnChart height="285px" x={buildx} y={buildy} />
                </Col>
              </Row>
            </Card>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <Card>
              <div style={{ marginBottom: 10 }}>部署时长趋势TOP5</div>
              <Row>
                <TimeChange
                  signDate={this.deploysignDate.bind(this)}
                  dbDate={this.deploydbDate.bind(this)}
                />
                <Col span={24}>
                  <ColumnChart height="285px" x={deployx} y={deployy} />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
        {/* 饼图 */}
        <Row>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <Card>
              <div>构建成功率</div>
              <PieChart
                height="150px"
                Times={rateData && rateData.buildInfo ? rateData.buildInfo : {}}
              />
            </Card>
          </Col>
          <Col xxl={12} xl={12} lg={12} md={24} sm={24} xs={24}>
            <Card>
              <div>部署成功率</div>
              <PieChart
                height="150px"
                Times={rateData && rateData.depolyInfo ? rateData.depolyInfo : {}}
              />
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.listProjects.get("resData"),
    topData: state.listProjects.get("topData"),
    topbuildData: state.listProjects.get("topbuildData"),
    rateData: state.listProjects.get("rateData"),
    instanceNum: state.listProjects.get("instanceNum")
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(projectAction, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Overview);
