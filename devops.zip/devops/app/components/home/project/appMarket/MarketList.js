import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Select, Modal, Button, Form, Card, Row, Col, Tabs } from "antd";
import * as action from "../../../../actions/Resource";
import CodeMirror from "../../../commons/CodeMirror/codemirroe";
import "./Index.css";
import QuillEditor from "../../../commons/QuillEditor/Index";

const TabPane = Tabs.TabPane;
const NewForm = Form.create()(props => {
  const { visible, onCancel, appDetailData } = props;
  return (
    <Modal maskClosable={false} width="60vw" visible={visible} footer={null} onCancel={onCancel}>
      <Card>
        <Row>
          <Col span={4}>
            <div>
              <img src={appDetailData.marketAppIcon} height="100px" alt="" />
            </div>
          </Col>
          <Col span={6}>
            <p style={{ fontSize: 18, fontWeight: 700 }}>{appDetailData.marketAppName}</p>
            <p>
              类型：
              {appDetailData.marketAppType}
            </p>
            <p>
              来源：
              {appDetailData.tenantId}
            </p>
          </Col>
        </Row>
      </Card>
      <Tabs defaultActiveKey="1">
        <TabPane tab="基本信息" key="1">
          {/* <QuillEditor EditorData={appDetailData.marketAppDesc} key={Math.random()} /> */}
          <div>{appDetailData.marketAppDesc}</div>
        </TabPane>
        <TabPane tab="编排文件" key="2">
          <CodeMirror
            serviceOrchestrationYml={appDetailData.serviceOrchestrationYml}
            readOnly={true}
          />
        </TabPane>
      </Tabs>
    </Modal>
  );
});
class AppMarket extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      visible: false,
      marketAppType: "",
      updataData: {}
    };

    this.setState = this.setState.bind(this);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  //   控件搜索
  search() {
    const { marketAppType } = this.state;
    const { actions } = this.props;
    actions.getmarketAppList({
      page: 1,
      marketAppType: marketAppType ? marketAppType : "All"
    });
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getmarketAppList({
      page: 1,
      marketAppType: "All"
    });
  }

  CardhandleClick(marketAppId) {
    const { actions } = this.props;
    this.setState({
      visible: true
    });
    actions.getmarketAppDetail({
      marketAppId
    });
  }

  IconhandleClick(record, e) {
    const { triggleStatus, selectedRow } = this.props;
    e.stopPropagation();
    triggleStatus(2);
    selectedRow(record);
  }

  handleChangeStatus(value) {
    this.setState({
      marketAppType: value
    });
  }

  render() {
    const { visible } = this.state;
    const { appListData, appDetailData } = this.props;
    const { Option } = Select;
    if (appListData) {
      appListData.map(item => {
        item.key = item.marketAppId;
      });
    }
    return (
      <div style={{ width: "calc(100vw - 300px)" }}>
        <Row style={{ marginTop: "10px", padding: "0 20px" }}>
          <Col span={6}>
            <span style={{ marginRight: 10 }}>应用类型:</span>
            <Select
              allowClear
              placeholder="应用类型"
              style={{ width: "70%" }}
              className="padright"
              onChange={this.handleChangeStatus.bind(this)}
            >
              <Option value="基础服务">基础服务</Option>
              <Option value="Web服务">Web服务</Option>
              <Option value="数据服务">数据服务</Option>
            </Select>
          </Col>

          <Col span={16} style={{ textAlign: "right" }}>
            <Button type="primary" onClick={this.search.bind(this)} style={{ marginRight: 10 }}>
              查询
            </Button>
            {/* <Button type="primary" className="padright">
              新增
            </Button> */}
          </Col>
        </Row>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} gutter={30}>
          <Card bordered={false}>
            {appListData
              ? appListData.map(v => {
                  return (
                    <Col sm={8} md={8} lg={8} xl={6} xxl={4} key={v.marketAppId}>
                      <Card
                        hoverable
                        cover={
                          <img
                            src={v.marketAppIcon}
                            height="150px"
                            onClick={this.CardhandleClick.bind(this, v.marketAppId)}
                            alt=""
                          />
                        }
                      >
                        <Row>
                          <Col span={18}>
                            <span style={{ fontSize: 18 }}>{v.marketAppName}</span>
                          </Col>
                          <Col span={5}>
                            <img
                              src="/images/appMarket/branch.png"
                              onClick={this.IconhandleClick.bind(this, v)}
                              alt=""
                            />
                          </Col>
                          {/* <Col span={3}>
                                <Icon type="heart" theme="outlined" style={{ fontSize: "16px" }} />
                              </Col> */}
                        </Row>
                      </Card>
                    </Col>
                  );
                })
              : ""}
          </Card>
        </Row>
        <NewForm
          visible={visible}
          appDetailData={appDetailData}
          onCancel={() => {
            this.setState({
              visible: false
            });
          }}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    appListData: state.Resource.get("appListData"),
    appListpageConfig: state.Resource.get("appListpageConfig"),
    appDetailData: state.Resource.get("appDetailData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AppMarket);
