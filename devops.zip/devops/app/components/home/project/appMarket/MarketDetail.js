import React from "react";
import { Spin, Select, Input, Icon, Button, Form, message } from "antd";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/Resource";
import CodeMirror from "../../../commons/CodeMirror/codemirroe";
import Validation from "../../../../utils/Validation";

const Option = Select.Option;
const FormItem = Form.Item;
const { TextArea } = Input;
class MarketDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.YarnValue = "";
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(1);
  }

  componentWillReceiveProps(nextProps) {
    const { deployData, triggleStatus, selectedNodeRow } = this.props;
    if (nextProps.deployData && nextProps.buildnum) {
      if (deployData !== nextProps.deployData) {
        triggleStatus(3);
        selectedNodeRow(nextProps.buildnum, nextProps.deployData);
      }
    }
  }

  submitClick() {
    const { form, projectId, selectedRow, actions } = this.props;
    const { envId, clusterName, namespaceName, clusterId, namespaceId, clusterVipIp } = this.state;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      // 默认
      values.deployType = 2;
      values.deployPodTemplate = 2;
      values.ymlcontent = this.YarnValue;
      values.projectId = projectId;
      values.deployEnvType = envId;
      values.resIds = clusterName;
      values.namespaceName = namespaceName;
      values.compName = namespaceName;
      values.packageUrl = selectedRow.marketAppImageUrl;
      values.applicationName = selectedRow.marketAppName;
      values.applicationCode = selectedRow.marketAppCode;
      // console.log(values);
      const container = {};
      container.clusterId = clusterId;
      container.clusterName = clusterName;
      container.namespaceId = namespaceId;
      container.namespaceName = namespaceName;
      container.deploymentType = 2;
      container.deploymentImageInfo = selectedRow.marketAppDesc;
      container.imageTag = selectedRow.marketAppName;
      container.imageTagId = selectedRow.marketAppId;
      container.deploymentClusterIp = clusterVipIp;
      container.service = {
        namespace: namespaceName
      };
      actions.findMarketdeploy({
        data: values,
        container
      });
    });
    // // //返回值
    // let buildnum = 2;
    // let data = {
    //   appId: "77",
    //   applicationName: "tomcat8.5",
    //   compName: "libin",
    //   createTime: "2018-11-13 15:57:21",
    //   deployCreateTime: "2018-11-13 15:57:21",
    //   deployDfDesc: "dsds",
    //   deployDfId: 470,
    //   deployDfName: "tom",
    //   deployEnvType: "test",
    //   deployPodTemplate: 2,
    //   deployRuntimeName: "tomcat",
    //   deployStatus: "BUILDINGH",
    //   deployType: 2,
    //   durationTime: 0,
    //   id: 209,
    //   instanceId: 986,
    //   lastBuildNum: 2,
    //   projectId: 2,
    //   resIds: "clustername",
    //   totalSuccessful: 1,
    //   updateTime: "2018-11-13 15:57:21"
    // };
    // this.props.triggleStatus(3);
    // this.props.selectedNodeRow(buildnum, data);
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getEnvironmentName({
      projectId
    });
    actions.getClusterslistById({ projectId }); // 集群
  }

  getYmlValue(value) {
    this.YarnValue = value;
  }

  changeEnvName(v) {
    const { nameData, actions, form } = this.props;
    const { clusterId } = this.state;
    let EnvData = {};
    if (v) {
      EnvData = nameData.find(item => item.envId == v);
    }
    this.setState({
      envId: EnvData.envId,
      envName: EnvData.envName
    });
    if (clusterId) {
      actions.getNamespacePodListByClusterId({
        clusterId,
        envId: v
      });
    }
    form.setFieldsValue({ namespaceName: "" });
  }

  changeclusterName(v) {
    const { actions, clusterData, form } = this.props;
    const { envId } = this.state;
    let clusterDatas = {};
    if (v != undefined) {
      clusterDatas = clusterData.find(item => item.clusterId == v);
    }
    this.setState({
      clusterId: clusterDatas.clusterId,
      clusterName: clusterDatas.clusterName,
      clusterVipIp: clusterDatas.clusterVipIp
    });
    if (envId) {
      actions.getNamespacePodListByClusterId({
        clusterId: v,
        envId
      });
    }
    form.setFieldsValue({ namespaceName: "" });
  }

  changenamespaceName(v) {
    const { nameSpacePodData } = this.props;
    let nameSpacePodDatas = {};
    if (v) {
      nameSpacePodDatas = nameSpacePodData.find(item => item.namespaceId == v);
    }
    this.setState({
      namespaceId: nameSpacePodDatas.namespaceId,
      namespaceName: nameSpacePodDatas.namespaceName
    });
  }

  render() {
    const { selectedRow, clusterData, nameData, nameSpacePodData, projectName, form } = this.props;
    const { getFieldDecorator } = form;
    const formItemLayout = {
      labelCol: { span: 5 },
      wrapperCol: { span: 17 }
    };
    return (
      <div>
        <div style={{ marginBottom: 5 }}>
          <span onClick={() => this.goBack()} style={{ cursor: "pointer" }}>
            <Icon type="left" style={{ fontSize: 16, color: "#08c" }} />
            返回
          </span>
          <span> /资源</span>
        </div>
        <Form>
          <div>基本信息</div>
          <FormItem label="名称" {...formItemLayout}>
            {getFieldDecorator("deployDfName", {
              rules: Validation.Rule_code,
              initialValue: ""
            })(<Input placeholder="请输入名称" maxLength={32} />)}
          </FormItem>
          <FormItem label="所属项目" {...formItemLayout}>
            {getFieldDecorator("projectName", {
              initialValue: projectName
            })(<Input disabled />)}
          </FormItem>
          <FormItem label="描述" {...formItemLayout}>
            {getFieldDecorator("deployDfDesc", {
              initialValue: ""
            })(<TextArea maxLength={256} />)}
          </FormItem>
          <div>部署设置</div>
          <FormItem label="应用名称" {...formItemLayout}>
            {getFieldDecorator("applicationName", {
              initialValue: selectedRow.marketAppName
            })(<Input disabled />)}
          </FormItem>
          <FormItem label="所属环境" {...formItemLayout}>
            {getFieldDecorator("deployEnvType", {
              rules: Validation.Rule_select,
              initialValue: ""
            })(
              <Select style={{ width: "50%" }} allowClear onChange={this.changeEnvName.bind(this)}>
                {nameData
                  ? nameData.map(v => {
                      return (
                        <Option value={v.envId} key={v.envId}>
                          {v.envName}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            )}
          </FormItem>
          <FormItem label="所属集群" {...formItemLayout}>
            {getFieldDecorator("clusterName", {
              rules: Validation.Rule_select,
              initialValue: ""
            })(
              <Select
                style={{ width: "50%" }}
                allowClear
                onChange={this.changeclusterName.bind(this)}
              >
                {clusterData
                  ? clusterData.map(v => {
                      return (
                        <Option value={v.clusterId} key={v.clusterId}>
                          {v.clusterName}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            )}
          </FormItem>
          <FormItem label="命名空间" {...formItemLayout}>
            {getFieldDecorator("namespaceName", {
              rules: Validation.Rule_select,
              initialValue: ""
            })(
              <Select
                style={{ width: "50%" }}
                allowClear
                onChange={this.changenamespaceName.bind(this)}
              >
                {nameSpacePodData
                  ? nameSpacePodData.map(v => {
                      return (
                        <Option value={v.namespaceId} key={v.namespaceId}>
                          {v.namespaceName}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            )}
          </FormItem>
          <div>编排文件</div>
          <CodeMirror
            readOnly={true}
            serviceOrchestrationYml={selectedRow.serviceOrchestrationYml}
            getValue={this.getYmlValue.bind(this)}
          />
        </Form>
        <div style={{ textAlign: "center", marginTop: "20px" }}>
          <Button
            type="primary"
            style={{ marginRight: "10px" }}
            onClick={() => {
              this.submitClick();
            }}
          >
            执行
          </Button>
          <Button onClick={this.goBack.bind(this)}>取消</Button>
        </div>
      </div>
    );
  }
}
const MarketDetails = Form.create()(MarketDetail);

const mapStateToProps = state => {
  return {
    clusterData: state.Resource.get("clusterData"),
    nameSpacePodData: state.Resource.get("nameSpacePodData"),
    nameData: state.Resource.get("nameData"),
    deployData: state.Resource.get("deployData"),
    buildnum: state.Resource.get("buildnum")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MarketDetails);
