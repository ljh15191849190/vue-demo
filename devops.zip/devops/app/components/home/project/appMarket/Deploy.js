import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Icon, message, Modal, Row, Col, Steps, Tabs } from "antd";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";

const Step = Steps.Step;
const TabPane = Tabs.TabPane;

class DockerDeploymentDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showLog: false
    };
    // 部署服务列信息
    this.podColumns = [
      {
        title: "pod名称",
        dataIndex: "name",
        key: "name",
        // width: 80
        render: (text, record) => this.renderColumns(text, record, "name")
      },
      {
        title: "状态",
        dataIndex: "status",
        key: "status",
        // width: 80,
        render: (text, record) => this.renderColumns(text, record, "status")
      },
      {
        title: "创建时间",
        dataIndex: "time",
        key: "time",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "time")
      },
      {
        title: "操作",
        dataIndex: "action",
        key: "action",
        // width: 80,
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    this.deployStatusCode = "BUILDINGH";
    this.timer = null;
    this.SuccessRunStatus = "loading";
    this.SuccessFinStatus = "close";
  }

  // 生命周期部分开始
  componentDidMount() {
    const { actions, selectedRow } = this.props;
    // 执行
    actions.executeDeployment({
      id: selectedRow.id,
      opsType: ""
    });
    this.timer1 = setInterval(() => {
      // 状态
      actions.findDeployStatus({
        id: selectedRow.id,
        defName: selectedRow.compName,
        buildNum: this.props.executeData ? this.props.executeData : ""
      });
      // 日志
      const obj = {
        deployType: selectedRow.deployType,
        deployDfId: selectedRow.deployDfId,
        deployInstanceId: selectedRow.instanceId
      };
      actions.deployConsole(obj);
    }, 5000);
    // pod组
    actions.getPodList({ id: selectedRow.id });
  }

  componentWillUnmount() {
    clearInterval(this.timer1);
  }

  componentDidUpdate() {
    const { deployStatusCode } = this.props;
    if (deployStatusCode === "SUCCESS" || deployStatusCode === "FAILURE") {
      clearInterval(this.timer1);
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.deployStatusCode) {
      this.deployStatusCode = nextProps.deployStatusCode;
    }
    if (nextProps.deployStatusCode === "SUCCESS") {
      this.SuccessRunStatus = "check";
      this.SuccessFinStatus = "check";
    } else if (nextProps.deployStatusCode === "FAILURE") {
      this.SuccessRunStatus = "close";
      this.SuccessFinStatus = "close";
    }
    if (nextProps.time) {
      this.time = nextProps.time;
    }
  }

  // 生命周期部分结束
  // 实例方法部分开始
  /**
   * 返回部署管理
   */
  goBack() {
    const { triggleStatus } = this.props;
    clearInterval(this.timer1);
    triggleStatus(1);
  }

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    if (column === "deployStatus" && text) {
      if (text === "FAILURE") {
        return (
          <div>
            <Icon
              className="padright"
              type="close-circle"
              style={{
                fontSize: 16,
                color: "#ff0000"
              }}
            />
            <span>失败</span>
          </div>
        );
      } else if (text === "SUCCESS") {
        return (
          <div>
            <Icon
              className="padright"
              type="check-circle"
              style={{
                fontSize: 16,
                color: "#00ff48"
              }}
            />
            <span>成功</span>
          </div>
        );
      } else if (text === "BUILDINGH") {
        return (
          <div>
            <Icon
              className="padright"
              type="clock-circle"
              style={{
                fontSize: 16,
                color: "#1890ff"
              }}
            />
            <span>部署中</span>
          </div>
        );
      }
    }
    if (column === "durationTime" && text) {
      return `${text / 1000}s`;
    }
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, type) {
    if (type === "log") {
      return (
        <div>
          <Icon
            type="file-text"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.showLogVisual.bind(this, record)}
          />
        </div>
      );
    }
  }

  /**
   * 获取pod组数据
   */
  getHistPodMethod() {}

  /**
   * 查看日志（pod）
   */
  showLogVisual(record) {
    const { actions, selectedRow } = this.props;
    this.setState({
      showLog: true
    });
    actions.getPodLog({
      id: selectedRow.id,
      podName: record.name
    });
  }

  /**
   * 关闭日志
   */
  closeLogVisual() {
    this.setState({
      showLog: false
    });
  }

  // 实例方法部分结束
  render() {
    const { consoleData, duratime, selectedRow, podData, podLog } = this.props;
    const { showLog } = this.state;
    // 部署状态判断
    switch (this.deployStatusCode) {
      case "SUCCESS":
        this.status = "部署成功";
        break;
      case "BUILDINGH":
        this.status = "部署中";
        break;
      case "FAILURE":
        this.status = "部署失败";
        break;
      default:
        break;
    }
    const projectName = sessionStorage.getItem("projectName")
      ? sessionStorage.getItem("projectName")
      : "";
    let consoleDatas;
    if (consoleData && consoleData.deployLog) {
      consoleDatas = consoleData.deployLog;
    }
    return (
      <div>
        <div>
          <span style={{ cursor: "pointer" }} onClick={this.goBack.bind(this)}>
            返回
          </span>
          <span> / 部署应用市场</span>
        </div>
        <Row style={{ height: "370px", color: "white" }}>
          <Col span={6} style={{ background: "#454A65", height: "100%", padding: "20px" }}>
            <Row style={{ height: "160px" }}>
              <Col style={{ fontSize: "80px", color: "#ddd" }} span={6}>
                <Icon
                  type="check-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "SUCCESS" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="loading"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "BUILDINGH" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="close-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "FAILURE" ? "inline-block" : "none"
                  }}
                />
              </Col>
              <Col span={17} style={{ paddingTop: "20px" }}>
                <div style={{ textAlign: "center", fontSize: "22px" }}>{this.status}</div>
                <div style={{ textAlign: "center" }}>
                  部署持续时间:
                  {duratime ? Number(duratime) / 1000 : ""}s
                </div>
              </Col>
            </Row>
            <Row style={{ marginTop: "20px" }}>
              <Col>
                <div>创建时间：</div>
                <div>
                  {consoleData && consoleData.buildBeginTime ? consoleData.buildBeginTime : ""}
                </div>
              </Col>
              <Col style={{ marginTop: "10px" }}>
                <div>最近部署时间：</div>
                <div>{this.time ? this.time : ""}</div>
              </Col>
            </Row>
          </Col>
          <Col span={18} style={{ background: "#3A3E55", height: "100%", padding: "20px" }}>
            <div>
              <div style={{ fontSize: "18px" }}>部署进程</div>
              <Row style={{ padding: "20px" }} id="steps">
                <Col span={22}>
                  <Steps>
                    <Step status="finish" title="连接到部署引擎" icon={<Icon type="check" />} />
                    <Step status="finish" title="下载镜像" icon={<Icon type="check" />} />
                    <Step status="finish" title="部署Pod" icon={<Icon type="check" />} />
                    <Step status="finish" title="部署Service" icon={<Icon type="check" />} />
                    <Step
                      status="finish"
                      title="正在部署"
                      icon={<Icon type={this.SuccessRunStatus} />}
                    />
                    <Step
                      status="finish"
                      title="部署完成"
                      icon={<Icon type={this.SuccessFinStatus} />}
                    />
                  </Steps>
                </Col>
              </Row>
            </div>
            <Row style={{ padding: "20px 10px 10px 0" }}>
              <Col span={12}>
                <div style={{ fontSize: "18px", marginBottom: "10px" }}>部署信息</div>
                <ul style={{ listStyle: "none", padding: "0" }}>
                  <li>
                    描述：
                    <span>{selectedRow.deployRuntimeName}</span>
                  </li>
                  <li>
                    项目：
                    <span>{projectName}</span>
                  </li>
                  <li>
                    部署类型：
                    <span>容器部署-应用市场部署</span>
                  </li>
                  <li>
                    部署介质：
                    <span>
                      {consoleData && consoleData.packageUrl ? consoleData.packageUrl : ""}
                    </span>
                  </li>
                </ul>
              </Col>
            </Row>
          </Col>
        </Row>
        <Tabs defaultActiveKey="1" onChange={this.getHistPodMethod.bind(this)}>
          <TabPane tab="部署日志" key="1">
            <div
              style={{
                maxHeight: 600,
                overflowY: "scroll"
              }}
            >
              <div dangerouslySetInnerHTML={{ __html: consoleDatas }} />
            </div>
          </TabPane>
          <TabPane tab="pod组" key="2">
            <Table
              columns={this.podColumns}
              pagination={false}
              dataSource={
                podData
                  ? podData.map((v, i) => {
                      v.key = i + 1;
                      return v;
                    })
                  : []
              }
            />
          </TabPane>
        </Tabs>
        {/* 弹框 */}
        <Modal
          maskClosable={false}
          title="pod日志"
          visible={showLog}
          footer={null}
          width={1000}
          key={Math.random()}
          onCancel={this.closeLogVisual.bind(this)}
        >
          <div
            style={{
              maxHeight: 500,
              overflowY: "scroll"
            }}
          >
            <div dangerouslySetInnerHTML={{ __html: podLog }} />
          </div>
        </Modal>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    consoleData: state.Deploy.get("consoleData"),
    executeData: state.Deploy.get("executeData"),
    podData: state.Deploy.get("podData"),
    deployStatusCode: state.Deploy.get("deployStatusCode"),
    time: state.Deploy.get("time"),
    duratime: state.Deploy.get("duratime"),
    podLog: state.Deploy.get("podLog")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, DeploymentManageActions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DockerDeploymentDetails);
