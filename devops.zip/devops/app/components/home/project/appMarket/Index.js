import React from "react";
import MarketList from "./MarketList";
import MarketDetail from "./MarketDetail";
import Deploy from "./Deploy";
// import DockerDeploymentDetails from "../deployment/DockerDeploymentDetails";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: 1,
      selectedRowData: {},
      selectedNodeRowData: {}
    };
    this.triggleStatus = this.triggleStatus.bind(this);
  }

  triggleStatus(show) {
    this.setState({
      showRepository: show
    });
  }

  selectedRow(record) {
    this.setState({
      selectedRowData: record
    });
  }

  selectedNodeRow(buildnum, record) {
    this.setState({
      buildnum,
      selectedNodeRowData: record
    });
  }

  componentDidMount() {}

  render() {
    const { showRepository, selectedRowData, selectedNodeRowData, buildnum } = this.state;
    const { projectId, projectName } = this.props;
    return (
      <div>
        {showRepository == 1 ? (
          <MarketList
            projectId={projectId}
            selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository == 2 ? (
          <MarketDetail
            projectId={projectId}
            projectName={projectName}
            selectedRow={selectedRowData}
            selectedNodeRow={this.selectedNodeRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository == 3 ? (
          <Deploy
            projectId={projectId}
            selectedRow={selectedNodeRowData}
            buildnum={buildnum}
            triggleStatus={this.triggleStatus}
            key={Math.random()}
          />
        ) : (
          // <DockerDeploymentDetails
          //   projectId={projectId}
          //   deploymentName={"ddd"}
          //   selectedRow={this.state.selectedRowData}
          //   triggleStatus={this.triggleStatus}
          //   key={Math.random()}
          // />
          ""
        )}
      </div>
    );
  }
}

export default Index;
