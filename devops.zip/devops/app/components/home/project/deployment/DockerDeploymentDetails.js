import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Icon,
  Button,
  Form,
  message,
  Select,
  Modal,
  Row,
  Col,
  Steps,
  Tabs,
  Radio
} from "antd";
import "antd/dist/antd.css";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import Validation from "../../../../utils/Validation";
import "./deploy.css";

const Option = Select.Option;
const FormItem = Form.Item;
const Search = Input.Search;
const Step = Steps.Step;
const TabPane = Tabs.TabPane;
const RadioGroup = Radio.Group;

class DockerDeploymentDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showLog: false,
      current: 0
    };
    // 部署服务列信息
    this.columns = [
      {
        title: "名称",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "应用验证路径",
        dataIndex: "verifyUrl",
        key: "verifyUrl",
        render: (text, record) => {
          return (
            <div>
              <a href={`http://${record.verifyUrl}`} target="_blank" rel="noopener noreferrer">
                {record.verifyUrl}
              </a>
            </div>
          );
        }
      },
      {
        title: "查看日志",
        dataIndex: "action",
        key: "action",
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    //
    this.podColumns = [
      {
        title: "pod名称",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "状态",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "创建时间",
        dataIndex: "verifyUrl",
        key: "verifyUrl",
        render: (text, record) => {
          return (
            <div>
              <a href={record.verifyUrl} target="_blank" rel="noopener noreferrer">
                {record.verifyUrl}
              </a>
            </div>
          );
        }
      },
      {
        title: "查看日志",
        dataIndex: "action",
        key: "action",
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    this.deployStatusCode = "";
    this.deployServiceData = [
      {
        resName: "resName",
        resHostIp: "192.168.1.1",
        verifyUrl: "192.168.1.1"
      }
    ];
  }

  // 生命周期部分开始
  // 生命周期部分结束
  // 实例方法部分开始

  /**
   * 返回部署管理
   */
  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(1);
  }

  /**
   * 一键部署
   */
  oneKeyDeployClick() {}

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    if (column === "deployStatus" && text) {
      if (text === "FAILURE") {
        return (
          <div>
            <Icon
              className="padright"
              type="close-circle"
              style={{
                fontSize: 16,
                color: "#ff0000"
              }}
            />
            <span>失败</span>
          </div>
        );
      } else if (text === "SUCCESS") {
        return (
          <div>
            <Icon
              className="padright"
              type="check-circle"
              style={{
                fontSize: 16,
                color: "#00ff48"
              }}
            />
            <span>成功</span>
          </div>
        );
      } else if (text === "BUILDINGH") {
        return (
          <div>
            <Icon
              className="padright"
              type="clock-circle"
              style={{
                fontSize: 16,
                color: "#1890ff"
              }}
            />
            <span>部署中</span>
          </div>
        );
      }
    }
    if (column === "durationTime" && text) {
      return `${text / 1000}s`;
    }
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, type) {
    if (type === "log") {
      return (
        <div>
          <Icon
            type="file-text"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.showLogVisual.bind(this)}
          />
        </div>
      );
    } else if (type === "history") {
      return (
        <div>
          <Icon
            type="eye"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.openHistory.bind(this, record)}
          />
        </div>
      );
    }
  }

  /**
   * 获取pod组数据
   */
  getHistPodMethod() {}

  /**
   * 查看日志
   */
  showLogVisual() {
    this.setState({
      showLog: true
    });
  }

  /**
   * 关闭日志
   */
  closeLogVisual() {
    this.setState({
      showLog: false
    });
  }

  // 实例方法部分结束
  render() {
    const projectName = sessionStorage.getItem("projectName")
      ? sessionStorage.getItem("projectName")
      : "";
    const { deploymentName, duratime, detailsData, consoleData } = this.props;
    const { state } = this;
    return (
      <div>
        <div>
          <span style={{ cursor: "pointer" }} onClick={this.goBack.bind(this)}>
            返回
          </span>
          <span> / 部署管理</span>
        </div>
        <Row style={{ height: "370px", color: "white" }}>
          <Col span={6} style={{ background: "#454A65", height: "100%", padding: "20px" }}>
            <div style={{ fontSize: "22px" }}>{deploymentName}</div>
            <Row style={{ height: "160px" }}>
              <Col style={{ fontSize: "80px", color: "#ddd" }} span={6}>
                <Icon
                  type="check-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "SUCCESS" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="loading"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "BUILDINGH" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="close-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "FAILURE" ? "inline-block" : "none"
                  }}
                />
              </Col>
              <Col span={17} style={{ paddingTop: "20px" }}>
                <div style={{ textAlign: "center" }}>{this.status}</div>
                <div style={{ textAlign: "center" }}>
                  部署持续时间:
                  {duratime ? Number(duratime) / 1000 : ""}s
                </div>
                <div style={{ textAlign: "center", marginTop: "10px" }}>
                  <Button type="primary" ghost onClick={this.oneKeyDeployClick.bind(this)}>
                    一键部署
                  </Button>
                </div>
              </Col>
            </Row>
            <Row style={{ marginTop: "20px" }}>
              <Col>
                <div>创建时间：</div>
                <div>
                  {detailsData && detailsData.deployCreateTime ? detailsData.deployCreateTime : ""}
                </div>
              </Col>
              <Col style={{ marginTop: "10px" }}>
                <div>最近部署时间：</div>
                <div>{this.time ? this.time : ""}</div>
              </Col>
            </Row>
          </Col>
          <Col span={18} style={{ background: "#3A3E55", height: "100%", padding: "20px" }}>
            <div>
              <div style={{ fontSize: "18px" }}>部署进程</div>
              <Row style={{ padding: "20px" }} id="steps">
                <Col span={18}>
                  <Steps
                    // progressDot
                    // current={0}
                    size="small"
                    style={{ color: "white" }}
                    current={state.current}
                  >
                    <Step title="连接到部署引擎" />
                    <Step title="下载playbook" />
                    <Step title="下载安装包" />
                    <Step title="准备部署" />
                    <Step
                      title="正在部署"
                      style={{ display: state.isDeployed ? "none" : "inline-block" }}
                    />
                    <Step
                      title="正在部署"
                      style={{ display: state.isDeployed ? "inline-block" : "none" }}
                      icon={<Icon type="loading" />}
                    />
                    <Step title="部署完成" status={state.currentStatus} />
                  </Steps>
                </Col>
                {/* <Col span={6} style={{ textAlign: "right" }}>
                      <Button>执行参数</Button>
                    </Col> */}
              </Row>
            </div>
            <Row style={{ padding: "20px 10px 10px 0" }}>
              <Col span={12}>
                <div style={{ fontSize: "18px", marginBottom: "10px" }}>部署信息</div>
                <ul style={{ listStyle: "none", padding: "0" }}>
                  <li>
                    描述:
                    <span>
                      {detailsData && detailsData.deployDfDesc ? detailsData.deployDfDesc : ""}
                    </span>
                  </li>
                  <li>
                    项目：
                    <span>{projectName}</span>
                  </li>
                  <li>
                    部署类型：
                    <span>{this.deployType}</span>
                  </li>
                  <li>
                    部署介质：
                    <span>
                      {detailsData && detailsData.packageUrl ? detailsData.packageUrl : ""}
                    </span>
                  </li>
                </ul>
              </Col>
            </Row>
          </Col>
        </Row>
        <div style={{ fontSize: "20px", marginTop: "20px", marginBottom: "20px" }}>部署服务</div>
        <Table columns={this.columns} dataSource={this.deployServiceData} />
        <Tabs defaultActiveKey="1" onChange={this.getHistPodMethod.bind(this)}>
          <TabPane tab="部署日志" key="1">
            <div
              style={{
                maxHeight: 500,
                overflowY: "scroll"
              }}
            >
              <div dangerouslySetInnerHTML={{ __html: consoleData }} />
            </div>
          </TabPane>
          <TabPane tab="pod组" key="2">
            <Table
              columns={this.podColumns}
              pagination={false}
              dataSource={this.deployServiceData}
            />
          </TabPane>
        </Tabs>
        {/* 弹框部分开始 */}
        <Modal maskClosable={false}
          title="部署日志"
          visible={state.showLog}
          footer={null}
          width={1000}
          onCancel={this.closeLogVisual.bind(this)}
        >
          <div
            style={{
              maxHeight: 500,
              overflowY: "scroll"
            }}
          >
            <div dangerouslySetInnerHTML={{ __html: consoleData }} />
          </div>
        </Modal>
        {/* 弹框部分结束 */}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    consoleData: state.Deploy.get("consoleData")
  };
};
const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, DeploymentManageActions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DockerDeploymentDetails);
