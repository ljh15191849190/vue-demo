import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
// import {Table, Button, Form, Popconfirm} from "antd";
import {
  Table,
  Input,
  Icon,
  Button,
  Popconfirm,
  Form,
  message,
  Select,
  Row,
  Col,
  Modal,
  Radio,
  Spin
} from "antd";
import "antd/dist/antd.css";
import * as ComponentAction from "../../../../actions/ComponentList";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import * as mdactions from "../../../../actions/MediumWarehouse";
import * as ImageActions from "../../../../actions/ImageHouse";
import * as ResourceAction from "../../../../actions/Resource";
import Validation from "../../../../utils/Validation";

const Option = Select.Option;
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const Search = Input.Search;
// 容器部署预执行界面
const ExecuteContainerDeploy = Form.create()(props => {
  const { onCancel, form, handleSubmit, selectedRow, projectName, onOk } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 15 }
  };
  return (
    <Form layout="vertical" onSubmit={handleSubmit}>
      <FormItem label="项目名称:" {...formItemLayout}>
        {getFieldDecorator("projectName", {
          initialValue: projectName
        })(<Input readOnly />)}
      </FormItem>
      <FormItem label="部署镜像:" {...formItemLayout}>
        {getFieldDecorator("softWare", {
          // rules: Validation.Rule_select,
          initialValue: selectedRow.packageUrl
            ? selectedRow.packageUrl.substr(selectedRow.packageUrl.indexOf("/"))
            : ""
        })(<Input readOnly />)}
      </FormItem>
      <FormItem label="所属集群:" {...formItemLayout}>
        {getFieldDecorator("resIds", {
          // rules: Validation.Rule_select,
          initialValue: selectedRow.resIds
        })(<Input readOnly />)}
      </FormItem>
      <FormItem label="所属命名空间:" {...formItemLayout}>
        {getFieldDecorator("nameSpace", {
          initialValue: selectedRow.compName
        })(<Input readOnly />)}
      </FormItem>
      <FormItem style={{ textAlign: "right" }}>
        <Button type="primary" style={{ marginRight: "10px" }} onClick={onCancel.bind(this)}>
          取消
        </Button>
        <Button type="primary" onClick={onOk.bind(this)}>
          执行
        </Button>
      </FormItem>
    </Form>
  );
});
// shell部署预执行界面
const ExecuteDeploy = Form.create()(props => {
  const {
    onCancel,
    form,
    handleSubmit,
    hostColumns,
    onChangeSelect,
    selectedRow,
    hostData,
    scope,
    projectName,
    softBagList,
    ipsListData,
    onOk,
    getIpsListbyId
  } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 15 }
  };
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      scope.setState({
        selectedIps: selectedRows
      });
    },
    getCheckboxProps: record => ({
      disabled: record.name === "Disabled User",
      name: record.name
    })
  };
  return (
    <Form layout="vertical" onSubmit={handleSubmit}>
      <FormItem
        label="操作类型:"
        {...formItemLayout}
        style={{ display: selectedRow && selectedRow.deployStatus === "" ? "block" : "none" }}
      >
        {getFieldDecorator("tagName", {
          rules: [{ required: true, message: "标签名称不能为空", maxLength: 32 }],
          initialValue: "install"
        })(
          <RadioGroup>
            <Radio value="install">安装</Radio>
            {/* <Radio value={"uninstall"}> 卸载</Radio>
            <Radio value={"update"}>升级</Radio>
            <Radio value={"rollback"}>回滚</Radio> */}
          </RadioGroup>
        )}
      </FormItem>
      <FormItem label="项目名称:" {...formItemLayout}>
        {getFieldDecorator("projectName", {
          initialValue: projectName
        })(<Input readOnly />)}
      </FormItem>
      <FormItem label="软件包:" {...formItemLayout}>
        {getFieldDecorator("softWare", {
          rules: Validation.Rule_select,
          initialValue: selectedRow.packageUrl.substr(selectedRow.packageUrl.lastIndexOf(":") + 5)
        })(
          <Select allowClear onChange={onChangeSelect}>
            {softBagList
              ? softBagList.map(v => {
                  return (
                    <Option value={v.artifactUrl} key={v.id}>
                      {v.artifactUrl
                        ? v.artifactUrl.substr(v.artifactUrl.lastIndexOf(":") + 5)
                        : ""}
                    </Option>
                  );
                })
              : ""}
          </Select>
        )}
      </FormItem>
      <FormItem label="选择主机:">
        <Search
          // placeholder="input search text"
          onSearch={value => getIpsListbyId(value)}
          enterButton
          style={{ marginBottom: "10px" }}
        />
        <Table columns={hostColumns} rowSelection={rowSelection} dataSource={ipsListData} />
      </FormItem>
      <FormItem style={{ textAlign: "right" }}>
        <Button type="primary" style={{ marginRight: "10px" }} onClick={onCancel.bind(this)}>
          取消
        </Button>
        <Button type="primary" onClick={onOk.bind(this)}>
          执行
        </Button>
      </FormItem>
    </Form>
  );
});
class DeploymentManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {},
      page: 1,
      pageSize: 10,
      loading: false,
      showDeployPage: false,
      executeEnter: false,
      executeConainerEnter: false,
      selectedRow: {},
      selectedIps: [],
      deployDfName: "",
      deployName: "",
      showContainerDeployPage: false,
      showContainerDeployPageKey: 1,
      showDeployPageKey: 2
    };
    this.dataSource = [
      {
        deploymentName: "部署任务一",
        applicationName: "组件一",
        successRate: "0%",
        status: "未部署"
      }
    ];
    this.hostData = [
      {
        name: "deploy153535",
        ip: "114.115.134.190 ",
        hostGroup: "----"
      }
    ];
    this.hostColumns = [
      {
        title: "主机",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "主机组",
        dataIndex: "path",
        key: "path",
        render: (text, record) => {
          return "---";
        }
      }
    ];
    this.columns = [
      {
        title: "部署名称",
        dataIndex: "deployDfName",
        width: 150,
        render: (text, record) => {
          return (
            <div>
              {/* <a onClick={this.detailClick.bind(this, record)}>{text}</a> */}
              <a onClick={this.toEditDeploy.bind(this, record)}>{text}</a>
            </div>
          );
        }
      },
      {
        title: "组件",
        dataIndex: "applicationName",
        width: 100,
        render: (text, record) => this.renderColumns(text, record, "applicationName")
      },
      {
        title: "部署成功率",
        dataIndex: "successRate",
        width: 100,
        render: (text, record) => this.renderColumns(text, record, "successRate")
      },
      {
        title: "部署状态",
        dataIndex: "deployStatus",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "deployStatus")
      },
      {
        title: "平均执行时长",
        dataIndex: "durationTime",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "durationTime")
      },
      {
        title: "最近部署时间",
        dataIndex: "deployCreateTime",
        width: 150,
        render: (text, record) => this.renderColumns(text, record, "deployCreateTime")
      },
      {
        title: "操作",
        dataIndex: "action1",
        width: 150,
        render: (text, record) => this.renderActions(text, record, "action")
      }
    ];
    this.timer = null;
    this.timer2 = null;
  }

  // 钩子函数部分
  componentDidMount() {
    const { actions } = this.props;
    this.query();
    actions.resetNameSpaceList();
    this.timer2 = setInterval(() => {
      const { deployDfName, deployType } = this.state;
      this.query(deployDfName, deployType);
    }, 3000);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
    clearInterval(this.timer2);
  }

  componentWillReceiveProps(nextProps) {
    const { actions, triggleStatus } = this.props;
    const { state } = this;
    if (nextProps.deleteFlag) {
      this.query();
    }
    if (nextProps.pageConfig) {
      actions.setCurrentpage(nextProps.pageConfig.page);
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          page: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.exception) {
      message.warning(nextProps.exception);
      this.setState(
        {
          executeEnter: false,
          executeConainerEnter: false
        },
        () => {
          actions.resetDepStatus();
        }
      );
    }
    if (nextProps.executeData && nextProps.executeFlag) {
      this.setState(
        {
          showDeployPage: false,
          showContainerDeployPage: false,
          executeEnter: false,
          executeConainerEnter: false
        },
        () => {
          if (state.selectedRow.deployPodTemplate && state.selectedRow.deployPodTemplate == 2) {
            actions.resetDepStatus();
            this.setState({
              selectedRow: ""
            });
          }
          if (state.selectedRow.deployPodTemplate && state.selectedRow.deployPodTemplate == 1) {
            triggleStatus(3, "normal", state.selectedRow);
          }
          if (state.selectedRow.deployPodTemplate && state.selectedRow.deployPodTemplate == 2) {
            triggleStatus(3, "normal", state.selectedRow);
          }
          if (!state.selectedRow.deployPodTemplate && state.selectedRow.deployType == 1) {
            triggleStatus(3, "normal", state.selectedRow);
          }
        }
      );
    }
    if (nextProps.defiantionListData.length > 0) {
      let filterData = [];
      filterData = nextProps.defiantionListData.filter(v => {
        return v.deployStatus && v.deployStatus === "BUILDINGH";
      });
      if (filterData && filterData.length > 0) {
        this.timer = setTimeout(() => {
          let sendData = [];
          filterData.forEach(item => {
            sendData = {
              id: item.id,
              defName: item.deployType == 2 ? item.compName : item.deployDfName,
              buildNum: item.lastBuildNum,
              instanceId: item.instanceId
            };
            actions.updateStatus(sendData);
          });
        }, 3000);
      } else {
        clearInterval(this.timer);
      }
    }
    if (nextProps.duratime) {
      actions.resetConsole();
    }
  }

  // 实例方法部分
  /**
   * 根据id查找主机列表
   */
  getIpsListbyId(values) {
    const { actions } = this.props;
    const { state } = this;
    actions.getIpsListbyId({
      id: state.selectedRow.id,
      param: values ? values : ""
    });
  }

  /**
   * 点击查询
   */
  clickQuery() {
    const { state } = this;
    const deployName = ReactDOM.findDOMNode(this.refs.deployName).value;
    const deployType = state.deployTypeSelect;
    this.setState({
      deployDfName: deployName,
      deployType
    });
    this.query(deployName, deployType, 1);
  }

  /**
   * 查询列表
   */
  query(deployDfName, deployType, page) {
    const { actions, currentPage, projectId } = this.props;
    const { state } = this;
    const conditions = [
      {
        name: "deployDfName",
        sopt: "like",
        value: deployDfName == undefined ? state.deployDfName : deployDfName
      },
      {
        name: "deployType",
        sopt: "eq",
        value: deployType == undefined ? state.deployType : deployType
      },
      { name: "projectId", sopt: "eq", value: projectId }
    ].filter(v => v.value);
    actions.definitionPageList({
      page: page ? page : currentPage ? currentPage : 1,
      size: state.pageSize,
      sortid: "id",
      sortvalue: "asc",
      conditions
    });
  }

  /**
   * shell执行部署
   */
  confirmDeploy() {
    const { actions, ipsList, passInIpsData, pageConfig } = this.props;
    const { state } = this;
    actions.setCurrentpage(pageConfig.page);
    if (state.selectedIps.length === 0) {
      message.warning("请选择主机！");
      return;
    }
    const form = this.refs["execute"];
    form.validateFields((err, values) => {
      if (!err) {
        this.setState({
          executeEnter: true
        });
        actions.executeDeployment({
          id: state.selectedRow.id,
          opsType: state.selectedRow.deployType,
          packageUrl: state.selectedRow.packageUrl,
          // tagName: values.tagName,
          deployOps: state.selectedRow ? "deploy" : "",
          resIds: state.selectedIps
            ? state.selectedIps
                .map(v => {
                  return v.resHostIp;
                })
                .join("-")
            : ""
        });
        passInIpsData(ipsList.list, ipsList.list);
        actions.updateHosts(state.selectedIps);
      }
    });
  }

  /**
   * 关闭shell执行部署
   */
  closeDeploy() {
    this.setState({
      showContainerDeployPage: false,
      showDeployPage: false,
      executeConainerEnter: false
    });
  }

  /**
   * 关闭容器执行部署
   */
  closeContainerDeploy() {
    this.setState({
      showContainerDeployPage: false,
      executeConainerEnter: false
    });
  }

  /**
   * 容器部署执行确认
   */
  confirmContainerDeploy() {
    const { actions, pageConfig } = this.props;
    const { state } = this;
    actions.setCurrentpage(pageConfig.page);
    const form = this.refs["executeContainer"];
    form.validateFields((err, values) => {
      if (!err) {
        this.setState({
          executeConainerEnter: true
        });
        actions.executeDeployment({
          id: state.selectedRow.id,
          opsType: state.selectedRow.deployType
        });
      }
    });
  }

  /**
   * 确认执行部署
   */
  handleSubmit() {}

  /**
   * 选择软件包
   *
   */
  onChangeSelect() {}

  /**
   * 新增任务
   */
  toNewDeploy() {
    const { triggleStatus } = this.props;
    triggleStatus(2, "create");
  }

  /**
   * 编辑任务
   */
  toEditDeploy(record) {
    const { triggleStatus, actions } = this.props;
    triggleStatus(2, "edit", record);
    // 请求接口便于打开的页面使用
    actions.findDefination(record.id);
  }

  /**
   * 选择部署类型
   */
  changeSelect(v) {
    this.setState({
      deployTypeSelect: v
    });
  }

  /**
   * 输入名称
   */
  changeName(e) {
    // this.setState({
    //   deployDfName: e.target.value
    // });
  }

  /**
   * 部署详情
   */
  detailClick(record) {
    const { triggleStatus } = this.props;
    triggleStatus(3, record);
  }

  // 时分秒
  formatDuring(mss) {
    if (mss) {
      const minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60), 10);
      const seconds = parseInt((mss % (1000 * 60)) / 1000, 10);
      const haoseconds = parseInt(mss % 1000, 10);
      return `${minutes}分钟-${seconds}秒-${haoseconds}毫秒`;
    } else {
      return "";
    }
  }

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    if (column === "applicationName") {
      return text == "undefined" ? "" : text;
    }
    if (column === "updateTime") {
      return record.lastBuildNum ? text : "";
    }
    if (column === "successRate") {
      return text ? `${text}%` : "";
    }
    if (column == "durationTime") {
      // text = this.formatDuring(text);
      return text ? `${text / 1000}s` : "";
    }
    if (column === "deployStatus" && text) {
      if (text === "FAILURE") {
        return (
          <div>
            <Icon
              className="padright"
              type="close-circle"
              style={{
                fontSize: 16,
                color: "#ff0000"
              }}
            />
            <span>失败</span>
          </div>
        );
      } else if (text === "SUCCESS") {
        return (
          <div>
            <Icon
              className="padright"
              type="check-circle"
              style={{
                fontSize: 16,
                color: "#00ff48"
              }}
            />
            <span>成功</span>
          </div>
        );
      } else if (text === "BUILDINGH") {
        return (
          <div>
            <Icon
              className="padright"
              type="clock-circle"
              style={{
                fontSize: 16,
                color: "#1890ff"
              }}
            />
            <span>部署中</span>
          </div>
        );
      }
    }
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, column) {
    return (
      <div>
        <div style={{ display: "flex", justifyContent: "flex-start" }}>
          <div>
            <a
              onClick={() => {
                this.openPerforme(record);
              }}
              className="padright"
            >
              <span />
              执行
            </a>
          </div>
          <div>
            <a
              style={{ margin: "0 10px" }}
              onClick={() => {
                this.openHistory(record);
              }}
            >
              历史
            </a>
          </div>
          <div>
            <Popconfirm
              title="确定删除?"
              okText="确认"
              cancelText="取消"
              onConfirm={() => this.deployDelete(record)}
            >
              <a>删除</a>
            </Popconfirm>
          </div>
        </div>
      </div>
    );
  }

  /**
   * 克隆
   */
  deployClone(record) {
    const { triggleStatus } = this.props;
    triggleStatus(2, "clone", record);
  }

  /**
   * 删除
   */
  deployDelete(record) {
    const { actions } = this.props;
    actions.deleteDefination(record.id);
  }

  /**
   * 历史
   */
  openHistory(record) {
    const { actions, triggleStatus, pageConfig } = this.props;
    actions.setCurrentpage(pageConfig.page);
    triggleStatus(4, "history", record);
  }

  /**
   * 执行
   */
  openPerforme(record) {
    const { actions, projectId } = this.props;
    const { state } = this;
    actions.resetDepStatus();
    if (record.deployType == "1") {
      this.setState({
        showDeployPage: true,
        selectedRow: record
      });
      actions.getIpsListbyId({ id: record.id, params: "" });
      // this.props.form.setFieldsValue({ projectName: this.props.projectName });
      const payload = {
        page: 1,
        conditions: [{}]
      };
      actions.findMedium(payload);
    } else if (record.deployType == "2") {
      this.setState({
        showContainerDeployPage: true,
        selectedRow: record,
        showDeployPageKey: state.showDeployPageKey + 1
      });
      actions.gethouseImageList({
        size: 1000,
        conditions: [
          {
            name: "projectCode",
            sopt: "eq",
            value: "common"
          }
        ]
      });
      actions.getClusterslistById({ projectId });
    }
  }

  /**
   * 分页操作
   */
  handlePageChange(page, pageSize) {
    const { actions, projectId } = this.props;
    const { state } = this;
    this.setState({
      loading: true,
      page,
      pageSize
    });
    actions.setCurrentpage(page);
    const conditions = [
      { name: "deployDfName", sopt: "eq", value: state.deployDfName },
      { name: "deployType", sopt: "eq", value: state.deployType },
      { name: "projectId", sopt: "eq", value: projectId }
    ].filter(v => v.value);
    actions.definitionPageList({
      page,
      size: pageSize,
      sortid: "id",
      sortvalue: "asc",
      conditions
    });
  }

  onShowSizeChange(current, pageSize) {
    const { actions, projectId } = this.props;
    const { state } = this;
    this.setState({
      current,
      pageSize
    });
    actions.setCurrentpage(current);
    const conditions = [
      { name: "deployDfName", sopt: "eq", value: state.deployDfName },
      { name: "deployType", sopt: "eq", value: state.deployType },
      { name: "projectId", sopt: "eq", value: projectId }
    ].filter(v => v.value);
    actions.definitionPageList({
      page: current,
      size: pageSize,
      sortid: "id",
      sortvalue: "asc",
      conditions
    });
  }

  render() {
    const {
      defiantionListData,
      projectId,
      projectName,
      softBagList,
      ipsList,
      houseimageData,
      clusterData,
      currentPage
    } = this.props;
    const { state } = this;
    const pagination = {
      total: state.pagination.total,
      pageSize: state.pagination.pageSize,
      current: currentPage,
      // showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange.bind(this),
      onChange: this.handlePageChange.bind(this)
    };
    return (
      <div>
        <Row style={{ marginTop: "10px", padding: "0 50px" }} type="flex">
          <Col span={6}>
            <span style={{ marginRight: 40 }}>名称:</span>
            <Input
              ref="deployName"
              style={{ width: "60%" }}
              onChange={this.changeName.bind(this)}
            />
          </Col>
          <Col span={6}>
            <span style={{ marginRight: 10 }}>部署类型：</span>
            <Select style={{ width: "50%" }} allowClear onChange={this.changeSelect.bind(this)}>
              <Option value="1" key="1">
                shell部署
              </Option>
              <Option value="2" key="2">
                容器部署
              </Option>
              {/* <Option value={"3"} key={"3"}>
                Ansible部署
              </Option> */}
            </Select>
          </Col>
          <Col span={11} style={{ textAlign: "right" }}>
            <Button type="primary" style={{ marginRight: 10 }} onClick={this.clickQuery.bind(this)}>
              查询
            </Button>
            <Button type="primary" onClick={this.toNewDeploy.bind(this)}>
              新增
            </Button>
          </Col>
        </Row>
        <Table
          style={{ marginTop: 20 }}
          columns={this.columns}
          dataSource={defiantionListData}
          // dataSource={this.dataSource}
          pagination={pagination}
          loading={state.loading}
          // onChange={this.handlePageChange.bind(this)}
        />
        {/* shell部署执行 */}
        <Modal
          maskClosable={false}
          title="执行部署"
          visible={state.showDeployPage}
          onOk={this.confirmDeploy.bind(this)}
          onCancel={this.closeDeploy.bind(this)}
          key={state.showDeployPageKey}
          okText="执行"
          cancelText="取消"
          width={800}
          footer={null}
        >
          <Spin spinning={state.executeEnter}>
            <ExecuteDeploy
              hostColumns={this.hostColumns}
              selectedRow={state.selectedRow}
              projectId={projectId}
              projectName={projectName}
              deploymentName={state.deploymentName}
              handleSubmit={this.handleSubmit.bind(this)}
              onChangeSelect={this.onChangeSelect.bind(this)}
              softBagList={softBagList}
              ipsListData={ipsList.list}
              onOk={this.confirmDeploy.bind(this)}
              onCancel={this.closeDeploy.bind(this)}
              getIpsListbyId={this.getIpsListbyId.bind(this)}
              scope={this}
              ref="execute"
            />
          </Spin>
        </Modal>
        {/* 容器部署执行 */}
        <Modal
          maskClosable={false}
          title="执行部署"
          visible={state.showContainerDeployPage}
          onOk={this.confirmContainerDeploy.bind(this)}
          onCancel={this.closeContainerDeploy.bind(this)}
          key={state.showContainerDeployPageKey}
          okText="执行"
          cancelText="取消"
          width={800}
          footer={null}
        >
          <Spin spinning={state.executeConainerEnter}>
            <ExecuteContainerDeploy
              scope={this}
              projectId={projectId}
              projectName={projectName}
              houseimageData={houseimageData}
              clusterData={clusterData}
              deploymentName={state.deploymentName}
              selectedRow={state.selectedRow}
              onOk={this.confirmContainerDeploy.bind(this)}
              onCancel={this.closeContainerDeploy.bind(this)}
              ref="executeContainer"
            />
          </Spin>
        </Modal>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    defiantionListData: state.Deploy.get("defiantionListData"),
    deleteFlag: state.Deploy.get("deleteFlag"),
    deployStatus: state.Deploy.get("deployStatus"),
    ipsList: state.Deploy.get("ipsList"),
    executeFlag: state.Deploy.get("executeFlag"),
    executeData: state.Deploy.get("executeData"),
    exception: state.Deploy.get("exception"),
    softBagList: state.MediumWarehouse.get("resData"),
    deployStatusCode: state.Deploy.get("deployStatusCode"),
    detailsData: state.Deploy.get("detailsData"),
    pageConfig: state.Deploy.get("pageConfig"),
    clusterData: state.Resource.get("clusterData"),
    houseimageData: state.ImageHouse.get("houseimageData"),
    currentPage: state.Deploy.get("currentPage"),
    duratime: state.Deploy.get("duratime"),
    nameSpacePodData: state.Resource.get("nameSpacePodData")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign(
    {},
    mdactions,
    DeploymentManageActions,
    ImageActions,
    ResourceAction
  );
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DeploymentManage);
