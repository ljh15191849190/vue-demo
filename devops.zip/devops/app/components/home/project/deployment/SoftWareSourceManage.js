import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Form,
  Input,
  Radio,
  Select,
  Button,
  Row,
  Col,
  Table,
  Modal,
  Popconfirm,
  message,
  Icon
} from "antd";
import "antd/dist/antd.css";
import * as ComponentAction from "../../../../actions/ComponentList";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import * as BuildActions from "../../../../actions/build/BuildManage";
import * as mdactions from "../../../../actions/MediumWarehouse";

const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;
const Search = Input.Search;

class SoftWareSourceManage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectSource: 1,
      selectedRows: []
    };
    this.fileObj = "";
    this.columns = [
      {
        title: "软件包名称",
        dataIndex: "artifactName",
        render: (text, record) => this.renderColumns(text, record, "artifactName")
      },
      {
        title: "软件包版本",
        dataIndex: "artifactVersion",
        render: (text, record) => this.renderColumns(text, record, "artifactVersion")
      },
      {
        title: "软件包路径",
        dataIndex: "artifactUrl",
        render: (text, record) => {
          if (record.artifactUrl) {
            const filePath = record.artifactUrl;
            const index = filePath.indexOf("/");
            const extention = filePath.substr(index + 1);
            return extention;
          }
        }
      },
      {
        title: "软件包类型",
        dataIndex: "status",
        render: (text, record) => {
          if (record.artifactUrl) {
            const filePath = record.artifactUrl;
            const index = filePath.lastIndexOf(".");
            const extention = filePath.substr(index + 1);
            return extention;
          }
        }
      }
    ];
  }

  // 钩子函数部分开始
  componentDidMount() {
    this.query();
  }

  componentWillReceiveProps(nextProps) {
    // if (nextProps.uploadSoftFlag) {
    //   message.info("上传成功");
    // }
  }

  query(values) {
    const { actions } = this.props;
    const payload = {
      page: 1,
      conditions: [{ name: "artifactName", sopt: "cn", value: values }]
    };
    actions.findMedium(payload);
  }

  // 钩子函数部分结束
  // 实例方法部分开始
  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    return text;
  }

  /**
   * 提交表单
   */
  handleSubmit(e) {
    const { onOk } = this.props;
    const { selectedRows } = this.state;
    e.preventDefault();
    onOk(selectedRows);
  }

  upload(e) {
    e.preventDefault();
    const fileObj = this.fileObj;
    if (fileObj.size >= 204800000) {
      message.info("上传文件不能超过200M");
      return;
    }
    const { form, actions, projectName, projectId } = this.props;
    form.validateFields((err, values) => {
      if (!err) {
        const formData = new FormData();
        formData.append("file", fileObj);
        const index = fileObj.name.lastIndexOf(".");
        const extention = fileObj.name.substr(index + 1);
        values.groupid = projectName;
        values.projectId = projectId;
        values.repName = "3rd-part";
        values.alliasName = fileObj.name.substring(0, fileObj.name.lastIndexOf("."));
        values.artifactId = fileObj.name.substring(0, fileObj.name.lastIndexOf("."));
        values.extension = extention;
        values.file = formData;
        actions.uploadSoft(values);
      }
    });
  }

  /**
   * 选择软件包来源
   */
  changeSource(e) {
    this.setState({
      selectSource: e.target.value
    });
    this.query();
  }

  /**
   * 上传文件
   */
  fileUpload(e) {
    this.fileObj = e.target.files[0];
  }

  /**
   * 验证上传格式
   */
  handleConfirm(rule, value, callback) {
    if (value) {
      const index = value.lastIndexOf(".");
      const extention = value.substr(index + 1);
      if (extention != "jar" && extention != "war" && extention != "zip") {
        callback("请上传jar,war,zip格式的文件,文件不超过200M");
      }
      callback();
    }
  }

  // 实例方法部分结束
  render() {
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 4 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 20 }
      }
    };
    const { props, state } = this;
    const { getFieldDecorator } = props.form;
    const source = 1;
    const rowSelection = {
      type: "radio",
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({
          selectedRows
        });
      },
      getCheckboxProps: record => ({
        disabled: record.name === "Disabled User", // Column configuration not to be checked
        name: record.name
      })
    };
    return (
      <div>
        <Form>
          <FormItem label="项目:" {...formItemLayout}>
            {getFieldDecorator("stageTpId", {
              rules: [
                {
                  required: true
                }
              ],
              initialValue: props.projectName
            })(<Input disabled />)}
          </FormItem>
          <FormItem {...formItemLayout} label="软件包来源：">
            {getFieldDecorator("source", {
              initialValue: source,
              rules: [
                {
                  required: true,
                  message: "请选择软件包来源"
                }
              ]
            })(
              <RadioGroup onChange={this.changeSource.bind(this)}>
                <Radio value={1}>发布仓库</Radio>
                <Radio value={2}>本地上传</Radio>
              </RadioGroup>
            )}
          </FormItem>
          <FormItem
            {...formItemLayout}
            label="软件包："
            style={{
              display: props.form.getFieldValue("source") === 1 ? "block" : "none"
            }}
          >
            {getFieldDecorator("softWare", {
              rules: [
                {
                  required: false,
                  message: "请选择软件包"
                  // validator: this.handleConfirm
                }
              ]
            })(
              <div>
                <Search
                  placeholder="
                  请输入关键字，按enter键搜索"
                  onSearch={value => this.query(value)}
                />
                <div style={{ height: "400px", overflowY: "auto" }}>
                  <Table
                    width={500}
                    columns={this.columns}
                    dataSource={props.resData}
                    pagination={false}
                    rowSelection={rowSelection}
                  />
                </div>
              </div>
            )}
          </FormItem>
          <FormItem
            {...formItemLayout}
            label="软件包："
            style={{
              display: props.form.getFieldValue("source") === 2 ? "block" : "none"
            }}
          >
            {getFieldDecorator("softWareBag", {
              rules: [
                {
                  required: true,
                  validator: this.handleConfirm,
                  message: "请上传jar,war,zip格式的文件"
                }
              ]
            })(
              <Input
                className="deploy-searh-input-img"
                type="file"
                // title="上传介质"
                onChange={this.fileUpload.bind(this)}
              />
            )}
          </FormItem>
          <div
            style={{
              display: props.form.getFieldValue("source") === 2 ? "block" : "none",
              textAlign: "center"
            }}
          >
            <Button type="primary" onClick={this.upload.bind(this)}>
              上传
            </Button>
          </div>
          <div
            style={{
              textAlign: "center",
              display: props.form.getFieldValue("source") === 1 ? "block" : "none"
            }}
          >
            <Button style={{ marginRight: "10px" }} onClick={props.onCancel.bind(this)}>
              取消
            </Button>
            <Button type="primary" onClick={this.handleSubmit.bind(this)}>
              确定
            </Button>
          </div>
        </Form>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.MediumWarehouse.get("resData"),
    uploadSoftFlag: state.MediumWarehouse.get("uploadSoftFlag")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, mdactions, DeploymentManageActions, BuildActions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
const SoftWareSourceManageFrom = Form.create()(SoftWareSourceManage);
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SoftWareSourceManageFrom);
