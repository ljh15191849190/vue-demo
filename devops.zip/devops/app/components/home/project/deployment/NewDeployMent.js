import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Icon,
  Button,
  Popconfirm,
  Form,
  message,
  Select,
  Modal,
  Row,
  Col,
  Checkbox,
  InputNumber,
  Divider,
  Radio,
  Spin,
  Switch
} from "antd";
import "antd/dist/antd.css";
import MonacoEditor from "react-monaco-editor";
import * as ComponentAction from "../../../../actions/ComponentList";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import * as ImageActions from "../../../../actions/ImageHouse";
import * as ResourceAction from "../../../../actions/Resource";
import * as EnvAction from "../../../../actions/Environment";
import CodeViewer from "../../../commons/CodeViewer";
import SoftWareSourceManageFrom from "./SoftWareSourceManage";
import Validation from "../../../../utils/Validation";
import CodeMirror from "../../../commons/CodeMirror/codemirroe";

const Option = Select.Option;
const FormItem = Form.Item;
const { TextArea } = Input;
const Search = Input.Search;
const RadioGroup = Radio.Group;

class NewDeployMent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      envType: "",
      type: "shell",
      hostData: [],
      showSettings: false,
      showMirrorSettings: false,
      variableData: [],
      portData: [],
      envVarData: [],
      memoryData: [
        {
          volumeName: "timezone",
          volumeHostPath: "/etc/localtime",
          volumeContainerPath: "/etc/localtime"
        }
      ],
      selectSoftWareSource: false,
      softWareKey: 1,
      addHostKey: 222,
      addHostVisual: false,
      selectedHostData: [],
      selectedRowKeys: [],
      selectedHostRowKeys: [],
      showHostData: [],
      refreshDom: 888,
      httpMethods: "",
      ipAddress: "",
      fileName: "",
      deployType: "1",
      deployMode: "1",
      envContent: {},
      showRunningEnvOps: 0,
      expandable: null,
      showLoadOptions: "ClusterIP",
      deploymentLivenessprobe: false,
      deploymentHpaMin: "1",
      deploymentHpaMax: "10",
      namespaceId: "",
      clusterId: "",
      selectCluster: {},
      applicationName: "",
      applicationCode: "",
      selectedApp: {},
      spin: true,
      saveLoading: false
    };
    this.deployStyle = "mirror";
    this.deployEnvType = "";
    this.serviceType = "ClusterIP";
    this.deploymentHpaTrigger = "30";
    this.deploymentReplicas = "1";
    this.deploymentHpaStepsize = "1";
    this.formContentByDeployType = "";
    this.loadStyleDom = "";
    this.avaliblePortNameStatus = true;
    this.avalibletargetPortStatus = true;
    this.avalibleclusterPortStatus = true;
    this.avaliblePortName = false;
    this.avalibletargetPort = false;
    this.avalibleclusterPort = false;
    this.maxStep = "";
    this.rules = {
      portNameRex: /^(?!_)[a-zA-Z_]+$/,
      targetPortRex: /^[1-9]$|(^[1-9][0-9]$)|(^[1-9][0-9][0-9]$)|(^[1-9][0-9][0-9][0-9]$)|(^[1-6][0-5][0-5][0-3][0-5]$)/,
      clusterPortRex: /^[1-9]$|(^[1-9][0-9]$)|(^[1-9][0-9][0-9]$)|(^[1-9][0-9][0-9][0-9]$)|(^[1-6][0-5][0-5][0-3][0-5]$)/
    };
    this.dockerPortColumns = [
      {
        title: "名称",
        dataIndex: "portName",
        key: "portName",
        render: (text, record, index) => {
          return (
            <FormItem validateStatus={this.avaliblePortNameStatus}>
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeDockerColumns.bind(this, text, record, "portName", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? this.rules["portNameRex"].test(text)
                      ? ""
                      : "请输入字母、下划线，不能以下划线开头"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "容器端口",
        dataIndex: "targetPort",
        key: "targetPort",
        render: (text, record, index) => {
          return (
            <FormItem validateStatus={this.avalibletargetPortStatus}>
              <Input
                // autoFocus
                value={text}
                // maxLength={32}
                onChange={this.onchangeDockerColumns.bind(this, text, record, "targetPort", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text ? (this.rules["targetPortRex"].test(text) ? "" : "请输入正确的端口号") : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "端口",
        dataIndex: "clusterPort",
        key: "clusterPort",
        render: (text, record, index) => {
          return (
            <FormItem validateStatus={this.avalibleclusterPortStatus}>
              <Input
                value={text}
                // maxLength={32}
                onChange={this.onchangeDockerColumns.bind(this, text, record, "clusterPort", index)}
              />
              <span style={{ color: "red" }}>
                {text !== ""
                  ? this.rules["clusterPortRex"].test(text)
                    ? ""
                    : "请输入正确的端口号"
                  : ""}
              </span>
            </FormItem>
          );
        }
      },
      {
        title: "协议",
        dataIndex: "serviceProtocol",
        key: "serviceProtocol",
        render: (text, record, index) => {
          return (
            <FormItem>
              <Select
                maxLength={32}
                style={{ width: 120 }}
                value={text}
                onChange={this.onchangeDockerColumns.bind(
                  this,
                  text,
                  record,
                  "serviceProtocol",
                  index
                )}
              >
                <Option value="TCP">TCP</Option>
                {/* <Option value="UDP">UDP</Option> */}
              </Select>
              {/* <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeDockerColumns.bind(
                  this,
                  text,
                  record,
                  "serviceProtocol",
                  index
                )}
              /> */}
            </FormItem>
          );
        }
      },
      {
        title: "操作",
        dataIndex: "action1",
        key: "action1",
        render: (text, record, index) => this.renderPortActions(text, record, index)
      }
    ];
    this.envVarColumns = [
      {
        title: "变量名称",
        dataIndex: "envName",
        key: "envName",
        render: (text, record, index) => {
          return (
            <FormItem>
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeEnvColumns.bind(this, text, record, "envName", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? this.rules["portNameRex"].test(text)
                      ? ""
                      : "请输入字母、下划线，不能以下划线开头"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "变量值",
        dataIndex: "envValue",
        key: "envValue",
        render: (text, record, index) => {
          return (
            <FormItem>
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeEnvColumns.bind(this, text, record, "envValue", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== "" ? (/^[^-]+$/.test(text) ? "" : "不能以中划线开头") : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "操作",
        dataIndex: "action1",
        key: "action1",
        render: (text, record, index) => this.renderEnvActions(text, record, index)
      }
    ];
    this.memoryColumns = [
      {
        title: "数据卷名",
        dataIndex: "volumeName",
        key: "volumeName",
        render: (text, record, index) => {
          return (
            <FormItem>
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeMemoryColumns.bind(this, text, record, "volumeName", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? /^(?!_)[a-zA-Z_]+$/.test(text)
                      ? ""
                      : "请输入字母、下划线，不能以下划线开头"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "主机路径",
        dataIndex: "volumeHostPath",
        key: "volumeHostPath",
        render: (text, record, index) => {
          return (
            <FormItem>
              <Input
                value={text}
                maxLength={256}
                onChange={this.onchangeMemoryColumns.bind(
                  this,
                  text,
                  record,
                  "volumeHostPath",
                  index
                )}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? /^\/[^\u4e00-\u9fa5]+$/.test(text)
                      ? ""
                      : "请输入非中文，必须以/开头"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "容器路径",
        dataIndex: "volumeContainerPath",
        key: "volumeContainerPath",
        render: (text, record, index) => {
          return (
            <Form>
              <FormItem>
                <Input
                  value={text}
                  maxLength={256}
                  onChange={this.onchangeMemoryColumns.bind(
                    this,
                    text,
                    record,
                    "volumeContainerPath",
                    index
                  )}
                />
                {
                  <span style={{ color: "red" }}>
                    {text !== ""
                      ? /^\/[^\u4e00-\u9fa5]+$/.test(text)
                        ? ""
                        : "请输入非中文，必须以/开头"
                      : ""}
                  </span>
                }
              </FormItem>
            </Form>
          );
        }
      },
      {
        title: "操作",
        dataIndex: "action1",
        key: "action1",
        render: (text, record, index) => this.renderMemoryActions(text, record, index)
      }
    ];
    this.hostColumns = [
      {
        title: "主机名",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "主机组",
        dataIndex: "path",
        key: "path",
        render: (text, record) => {
          return "---";
        }
      }
    ];
    this.columns = [
      {
        title: "序号",
        dataIndex: "order",
        key: "order"
      },
      {
        title: "主机组",
        dataIndex: "definitionName1",
        key: "definitionName1",
        render: (text, record) => {
          return "---";
        }
      },
      {
        title: "主机名",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "操作",
        dataIndex: "action1",
        key: "action1",
        render: (text, record, index) => this.renderActions(text, record, index)
      }
    ];
    this.varColumns = [
      // {
      //   title: "序号",
      //   dataIndex: "order"
      // },
      {
        title: "Key",
        dataIndex: "attrKey",
        render: (text, record, index) => {
          return (
            <FormItem
              validateStatus={text !== "" && (/^[a-zA-Z0-9_ ]+$/.test(text) ? "success" : "error")}
            >
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeKey.bind(this, text, record, "attrKey", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? /^[a-zA-Z0-9_ ]+$/.test(text)
                      ? ""
                      : "请输入字母，数字，下划线"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "Value",
        dataIndex: "attrValue",
        render: (text, record, index) => {
          return (
            <FormItem
              validateStatus={
                text !== "" && (/^[0-9a-zA-Z-_:/\u4e00-\u9fa5]*$/.test(text) ? "success" : "error")
              }
            >
              <Input
                value={text}
                maxLength={32}
                onChange={this.onchangeValue.bind(this, text, record, "attrValue", index)}
              />
              {
                <span style={{ color: "red" }}>
                  {text !== ""
                    ? /^[0-9a-zA-Z-_:/\u4e00-\u9fa5]*$/.test(text)
                      ? ""
                      : "请输入中文，字母，数字，-_:/"
                    : ""}
                </span>
              }
            </FormItem>
          );
        }
      },
      {
        title: "描述",
        dataIndex: "attrDesc",
        render: (text, record, index) => {
          return (
            <Input
              value={text}
              maxLength={128}
              onChange={this.onchangeDesc.bind(this, text, record, "attrDesc", index)}
            />
          );
        }
      },
      {
        title: "操作",
        dataIndex: "action1",
        render: (text, record, index) => this.renderParamsActions(text, record, index)
      }
    ];
    this.softUrl = "";
    // this.resIds = "";
    this.deployType = "1";
    this.firstclick = false;
    this.firstRender = false;
    this.firstResId = false;
    this.firstEnv = false;
    this.firstHost = false;
    this.firstYml = false;
    this.changeReplicasFlag = false;
    this.defaultHttp = "";
    this.defaultUrl = "";
    this.defaultFileName = "";
    this.envContent = {};
  }

  // 钩子函数部分
  componentDidMount() {
    const { state, props } = this;
    const { actions, projectId, projectCode, editType, id } = props;
    // 获取组件信息
    actions.getComponentList({
      projectId,
      page: 1,
      size: 100,
      sortid: "id",
      sortvalue: "desc",
      conditions: []
    });
    // 获取shell脚本
    actions.getShellContent({});
    // 获取镜像内容
    actions.getImageList({
      projectCode
    });
    // 根据projectid获取集群信息
    actions.getClusterslistById({ projectId });
    // 获取yml文件
    actions.findDeployYmlTmp({ type: state.type });
    // 获取应用市场信息
    this.getMarketList();
    // fetch("./DelployShell.sh").then(res => {
    //   console.log("resres", res);
    // });
    if (editType !== "create") {
      actions.findDefination(id);
    }
    // 获取运行环境
    actions.getRunningEnvList({
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "asc",
      conditions: [{}]
    });
    // 获取环境类型
    actions.getEnvironment({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        }
      ]
    });
  }

  componentWillUpdate(nextProps, nextState) {}

  componentWillReceiveProps(nextProps) {
    const { state, props } = this;
    const { actions, form } = props;
    if (nextProps.envFlag) {
      this.setState({
        saveLoading: false
      });
      actions.resetEnvError();
    }
    if (
      nextProps.editType !== "create" &&
      nextProps.detailsData &&
      nextProps.detailsData.data &&
      !this.firstEnv
    ) {
      form.setFieldsValue({
        installRuntimeEnv: Boolean(nextProps.detailsData.data.installRuntimeEnv)
      });
      this.setState({
        envType: nextProps.detailsData.data.compName,
        showRunningEnvOps: nextProps.detailsData.data.installRuntimeEnv,
        envContent: {
          compCode: nextProps.detailsData.data.compCode,
          compIcon: nextProps.detailsData.data.compIcon,
          compId: nextProps.detailsData.data.compId,
          compName: nextProps.detailsData.data.compName,
          compType: nextProps.detailsData.data.compType
        }
      });
      this.firstEnv = true;
    }
    if (nextProps.saveFlag == 1 || nextProps.updateFlag == 1 || nextProps.cloneFlag == 1) {
      this.setState({
        spin: false,
        saveLoading: false
      });
      this.goBack();
      actions.resetDepStatus();
    }
    if (nextProps.saveFlag == 2 || nextProps.updateFlag == 2) {
      this.setState({
        spin: false,
        saveLoading: false
      });
    }
    if (nextProps.ymlTmpData && !this.firstYml) {
      this.ymlTmpData = nextProps.ymlTmpData;
      this.firstYml = true;
    }
    if (nextProps.editType == "create") {
      this.setState({
        spin: false
      });
    }
    if (
      nextProps.editType !== "create" &&
      Object.keys(nextProps.detailsData).length > 0 &&
      !this.firstclick
    ) {
      if (nextProps.detailsData && Object.keys(nextProps.detailsData).length > 0) {
        const dataFlag = nextProps.detailsData && nextProps.detailsData.container;
        if (
          nextProps.detailsData.data &&
          Object.keys(nextProps.detailsData.data).length > 0 &&
          nextProps.detailsData.data.deployPodTemplate !== undefined
        ) {
          this.setState({
            deployMode: nextProps.detailsData.data.deployPodTemplate
              ? nextProps.detailsData.data.deployPodTemplate
              : ""
          });
        }
        if (nextProps.envData && nextProps.envData.length > 0) {
          const deployEnvType = nextProps.detailsData.data
            ? nextProps.detailsData.data.deployEnvType
            : "";
          this.setState({
            envId: deployEnvType
          });
        }
        this.setState({
          hostData: nextProps.detailsData.ips,
          spin: false,
          saveLoading: false,
          showMirrorSettings:
            nextProps.detailsData &&
            nextProps.detailsData.data &&
            nextProps.detailsData.data.packageUrl
              ? true
              : false,
          applicationCode:
            nextProps.detailsData &&
            nextProps.detailsData.data &&
            nextProps.detailsData.data.applicationCode
              ? nextProps.detailsData.data.applicationCode
              : "",
          applicationId:
            nextProps.detailsData && nextProps.detailsData.data && nextProps.detailsData.data.appId
              ? nextProps.detailsData.data.appId
              : "",
          applicationName:
            nextProps.detailsData.data && nextProps.detailsData.data.applicationName
              ? nextProps.detailsData.data.applicationName
              : "",
          namespaceId: dataFlag ? nextProps.detailsData.container.namespaceId : "",
          // imageTagId: dataFlag ? nextProps.detailsData.container.imageTagId : "",
          showLoadOptions:
            nextProps.detailsData && nextProps.detailsData.service
              ? nextProps.detailsData.service.serviceType
              : "",
          deployType:
            nextProps.detailsData && nextProps.detailsData.data
              ? nextProps.detailsData.data.deployType
              : "",
          clusterId: dataFlag ? nextProps.detailsData.container.clusterId : "",
          deploymentLimitCpu: dataFlag ? nextProps.detailsData.container.deploymentLimitCpu : "",
          deploymentLimitMem: dataFlag ? nextProps.detailsData.container.deploymentLimitMem : "",
          deploymentRequestCpu: dataFlag
            ? nextProps.detailsData.container.deploymentRequestCpu
            : "",
          deploymentRequestMem: dataFlag
            ? nextProps.detailsData.container.deploymentRequestMem
            : "",
          deploymentClusterIp: dataFlag ? nextProps.detailsData.container.deploymentClusterIp : "",
          clusterVipIp: nextProps.detailsData.service
            ? nextProps.detailsData.service.serviceClusterIp
            : "",
          deploymentHpaMin: dataFlag ? nextProps.detailsData.container.deploymentHpaMin : "",
          deploymentHpaMax: dataFlag ? nextProps.detailsData.container.deploymentHpaMax : "",
          deploymentLivenessprobe: dataFlag
            ? nextProps.detailsData.container.deploymentLivenessprobe
            : "",
          clusterIngressVipIp: nextProps.detailsData.route
            ? nextProps.detailsData.route.clusterIngressVipIp
            : ""
        });
      }
      if (nextProps.detailsData.env) {
        const envData = nextProps.detailsData.env.map(v => {
          return {
            envName: v.envName,
            envValue: v.envValue
          };
        });
        this.setState({
          envVarData: envData
        });
      }
      if (nextProps.detailsData.port) {
        const portData = nextProps.detailsData.port.map(v => {
          return {
            portName: v.portName,
            clusterPort: v.clusterPort,
            targetPort: v.targetPort,
            serviceProtocol: v.serviceProtocol
          };
        });
        this.setState({
          portData
        });
      }
      if (nextProps.detailsData.volume) {
        const memoryData = nextProps.detailsData.volume.map(v => {
          return {
            volumeName: v.volumeName,
            volumeHostPath: v.volumeHostPath,
            volumeContainerPath: v.volumeContainerPath,
            deploymentId: v.deploymentId
          };
        });
        this.setState({
          memoryData
        });
      }
      this.envContent = {
        compCode: nextProps.detailsData.compCode,
        compIcon: nextProps.detailsData.compIcon,
        compId: nextProps.detailsData.compId,
        compName: nextProps.detailsData.compName,
        compType: nextProps.detailsData.compType
      };
      if (nextProps.editType !== "create") {
        this.setState({
          variableData: nextProps.attr
        });
      }
      switch (nextProps.detailsData.deployType) {
        case 1:
          this.setState({
            type: "shell"
          });
          break;
        case 2:
          this.setState({
            type: "container"
          });
          break;
        case 3:
          this.setState({
            type: "ansible"
          });
          break;
        default:
          break;
      }
      this.firstclick = true;
    }
  }

  // 实例方法部分
  changeEnv(v, option) {
    const { state, props } = this;
    const { form } = props;
    this.setState({
      envId: option && option.key ? option.key : "",
      hostData: [],
      showHostData: [],
      selectedHostData: [],
      selectedRowKeys: [],
      selectedHostRowKeys: []
    });
    this.clusterName = "";
    this.namespaceName = "";
    form.setFieldsValue({ clusterName: "", namespaceName: "" });
    this.setState({
      clusterId: "",
      selectCluster: {},
      clusterIngressVipIp: "",
      deploymentClusterIp: "",
      clusterVipIp: "",
      namespaceId: "",
      deploymentLimitCpu: "",
      deploymentLimitMem: "",
      deploymentRequestCpu: "",
      deploymentRequestMem: ""
    });
  }

  /**
   *  获取应用市场信息
   */
  getMarketList(marketAppName) {
    const { actions } = this.props;
    actions.getmarketAppList({
      page: 1,
      marketAppType: marketAppName ? marketAppName : "All"
    });
  }

  /**
   * 返回部署管理
   */
  goBack() {
    const { actions, triggleStatus } = this.props;
    actions.resetDepStatus();
    actions.resetDetails();
    triggleStatus(1);
  }

  /**
   * 根据部署类型判断对应的表格dom
   */
  renderByDeployType() {
    const { props, state } = this;
    const { form } = props;
    const { getFieldDecorator } = form;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 17 }
    };
    const containerLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 16 }
    };
    const urlyLayout = {
      labelCol: { span: 8 },
      wrapperCol: { span: 15 }
    };
    // 获取表格数据源
    const { variableData, portData, envVarData, memoryData, selectedHostRowKeys } = this.state;
    const deployType = String(this.deployType);
    const rowHostSelection = {
      selectedRowKeys: selectedHostRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({
          showHostData: selectedRows,
          selectedHostRowKeys: selectedRowKeys
        });
      }
    };
    switch (deployType) {
      case "1":
        this.formContentByDeployType = (
          <div>
            <FormItem label="运行环境" {...formItemLayout}>
              <Checkbox
                onChange={this.installEnvChange.bind(this)}
                checked={this.installRuntimeEnv}
              >
                是否安装运行环境
              </Checkbox>
              <Row key={Math.random()}>
                {this.installRuntimeEnv && props.runningEnvList.length > 0
                  ? props.runningEnvList.map((v, i) => {
                      return (
                        <div key={Math.random()}>
                          <Col span={4}>
                            <Row
                              style={{
                                height: "82px",
                                textAlign: "center",
                                border:
                                  state.envType === v.compName
                                    ? "2px solid    #9932CC"
                                    : "1px solid #ccc",
                                cursor: "pointer",
                                margin: "0 10px",
                                marginBottom: "10px"
                              }}
                              onClick={this.selectRunningEnv.bind(this, v)}
                            >
                              <Col>
                                <img src="/images/img/shell.jpg" alt="" />
                              </Col>
                              <Col style={{ textAlign: "center" }}>
                                <span>{v.compName}</span>
                              </Col>
                            </Row>
                          </Col>
                        </div>
                      );
                    })
                  : ""}
              </Row>
            </FormItem>
            <FormItem label="选择软件包" {...formItemLayout}>
              {getFieldDecorator("packageUrl", {
                rules: Validation.Rule_select,
                initialValue: this.softUrl
              })(
                <Input
                  readOnly
                  addonAfter={
                    <div>
                      <Icon
                        onClick={this.openSoftWareSource.bind(this)}
                        type="cloud-upload"
                        theme="outlined"
                        style={{ fontSize: "25px", color: "#999", cursor: "pointer" }}
                      />
                      <Divider
                        type="vertical"
                        style={{
                          fontSize: "20px",
                          display: this.softUrl ? "inline-block" : "none"
                        }}
                      />
                      <Icon
                        onClick={this.deleteSoftWareSource.bind(this)}
                        type="delete"
                        theme="outlined"
                        style={{
                          fontSize: "25px",
                          color: "#999",
                          cursor: "pointer",
                          display: this.softUrl ? "inline-block" : "none"
                        }}
                      />
                    </div>
                  }
                />
                // <div>
                //   {this.softUrl}
                //   {/* <Row>
                //   <Col
                //     span={21}
                //     style={{background: "#e4e4e4", marginRight: "5px", paddingLeft: "10px"}}
                //   >
                //     软件包路径
                //   </Col>
                //   <Col
                //     span={2}
                //     style={{textAlign: "center", fontSize: "20px", background: "#e4e4e4"}}
                //   >
                //     <Icon type="plus" theme="outlined" style={{cursor: "pointer"}} />
                //   </Col>
                // </Row> */}
                // </div>
              )}
            </FormItem>
            <FormItem label="环境类型" {...formItemLayout}>
              {getFieldDecorator("deployEnvType", {
                rules: Validation.Rule_envType,
                initialValue: this.deployEnvType ? Number(this.deployEnvType) : ""
              })(
                <Select style={{ width: "50%" }} allowClear onChange={this.changeEnv.bind(this)}>
                  {props.envData
                    ? props.envData.map(v => {
                        return (
                          <Option value={v.envId} key={v.envId}>
                            {v.envName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            <FormItem label="配置主机" {...formItemLayout}>
              {getFieldDecorator("resIds", {
                rules: [
                  {
                    required: true,
                    message: "请选择配置主机"
                  }
                ],
                initialValue: this.resIds
              })(
                <div>
                  <Row style={{ marginBottom: "10px" }}>
                    <Col span={13} />
                    <Col span={11}>
                      <Row>
                        <Col
                          span={18}
                          style={{ textAlign: "right", cursor: "pointer" }}
                          onClick={() => {
                            this.addHost();
                          }}
                        >
                          <Icon type="plus" theme="outlined" />
                          添加主机
                        </Col>
                        <Col
                          span={6}
                          style={{ textAlign: "right", cursor: "pointer" }}
                          onClick={this.deleteHost.bind(this)}
                        >
                          <Icon type="delete" theme="outlined" style={{ marginLeft: "10px" }} />
                          批量移除
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Table
                    columns={this.columns}
                    dataSource={state.hostData}
                    rowSelection={rowHostSelection}
                    // onChange={this.handlePageChange.bind(this)}
                  />
                </div>
              )}
            </FormItem>
            <FormItem label="日志目录" {...formItemLayout}>
              {getFieldDecorator("serviceLogPath", {
                rules: Validation.Rule_nochinese,
                initialValue: this.serviceLogPath
              })(<Input maxLength={256} />)}
              <div>
                {"只有一个日志文件,则/**/*.log;每天打一个新的日志文件，则/**/*.${yyyy-MM-dd}.log"}
              </div>
            </FormItem>
            <FormItem label="部署路径" {...formItemLayout}>
              {getFieldDecorator("deployPath", {
                rules: Validation.Rule_nochinese,
                initialValue: this.deployPath
              })(<Input onChange={this.changeDeployPath.bind(this)} maxLength={256} />)}
              <div>
                {
                  "软件包部署到您的主机上的路径，您填写的内容在以下的shell脚本中以{{deploy_path}}被引用"
                }
              </div>
            </FormItem>
            <FormItem label="停止脚本" {...formItemLayout}>
              {getFieldDecorator("stopShellPath", {
                rules: Validation.Rule_nochinese,
                initialValue: this.stopShellPath
              })(<Input maxLength={256} />)}
              <div>{"停止脚本，您填写的内容在以下的shell脚本中以{{stop_sh}}被引用"}</div>
            </FormItem>
            <FormItem label="启动脚本" {...formItemLayout}>
              {getFieldDecorator("startShellPath", {
                rules: Validation.Rule_nochinese,
                initialValue: this.startShellPath
              })(<Input maxLength={256} />)}
              <div>{"启动脚本，您填写的内容在以下的shell脚本中以{{start_sh}}被引用"}</div>
            </FormItem>
            <FormItem label="重启脚本" {...formItemLayout}>
              {getFieldDecorator("restartShellPath", {
                rules: Validation.Rule_nochinese,
                initialValue: this.restartShellPath
              })(<Input maxLength={256} />)}
              <div>{"重启脚本，您填写的内容在以下的shell脚本中以{{restart_sh}}被引用"}</div>
            </FormItem>
            <FormItem label="Shell脚本" {...formItemLayout}>
              {getFieldDecorator("shellContent", {
                rules: Validation.Rule_select,
                initialValue: this.shellContent
              })(
                <MonacoEditor
                  // width="100%"
                  height="600"
                  language="shell"
                  theme="vs-dark"
                  value={props.editType == "create" ? props.shellContent : this.shellContent}
                  options={{ selectOnLineNumbers: true }}
                  onChange={this.changeEdit.bind(this)}
                  editorDidMount={this.editorDidMount.bind(this)}
                />
              )}
            </FormItem>
            {/* <div
              style={{ textAlign: "center", cursor: "pointer", marginBottom: "10px" }}
              onClick={this.showSettingsClick.bind(this)}
            >
              高级配置高级配置
              <Icon
                type="caret-down"
                theme="outlined"
                style={{ display: this.state.showSettings ? "none" : "inline-block" }}
              />
              <Icon
                type="caret-up"
                theme="outlined"
                style={{ display: this.state.showSettings ? "inline-block" : "none" }}
              />
            </div> */}
            {/* <div style={{ display: this.state.showSettings ? "block" : "none" }}> */}
            <div style={{ marginTop: "10px" }}>
              <FormItem label="差异化配置文件路径：" {...formItemLayout}>
                {getFieldDecorator("differentiationPath", {
                  rules: Validation.Rule_falsechinese,
                  initialValue: this.differentiationPath
                })(
                  <TextArea
                    maxLength={256}
                    placeholder="哪个配置文件需要针对不同的环境做差异化的配置，这里就写该配置文件的路径，如/usr/share/tomcat/Tomcat_Test/WEB-INF/classes/config.properties,多个配置文件请以回车键隔开”"
                  />
                )}
                <div>
                  {
                    "差异化配置文件路径，您填写的内容在以下的shell脚本中以{{diff_config_files}}被引用"
                  }
                </div>
              </FormItem>
              <FormItem label="配置变量" {...formItemLayout}>
                <div style={{ textAlign: "right", padding: "10px" }}>
                  <Button type="primary" onClick={this.addVar.bind(this)}>
                    添加
                  </Button>
                </div>
                {getFieldDecorator("env", {
                  // initialValue: definitionName
                })(<Table columns={this.varColumns} dataSource={variableData} />)}
                <div>
                  {"配置变量，您填写的内容在以下的shell脚本中以{{shell_config_params}}被引用"}
                </div>
              </FormItem>
              <FormItem label="应用验证路径" {...formItemLayout}>
                <div>
                  <Row>
                    <Col span={3}>
                      {getFieldDecorator("verifyUrl", {
                        initialValue: this.defaultHttp,
                        rules: [{ required: true, message: "请选择" }]
                      })(
                        <Select
                          style={{ width: "100%" }}
                          // value={this.defaultHttp}
                          onChange={this.changeHttp.bind(this)}
                        >
                          <Option value="http">http</Option>
                          <Option value="https">https</Option>
                        </Select>
                      )}
                    </Col>
                    <Col span={7}>
                      <Row>
                        <Col span={3}>
                          {/* <Row> */}
                          {/* <Col span={6}> */}
                          <div
                            style={{
                              height: "32px",
                              lineHeight: "32px",
                              // display: "inline-block",
                              padding: "0 5px",
                              fontSize: "14px",
                              color: "#262626",
                              marginTop: "4px",
                              textAlign: "center"
                            }}
                          >
                            ://
                          </div>
                          {/* </Col> */}
                          {/* </Row> */}
                        </Col>
                        <Col span={21}>
                          <FormItem label="主机IP：" {...urlyLayout}>
                            {getFieldDecorator("resHostIp", {
                              rules: Validation.Rule_number,
                              initialValue: this.defaultUrl
                            })(
                              <Input
                                style={{ width: "108%" }}
                                placeholder="端口"
                                maxLength={16}
                                onChange={this.changeIp.bind(this)}
                              />
                            )}
                          </FormItem>
                        </Col>
                      </Row>
                    </Col>
                    <Col span={4}>
                      {/* <Row>
                        <Col span={12}> */}
                      <FormItem label="/" colon={false} {...formItemLayout}>
                        {getFieldDecorator("defaultFileName", {
                          rules: Validation.Rule_falsechinese,
                          initialValue: this.defaultFileName
                        })(
                          <Input
                            maxLength={32}
                            placeholder="e.g. 1.html"
                            onChange={this.changeFile.bind(this)}
                          />
                        )}
                      </FormItem>
                      {/* </Col>
                      </Row> */}
                    </Col>
                  </Row>
                </div>
                <div>示例：https//10.1.1.1:8080/1.html。其中，主机IP自动配置</div>
              </FormItem>
            </div>
          </div>
        );
        break;
      case "2":
        this.formContentByDeployType = (
          <div>
            <FormItem label="环境类型" {...formItemLayout}>
              {getFieldDecorator("deployEnvType", {
                rules: Validation.Rule_envType,
                initialValue: this.deployEnvType ? Number(this.deployEnvType) : ""
              })(
                <Select
                  style={{ width: "50%" }}
                  allowClear
                  disabled={props.editType === "edit"}
                  onChange={this.changeEnv.bind(this)}
                >
                  {props.envData
                    ? props.envData.map(v => {
                        return (
                          <Option value={v.envId} key={v.envId}>
                            {v.envName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            {/* {this.state.envId || this.deployEnvType ? ( */}
            <FormItem label="所在集群" {...formItemLayout}>
              {getFieldDecorator("clusterName", {
                rules: [
                  {
                    required: true,
                    message: "请选择所在集群"
                  }
                ],
                initialValue: this.clusterName
              })(
                <Select
                  // disabled={this.state.envId || this.deployEnvType ? false : true}
                  style={{ width: "50%" }}
                  allowClear
                  disabled={props.editType === "edit"}
                  onChange={this.changeCluster.bind(this)}
                  // onDropdownVisibleChange={this.dropDownCluster.bind(this)}
                >
                  {props.clusterData
                    ? props.clusterData.map(v => {
                        return (
                          <Option value={v.clusterName} key={v.clusterId}>
                            {v.clusterName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            <FormItem label="命名空间" {...formItemLayout}>
              {getFieldDecorator("namespaceName", {
                rules: [
                  {
                    required: true,
                    message: "请选择命名空间"
                  }
                ],
                initialValue: this.namespaceName
              })(
                <Select
                  // disabled={this.state.envId || this.deployEnvType ? false : true}
                  style={{ width: "50%" }}
                  allowClear
                  disabled={props.editType === "edit"}
                  onChange={this.changeNameSpace.bind(this)}
                  onDropdownVisibleChange={this.dropDownNameSpace.bind(this)}
                >
                  {props.nameSpacePodData
                    ? props.nameSpacePodData.map(v => {
                        return (
                          <Option value={v.namespaceName} key={v.namespaceId}>
                            {v.namespaceName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            {/* ) : (
              ""
            )} */}
            <FormItem label="部署方式" {...formItemLayout}>
              <Row>{this.renderByDeployMode()}</Row>
            </FormItem>
            {/* 部署方式为应用商店 */}
            <div style={{ display: state.deployMode == "2" ? "block" : "none" }}>
              <Row>
                <Col span={5}>选择文件</Col>
                <Col span={17}>
                  <Search
                    onSearch={value => this.getMarketList(value)}
                    style={{ display: props.editType == "create" ? "block" : "none" }}
                  />
                  <FormItem {...formItemLayout}>
                    <Row className="line-margin">
                      {props.appListData
                        ? props.appListData.map(v => {
                            return (
                              <Col span={4}>
                                <Row className="text-center">
                                  <Col key={Math.random()} className="pointer-style">
                                    <img
                                      className={
                                        state.applicationName == v.marketAppName
                                          ? "selected-border"
                                          : "application-style"
                                      }
                                      style={{ width: "110px", height: "110px" }}
                                      src={v.marketAppIcon}
                                      alt=""
                                    />
                                  </Col>
                                  <Col key={Math.random()}>{v.marketAppName}</Col>
                                </Row>
                              </Col>
                            );
                          })
                        : ""}
                    </Row>
                  </FormItem>
                </Col>
              </Row>
              <Row>
                <Col span={6}>编排文件</Col>
                <Col span={16}>
                  <FormItem {...formItemLayout}>
                    {getFieldDecorator("ymlContent", {
                      rules: [
                        {
                          required: true,
                          message: "请输入YAML文件"
                        }
                      ],
                      initialValue: this.ymlTmpData
                    })(
                      <CodeMirror
                        title="YAML"
                        readOnly={true}
                        serviceOrchestrationYml={this.ymlTmpData ? this.ymlTmpData : ""}
                        // getValue={this.getYmlValue.bind(this)}
                      />
                    )}
                  </FormItem>
                </Col>
              </Row>
            </div>
            {/* 部署方式为镜像仓库 */}
            <div style={{ display: state.deployMode == "1" ? "block" : "none" }}>
              <div>应用配置</div>
              <FormItem label="实例数量" {...formItemLayout}>
                {getFieldDecorator("deploymentReplicas", {
                  rules: [
                    {
                      required: true,
                      message: "请输入实例数量"
                    }
                  ],
                  initialValue: this.deploymentReplicas
                })(<InputNumber min={1} max={10} onChange={this.changeReplicas.bind(this)} />)}
                <span style={{ marginLeft: "5px" }}>个</span>
              </FormItem>
              <FormItem label="启用动态伸缩" {...formItemLayout}>
                {getFieldDecorator("deploymentEnableHpa", {
                  rules: [
                    {
                      required: false
                    }
                  ],
                  initialValue: this.deploymentEnableHpa == 0 ? false : true
                })(
                  <Checkbox
                    checked={
                      state.expandable === null ? this.deploymentEnableHpa : state.expandable
                    }
                    onChange={this.Dynamicexpansion.bind(this)}
                  />
                )}
              </FormItem>
              <FormItem
                label="伸缩范围"
                {...formItemLayout}
                style={{
                  // display: this.state.expandable ? "block" : "none"   //原有
                  display:
                    state.expandable === null
                      ? this.deploymentEnableHpa == 1
                        ? "block"
                        : "none"
                      : state.expandable
                      ? "block"
                      : "none"
                }}
              >
                <InputNumber
                  min={1}
                  max={10}
                  onChange={this.changeMin.bind(this)}
                  value={state.deploymentHpaMin}
                />
                <span style={{ margin: "0 10px" }}>-</span>
                <InputNumber
                  min={1}
                  max={10}
                  onChange={this.changeMax.bind(this)}
                  value={state.deploymentHpaMax}
                />
              </FormItem>
              <FormItem
                label="伸缩步长"
                {...formItemLayout}
                style={{
                  // display: this.state.expandable ? "block" : "none"  //原有
                  display:
                    state.expandable === null
                      ? this.deploymentEnableHpa == 1
                        ? "block"
                        : "none"
                      : state.expandable
                      ? "block"
                      : "none"
                }}
              >
                {getFieldDecorator("deploymentHpaStepsize", {
                  rules: [
                    {
                      required: false
                    }
                  ],
                  initialValue: this.deploymentHpaStepsize
                })(
                  <InputNumber
                    min={1}
                    max={this.maxStep}
                    // formatter={value => `${value}%`}
                    onChange={this.changeStep.bind(this)}
                  />
                )}
              </FormItem>
              <FormItem
                label="CPU占用率"
                {...formItemLayout}
                style={{
                  // display: this.state.expandable ? "block" : "none"  //原有
                  display:
                    state.expandable === null
                      ? this.deploymentEnableHpa == 1
                        ? "block"
                        : "none"
                      : state.expandable
                      ? "block"
                      : "none"
                }}
              >
                {getFieldDecorator("deploymentHpaTrigger", {
                  rules: [
                    {
                      required: false
                    }
                  ],
                  initialValue: this.deploymentHpaTrigger
                })(<InputNumber min={10} max={90} />)}
                %
              </FormItem>
              <FormItem label="容器" {...containerLayout}>
                <div style={{ border: "1px solid #e4e4e4" }}>
                  <FormItem label="镜像" {...formItemLayout}>
                    {getFieldDecorator("packageUrl", {
                      rules: [
                        {
                          required: true,
                          message: "请选择镜像"
                        }
                      ],
                      initialValue: this.packageUrl
                    })(
                      <Select
                        style={{ width: "50%" }}
                        allowClear
                        onChange={this.changeImage.bind(this)}
                      >
                        {props.imageList
                          ? props.imageList.map(v => {
                              return (
                                <Option value={v.pullUrl} key={v.pullUrl}>
                                  {v.imageAndTag}
                                </Option>
                              );
                            })
                          : ""}
                        {/* {props.houseimageData
                          ? props.houseimageData.map(v => {
                              return (
                                <Option value={v.imageUrl} key={v.imageUrl}>
                                  {v.imageName}
                                </Option>
                              );
                            })
                          : ""} */}
                      </Select>
                    )}
                  </FormItem>
                  <FormItem label="端口" {...formItemLayout}>
                    <Row>
                      <Col span={16}>同一任务下，端口名称和端口不能重复</Col>
                      <Col span={8} style={{ textAlign: "right" }}>
                        <Icon
                          type="plus-circle"
                          theme="outlined"
                          onClick={() => this.addPort()}
                          style={{ cursor: "pointer" }}
                        />
                      </Col>
                    </Row>
                    {getFieldDecorator("port", {
                      // initialValue: definitionName
                      rules: [{ required: true, message: "请填写端口信息" }]
                    })(
                      <Table
                        bordered
                        columns={this.dockerPortColumns}
                        dataSource={portData}
                        pagination={false}
                      />
                    )}
                  </FormItem>
                  <div
                    style={{ textAlign: "center", cursor: "pointer", marginBottom: "10px" }}
                    onClick={this.showMirrorSettingsClick.bind(this)}
                  >
                    高级配置
                    <Icon
                      type="caret-down"
                      theme="outlined"
                      style={{ display: state.showMirrorSettings ? "none" : "inline-block" }}
                    />
                    <Icon
                      type="caret-up"
                      theme="outlined"
                      style={{ display: state.showMirrorSettings ? "inline-block" : "none" }}
                    />
                  </div>
                  <div style={{ display: state.showMirrorSettings ? "block" : "none" }}>
                    <FormItem label="内存" {...formItemLayout}>
                      {getFieldDecorator("deploymentRequestMem", {
                        initialValue: this.deploymentRequestMem
                      })(
                        <InputNumber
                          min={0}
                          max={
                            state.deploymentLimitMem
                              ? Number(state.deploymentLimitMem.match(/\d+/g)[0])
                              : 10000
                          }
                        />
                      )}
                      <span style={{ marginLeft: "10px" }}>Mi</span>
                      <div
                        style={{ display: state.deploymentLimitMem ? "block" : "none" }}
                      >{`当前命名空间内存不超过${state.deploymentLimitMem}`}</div>
                    </FormItem>
                    <FormItem label="CPU" {...formItemLayout}>
                      {getFieldDecorator("deploymentRequestCpu", {
                        initialValue: this.deploymentRequestCpu
                      })(
                        <InputNumber
                          min={0.1}
                          step={0.1}
                          max={state.deploymentLimitCpu ? Number(state.deploymentLimitCpu) : 4}
                        />
                      )}
                      <span style={{ marginLeft: "10px" }}>核</span>
                      <div
                        style={{ display: state.deploymentLimitMem ? "block" : "none" }}
                      >{`当前命名空间CPU不超过${state.deploymentLimitCpu}核`}</div>
                    </FormItem>
                    <FormItem label="command" {...formItemLayout}>
                      {getFieldDecorator("deploymentContainerCmd", {
                        rules: Validation.Rule_command,
                        initialValue: this.deploymentContainerCmd
                      })(<Input maxLength={64} />)}
                    </FormItem>
                    <FormItem label="Args" {...formItemLayout}>
                      {getFieldDecorator("deploymentContainerArgs", {
                        rules: Validation.Rule_command,
                        initialValue: this.deploymentContainerArgs
                      })(<Input maxLength={64} />)}
                    </FormItem>
                    <FormItem label="环境变量" {...formItemLayout}>
                      <Row>
                        <Col span={16}>同一任务下，变量名称不能重复</Col>
                        <Col span={8} style={{ textAlign: "right" }}>
                          <Icon
                            type="plus-circle"
                            theme="outlined"
                            onClick={() => this.addEnvVar()}
                            style={{ cursor: "pointer" }}
                          />
                        </Col>
                      </Row>
                      {getFieldDecorator("variable", {
                        // initialValue: definitionName
                      })(
                        <Table
                          bordered
                          columns={this.envVarColumns}
                          dataSource={envVarData}
                          pagination={false}
                        />
                      )}
                    </FormItem>
                    <FormItem label="存储" {...formItemLayout}>
                      <Row>
                        <Col span={16}>同一任务下，数据卷名不能重复</Col>
                        <Col span={8} style={{ textAlign: "right" }}>
                          <Icon
                            type="plus-circle"
                            theme="outlined"
                            onClick={() => this.addMemory()}
                            style={{ cursor: "pointer" }}
                          />
                        </Col>
                      </Row>
                      {getFieldDecorator("memory", {
                        // initialValue: definitionName
                      })(
                        <Table
                          bordered
                          columns={this.memoryColumns}
                          dataSource={memoryData}
                          pagination={false}
                        />
                      )}
                      <div>timezone 为时钟同步路径，根据本地环境已经容器进行填写</div>
                    </FormItem>
                    <FormItem label="设置高可用" {...formItemLayout}>
                      {getFieldDecorator("deploymentLivenessprobe", {
                        initialValue: this.deploymentLivenessprobe,
                        valuePropName: "checked"
                      })(
                        <Switch
                          checkedChildren="是"
                          unCheckedChildren="否"
                          // defaultChecked={false}
                          onChange={this.onchangeSwitch.bind(this)}
                        />
                      )}
                    </FormItem>
                    {this.HigAvailabilityformItemDom}
                  </div>
                </div>
              </FormItem>
              <div>设置访问方式</div>
              <FormItem label="负载均衡" {...formItemLayout}>
                {getFieldDecorator("serviceType", {
                  rules: [
                    {
                      required: false
                    }
                  ],
                  initialValue: this.serviceType
                })(
                  <RadioGroup onChange={this.onChangeLoad.bind(this)}>
                    <Radio value="LoadBalancer">公网访问</Radio>
                    <Radio value="ClusterIP">内部访问</Radio>
                  </RadioGroup>
                )}
              </FormItem>
              {this.loadStyleDom}
              <Row>
                <Col span={4}>编排文件</Col>
                <Col span={16}>
                  <FormItem {...formItemLayout}>
                    {getFieldDecorator("ymlContent", {
                      rules: [
                        {
                          required: true,
                          message: "请输入YAML文件"
                        }
                      ],
                      initialValue: this.ymlTmpData
                    })(
                      <CodeMirror
                        title="YAML"
                        serviceOrchestrationYml={this.ymlTmpData ? this.ymlTmpData : ""}
                        readOnly={true}
                        // getValue={this.getYmlValue.bind(this)}
                      />
                    )}
                  </FormItem>
                </Col>
              </Row>
            </div>
          </div>
        );
        break;
      // case "3":
      //   this.formContentByDeployType = <div>{"ansible部署"}</div>;
      //   break;
      default:
        break;
    }
    return this.formContentByDeployType;
  }

  /**
   * 是否安装运行环境
   */
  installEnvChange(e) {
    const { actions } = this.props;
    this.setState({
      showRunningEnvOps: e.target.checked,
      installRuntimeEnv: Number(e.target.checked)
    });
    this.installRuntimeEnv = e.target.checked;
    actions.getRunningEnvList({
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "asc",
      conditions: [{}]
    });
  }

  getYmlValue(value) {
    // this.setState({
    //   ymlTmpData: value
    // });
    this.ymlTmpData = value;
  }

  /**
   * 选择部署类型
   */
  selectType(type, e) {
    const { props } = this;
    this.setState({
      deployType: e.target.value,
      type
    });
    switch (type) {
      case "shell":
        this.setState({
          type: "shell",
          deployType: "1"
        });
        this.deployType = "1";
        break;
      case "container":
        this.setState({
          type: "container",
          deployType: "2"
        });
        this.deployType = "2";
        break;
      // case "ansible":
      //   <div>{"ansible部署"}</div>;
      //   this.setState({
      //     type: "ansible",
      //     deployType: "3"
      //   });
      //   this.deployType = "3";
      //   break;
      default:
        break;
    }
    props.form.setFieldsValue({ deployType: Number(e.target.value) });
  }

  /**
   * 选择部署方式
   */
  selectDeployMode(type, e) {
    switch (type) {
      case "mirror":
        this.setState({
          deployMode: "1"
          // deployMode: "1"
        });
        break;
      case "shop":
        this.setState({
          deployMode: "2"
          // deployMode: "2"
        });
        break;
      default:
        break;
    }
  }

  /**
   * 是否启用动态伸缩
   */
  Dynamicexpansion(e) {
    this.setState({
      expandable: e.target.checked
    });
  }

  /**
   * 选择运行环境类型
   */
  selectRunningEnv(v, e) {
    switch (v.compName) {
      case "tomcat1.8":
        this.setState({
          envType: "tomcat1.8",
          envContent: v
        });
        this.envContent = v;
        break;
      case "jdk1.8":
        this.setState({
          envType: "jdk1.8",
          envContent: v
        });
        this.envContent = v;
        break;
      case "PHP":
        this.setState({
          envType: "PHP"
        });
        break;
      case "Python":
        this.setState({
          envType: "Python"
        });
        break;
      case "Nodejs":
        this.setState({
          envType: "Nodejs"
        });
        break;
      case "Ruby":
        this.setState({
          envType: "Ruby"
        });
        break;
      case "Go":
        this.setState({
          envType: "Go"
        });
        break;
      default:
        break;
    }
  }

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, index) {
    return (
      <div>
        <Popconfirm
          title="确定删除?"
          okText="确认"
          cancelText="取消"
          onConfirm={() => this.deployDelete(text, record, index)}
        >
          <Icon type="delete" theme="outlined" style={{ cursor: "pointer" }} />
        </Popconfirm>
        <Icon
          type="plus"
          theme="outlined"
          onClick={() => this.addHost(text, record, index)}
          style={{ cursor: "pointer", marginLeft: "10px" }}
        />
      </div>
    );
  }

  /**
   * 配置变量操作列表
   */
  renderParamsActions(text, record, index) {
    return (
      <div>
        <Popconfirm
          title="确定删除?"
          okText="确认"
          cancelText="取消"
          onConfirm={() => this.varDelete(text, record, index)}
        >
          <Icon type="delete" theme="outlined" style={{ cursor: "pointer" }} />
        </Popconfirm>
        <Icon
          type="plus"
          theme="outlined"
          onClick={() => this.addVar(text, record, index)}
          style={{ cursor: "pointer", marginLeft: "10px" }}
        />
      </div>
    );
  }

  /**
   * 容器端口操作列表
   */
  renderPortActions(text, record, index) {
    return (
      <div style={{ width: "50px" }}>
        <Popconfirm
          title="确定删除?"
          okText="确认"
          cancelText="取消"
          onConfirm={() => this.deletePort(text, record, index)}
        >
          <Icon type="delete" theme="outlined" style={{ cursor: "pointer" }} />
        </Popconfirm>
        <Icon
          type="plus"
          theme="outlined"
          onClick={() => this.addPort(text, record, index)}
          style={{ cursor: "pointer", marginLeft: "10px" }}
        />
      </div>
    );
  }

  /**
   * 环境变量操作列表
   */
  renderEnvActions(text, record, index) {
    return (
      <div>
        <Popconfirm
          title="确定删除?"
          okText="确认"
          cancelText="取消"
          onConfirm={() => this.deleteEnvVar(text, record, index)}
        >
          <Icon type="delete" theme="outlined" style={{ cursor: "pointer" }} />
        </Popconfirm>
        <Icon
          type="plus"
          theme="outlined"
          onClick={() => this.addEnvVar(text, record, index)}
          style={{ cursor: "pointer", marginLeft: "10px" }}
        />
      </div>
    );
  }

  /**
   * 存储操作列表
   */
  renderMemoryActions(text, record, index) {
    return (
      <div>
        <Popconfirm
          title="确定删除?"
          okText="确认"
          cancelText="取消"
          style={{ display: record.volumeName == "timezone" ? "none" : "inline-block" }}
          onConfirm={() => this.deleteMemory(text, record, index)}
        >
          <Icon
            type="delete"
            theme="outlined"
            style={{
              cursor: "pointer",
              display: record.volumeName == "timezone" ? "none" : "inline-block"
            }}
          />
        </Popconfirm>
        <Icon
          type="plus"
          theme="outlined"
          onClick={() => this.addMemory(text, record, index)}
          style={{ cursor: "pointer", marginLeft: "10px" }}
        />
      </div>
    );
  }

  /**
   * 确定
   */
  submitClick() {
    const { state, props } = this;
    if (state.portData.length > 0) {
      let isAvalible;
      let portNameIsAvalible;
      let targetPortIsAvalible;
      let clusterPortIsAvalible;
      state.portData.forEach(v => {
        for (const key in v) {
          if (v[key] == "") {
            isAvalible = false;
          } else if (v[key]) {
            switch (key) {
              case "portName":
                portNameIsAvalible = this.rules["portNameRex"].test(v[key]) ? true : false;
                this.avaliblePortNameStatus = portNameIsAvalible ? "success" : "error";
                break;
              case "targetPort":
                targetPortIsAvalible = this.rules["targetPortRex"].test(v[key]) ? true : false;
                this.avalibletargetPortStatus = targetPortIsAvalible ? "success" : "error";
                break;
              case "clusterPort":
                clusterPortIsAvalible = this.rules["clusterPortRex"].test(v[key]) ? true : false;
                this.avalibleclusterPortStatus = clusterPortIsAvalible ? "success" : "error";
                break;
              default:
                break;
            }
            isAvalible = portNameIsAvalible && targetPortIsAvalible && clusterPortIsAvalible;
          }
        }
      });
      if (isAvalible) {
        props.form.setFieldsValue({
          port: "avaliblePort"
        });
      } else {
        props.form.setFieldsValue({
          port: undefined
        });
      }
    }
    props.form.validateFields((err, values) => {
      if (!err) {
        if (props.editType == "edit") {
          this.deployStyle =
            props.detailsData &&
            props.detailsData.data &&
            props.detailsData.data.deployPodTemplate == 1
              ? "mirror"
              : props.detailsData.data.deployPodTemplate == 2
              ? "shop"
              : "";
        }
        // shell部署数据处理
        if (this.deployType == "1") {
          values.installRuntimeEnv = Number(
            this.installRuntimeEnv ? this.installRuntimeEnv : false
          );
          values.applicationCode = state.applicationCode;
          values.appId = state.applicationId;
          values.deployType = this.deployType;
          // 用户选择了具体的运行环境后对表单域进行对应的赋值
          if (Object.keys(state.envContent).length > 0) {
            values.compCode = state.envContent.compCode || "";
            values.compIcon = state.envContent.compIcon || "";
            values.compId = state.envContent.compId || "";
            values.compType = state.envContent.compType || "";
            values.compName = state.envContent.compName || "";
          }
          // 勾选了安装运行环境但是没有选择具体的类型
          if (values.installRuntimeEnv && state.envContent.compCode == "") {
            message.info("请选择要安装的运行环境!");
            return;
          }
          if (values.installRuntimeEnv && Object.keys(state.envContent).length == 0) {
            message.info("请选择要安装的运行环境!");
            return;
          }
          // 不勾选运行环境除了compType均置空，compType目前赋值为1
          if (!values.installRuntimeEnv) {
            values.compCode = "";
            values.compIcon = "";
            values.compId = "";
            values.compType = state.deployType;
            values.compName = "";
          }
          const detailsData = props.detailsData ? props.detailsData.data : [];
          // deployDfName仅在编辑情况下取该值
          if (props.editType === "edit") {
            values.deployDfName = detailsData.deployDfName || "";
          }
          // 非新增情况下的表单取值
          if (props.editType === "edit" || props.editType === "clone") {
            values.deployDfId = detailsData.deployDfId;
            values.deployCreateTime = detailsData.deployCreateTime || "";
            values.createTime = detailsData.createTime || "";
            values.projectId = detailsData.projectId;
            values.successRate = detailsData.successRate || "";
            values.totalFailed = detailsData.totalFailed || 0;
            values.totalSuccessful = detailsData.totalSuccessful || 0;
            values.lastDeployTime = detailsData.lastDeployTime || "";
            values.durationTime = detailsData.durationTime || "";
            values.deployStatus = detailsData.deployStatus || "";
            values.lastBuildNum = detailsData.lastBuildNum || "";
          } else if (props.editType === "create") {
            // 新增情况下的表单取值
            values.deployType = state.deployType;
            values.projectId = props.projectId;
            values.deployDfId = "";
            values.deployCreateTime = "";
            values.successRate = "";
            values.totalFailed = "";
            values.totalSuccessful = "";
            values.lastDeployTime = "";
            values.durationTime = "";
            values.deployStatus = "";
            values.lastBuildNum = "";
            values.installRuntimeEnv = values.installRuntimeEnv ? values.installRuntimeEnv : 0;
          }
          delete values.env;
          values.resIds = this.ipArr.join("-");

          // 配置变量数据处理
          const varData = Object.assign([], state.variableData);
          varData.forEach((v, i) => {
            v.positionId = i;
            v.compId = this.envContent.compId;
            delete v.key;
          });
          // 拼接应用验证路径
          if (this.defaultHttp && this.defaultUrl) {
            values.verifyUrl = `${this.defaultHttp}://ip:${this.defaultUrl}/${
              this.defaultFileName
            }`;
          }
          // 根据editType判断保存的接口
          if (props.editType === "create") {
            props.actions.saveDefination({ data: values, attr: varData });
          } else if (props.editType === "clone") {
            varData.forEach(v => {
              delete v.attrId;
              delete v.id;
            });
            props.actions.cloneDefination({ data: values, attr: varData });
          } else if (props.editType === "edit") {
            values.id = props.id ? props.id : "";
            props.actions.updateDefination({ data: values, attr: varData });
          }
        } else if (this.deployType == "2" && this.deployStyle == "shop") {
          const {
            clusterId,
            applicationId,
            deployType,
            ymlTmpData,
            namespaceId,
            imageTagId,
            deploymentClusterIp,
            clusterVipIp,
            applicationCode,
            eployStatus,
            durationTime,
            lastBuildNum,
            successRate,
            totalSuccessful,
            updateTime
          } = this.state;
          const {
            namespaceName,
            deployDfName,
            applicationName,
            deployDfDesc,
            packageUrl,
            clusterName,
            deployEnvType
          } = values;
          const detailsData = props.detailsData.data;
          const containerData = props.detailsData.container;
          const serviceData = props.detailsData.service;
          // data数据封装
          const data = {
            appId: applicationId || "",
            applicationName: applicationName || "",
            applicationCode: applicationCode || "",
            createTime: detailsData.createTime || "",
            // deloyName: "",
            compName: namespaceName || "",
            deployCreateTime: detailsData.deployCreateTime || "",
            deployDfDesc: deployDfDesc || "",
            deployDfId: detailsData.deployDfId || "",
            deployDfName: deployDfName || "",
            deployType: deployType || "",
            deployEnvType: deployEnvType || "",
            deployPodTemplate: "2",
            deployStatus: detailsData.deployStatus || "",
            durationTime: detailsData.lastBuildNum || "",
            deployRuntimeName: detailsData.deployRuntimeName || "",
            id: detailsData.id || "",
            instanceId: detailsData.instanceId || "",
            projectId: props.projectId,
            totalSuccessful: detailsData.totalSuccessful || "",
            resIds: clusterName || "",
            packageUrl: packageUrl || "",
            updateTime: detailsData.updateTime || "",
            lastBuildNum: detailsData.lastBuildNum || "",
            successRate: detailsData.successRate || ""
          };
          // 容器数据封装
          const container = {
            deploymentReplicas: containerData.deploymentReplicas || "",
            tagId: containerData.tagId || "",
            // imageTagId: imageTagId || "",
            updateTime: containerData.updateTime || "",
            clusterId: clusterId !== undefined ? clusterId : "",
            deloyName: containerData.deloyName || "",
            deploymentImageInfo: containerData.deploymentImageInfo || "",
            createTime: containerData.createTime || "",
            namespaceId: namespaceId || "",
            clusterName: clusterName || "",
            deploymentClusterIp: deploymentClusterIp || "",
            deploymentId: containerData.deploymentId || "",
            id: containerData.id || "",
            imageTag: containerData.imageTag || "",
            deploymentYml: this.ymlTmpData || "",
            namespaceName: namespaceName || "",
            deploymentType: "2",
            // service数据封装
            service: {
              serviceYml: serviceData.serviceYml || "",
              createTime: serviceData.createTime || "",
              deploymentId: serviceData.deploymentId || "",
              updateTime: serviceData.updateTime || "",
              namespace: serviceData.namespace || "",
              id: serviceData.id || "",
              serviceId: serviceData.serviceId || "",
              serviceName: serviceData.serviceName || "",
              serviceClusterIp: clusterVipIp || ""
            }
          };
          if (props.editType === "edit") {
            props.actions.updateDefination({
              data,
              container
            });
          }
        } else if (this.deployType == "2" && this.deployStyle == "mirror") {
          const {
            clusterId,
            applicationId,
            deployType,
            namespaceId,
            imageTagId,
            deploymentHpaMin,
            deploymentHpaMax,
            memoryData,
            portData,
            envVarData,
            deploymentLimitCpu,
            deploymentLimitMem,
            deploymentClusterIp,
            clusterIngressVipIp,
            clusterVipIp,
            applicationCode
          } = this.state;
          const {
            namespaceName,
            deployDfName,
            applicationName,
            deployDfDesc,
            packageUrl,
            clusterName,
            deploymentReplicas,
            deploymentHpaStepsize,
            deploymentHpaTrigger,
            deploymentEnableHpa,
            deploymentLivenessprobe,
            deploymentLivenessprobeScheme,
            deploymentLivenessprobePath,
            deploymentLivenessprobePort,
            lpInitialdelaydeconds,
            lpTimeoutseconds,
            lpPeriodseconds,
            serviceType,
            routePath,
            routePort,
            deploymentRequestMem,
            deploymentRequestCpu,
            deploymentContainerCmd,
            deploymentContainerArgs,
            deployEnvType,
            routeProtocol
          } = values;
          // data数据封装
          const data = {
            compName: namespaceName || "",
            deployType: deployType || "",
            deployEnvType: deployEnvType || "",
            projectId: props.projectId,
            deployDfName: deployDfName || "",
            applicationName: applicationName || "",
            applicationCode: applicationCode || "",
            appId: applicationId || "",
            deployDfDesc: deployDfDesc || "",
            packageUrl: packageUrl || "",
            deployPodTemplate: "1",
            resIds: clusterName || ""
          };
          // 容器数据封装
          const container = {
            deploymentStrategyMaxunavailable: "1", // ：没有选择伸缩，为1，选择伸缩，副本数为1 2  为1  大于等于3  为 副本数减步长
            deploymentStrategyMaxsurge: "1",
            clusterId: clusterId !== undefined ? clusterId : "",
            clusterName: clusterName || "",
            namespaceId: namespaceId || "",
            namespaceName: namespaceName || "",
            deloyName:
              applicationCode && namespaceName ? `${applicationCode}-${namespaceName}` : "",
            deploymentImageInfo: packageUrl || "",
            imageTag: packageUrl || "",
            // imageTagId: imageTagId || "",
            deploymentReplicas: deploymentReplicas || "",
            deploymentType: "1",

            deploymentLimitCpu: deploymentLimitCpu || "",
            deploymentLimitMem: deploymentLimitMem || "",
            deploymentRequestCpu: deploymentRequestCpu || state.deploymentRequestCpu,
            deploymentRequestMem: deploymentRequestMem
              ? `${deploymentRequestMem}Mi`
              : state.deploymentRequestMem
              ? `${state.deploymentRequestMem}`
              : "",

            deploymentClusterIp: deploymentClusterIp || "",
            deploymentLabelMatchLabels: `app:${applicationCode}-${namespaceName}`,
            deploymentEnableHpa:
              deploymentEnableHpa !== undefined ? Number(deploymentEnableHpa) : 0,
            deploymentHpaTrigger: deploymentHpaTrigger || "",
            deploymentHpaStepsize: Math.ceil(Number(deploymentReplicas) * 0.3),
            deploymentHpaMin: deploymentHpaMin ? deploymentHpaMin : "",
            deploymentHpaMax: deploymentHpaMax ? deploymentHpaMax : "",

            deploymentLivenessprobe:
              deploymentLivenessprobe !== undefined ? Number(deploymentLivenessprobe) : 0,
            deploymentLivenessprobePath: deploymentLivenessprobePath
              ? deploymentLivenessprobePath
              : "",
            deploymentLivenessprobePort: deploymentLivenessprobePort
              ? Number(deploymentLivenessprobePort)
              : "",
            deploymentLivenessprobeScheme: deploymentLivenessprobeScheme
              ? deploymentLivenessprobeScheme
              : "",
            deploymentLivenessprobeType:
              deploymentLivenessprobeScheme == "HTTP" ? "HTTPGetAction" : "",
            lpInitialdelaydeconds: lpInitialdelaydeconds ? lpInitialdelaydeconds : "",
            lpTimeoutseconds: lpTimeoutseconds ? lpTimeoutseconds : "",
            lpPeriodseconds: lpPeriodseconds ? lpPeriodseconds : "",
            // label数据封装
            label: {
              labelKey: "app",
              labelValue:
                applicationCode && namespaceName ? `${applicationCode}-${namespaceName}` : ""
            },
            // 存储数据封装
            volume: memoryData.map((v, i) => {
              return {
                volumeName: v.volumeName,
                volumeHostPath: v.volumeHostPath,
                volumeContainerPath: v.volumeContainerPath
              };
            }),
            // 端口数据封装
            port: portData.map((v, i) => {
              return {
                portName: v.portName,
                clusterPort: Number(v.clusterPort),
                targetPort: Number(v.targetPort),
                serviceProtocol: v.serviceProtocol,
                portPos: i
              };
            }),
            // service数据封装
            service: {
              serviceName:
                applicationCode && namespaceName ? `${applicationCode}-${namespaceName}` : "",
              serviceSelector:
                applicationCode && namespaceName ? `app:${applicationCode}-${namespaceName}` : "",
              serviceType: serviceType || "",
              serviceProtocol: routeProtocol,
              namespace: namespaceName || "",
              serviceClusterIp: clusterVipIp || ""
            },
            route: {
              routeName:
                clusterName && namespaceName && applicationCode
                  ? `${clusterName}-${applicationCode}-${namespaceName}-ingress`
                  : "",
              routeProtocol: values.routeProtocol,
              routePath,
              routePort: Number(routePort) || "",
              routeIp: clusterVipIp || "",
              namespace: namespaceName || "",
              serviceName:
                applicationCode && namespaceName ? `${applicationCode}-${namespaceName}` : ""
            },
            // 环境变量数据封装
            env: envVarData.map((v, i) => {
              return {
                envName: v.envName,
                envValue: v.envValue,
                envPos: i
              };
            })
          };
          // command 和arg没有就不传该字段
          if (deploymentContainerCmd) {
            container.deploymentContainerCmd = deploymentContainerCmd;
          }
          if (deploymentContainerArgs) {
            container.deploymentContainerArgs = deploymentContainerArgs;
          }
          // 根据editType判断保存的接口
          if (props.editType === "create") {
            data.deployRuntimeName =
              applicationCode && namespaceName ? `${applicationCode}-${namespaceName}` : "";
            this.setState({
              saveLoading: true
            });
            props.actions.saveDefination({
              data,
              container
            });
          } else if (props.editType === "edit") {
            const detailsData = props.detailsData.data;
            const containerData = props.detailsData.container;
            const serviceData = props.detailsData.service;
            const routeData = props.detailsData.route;
            data.deployStatus = detailsData.deployStatus || "";
            data.durationTime = detailsData.durationTime || "";
            data.lastBuildNum = detailsData.lastBuildNum || "";
            data.successRate = detailsData.successRate || "";
            data.totalSuccessful = detailsData.totalSuccessful || "";
            data.id = detailsData.id || "";
            data.deployDfId = detailsData.deployDfId;
            data.createTime = detailsData.createTime || "";
            data.deployCreateTime = detailsData.deployCreateTime || "";
            data.updateTime = detailsData.updateTime || "";
            data.deployRuntimeName = detailsData.deployRuntimeName || "";
            data.instanceId = detailsData.instanceId || "";
            container.deploymentId = containerData ? containerData.deploymentId : "";
            container.id = containerData ? containerData.id : "";
            container.tagId = containerData ? containerData.tagId : "";

            container.service.serviceId = serviceData ? serviceData.serviceId : "";
            container.service.id = serviceData ? serviceData.id : "";
            container.service.updateTime = serviceData ? serviceData.updateTime : "";
            container.service.createTime = serviceData ? serviceData.createTime : "";
            container.service.deploymentId = serviceData ? serviceData.deploymentId : "";

            container.route.id = routeData ? routeData.id : "";
            container.route.serviceId = routeData ? routeData.serviceId : "";
            container.route.routeId = routeData ? routeData.routeId : "";
            container.route.updateTime = routeData ? routeData.updateTime : "";
            container.route.createTime = routeData ? routeData.createTime : "";
            container.route.routeDomainName = routeData ? routeData.routeDomainName : "";
            container.route.routeType = routeData ? routeData.routeType : "";
            container.route.routeRule = routeData ? routeData.routeRule : "";
            container.route.namespace = routeData ? routeData.namespace : "";
            this.setState({
              saveLoading: true
            });
            props.actions.updateDefination({
              data,
              container
            });
          }
        }
      }
    });
  }

  /**
   * 展示高级设置
   */
  showSettingsClick() {
    this.setState(prevState => ({
      showSettings: !prevState.showSettings
    }));
  }

  /**
   * 展示容器高级设置
   */
  showMirrorSettingsClick() {
    this.setState(prevState => ({
      showMirrorSettings: !prevState.showMirrorSettings
    }));
  }

  /**
   * 添加端口
   */
  addPort() {
    const addData = {
      portName: "",
      clusterPort: "",
      targetPort: "",
      serviceProtocol: ""
    };
    this.setState(prevState => {
      prevState.portData.push(addData);
      return { portData: prevState.portData };
    });
  }

  /**
   * 删除端口
   */
  deletePort(text, record, index) {
    const { props, state } = this;
    const portData = [...state.portData];
    portData.splice(index, 1);
    this.setState({
      portData
    });
    props.form.setFieldsValue({
      port: undefined
    });
  }

  /**
   * 添加环境变量
   */
  addEnvVar() {
    const addEnvData = {
      envName: "",
      envValue: ""
    };
    // const envVarData = Object.assign([], this.state.envVarData);
    // envVarData.push(addData);
    // this.setState({
    //   envVarData: envVarData
    // });
    this.setState(prevState => {
      prevState.envVarData.push(addEnvData);
      return { envVarData: prevState.envVarData };
    });
  }

  /**
   * 删除环境变量
   */
  deleteEnvVar(text, record, index) {
    this.setState(prevState => {
      prevState.envVarData.splice(index, 1);
      return { envVarData: prevState.envVarData };
    });
  }

  /**
   * 添加存储
   */
  addMemory() {
    const addData = {
      volumeName: "",
      volumeHostPath: "",
      volumeContainerPath: ""
    };
    this.setState(prevState => {
      prevState.memoryData.push(addData);
      return { memoryData: prevState.memoryData };
    });
  }

  /**
   * 删除存储
   */
  deleteMemory(text, record, index) {
    this.setState(prevState => {
      prevState.memoryData.splice(index, 1);
      return { memoryData: prevState.memoryData };
    });
  }

  /**
   * 添加变量
   */
  addVar() {
    const addData = {
      attrKey: "",
      attrValue: "",
      attrDesc: ""
    };
    this.setState(prevState => {
      prevState.variableData.push(addData);
      return { variableData: prevState.variableData };
    });
  }

  /**
   * 删除变量
   */
  varDelete(text, record, index) {
    this.setState(prevState => {
      prevState.variableData.splice(index, 1);
      return { variableData: prevState.variableData };
    });
  }

  /**
   * 添加主机
   */
  deployadd(text, record, index) {
    this.setState(prevState => {
      prevState.hostData.push({
        definitionName1: "",
        applicationName1: "",
        IP: "192.168.2.1"
      });
      return { hostData: prevState.hostData };
    });
  }

  /**
   * 取消
   */
  cancel() {
    const { triggleStatus } = this.props;
    triggleStatus(1);
  }

  /**
   * 打开选择软件包界面
   */
  openSoftWareSource() {
    this.setState(prevState => ({
      selectSoftWareSource: true,
      softWareKey: prevState.softWareKey + 1
    }));
  }

  /**
   * 关闭选择软件包界面
   */
  closeSoftWareSource() {
    this.setState({
      selectSoftWareSource: false
    });
  }

  /**
   * 清除选择的软件包
   */
  deleteSoftWareSource() {
    this.softUrl = "";
    this.setState(prevState => ({
      refreshDom: prevState.refreshDom + 1
    }));
  }

  /**
   * 确认选择软件包
   */
  confirmSoftWareSource(selectedData) {
    const { form } = this.props;
    this.setState({
      selectSoftWareSource: false
    });
    if (selectedData) {
      this.softUrl = selectedData[0].artifactUrl;
      form.setFieldsValue({ softUrl: this.softUrl });
    }
  }

  /**
   * 组件选择下拉
   */
  changeComponent(v, option) {
    const { componenetLists } = this.props;
    const selectComp = componenetLists.find(item => item.applicationName == v);
    this.setState({
      applicationName: v,
      applicationId: option.key,
      applicationCode: selectComp.applicationCode
    });
  }

  /**
   * 所在集群下拉
   */
  changeCluster(v, option) {
    const { props, state } = this;
    this.namespaceName = "";
    props.form.setFieldsValue({ namespaceName: "" });
    const selectCluster = props.clusterData.find(item => item.clusterName == v);
    this.setState({
      clusterId: option ? option.key : "",
      selectCluster: selectCluster ? selectCluster : "",
      clusterIngressVipIp:
        selectCluster && selectCluster.clusterIngressVipIp ? selectCluster.clusterIngressVipIp : "",
      deploymentClusterIp:
        selectCluster && selectCluster.clusterVipIp ? selectCluster.clusterVipIp : "",
      clusterVipIp: selectCluster && selectCluster.clusterVipIp ? selectCluster.clusterVipIp : "",
      namespaceId: "",
      deploymentLimitCpu: "",
      deploymentLimitMem: "",
      deploymentRequestCpu: "",
      deploymentRequestMem: ""
    });
    if (!state.envId) {
      // message.info("请选择环境类型");
      return;
    }
    if (option && option.key) {
      props.actions.getNamespacePodListByClusterId({
        clusterId: option.key,
        envId: state.envId
      });
    }
  }

  /**
   * 命名空间下拉
   */
  changeNameSpace(v, option) {
    const { nameSpacePodData } = this.props;
    const selectNameSpace = nameSpacePodData.find(item => item.namespaceName == v);
    this.setState({
      namespaceId: option ? option.key : "",
      deploymentLimitCpu:
        selectNameSpace && selectNameSpace.deploymentDefaultLimitCpu
          ? selectNameSpace.deploymentDefaultLimitCpu
          : "",
      deploymentLimitMem:
        selectNameSpace && selectNameSpace.deploymentDefaultLimitMem
          ? selectNameSpace.deploymentDefaultLimitMem
          : "",
      deploymentRequestCpu:
        selectNameSpace && selectNameSpace.deploymentDefaultRequestCpu
          ? selectNameSpace.deploymentDefaultRequestCpu
          : "",
      deploymentRequestMem:
        selectNameSpace && selectNameSpace.deploymentDefaultRequestMem
          ? selectNameSpace.deploymentDefaultRequestMem
          : ""
    });
    if (selectNameSpace) {
      this.deploymentRequestCpu = selectNameSpace.deploymentDefaultRequestCpu
        ? selectNameSpace.deploymentDefaultRequestCpu
        : "";
      this.deploymentRequestMem = selectNameSpace.deploymentDefaultRequestMem
        ? selectNameSpace.deploymentDefaultRequestMem.match(/\d+/g)
          ? selectNameSpace.deploymentDefaultRequestMem.match(/\d+/g)[0]
          : ""
        : "";
    }
  }

  dropDownNameSpace() {
    const { clusterId } = this.state;
    if (!clusterId) {
      message.info("请选择所在集群");
    }
  }

  dropDownCluster() {
    const { envId } = this.state;
    if (!envId) {
      message.info("请选择环境类型");
    }
  }

  changeMin(v) {
    this.setState({
      deploymentHpaMin: v
    });
  }

  changeMax(v) {
    this.setState({
      deploymentHpaMax: v
    });
  }

  /**
   * 打开添加主机列表
   */
  addHost() {
    const { props, state } = this;
    if (!state.envId) {
      message.info("请选择环境类型");
      return;
    }
    this.setState(
      prevState => ({
        addHostVisual: true,
        addHostKey: prevState.addHostKey + 1
      }),
      () => {
        props.actions.getHostList({
          page: 1,
          size: 10,
          sortid: "resHostUptime",
          sortvalue: "desc",
          conditions: [
            {
              name: "projectId",
              sopt: "eq",
              value: props.projectId ? String(props.projectId) : ""
            },
            {
              name: "envId",
              sopt: "eq",
              value: state.envId !== undefined ? state.envId : ""
            }
          ]
        });
      }
    );
  }

  deleteHost() {
    const { props, state } = this;
    if (state.showHostData.length == 0) {
      message.info("请选择要移除的主机!");
      return;
    }
    const hostData = [...state.hostData];
    this.selectData = hostData.filter(item => {
      return !state.showHostData.find(v => v.resId === item.resId);
    });
    this.setState({
      hostData: this.selectData
    });
    props.form.setFieldsValue({ resIds: this.selectData.join("-") });
  }

  /**
   * 删除主机
   */
  deployDelete(text, record, index) {
    const { props, state } = this;
    const hostData = [...state.hostData];
    hostData.splice(index, 1);
    this.setState({ hostData });
    props.form.setFieldsValue({ resIds: hostData.join("-") });
  }

  /**
   * 确定选择主机
   */
  confirmAddHost() {
    const { props, state } = this;
    const data = JSON.parse(JSON.stringify(state.hostData));
    const tmp = data
      .filter(v => !state.selectedHostData.find(val => val.resId === v.resId))
      .concat(state.selectedHostData);
    this.setState(
      {
        addHostVisual: false,
        hostData: tmp
      },
      () => {
        this.ipArr = state.selectedHostData.map(v => {
          return v.resHostIp;
        });
        props.form.setFieldsValue({ resIds: this.ipArr.join("-") });
      }
    );
  }

  /**
   * 取消选择主机
   */
  closeAddHost() {
    this.setState({
      addHostVisual: false
    });
  }

  /**
   * key改变
   */
  onchangeKey(text, record, key, index, e) {
    const { state } = this;
    const variableData = [...state.variableData];
    variableData[index][key] = e.target.value;
    this.setState({
      variableData
    });
  }

  /**
   * Value改变
   */
  onchangeValue(text, record, key, index, e) {
    const { state } = this;
    const variableData = [...state.variableData];
    variableData[index][key] = e.target.value;
    this.setState({
      variableData
    });
  }

  /**
   * 描述改变
   */
  onchangeDesc(text, record, key, index, e) {
    const { state } = this;
    const variableData = [...state.variableData];
    variableData[index][key] = e.target.value;
    this.setState({
      variableData
    });
  }

  /**
   * 容器端口列数据修改
   */
  onchangeDockerColumns(text, record, key, index, e) {
    const { props, state } = this;
    const portData = [...state.portData];
    if (key !== "serviceProtocol") {
      portData[index][key] = e.target.value;
      switch (key) {
        case "portName":
          this.avaliblePortName = this.rules["portNameRex"].test(e.target.value);
          this.avaliblePortNameStatus =
            e.target.value && this.rules["portNameRex"].test(e.target.value) ? "success" : "error";
          break;
        case "targetPort":
          this.avalibletargetPort = this.rules["targetPortRex"].test(e.target.value);
          this.avalibletargetPortStatus =
            e.target.value && this.avalibletargetPort ? "success" : "error";
          break;
        case "clusterPort":
          this.avalibleclusterPort = this.rules["clusterPortRex"].test(e.target.value);
          this.avalibleclusterPortStatus =
            e.target.value && this.avalibleclusterPort ? "success" : "error";
          break;
        default:
          break;
      }
    } else {
      portData[index][key] = e;
    }
    this.setState({
      portData
    });
    if (state.portData.length > 0) {
      let isAvalible;
      state.portData.forEach(v => {
        for (const k in v) {
          if (v[k] == "") {
            isAvalible = false;
          } else if (v[k]) {
            let portNameIsAvalible;
            let targetPortIsAvalible;
            let clusterPortIsAvalible;
            switch (k) {
              case "portName":
                portNameIsAvalible = this.rules["portNameRex"].test(v[k]) ? true : false;
                break;
              case "targetPort":
                targetPortIsAvalible = this.rules["targetPortRex"].test(v[k]) ? true : false;
                break;
              case "clusterPort":
                clusterPortIsAvalible = this.rules["clusterPortRex"].test(v[k]) ? true : false;
                break;
              default:
                break;
            }
            isAvalible = portNameIsAvalible && targetPortIsAvalible && clusterPortIsAvalible;
          }
        }
      });
      if (isAvalible) {
        props.form.setFieldsValue({
          port: "avaliblePort"
        });
      } else {
        props.form.setFieldsValue({
          port: undefined
        });
      }
    }
  }

  /**
   * 环境变量列数据修改
   */
  onchangeEnvColumns(text, record, key, index, e) {
    const { state } = this;
    const envVarData = [...state.envVarData];
    envVarData[index][key] = e.target.value;
    this.setState({
      envVarData
    });
  }

  /**
   * 存储列数据修改
   */
  onchangeMemoryColumns(text, record, key, index, e) {
    const { state } = this;
    const memoryData = [...state.memoryData];
    memoryData[index][key] = e.target.value;
    this.setState({
      memoryData
    });
  }

  /**
   * http改变
   */
  changeHttp(value) {
    this.defaultHttp = value;
    this.setState({
      httpMethods: value
    });
  }

  /**
   * ip改变
   */
  changeIp(e) {
    this.defaultUrl = e.target.value;
    this.setState({
      ipAddress: e.target.value
    });
  }

  /**
   * html文件改变
   */
  changeFile(e) {
    this.defaultFileName = e.target.value;
    this.setState({
      fileName: e.target.value
    });
  }

  /**
   * 获取最新shell脚本
   */
  changeEdit(newValue, e) {
    const { props } = this;
    props.form.setFieldsValue({ shellContent: newValue });
    this.setState({
      shellContent: newValue
    });
  }

  editorDidMount(editor, monaco) {
    editor.focus();
    // props.changeEdit(newValue);
  }

  changeDeployPath(e) {
    this.deployPath = e.target.value;
    const { props } = this;
    props.form.setFieldsValue({
      deployPath: e.target.value
      // resIds: props.detailsData ? props.detailsData.resIds : ""
    });
  }

  /**
   * 更改应用
   */
  changeApplication(v, e) {
    this.setState({
      applicationName: v.applicationName,
      selectedApp: v
    });
  }

  /**
   * 负载均衡
   */
  onChangeLoad(e) {
    this.setState({
      showLoadOptions: e.target.value
    });
  }

  /**
   *设置高可用
   */
  onchangeSwitch(checked) {
    this.setState({
      deploymentLivenessprobe: Number(checked)
    });
  }

  /**
   * 选择镜像
   */
  changeImage(v, option) {
    const { houseimageData } = this.props;
    const selectImage = houseimageData.find(item => item.imageUrl == v);
    // let selectImage = props.houseimageData.find(item => item.imageAndTag == v);
    // this.setState({ imageTagId: selectImage.imageId });
  }

  /**
   * 改变伸缩步长
   */
  changeStep(v) {
    this.deploymentHpaStepsizeTmp = v;
  }

  /**
   * 改变实例数量
   */
  changeReplicas(v) {
    const { props } = this;
    this.changeReplicasFlag = true;
    if (v - 4 < 0) {
      if (v > 1) {
        this.deploymentHpaStepsize = v - 1;
        props.form.setFieldsValue({ deploymentHpaStepsize: v - 1 });
      } else {
        this.deploymentHpaStepsize = 1;
        props.form.setFieldsValue({ deploymentHpaStepsize: 1 });
      }
    } else if (v - 4 >= 0) {
      this.deploymentHpaStepsize = Math.floor(v * 0.75);
      props.form.setFieldsValue({ deploymentHpaStepsize: Math.floor(v * 0.75) });
    }
  }

  /**
   * 判断显示的部署类型
   */
  renderDeployTypeDom() {
    const { props, state } = this;
    if (props.editType == "edit" && this.deployType == "1") {
      this.deployTypeDom = (
        <Row>
          <Col span={4}>
            <div onClick={this.selectType.bind(this, "shell")}>
              <Row
                style={{
                  height: "82px",
                  textAlign: "center",
                  border: this.deployType == "1" ? "2px solid #9932CC" : "1px solid #ccc",
                  cursor: "pointer"
                }}
              >
                <Col>
                  <img src="/images/img/shell.jpg" alt="" />
                </Col>
                <Col style={{ textAlign: "center" }}>
                  <span>shell部署</span>
                </Col>
              </Row>
            </div>
          </Col>
        </Row>
      );
    } else if (props.editType == "edit" && this.deployType == "2") {
      this.deployTypeDom = (
        <Row>
          <Col span={4} style={{ margin: "0 10px" }}>
            <div onClick={this.selectType.bind(this, "container")}>
              <Row
                style={{
                  // width: "150px",
                  height: "82px",
                  // lineHeight: "82px",
                  textAlign: "center",
                  border: this.deployType == "2" ? "2px solid  #9932CC" : "1px solid #ccc",
                  cursor: "pointer"
                }}
              >
                <Col>
                  <img src="/images/img/container.jpg" alt="" />
                </Col>
                <Col style={{ textAlign: "center" }}>
                  <span>容器部署</span>
                </Col>
              </Row>
            </div>
          </Col>
          {/* <Col span={4}>
        <div onClick={this.selectType.bind(this, "ansible")}>
          <Row
            style={{
              // width: "150px",
              height: "82px",
              // lineHeight: "82px",
              textAlign: "center",
              border:
                this.deployType == "3" ? "2px solid    #9932CC" : "1px solid #ccc",
              cursor: "pointer"
            }}
          >
            <Col>
              <img src="/images/img/ansible.jpg" />
            </Col>
            <Col style={{ textAlign: "center" }}>
              <span>Ansible部署</span>
            </Col>
          </Row>
        </div>
      </Col> */}
        </Row>
      );
    } else if (props.editType == "create") {
      this.deployTypeDom = (
        <Row>
          <Col span={4}>
            <div onClick={this.selectType.bind(this, "shell")}>
              <Row
                style={{
                  height: "82px",
                  textAlign: "center",
                  border: this.deployType == "1" ? "2px solid #9932CC" : "1px solid #ccc",
                  cursor: "pointer"
                }}
              >
                <Col>
                  <img src="/images/img/shell.jpg" alt="" />
                </Col>
                <Col style={{ textAlign: "center" }}>
                  <span>shell部署</span>
                </Col>
              </Row>
            </div>
          </Col>
          <Col span={4} style={{ margin: "0 10px" }}>
            <div onClick={this.selectType.bind(this, "container")}>
              <Row
                style={{
                  height: "82px",
                  textAlign: "center",
                  border: this.deployType == "2" ? "2px solid  #9932CC" : "1px solid #ccc",
                  cursor: "pointer"
                }}
              >
                <Col>
                  <img src="/images/img/container.jpg" alt="" />
                </Col>
                <Col style={{ textAlign: "center" }}>
                  <span>容器部署</span>
                </Col>
              </Row>
            </div>
          </Col>
          {/* <Col span={4}>
        <div onClick={this.selectType.bind(this, "ansible")}>
          <Row
            style={{
              // width: "150px",
              height: "82px",
              // lineHeight: "82px",
              textAlign: "center",
              border:
                this.deployType == "3" ? "2px solid    #9932CC" : "1px solid #ccc",
              cursor: "pointer"
            }}
          >
            <Col>
              <img src="/images/img/ansible.jpg" />
            </Col>
            <Col style={{ textAlign: "center" }}>
              <span>Ansible部署</span>
            </Col>
          </Row>
        </div>
      </Col> */}
        </Row>
      );
    }
    return this.deployTypeDom;
  }

  /**
   * 判断部署方式dom
   */
  renderByDeployMode() {
    const { state, props } = this;
    if (props.editType == "edit" && state.deployMode == "1") {
      this.deployStyleDom = (
        <Col
          span={4}
          className="un-selected pointer-style"
          // onClick={this.selectDeployMode.bind(this, "mirror")}
          style={{
            border: state.deployMode == "1" ? "2px solid #9932CC" : "1px solid #ccc",
            cursor: "pointer"
          }}
        >
          <Row>
            <img src="/images/img/page.png" alt="" />
          </Row>
          <Row>镜像仓库</Row>
        </Col>
      );
    } else if (props.editType == "edit" && state.deployMode == "2") {
      this.deployStyleDom = (
        <Col
          span={4}
          className="un-selected pointer-style"
          style={{
            margin: "0 10px",
            border: state.deployMode == "2" ? "2px solid #9932CC" : "1px solid #ccc",
            cursor: "pointer"
          }}
        >
          <Row>
            <img src="/images/img/shop.png" alt="" />
          </Row>
          <Row>应用商店</Row>
        </Col>
      );
    } else if (props.editType == "create") {
      this.deployStyleDom = (
        <div>
          <Col
            span={4}
            className="un-selected pointer-style"
            onClick={this.selectDeployMode.bind(this, "mirror")}
            style={{
              border: state.deployMode == "1" ? "2px solid #9932CC" : "1px solid #ccc",
              cursor: "pointer"
            }}
          >
            <Row>
              <img src="/images/img/page.png" alt="" />
            </Row>
            <Row>镜像仓库</Row>
          </Col>
          {/* <Col
            span={4}
            className="un-selected pointer-style"
            style={{
              margin: "0 10px",
              border: this.state.deployMode == "shop" ? "2px solid #9932CC" : "1px solid #ccc",
              cursor: "pointer"
            }}
            onClick={this.selectDeployMode.bind(this, "shop")}
          >
            <Row>
              <img src="/images/img/shop.png" />
            </Row>
            <Row>应用商店</Row>
          </Col> */}
        </div>
      );
    }
    return this.deployStyleDom;
  }

  /**
   * 部署方式为应用商店
   */

  render() {
    const { props, state } = this;
    const { getFieldDecorator } = props.form;
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 17 }
    };
    const containerLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 16 }
    };
    const availabilityLayout = {
      labelCol: { span: 14 },
      wrapperCol: { span: 10 }
    };
    this.menu = [{ name: "Tomcat" }, { name: "Java" }];
    this.applicationData = [
      { name: "tomcat8.5" },
      { name: "sonarQube" },
      { name: "jenkins" },
      { name: "Java" },
      { name: "mySQL" },
      { name: "Gitlab" }
    ];
    if (props.editType == "create") {
      if (this.changeReplicasFlag) {
        this.maxStep = this.deploymentHpaStepsize;
      } else if (!this.changeReplicasFlag) {
        this.maxStep = 4;
      }
    } else if (props.editType == "edit") {
      this.maxStep = this.deploymentHpaStepsize;
    }
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.setState({
          selectedHostData: selectedRows,
          selectedRowKeys
        });
      }
    };
    // this.changeReplicasFlag&&props.editType=='create' ? this.deploymentHpaStepsize : 4
    // 获取表格数据源
    const {
      variableData,
      hostData,
      portData,
      envVarData,
      memoryData,
      showLoadOptions,
      deploymentLivenessprobe,
      deployMode
    } = this.state;
    // 获取编辑信息
    const detailsData = props.detailsData.data;
    const containerData = props.detailsData.container;
    const serviceData = props.detailsData.service;
    const routeData = props.detailsData.route;

    this.deploymentEnableHpa = containerData // test
      ? containerData.deploymentEnableHpa
        ? containerData.deploymentEnableHpa
        : 0
      : 0;

    if (props.editType == "edit" && detailsData && !this.firstRender) {
      this.resIds = detailsData.resIds;
      this.deployDfName = props.editType == "clone" ? "" : detailsData.deployDfName;
      this.applicationName = detailsData.applicationName;
      this.deployDfDesc = detailsData.deployDfDesc;
      this.deployType = detailsData.deployType;
      this.installRuntimeEnv =
        detailsData && detailsData.installRuntimeEnv
          ? Boolean(detailsData.installRuntimeEnv)
          : false;
      props.form.setFieldsValue({
        installRuntimeEnv: detailsData.installRuntimeEnv
      });
      this.deployPath = detailsData.deployPath;
      this.serviceLogPath = detailsData.serviceLogPath;
      this.stopShellPath = detailsData.stopShellPath;
      this.startShellPath = detailsData.startShellPath;
      this.restartShellPath = detailsData.restartShellPath;
      this.softUrl = detailsData.packageUrl;
      this.shellContent = detailsData.shellContent;
      // props.form.setFieldsValue({ shellContent: detailsData.shellContent });
      this.differentiationPath = detailsData.differentiationPath;
      this.ips = props.ipsData;
      this.deployEnvType = detailsData.deployEnvType;

      this.defaultVerifyUrl = detailsData.verifyUrl;
      if (this.defaultVerifyUrl) {
        const index = this.defaultVerifyUrl.indexOf(":");
        const index1 = this.defaultVerifyUrl.lastIndexOf(":");
        const index2 = this.defaultVerifyUrl.lastIndexOf("/");
        this.defaultHttp = this.defaultVerifyUrl.substring(0, index);
        this.defaultUrl = this.defaultVerifyUrl.substring(index1 + 1, index2);
        this.defaultFileName = this.defaultVerifyUrl.substring(index2 + 1);
      }
      // 容器部署自有信息
      if (detailsData.deployType !== 1) {
        this.clusterName = containerData.clusterName || "";
        this.namespaceName = containerData.namespaceName || "";
        this.deploymentReplicas = containerData.deploymentReplicas || "";
        this.deployType = String(detailsData.deployType);
        this.packageUrl = detailsData.packageUrl || "";
        this.deployEnvType = detailsData.deployEnvType || "";
        this.deploymentRequestMem = containerData.deploymentRequestMem
          ? containerData.deploymentRequestMem.match(/\d+/g)
            ? containerData.deploymentRequestMem.match(/\d+/g)[0]
            : ""
          : "";
        this.deploymentRequestCpu = containerData.deploymentRequestCpu || "";
        this.deploymentContainerCmd = containerData.deploymentContainerCmd || "";
        this.deploymentContainerArgs = containerData.deploymentContainerArgs || "";
        this.deploymentLivenessprobeScheme = containerData.deploymentLivenessprobeScheme || "";
        this.deploymentLivenessprobePort = containerData.deploymentLivenessprobePort || "";
        this.pInitialdelaydeconds = containerData.pInitialdelaydeconds || "";
        this.lpTimeoutseconds = containerData.lpTimeoutseconds || "";
        this.lpPeriodseconds = containerData.lpPeriodseconds || "";
        this.deploymentLivenessprobe = Boolean(containerData.deploymentLivenessprobe);
        this.deploymentLivenessprobePath = containerData.deploymentLivenessprobePath || "";
        this.deploymentEnableHpa = containerData.deploymentEnableHpa || "";
        this.deploymentHpaTrigger = containerData.deploymentHpaTrigger || "";
        this.ymlContent = containerData.deploymentHpaTrigger || "";
        this.deploymentHpaStepsize =
          containerData.deploymentHpaStepsize &&
          containerData.deploymentReplicas &&
          Number(containerData.deploymentHpaStepsize) -
            Number(containerData.deploymentReplicas) * 0.7 >
            0
            ? Math.ceil(Number(containerData.deploymentReplicas) * 0.7)
            : containerData.deploymentHpaStepsize
            ? Number(containerData.deploymentHpaStepsize)
            : "";
        this.deploymentHpaStepsizeTmp = containerData.deploymentHpaStepsize;
        this.lpInitialdelaydeconds = containerData.lpInitialdelaydeconds || "";
        this.lpInitialdelaydeconds = containerData.lpInitialdelaydeconds || "";
        this.serviceType = serviceData ? serviceData.serviceType : "";
        this.routeProtocol = routeData ? routeData.routeProtocol : "";
        this.routePath = routeData ? routeData.routePath : "";
        this.routePort = routeData ? routeData.routePort : "";
      }
      this.firstRender = true;
    } else if (props.editType === "create") {
      this.shellContent = props.shellContent;
    }
    // 是否显示高可用选项
    if (deploymentLivenessprobe) {
      this.HigAvailabilityformItemDom = (
        <div>
          <FormItem label="重启检查项" {...formItemLayout}>
            {getFieldDecorator("deploymentLivenessprobeScheme", {
              initialValue: this.deploymentLivenessprobeScheme
            })(
              <Select style={{ width: "50%" }}>
                <Option value="HTTP">http</Option>
              </Select>
            )}
          </FormItem>
          <Row style={{ paddingLeft: "7.7%" }}>
            <Col span={4}>
              <FormItem label="端口" {...availabilityLayout}>
                {getFieldDecorator("deploymentLivenessprobePort", {
                  rules: Validation.Rule_resHostIp,
                  initialValue: this.deploymentLivenessprobePort
                })(<Input maxLength={256} style={{ width: "80%" }} />)}
              </FormItem>
            </Col>
            <Col span={4}>
              <FormItem label="首次检查延时" {...availabilityLayout}>
                {getFieldDecorator("lpInitialdelaydeconds", {
                  rules: Validation.Rule_falsenumber,
                  initialValue: this.lpInitialdelaydeconds
                })(<Input maxLength={256} style={{ width: "80%" }} />)}
                &nbsp;S
              </FormItem>
            </Col>
            <Col span={4}>
              <FormItem label="检查超时" {...availabilityLayout}>
                {getFieldDecorator("lpTimeoutseconds", {
                  rules: Validation.Rule_falsenumber,
                  initialValue: this.lpTimeoutseconds
                })(<Input maxLength={256} style={{ width: "80%" }} />)}
                &nbsp;S
              </FormItem>
            </Col>
            <Col span={4}>
              <FormItem label="检查间隔" {...availabilityLayout}>
                {getFieldDecorator("lpPeriodseconds", {
                  rules: Validation.Rule_falsenumber,
                  initialValue: this.lpPeriodseconds
                })(<Input maxLength={256} style={{ width: "80%" }} />)}
                &nbsp;S
              </FormItem>
            </Col>
          </Row>
          <FormItem label="path路径" {...formItemLayout}>
            {getFieldDecorator("deploymentLivenessprobePath", {
              rules: Validation.Rule_path,
              initialValue: this.deploymentLivenessprobePath
            })(<Input maxLength={256} style={{ width: "70%" }} />)}
          </FormItem>
        </div>
      );
    } else {
      this.HigAvailabilityformItemDom = "";
    }
    // 负载均衡设置为公网访问选项
    if (showLoadOptions == "LoadBalancer") {
      this.loadStyleDom = (
        <div>
          <FormItem label="服务名称" {...formItemLayout}>
            {getFieldDecorator("routeProtocol", {
              rules: Validation.Rule_routeProtocol,
              initialValue: this.routeProtocol
            })(<Input maxLength={32} />)}
            <div>服务名为高级配置中，端口列表指定的服务名</div>
          </FormItem>
          <FormItem label="验证路径" {...formItemLayout}>
            {getFieldDecorator("routePath", {
              rules: Validation.Rule_routePath,
              initialValue: this.routePath
            })(<Input maxLength={256} />)}
            <div>路径为当前服务对应的验证路径</div>
          </FormItem>
          <FormItem label="路由端口" {...formItemLayout}>
            {getFieldDecorator("routePort", {
              rules: Validation.Rule_number,
              initialValue: this.routePort
            })(<Input maxLength={32} />)}
            <div>路由端口为当前选择服务端口，注意不是容器端口</div>
          </FormItem>
        </div>
      );
    } else {
      this.loadStyleDom = "";
    }
    if (hostData) {
      this.ipArr = hostData.map(v => {
        return v.resHostIp;
      });
      hostData.forEach((v, i) => {
        v.order = i + 1;
        v.key = i;
      });
    }
    if (variableData) {
      variableData.forEach((v, i) => {
        v.key = i;
      });
    }
    return (
      <Spin spinning={state.spin}>
        <div id="deployMentForm">
          <div>
            <span style={{ cursor: "pointer" }} onClick={this.goBack.bind(this)}>
              返回
            </span>
            <span> / 部署管理</span>
          </div>
          <div
            style={{
              textAlign: "left",
              height: "60px",
              lineHeight: "60px",
              padding: "10px",
              borderBottom: "1px solid #ccc"
            }}
          >
            <span style={{ display: props.editType == "create" ? "inline-block" : "none" }}>
              创建部署任务
            </span>
            <span style={{ display: props.editType == "edit" ? "inline-block" : "none" }}>
              修改部署任务
            </span>
          </div>
          <Form>
            <div>基本信息</div>
            <FormItem label="名称" {...formItemLayout}>
              {getFieldDecorator("deployDfName", {
                rules: Validation.Rule_code,
                initialValue: this.deployDfName
              })(
                <Input
                  placeholder="请输入任务名称"
                  maxLength={32}
                  disabled={props.editType === "edit"}
                />
              )}
            </FormItem>
            <FormItem label="所属组件" {...formItemLayout}>
              {getFieldDecorator("applicationName", {
                rules: Validation.Rule_select,
                initialValue: this.applicationName
              })(
                <Select
                  style={{ width: "50%" }}
                  allowClear
                  disabled={props.editType === "edit"}
                  onChange={this.changeComponent.bind(this)}
                >
                  {props.componenetLists
                    ? props.componenetLists.map(v => {
                        return (
                          <Option value={v.applicationName} key={v.applicationId}>
                            {v.applicationName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            <FormItem label="描述" {...formItemLayout}>
              {getFieldDecorator("deployDfDesc", {
                initialValue: this.deployDfDesc
              })(<TextArea maxLength={256} />)}
            </FormItem>
            <div>部署设置</div>
            <FormItem label="部署类型" {...formItemLayout}>
              {getFieldDecorator("deployType", {
                // initialValue: this.deployType
              })(this.renderDeployTypeDom())}
            </FormItem>
            <div>{this.renderByDeployType()}</div>
          </Form>
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <Button
              type="primary"
              loading={state.saveLoading}
              style={{ marginRight: "10px" }}
              onClick={() => {
                this.submitClick();
              }}
            >
              确定
            </Button>
            <Button onClick={this.cancel.bind(this)}>取消</Button>
          </div>
          {/* 弹框部分开始 */}
          <Modal
            maskClosable={false}
            title="发布仓库管理"
            visible={state.selectSoftWareSource}
            onOk={() => this.confirmSoftWareSource()}
            onCancel={this.closeSoftWareSource.bind(this)}
            key={state.softWareKey}
            okText="确定"
            cancelText="取消"
            width={900}
            footer={null}
          >
            <SoftWareSourceManageFrom
              projectName={props.projectName}
              projectId={props.projectId}
              onOk={this.confirmSoftWareSource.bind(this)}
              onCancel={this.closeSoftWareSource.bind(this)}
            />
          </Modal>
          <Modal
            maskClosable={false}
            title="配置主机"
            visible={state.addHostVisual}
            onOk={this.confirmAddHost.bind(this)}
            onCancel={this.closeAddHost.bind(this)}
            // key={state.addHostKey}
            okText="确定"
            cancelText="取消"
            width={900}
            // footer={null}
          >
            <Table
              columns={this.hostColumns}
              rowKey="id"
              rowSelection={rowSelection}
              pagination={props.hostPageConfig}
              dataSource={props.hostListData}
            />
          </Modal>
          {/* 弹框部分结束 */}
        </div>
      </Spin>
    );
  }
}
const mapStateToProps = state => {
  return {
    saveFlag: state.Deploy.get("saveFlag"),
    updateFlag: state.Deploy.get("updateFlag"),
    runningEnvList: state.Deploy.get("runningEnvList"),
    hostListData: state.Deploy.get("hostListData"),
    hostPageConfig: state.Deploy.get("hostPageConfig"),
    shellContent: state.Deploy.get("shellContent"),
    detailsData: state.Deploy.get("detailsData"),
    ipsData: state.Deploy.get("ipsData"),
    attr: state.Deploy.get("attr"),
    cloneFlag: state.Deploy.get("cloneFlag"),
    ymlTmpData: state.Deploy.get("ymlTmpData"),
    componenetLists: state.PjmComponent.get("resData"),
    clusterData: state.Resource.get("clusterData"),
    nameSpacePodData: state.Resource.get("nameSpacePodData"),
    imageList: state.Deploy.get("imageList"),
    envFlag: state.Deploy.get("envFlag"),
    houseimageData: state.ImageHouse.get("houseimageData"),
    envData: state.Environment.get("resData"),
    appListData: state.Resource.get("appListData")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign(
    {},
    DeploymentManageActions,
    ComponentAction,
    ResourceAction,
    ImageActions,
    EnvAction
  );
  return { actions: bindActionCreators(combineAction, dispatch) };
};
const NewDeployMentFrom = Form.create()(NewDeployMent);
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(NewDeployMentFrom);
