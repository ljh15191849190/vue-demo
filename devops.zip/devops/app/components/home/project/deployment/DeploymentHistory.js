import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Icon,
  Button,
  Popconfirm,
  Form,
  message,
  Select,
  Modal,
  Row,
  Col,
  Checkbox,
  InputNumber,
  Steps,
  Tabs,
  Radio
} from "antd";
import "antd/dist/antd.css";
import * as ComponentAction from "../../../../actions/ComponentList";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import CodeViewer from "../../../commons/CodeViewer";
import MonacoEditor from "../../../commons/MonacoEditor";

const Option = Select.Option;
const FormItem = Form.Item;
const { TextArea } = Input;
const Search = Input.Search;
const Step = Steps.Step;
const TabPane = Tabs.TabPane;
const RadioGroup = Radio.Group;

class DeploymentHistory extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {},
      isDeployed: false,
      showDeployPage: false,
      showDeployPageKey: 1,
      deployStatus: 1,
      historyVisual: false,
      current: 0,
      total: "",
      pageSize: 10,
      hostData: [
        {
          name: "---",
          path: "iiii",
          ip: "192.168.1.1"
        }
      ],
      historyData: [
        {
          order: 1,
          operator: "000",
          deploymnetTime: "xxxx",
          type: "000",
          status: "---",
          lastTime: "---"
        }
      ]
    };
    const { selectedRow, deployType } = this.props;
    this.columns = [
      {
        title: "名称",
        dataIndex: "name",
        key: "name"
      },
      {
        title: "IP",
        dataIndex: "ip",
        key: "ip",
        render: (text, record) => this.renderColumns(text, record, "ip")
      },
      {
        title: "应用验证路径",
        dataIndex: "path",
        key: "path",
        render: (text, record) => this.renderColumns(text, record, "path")
      },
      {
        title: "查看日志",
        dataIndex: "action",
        key: "action",
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    this.hostInfoColumns = [
      {
        title: "序号",
        dataIndex: "order",
        key: "order",
        render: (text, record) => this.renderColumns(text, record, "order")
      },
      {
        title: "主机",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "应用验证路径",
        dataIndex: "path",
        key: "path",
        render: (text, record) => {
          return selectedRow.verifyUrl ? (
            <a
              href={selectedRow.verifyUrl.replace("ip", record.resHostIp)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {selectedRow.verifyUrl.replace("ip", record.resHostIp)}
            </a>
          ) : (
            ""
          );
        }
      }
    ];
    this.hostColumns = [
      {
        title: "主机",
        dataIndex: "name",
        key: "name"
      },
      {
        title: "IP",
        dataIndex: "ip",
        key: "ip",
        render: (text, record) => this.renderColumns(text, record, "ip")
      },
      {
        title: "主机组",
        dataIndex: "path",
        key: "path",
        render: (text, record) => this.renderColumns(text, record, "path")
      }
    ];
    this.urlColumns = [
      {
        title: deployType == 1 ? "软件包URL" : "镜像",
        dataIndex: "packageUrl",
        key: "packageUrl"
        // width: 80
      }
    ];
    this.paramsColumns = [
      {
        title: "序号",
        dataIndex: "order",
        key: "order"
      },
      {
        title: "名称",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => {
          return "hostName";
        }
      },
      {
        title: "默认值",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "描述",
        dataIndex: "description",
        key: "description"
      }
    ];
    this.historialColumns = [
      {
        title: "序号",
        dataIndex: "deployNumber",
        key: "deployNumber"
        // width: 80
      },
      // {
      //   title: "操作者",
      //   dataIndex: "operator",
      //   key: "operator"
      //   // width: 100
      // },
      {
        title: "部署时间",
        dataIndex: "buildBeginTime",
        key: "buildBeginTime",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "buildBeginTime")
      },
      // {
      //   title: "类型",
      //   dataIndex: "type",
      //   key: "type",
      //   // width: 80,
      //   render: (text, record) => this.renderColumns(text, record, "type")
      // },
      {
        title: "状态",
        dataIndex: "deployStatus",
        key: "deployStatus",
        // width: 80,
        render: (text, record) => this.renderColumns(text, record, "deployStatus")
      },
      {
        title: "部署持续时间",
        dataIndex: "durationTime",
        key: "durationTime",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "durationTime")
      },
      {
        title: "操作",
        dataIndex: "action",
        key: "action",
        // width: 80,
        render: (text, record) => this.renderActions(text, record, "history")
      }
    ];
    this.timer1 = null;
  }

  // 生命周期部分开始
  componentDidMount() {
    const { actions, selectedRow } = this.props;
    actions.getHistoryData({
      page: 1,
      size: 10,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
    });
  }

  componentWillUnmount() {
    clearInterval(this.timer1);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  // 生命周期部分结束
  // 实例方法部分开始
  /**
   * 分页操作
   */
  handlePageChange(page, pageSize) {
    const { actions, selectedRow } = this.props;
    this.setState({
      loading: true,
      page,
      pageSize
    });
    actions.getHistoryData({
      page,
      size: pageSize,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
    });
  }

  onShowSizeChange(current, pageSize) {
    const { actions, selectedRow } = this.props;
    this.setState({
      current,
      pageSize
    });
    actions.getHistoryData({
      page: current,
      size: pageSize,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
    });
  }

  /**
   * 返回部署管理
   */
  goBack() {
    const { actions, triggleStatus } = this.props;
    actions.resetDetails();
    triggleStatus(1);
  }

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    if (column === "deployStatus" && text) {
      if (text === "FAILURE") {
        return (
          <div>
            <Icon
              className="padright"
              type="close-circle"
              style={{
                fontSize: 16,
                color: "#ff0000"
              }}
            />
            <span>失败</span>
          </div>
        );
      } else if (text === "SUCCESS") {
        return (
          <div>
            <Icon
              className="padright"
              type="check-circle"
              style={{
                fontSize: 16,
                color: "#00ff48"
              }}
            />
            <span>成功</span>
          </div>
        );
      } else if (text === "BUILDINGH") {
        return (
          <div>
            <Icon
              className="padright"
              type="clock-circle"
              style={{
                fontSize: 16,
                color: "#1890ff"
              }}
            />
            <span>部署中</span>
          </div>
        );
      }
    }
    if (column === "durationTime" && text) {
      return `${text / 1000}s`;
    }
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, type) {
    if (type === "log") {
      return (
        <div>
          <Icon type="file-text" theme="outlined" style={{ cursor: "pointer", fontSize: "18px" }} />
        </div>
      );
    } else if (type === "history") {
      return (
        <div>
          <Icon
            type="eye"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.openHistory.bind(this, record)}
          />
        </div>
      );
    }
  }

  /**
   * 打开历史
   */
  openHistory(record) {
    const { actions, selectedRow } = this.props;
    this.setState({
      historyVisual: true,
      deployStatus: record.deployStatus
    });
    actions.getHistoryDataDetails({ id: record.id });
    actions.deployHisConsole({
      jobName: selectedRow.deployDfName,
      buildNum: record.deployNumber,
      pojectId: record.projectId
    });
  }

  /**
   * 关闭历史
   */
  closeHistory() {
    const { actions } = this.props;
    this.setState({
      historyVisual: false
    });
    actions.resetDetails();
  }

  /**
   * 执行参数
   */
  renderExecumentParamsDom() {
    const { deployType, historyDetails } = this.props;
    let dom = "";
    if (deployType == 1) {
      dom = (
        <div style={{ marginBottom: "20px" }}>
          <div style={{ fontSize: "15px", paddingLeft: "10px" }}>执行参数</div>
          <Table
            columns={this.paramsColumns}
            pagination={false}
            dataSource={
              historyDetails.ips
                ? historyDetails.ips.map((v, i) => {
                    v.order = i + 1;
                    return v;
                  })
                : []
            }
          />
        </div>
      );
    }
    return dom;
  }

  /**
   * 主机信息
   */
  renderHostsDom() {
    let hostDom = "";
    const { deployType, historyDetails } = this.props;
    if (deployType == 1) {
      hostDom = (
        <div style={{ marginBottom: "20px" }}>
          <div style={{ fontSize: "15px", paddingLeft: "10px" }}>主机信息</div>
          <Table
            columns={this.hostInfoColumns}
            pagination={false}
            dataSource={
              historyDetails.ips
                ? historyDetails.ips.map((v, i) => {
                    v.order = i + 1;
                    return v;
                  })
                : []
            }
          />
        </div>
      );
    }
    return hostDom;
  }

  // 实例方法部分结束
  render() {
    const urlArr = [];
    const { historyDetails, historyData, deployType, selectedRow, hisConsoleData } = this.props;
    const { state } = this;
    if (historyDetails.data) {
      urlArr[0] = historyDetails.data;
    }
    const pagination = {
      total: state.pagination.total,
      pageSize: state.pagination.pageSize,
      current: state.pagination.current,
      // showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange.bind(this),
      onChange: this.handlePageChange.bind(this)
    };
    return (
      <div>
        <div>
          <span style={{ cursor: "pointer" }} onClick={this.goBack.bind(this)}>
            返回
          </span>
          <span> / 部署管理</span>
        </div>
        <Table
          columns={this.historialColumns}
          pagination={pagination}
          dataSource={historyData.map((v, i) => {
            v.order = i + 1;
            return v;
          })}
        />
        {/* 弹框部分开始 */}

        <Modal maskClosable={false}
          title="部署历史"
          visible={state.historyVisual}
          footer={null}
          width={1000}
          onCancel={this.closeHistory.bind(this)}
        >
          <Tabs defaultActiveKey="1">
            <TabPane tab="部署详情" key="1">
              <Row style={{ textAlign: "center", marginBottom: "30px" }}>
                <Col span={12}>
                  <Row display="flex" alignitems="center">
                    <Col span={8}>
                      <Icon
                        type="check-circle"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "SUCCESS" ? "inline-block" : "none",
                          color: "#00ff48",
                          fontSize: "50px"
                        }}
                      />
                      <Icon
                        type="loading"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "BUILDINGH" ? "inline-block" : "none",
                          color: "#1890ff",
                          fontSize: "50px"
                        }}
                      />
                      <Icon
                        type="close-circle"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "FAILURE" ? "inline-block" : "none",
                          color: "#ff0000",
                          fontSize: "50px"
                        }}
                      />
                    </Col>
                    <Col span={14}>
                      <div>
                        类型：
                        {"安装"}
                      </div>
                      <div>
                        时间：
                        {historyDetails && historyDetails.data
                          ? historyDetails.data.buildBeginTime
                          : ""}
                      </div>
                    </Col>
                  </Row>
                </Col>
              </Row>
              <div style={{ marginBottom: "20px" }}>
                <div
                  style={{
                    display: deployType == 1 ? "block" : "none",
                    fontSize: "15px",
                    paddingLeft: "10px"
                  }}
                >
                  软件包URL
                </div>
                <div
                  style={{
                    display: deployType == 2 ? "block" : "none",
                    fontSize: "15px",
                    paddingLeft: "10px"
                  }}
                >
                  部署镜像
                </div>
                <Table columns={this.urlColumns} pagination={false} dataSource={urlArr} />
              </div>
              {this.renderExecumentParamsDom()}
              {this.renderHostsDom()}
            </TabPane>
            <TabPane tab="部署日志" key="2">
              <div
                style={{
                  maxHeight: 500,
                  overflowY: "scroll"
                }}
              >
                <div
                  dangerouslySetInnerHTML={{
                    __html:
                      selectedRow.deployType == 1
                        ? hisConsoleData
                        : historyDetails.data && historyDetails.data.deployLog
                        ? historyDetails.data.deployLog
                        : ""
                  }}
                />
              </div>
            </TabPane>
          </Tabs>
        </Modal>
        {/* 弹框部分结束 */}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.Build.get("resData"),
    historyData: state.Deploy.get("historyData"),
    pageConfig: state.Deploy.get("pageConfig"),
    historyDetails: state.Deploy.get("historyDetails"),
    consoleData: state.Deploy.get("consoleData"),
    hisConsoleData: state.Deploy.get("hisConsoleData")
  };
};

const mapDispatchToProps = dispatch => {
  // let combineAction = Object.assign({}, BuildActions, ComponentAction);
  return { actions: bindActionCreators(DeploymentManageActions, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DeploymentHistory);
