import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Icon,
  Button,
  Form,
  message,
  Select,
  Modal,
  Row,
  Col,
  Steps,
  Tabs,
  Radio
} from "antd";
import "antd/dist/antd.css";
import moment from "moment";
import { cps } from "redux-saga/effects";
import * as ComponentAction from "../../../../actions/ComponentList";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";
import * as mdactions from "../../../../actions/MediumWarehouse";
import Validation from "../../../../utils/Validation";
import "./deploy.css";

const Option = Select.Option;
const FormItem = Form.Item;
const Search = Input.Search;
const Step = Steps.Step;
const TabPane = Tabs.TabPane;
const RadioGroup = Radio.Group;
const ExecuteDeploy = Form.create()(props => {
  const {
    onCancel,
    form,
    handleSubmit,
    hostColumns,
    onChangeSelect,
    softBagList,
    ipsListData,
    detailsData,
    scope,
    selectedRow,
    projectName,
    deployStatusCode,
    getIpsListbyId
  } = props;
  const { getFieldDecorator } = form;
  const formItemLayout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 15 }
  };
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      scope.setState({
        selectedIps: selectedRows
      });
    },
    getCheckboxProps: record => ({
      disabled: record.name === "Disabled User",
      name: record.name
    })
  };
  return (
    <Form layout="vertical" onSubmit={handleSubmit}>
      <FormItem
        label="操作类型:"
        {...formItemLayout}
        style={{
          display: deployStatusCode === "" ? "block" : "none"
        }}
      >
        {getFieldDecorator("opsType", {
          rules: [{ required: true, message: "标签名称不能为空", maxLength: 32 }],
          initialValue: "install"
        })(
          <RadioGroup>
            <Radio value="install">安装</Radio>
          </RadioGroup>
        )}
      </FormItem>
      <FormItem label="项目名称:" {...formItemLayout}>
        {getFieldDecorator("applicationName", {
          initialValue:
            detailsData && detailsData.applicationName ? detailsData.applicationName : projectName
        })(<Input readOnly />)}
      </FormItem>
      <FormItem label="软件包:" {...formItemLayout}>
        {getFieldDecorator("packageUrl", {
          rules: Validation.Rule_select,
          initialValue: detailsData && detailsData.packageUrl ? detailsData.packageUrl : ""
        })(
          <Select allowClear onChange={onChangeSelect}>
            {softBagList
              ? softBagList.map(v => {
                  return (
                    <Option value={v.artifactUrl} key={Math.random()}>
                      {v.artifactUrl
                        ? v.artifactUrl.substr(v.artifactUrl.lastIndexOf(":") + 5)
                        : ""}
                    </Option>
                  );
                })
              : ""}
          </Select>
        )}
      </FormItem>
      <FormItem label="选择主机:">
        <Search
          // placeholder="input search text"
          onSearch={value => getIpsListbyId(value)}
          enterButton
          style={{ marginBottom: "10px" }}
        />
        <Table columns={hostColumns} rowSelection={rowSelection} dataSource={ipsListData} />
      </FormItem>
    </Form>
  );
});

class DeploymentDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pagination: {},
      isDeployed: false,
      loading: false,
      showDeployPage: false,
      showDeployPageKey: 1,
      deployStatus: 1,
      historyVisual: false,
      current: 0,
      currentStatus: "",
      selectedIps: [],
      isEnter: false,
      total: "",
      pageSize: 10,
      hisPagination: {},
      showPodLog: false,
      podLogKey: 2,
      hostData: [
        {
          name: "---",
          path: "iiii",
          ip: "192.168.1.1"
        }
      ],
      historyData: [
        {
          order: 1,
          operator: "000",
          deploymnetTime: "xxxx",
          type: "000",
          status: "---",
          lastTime: "---"
        }
      ]
    };
    this.SuccessRunStatus = "loading";
    this.startStatus = "loading";
    this.SuccessFinStatus = "close";
    const { selectedRow } = this.props;
    const { verifyUrl } = selectedRow;
    this.deployColumns = [
      {
        title: "名称",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "应用验证路径",
        dataIndex: "verifyUrl",
        key: "verifyUrl",
        render: (text, record) => {
          return (
            <div>
              <a href={`http://${record.verifyUrl}`} target="_blank" rel="noopener noreferrer">
                {record.verifyUrl}
              </a>
            </div>
          );
        }
      },
      {
        title: "查看日志",
        dataIndex: "action",
        key: "action",
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    this.columns = [
      {
        title: "名称",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "应用验证路径",
        dataIndex: "verifyUrl",
        key: "verifyUrl",
        render: (text, record) => {
          return verifyUrl ? (
            <a
              href={verifyUrl.replace("ip", record.resHostIp)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {verifyUrl.replace("ip", record.resHostIp)}
            </a>
          ) : (
            ""
          );
        }
      },
      {
        title: "查看日志",
        dataIndex: "action",
        key: "action",
        render: (text, record) => this.renderActions(text, record, "log")
      }
    ];
    this.hostInfoColumns = [
      {
        title: "序号",
        dataIndex: "order",
        key: "order",
        render: (text, record) => this.renderColumns(text, record, "order")
      },
      {
        title: "主机",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "应用验证路径",
        dataIndex: "path",
        key: "path",
        render: (text, record) => {
          return verifyUrl ? (
            <a
              href={verifyUrl.replace("ip", `http://${record.resHostIp}`)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {verifyUrl.replace("ip", record.resHostIp)}
            </a>
          ) : (
            ""
          );
        }
      }
    ];
    this.hostColumns = [
      {
        title: "主机",
        dataIndex: "resName",
        key: "resName"
      },
      {
        title: "IP",
        dataIndex: "resHostIp",
        key: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "ip")
      },
      {
        title: "主机组",
        dataIndex: "path",
        key: "path",
        render: (text, record) => {
          return "---";
        }
      }
    ];
    this.urlColumns = [
      {
        title: "软件包URL",
        dataIndex: "packageUrl",
        key: "packageUrl"
        // width: 80
      }
    ];
    this.paramsColumns = [
      {
        title: "序号",
        dataIndex: "order",
        key: "order"
      },
      {
        title: "名称",
        dataIndex: "name",
        key: "name",
        render: (text, record) => {
          return "hostName";
        }
      },
      {
        title: "默认值",
        dataIndex: "resName",
        key: "resName",
        render: (text, record) => this.renderColumns(text, record, "resName")
      },
      {
        title: "描述",
        dataIndex: "description",
        key: "description"
      }
    ];
    this.historialColumns = [
      {
        title: "序号",
        dataIndex: "deployNumber",
        key: "deployNumber"
        // width: 80
      },
      // {
      //   title: "操作者",
      //   dataIndex: "operator",
      //   key: "operator"
      //   // width: 100
      // },
      {
        title: "部署时间",
        dataIndex: "buildBeginTime",
        key: "buildBeginTime",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "buildBeginTime")
      },
      // {
      //   title: "类型",
      //   dataIndex: "type",
      //   key: "type",
      //   // width: 80,
      //   render: (text, record) => this.renderColumns(text, record, "type")
      // },
      {
        title: "状态",
        dataIndex: "deployStatus",
        key: "deployStatus",
        // width: 80,
        render: (text, record) => this.renderColumns(text, record, "deployStatus")
      },
      {
        title: "部署持续时间",
        dataIndex: "durationTime",
        key: "durationTime",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "durationTime")
      },
      {
        title: "操作",
        dataIndex: "action",
        key: "action",
        // width: 80,
        render: (text, record) => this.renderActions(text, record, "history")
      }
    ];
    this.podColumns = [
      {
        title: "pod名称",
        dataIndex: "name",
        key: "name",
        // width: 80
        render: (text, record) => this.renderColumns(text, record, "name")
      },
      {
        title: "状态",
        dataIndex: "status",
        key: "status",
        // width: 80,
        render: (text, record) => this.renderColumns(text, record, "status")
      },
      {
        title: "创建时间",
        dataIndex: "time",
        key: "time",
        // width: 150,
        render: (text, record) => this.renderColumns(text, record, "time")
      },
      {
        title: "操作",
        dataIndex: "action",
        key: "action",
        // width: 80,
        render: (text, record) => this.renderActions(text, record, "pod")
      }
    ];
    this.timer = null;
    this.timer1 = null;
    this.timer2 = null;
    this.timer3 = null;
    this.deployType = "";
    this.deployStatusCode = "BUILDINGH";
  }

  // 生命周期部分开始
  componentDidMount() {
    this.deployStatusCode = "BUILDINGH";
    const {
      actions,
      selectedRow,
      id,
      executeData,
      deployType,
      defName,
      projectId,
      compName
    } = this.props;
    const { deployDfId } = selectedRow;
    actions.resetDeployCode();
    if (deployDfId) {
      actions.getHistoryData({
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: [{ name: "deployDfId", sopt: "eq", value: String(deployDfId) }]
      });
    }
    actions.findDefination(id);
    actions.getPodList({ id });
    const payload = {
      page: 1,
      conditions: [{}]
    };
    actions.findMedium(payload);
    this.timer1 = setInterval(() => {
      if (executeData) {
        let obj = {};
        if (deployType == 1) {
          obj = {
            jobName: defName,
            buildNum: executeData ? executeData : this.executeData,
            pojectId: projectId,
            deployType
          };
        } else if (deployType == 2) {
          obj = {
            deployType,
            deployDfId
          };
        }
        actions.deployConsole(obj);
        actions.findDeployStatus({
          id,
          defName: deployType == 1 ? defName : deployType == 2 ? compName : "",
          buildNum: executeData ? executeData : this.executeData
        });
      }
    }, 2000);
    this.timer = setTimeout(() => {
      this.startStatus = "check";
    }, 2000);
  }

  componentWillUpdate(nextProps, nextState) {
    const { executeData, actions } = this.props;
    if (nextProps.time) {
      this.time = nextProps.time;
    }
    if (nextProps.deployStatusCode === "FAILURE") {
      nextState.current = 7;
      nextState.isDeployed = false;
      this.executeData = executeData;
      actions.resetDepStatus();
    }
  }

  componentWillReceiveProps(nextProps) {
    const { actions, executeData, selectedRow, id, defName, deployType, compName } = this.props;
    const { current } = this.state;
    if (nextProps.deployStatusCode) {
      this.deployStatusCode = nextProps.deployStatusCode;
    }
    if (nextProps.exception) {
      message.warning(nextProps.exception);
      this.SuccessRunStatus = "close";
      this.SuccessFinStatus = "close";
      this.deployStatusCode = "FAILURE";
      actions.resetDepStatus();
      clearInterval(this.timer1);
      clearInterval(this.timer2);
      clearTimeout(this.timer);
      clearTimeout(this.timer3);
    }
    if (nextProps.hisPageConfig) {
      this.setState({
        hisPagination: {
          total: nextProps.hisPageConfig.total,
          current: nextProps.hisPageConfig.page,
          pageSize: nextProps.hisPageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.deployStatusCode !== "") {
      const fun = () => {
        let obj = {};
        if (nextProps.deployType == 2) {
          actions.getPodList({ id });
          obj = {
            deployType: nextProps.deployType,
            deployDfId: nextProps.deployDfId
          };
        } else if (nextProps.deployType == 1) {
          obj = {
            jobName: nextProps.defName,
            buildNum: nextProps.executeData ? executeData : this.executeData,
            pojectId: nextProps.projectId,
            deployType: nextProps.deployType
          };
          actions.getHistoryData({
            page: 1,
            size: 10,
            sortid: "id",
            sortvalue: "desc",
            conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
          });
        }
        actions.deployConsole(obj);
        clearInterval(this.timer1);
        clearInterval(this.timer2);
        clearTimeout(this.timer);
        clearTimeout(this.timer3);
      };
      if (nextProps.deployStatusCode === "SUCCESS") {
        this.SuccessRunStatus = "check";
        this.SuccessFinStatus = "check";
        this.startStatus = "check";
        fun();
        actions.resetDepStatus();
        clearInterval(this.timer1);
        clearInterval(this.timer2);
        clearTimeout(this.timer);
        clearTimeout(this.timer3);
      } else if (nextProps.deployStatusCode === "FAILURE") {
        this.SuccessRunStatus = "close";
        this.SuccessFinStatus = "close";
        fun();
        actions.resetDepStatus();
        clearInterval(this.timer1);
        clearInterval(this.timer2);
        clearTimeout(this.timer);
        clearTimeout(this.timer3);
      } else if (nextProps.deployStatusCode === "BUILDINGH") {
        this.SuccessRunStatus = "loading";
        this.SuccessFinStatus = "loading";
      }
    }
    if (nextProps.deployStatusCode === "BUILDINGH" || nextProps.deployStatusCode === "SUCCESS") {
      this.setState(
        {
          current: 4,
          isDeployed: true
        },
        () => {
          if (nextProps.executeFlag && current === 4 && nextProps.deployStatusCode == "SUCCESS") {
            this.setState(
              {
                current: 7,
                isDeployed: false,
                currentStatus: "finish"
              },
              () => {
                this.executeData = executeData;
                actions.resetDepStatus();
              }
            );
            // nextState.current = 7;
            // nextState.isDeployed = true;
          } else if (
            nextProps.executeFlag &&
            current === 4 &&
            nextProps.deployStatusCode === "FAILURE"
          ) {
            this.setState(
              {
                current: 7,
                isDeployed: false,
                currentStatus: "error"
              },
              () => {
                this.executeData = executeData;
                actions.resetDepStatus();
              }
            );
          }
        }
      );
    }
    if (this.deployStatusCode === "BUILDINGH" && (this.onkeyDep || this.paramsDep)) {
      this.timer1 = setInterval(() => {
        if (nextProps.executeData) {
          // let selectedRow = this.props.selectedRow;
          let obj = {};
          if (nextProps.deployType == 1) {
            obj = {
              jobName: nextProps.defName,
              buildNum: nextProps.executeData ? executeData : this.executeData,
              pojectId: nextProps.projectId,
              deployType: nextProps.deployType
            };
          } else if (nextProps.deployType == 2) {
            obj = {
              deployType: nextProps.deployType,
              deployDfId: nextProps.deployDfId
            };
          }
          actions.deployConsole(obj);
          actions.findDeployStatus({
            id,
            defName: deployType == 1 ? defName : deployType == 2 ? compName : "",
            buildNum: executeData ? executeData : this.executeData
          });
          this.onkeyDep = false;
          this.paramsDep = false;
        }
      }, 2000);
    }
  }

  componentWillUnmount() {
    const { actions } = this.props;
    clearTimeout(this.timer);
    clearInterval(this.timer1);
    clearInterval(this.timer2);
    clearInterval(this.timer3);
    actions.resetDeployCode();
    actions.resetDepStatus();
  }

  // 生命周期部分结束
  // 实例方法部分开始
  /**
   * 返回部署管理
   */
  goBack() {
    const { actions, triggleStatus } = this.props;
    actions.resetDeployCode();
    actions.resetDepStatus();
    actions.resetConsole();
    triggleStatus(1);
    clearTimeout(this.timer);
    clearInterval(this.timer1);
    clearInterval(this.timer2);
    clearInterval(this.timer3);
  }

  /**
   * 一键部署
   */
  oneKeyDeployClick() {
    clearTimeout(this.timer);
    const { actions, selectedRow, allHosts, detailsData, id } = this.props;
    const { selectedIps } = this.state;
    this.deployStatusCode = "BUILDINGH";
    actions.resetDeployCode();
    actions.resetConsole();
    actions.findDefination(id);
    actions.updateHosts(allHosts);
    this.onkeyDep = true;
    this.startStatus = "loading";
    this.SuccessRunStatus = "loading";
    this.SuccessFinStatus = "close";
    this.setState(
      {
        current: 0,
        isDeployed: false,
        loading: true
      },
      () => {
        this.timer = setTimeout(() => {
          this.setState({
            current: 4,
            isDeployed: true
          });
          this.startStatus = "check";
          if (selectedRow.deployType == 1) {
            const resIds = selectedIps.map(v => {
              return v.resHostIp;
            });
            actions.executeDeployment({
              id,
              opsType: "install",
              packageUrl: detailsData.packageUrl,
              resIds: allHosts
                ? allHosts
                    .map(v => {
                      return v.resHostIp;
                    })
                    .join("-")
                : "",
              deployOps: "deploy"
            });
          } else if (selectedRow.deployType == 2) {
            actions.executeDeployment({
              id: selectedRow.id,
              opsType: selectedRow.deployType
            });
          }
        }, 3000);
      }
    );
  }

  /**
   * 部署
   */
  deployClick() {
    const { actions, id } = this.props;
    this.setState(prevState => ({
      showDeployPage: true,
      showDeployPageKey: prevState.showDeployPageKey + 1,
      isEnter: false
    }));
    actions.getIpsListbyId({ id, params: "" });
  }

  /**
   * 执行部署
   */
  confirmDeploy() {
    const { selectedIps } = this.state;
    const { actions, id } = this.props;
    clearTimeout(this.timer);
    if (selectedIps.length === 0) {
      message.warning("请选择主机！");
      return;
    }
    const form = this.refs["execute"];
    form.validateFields((err, values) => {
      if (!err) {
        this.paramsDep = true;
        this.deployStatusCode = "BUILDINGH";
        actions.resetDeployCode();
        actions.updateHosts(selectedIps);
        const formData = form.getFieldsValue();
        this.setState({
          showDeployPage: false,
          isEnter: true
        });
        this.setState(
          {
            current: 0,
            isDeployed: false,
            loading: true
          },
          () => {
            this.timer = setTimeout(() => {
              this.setState({
                current: 4,
                isDeployed: true
              });
              this.startStatus = "check";
              const resIds = selectedIps.map(v => {
                return v.resHostIp;
              });
              actions.executeDeployment({
                id,
                opsType: formData.opsType,
                packageUrl: formData.packageUrl,
                resIds: resIds.join("-"),
                deployOps: "deploy"
              });
            }, 3000);
          }
        );
      }
    });
  }

  /**
   * 关闭执行部署
   */
  closeDeploy() {
    this.setState({
      showDeployPage: false
    });
  }

  /**
   * 确认执行部署
   */
  handleSubmit() {}

  /**
   * 选择软件包
   *
   */
  onChangeSelect(v) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  /**
   * 渲染列数据
   */
  renderColumns(text, record, column) {
    if (column === "deployStatus" && text) {
      if (text === "FAILURE") {
        return (
          <div>
            <Icon
              className="padright"
              type="close-circle"
              style={{
                fontSize: 16,
                color: "#ff0000"
              }}
            />
            <span>失败</span>
          </div>
        );
      } else if (text === "SUCCESS") {
        return (
          <div>
            <Icon
              className="padright"
              type="check-circle"
              style={{
                fontSize: 16,
                color: "#00ff48"
              }}
            />
            <span>成功</span>
          </div>
        );
      } else if (text === "BUILDINGH") {
        return (
          <div>
            <Icon
              className="padright"
              type="clock-circle"
              style={{
                fontSize: 16,
                color: "#1890ff"
              }}
            />
            <span>部署中</span>
          </div>
        );
      }
    }
    if (column === "durationTime" && text) {
      return `${text / 1000}s`;
    }
    if (column === "time" && text) {
      return moment(text)
        .utc()
        .zone(+8)
        .format("YYYY-MM-DD HH:mm:ss");
    }
    return text;
  }

  /**
   * 操作列表
   */
  renderActions(text, record, type) {
    if (type === "log") {
      return (
        <div>
          <Icon
            type="file-text"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.showLogVisual.bind(this)}
          />
        </div>
      );
    } else if (type === "history") {
      return (
        <div>
          <Icon
            type="eye"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.openHistory.bind(this, record)}
          />
        </div>
      );
    } else if (type === "pod") {
      return (
        <div>
          <Icon
            type="file-text"
            theme="outlined"
            style={{ cursor: "pointer", fontSize: "18px" }}
            onClick={this.showPodLogVisual.bind(this, record)}
          />
        </div>
      );
    }
  }

  /**
   * 打开历史
   */
  openHistory(record) {
    const { actions, selectedRow } = this.props;
    this.setState({
      historyVisual: true,
      deployStatus: record.deployStatus
    });
    actions.getHistoryDataDetails({ id: record.id });
    actions.deployHisConsole({
      jobName: selectedRow.deployDfName,
      buildNum: record.deployNumber,
      pojectId: record.projectId
    });
  }

  getHistDataMethod(activeKey) {
    const { actions, selectedRow, id } = this.props;
    if (activeKey == "3") {
      actions.getPodList({ id });
    } else if (activeKey == "2") {
      actions.getHistoryData({
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
      });
    }
  }

  /**
   * 根据id查找主机列表
   */
  getIpsListbyId(values) {
    const { actions, selectedRow } = this.props;
    actions.getIpsListbyId({
      id: selectedRow.id,
      param: values ? values : ""
    });
  }

  /**
   * 关闭历史
   */
  closeHistory() {
    this.setState({
      historyVisual: false
    });
  }

  /**
   * 查看日志
   */
  showLogVisual() {
    this.setState({
      showLog: true
    });
  }

  /**
   * 关闭日志
   */
  closeLogVisual() {
    this.setState({
      showLog: false
    });
  }

  showPodLogVisual(record) {
    const { actions, selectedRow } = this.props;
    this.setState(prevState => ({
      showPodLog: true,
      pLineTpId: prevState.podLogKey + 1
    }));
    actions.getPodLog({
      id: selectedRow.id,
      podName: record.name
    });
  }

  closePodLogVisual() {
    this.setState({
      showPodLog: false
    });
  }

  /**
   * 分页操作
   */
  handlePageChange(page, pageSize) {
    const { actions, selectedRow } = this.props;
    this.setState({
      loading: true,
      page,
      pageSize
    });
    actions.getHistoryData({
      page,
      size: pageSize,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
    });
  }

  onShowSizeChange(current, pageSize) {
    const { actions, selectedRow } = this.props;
    this.setState({
      // current: current,
      page: current,
      pageSize
    });
    actions.getHistoryData({
      page: current,
      size: pageSize,
      sortid: "id",
      sortvalue: "desc",
      conditions: [{ name: "deployDfId", sopt: "eq", value: String(selectedRow.deployDfId) }]
    });
  }

  // 实例方法部分结束
  render() {
    const { props, state } = this;
    const {
      historyDetails,
      passInIpsData,
      detailsData,
      deploymentName,
      selectedRow,
      historyData,
      selectedHosts,
      podData,
      podLog,
      duratime,
      softBagList,
      ipsList,
      deployStatusCode,
      hisConsoleData,
      consoleData
    } = this.props;
    const hisPagination = {
      total: state.hisPagination.total,
      pageSize: state.hisPagination.pageSize,
      current: state.hisPagination.current,
      // showSizeChanger: true,
      onShowSizeChange: this.onShowSizeChange.bind(this),
      onChange: this.handlePageChange.bind(this)
    };
    // 部署历史数据
    const urlArr = [];
    if (historyDetails.data) {
      urlArr[0] = historyDetails.data;
    }
    if (passInIpsData && detailsData && detailsData.verifyUrl) {
      passInIpsData.forEach(v => {
        v.verifyUrl = detailsData.verifyUrl.replace(/ip/, v.resHostIp);
      });
    }
    // 部署日志数据
    let consoleData1;
    if (selectedRow && consoleData && selectedRow.deployType !== 2) {
      consoleData1 = consoleData;
    } else if (selectedRow && props.consoleData && selectedRow.deployType == 2) {
      consoleData1 = consoleData.deployLog;
    }
    // 根据后台数据判断部署类型
    if (detailsData && detailsData.data && detailsData.data.deployType == 1) {
      this.deployType = "shell部署";
    } else if (detailsData && detailsData.data && detailsData.data.deployType == 2) {
      this.deployType = "容器部署";
    }
    // 部署状态判断
    switch (this.deployStatusCode) {
      case "SUCCESS":
        this.status = "部署成功";
        break;
      case "BUILDINGH":
        this.status = "部署中";
        break;
      case "FAILURE":
        this.status = "部署失败";
        break;
      default:
        break;
    }
    // 项目名称获取
    const projectName = sessionStorage.getItem("projectName")
      ? sessionStorage.getItem("projectName")
      : "";
    let createTime;
    let deployMedia;
    if (detailsData && detailsData.data && detailsData.data.deployType !== 2) {
      // 是否显示部署按钮
      this.paramsDeployDom = (
        <Button
          type="primary"
          style={{
            marginRight: "10px",
            display: this.deployStatusCode === "BUILDINGH" ? "none" : "inline-block"
          }}
          ghost
          onClick={this.deployClick.bind(this)}
        >
          部署
        </Button>
      );
      // tab页签内容判断
      this.tabChildren = (
        <TabPane
          tab="部署历史"
          key="2"
          style={{
            display: detailsData && detailsData.data
          }}
        >
          <Table
            columns={this.historialColumns}
            pagination={hisPagination}
            dataSource={historyData.map((v, i) => {
              v.order = i + 1;
              return v;
            })}
          />
        </TabPane>
      );
      // 部署服务or部署主机的判断
      this.deployTable = (
        <div>
          <div
            style={{
              fontSize: "20px",
              marginTop: "20px",
              marginBottom: "20px",
              display: detailsData && detailsData.data && detailsData.data.deployType
            }}
          >
            部署主机
          </div>
          <Table columns={this.columns} dataSource={selectedHosts} />
        </div>
      );
      createTime = detailsData.data.createTime ? detailsData.data.createTime : "";
      deployMedia = (
        <div>
          软件包：
          <span>
            {detailsData && detailsData.data && detailsData.data.packageUrl
              ? detailsData.data.packageUrl
              : ""}
          </span>
        </div>
      );
    } else {
      this.paramsDeployDom = "";
      const deployTableData = [];
      if (detailsData && detailsData.service && detailsData.service.serviceType == "LoadBalancer") {
        deployTableData[0] = {
          resName: detailsData.service.serviceName || "",
          resHostIp: detailsData.route.routeIp || "",
          verifyUrl: detailsData.route.routeDomainName + detailsData.route.routePath || ""
        };
      }
      this.tabChildren = (
        <TabPane
          tab="pod组"
          key="3"
          style={{
            display: detailsData && detailsData.data
          }}
        >
          <Table
            columns={this.podColumns}
            // pagination={hisPagination}
            dataSource={podData.map((v, i) => {
              v.order = i + 1;
              return v;
            })}
          />
        </TabPane>
      );
      this.deployTable = (
        <div>
          <div
            style={{
              fontSize: "20px",
              marginTop: "20px",
              marginBottom: "20px",
              display: detailsData && detailsData.data && detailsData.data.deployType
            }}
          >
            部署服务
          </div>
          <Table
            columns={this.deployColumns}
            dataSource={deployTableData}
            style={{ display: deployTableData.length > 0 ? "block" : "none" }}
          />
          <div
            style={{
              display: deployTableData.length > 0 ? "none" : "block",
              textAlign: "center",
              border: "1px solid #e4e4e4",
              padding: "10px",
              height: "100px",
              lineHeight: "100px"
            }}
          >
            公网访问无部署服务
          </div>
        </div>
      );
      deployMedia = (
        <div>
          部署介质：
          <span>
            {detailsData && detailsData.route
              ? detailsData.route.routeDomainName + detailsData.route.routePath
              : ""}
          </span>
        </div>
      );
      // createTime = this.props.detailsData.data ? this.props.detailsData.data.createTime : "";
    }
    return (
      <div style={{ width: "" }}>
        <div>
          <span style={{ cursor: "pointer" }} onClick={this.goBack.bind(this)}>
            返回
          </span>
          <span> / 部署管理</span>
        </div>
        <Row style={{ height: "370px", color: "white" }}>
          <Col span={6} style={{ background: "#454A65", height: "100%", padding: "20px" }}>
            <div style={{ fontSize: "22px" }}>{deploymentName}</div>
            <Row style={{ height: "160px" }}>
              <Col style={{ fontSize: "80px", color: "#ddd" }} span={6}>
                <Icon
                  type="check-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "SUCCESS" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="loading"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "BUILDINGH" ? "inline-block" : "none"
                  }}
                />
                <Icon
                  type="close-circle"
                  theme="outlined"
                  style={{
                    display: this.deployStatusCode === "FAILURE" ? "inline-block" : "none"
                  }}
                />
              </Col>
              <Col span={17} style={{ paddingTop: "20px" }}>
                <div style={{ textAlign: "center" }}>{this.status}</div>
                <div style={{ textAlign: "center" }}>
                  部署持续时间:
                  {duratime ? Number(duratime) / 1000 : ""}s
                </div>
                <div style={{ textAlign: "center", marginTop: "10px" }}>
                  {this.paramsDeployDom}
                  <Button type="primary" ghost onClick={this.oneKeyDeployClick.bind(this)}>
                    一键部署
                  </Button>
                </div>
              </Col>
            </Row>
            <Row style={{ marginTop: "20px" }}>
              <Col>
                <div>创建时间：</div>
                <div>{detailsData.data && detailsData.data ? detailsData.data.createTime : ""}</div>
              </Col>
              <Col style={{ marginTop: "10px" }}>
                <div>最近部署时间：</div>
                <div>{this.time ? this.time : ""}</div>
              </Col>
            </Row>
          </Col>
          <Col span={18} style={{ background: "#3A3E55", height: "100%", padding: "20px" }}>
            <div style={{ height: "140px" }}>
              <div style={{ fontSize: "18px" }}>部署进程</div>
              <Row style={{ marginTop: "50px" }} id="steps">
                {/* <Col> */}
                <Steps size="small">
                  <Step
                    status="finish"
                    title="连接到部署引擎"
                    icon={<Icon type={this.startStatus} />}
                  />
                  <Step
                    status="finish"
                    title="下载playbook"
                    icon={<Icon type={this.startStatus} />}
                  />
                  <Step
                    status="finish"
                    title="下载安装包"
                    icon={<Icon type={this.startStatus} />}
                  />
                  <Step status="finish" title="准备部署" icon={<Icon type={this.startStatus} />} />
                  <Step
                    status="finish"
                    title="正在部署"
                    icon={<Icon type={this.SuccessRunStatus} />}
                    // style={{ display: this.state.isDeployed ? "none" : "inline-block" }}
                  />
                  <Step
                    title="部署完成"
                    status="finish"
                    icon={<Icon type={this.SuccessFinStatus} />}
                  />
                </Steps>
              </Row>
            </div>
            <Row style={{ padding: "20px 10px 10px 0" }}>
              <Col span={12}>
                <div style={{ fontSize: "18px", marginBottom: "10px" }}>部署信息</div>
                <ul style={{ listStyle: "none", padding: "0" }}>
                  <li>
                    描述:
                    <span>
                      {detailsData && detailsData.deployDfDesc ? detailsData.deployDfDesc : ""}
                    </span>
                  </li>
                  <li>
                    项目：<span>{projectName}</span>
                  </li>
                  <li>
                    部署类型：
                    <span>{this.deployType}</span>
                  </li>
                  <li>{deployMedia}</li>
                </ul>
              </Col>
            </Row>
          </Col>
        </Row>
        {/* 部署主机or部署服务数据展示 */}
        {this.deployTable}
        <Tabs defaultActiveKey="1" onChange={this.getHistDataMethod.bind(this)}>
          <TabPane tab="部署日志" key="1">
            <div
              style={{
                maxHeight: 500,
                overflowY: "scroll"
              }}
            >
              <div
                dangerouslySetInnerHTML={{
                  __html: consoleData1
                }}
              />
            </div>
          </TabPane>
          {this.tabChildren}
        </Tabs>
        {/* 弹框部分开始 */}
        <Modal maskClosable={false}
          title="执行部署"
          visible={state.showDeployPage}
          onOk={this.confirmDeploy.bind(this)}
          onCancel={this.closeDeploy.bind(this)}
          key={state.showDeployPageKey}
          okText="执行"
          cancelText="取消"
        >
          <ExecuteDeploy
            hostColumns={this.hostColumns}
            projectName={projectName}
            softBagList={softBagList}
            selectedRow={selectedRow}
            detailsData={detailsData}
            ipsListData={ipsList.list}
            deployStatusCode={deployStatusCode}
            handleSubmit={this.handleSubmit.bind(this)}
            onChangeSelect={this.onChangeSelect.bind(this)}
            getIpsListbyId={this.getIpsListbyId.bind(this)}
            ref="execute"
            scope={this}
          />
        </Modal>
        <Modal maskClosable={false}
          title="部署历史"
          visible={state.historyVisual}
          footer={null}
          width={1000}
          onCancel={this.closeHistory.bind(this)}
        >
          <Tabs defaultActiveKey="1">
            <TabPane tab="部署详情" key="1">
              <Row style={{ textAlign: "center", marginBottom: "30px" }}>
                <Col span={12}>
                  <Row display="flex" alignitems="center">
                    <Col span={8}>
                      <Icon
                        type="check-circle"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "SUCCESS" ? "inline-block" : "none",
                          color: "#00ff48",
                          fontSize: "50px"
                        }}
                      />
                      <Icon
                        type="loading"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "BUILDINGH" ? "inline-block" : "none",
                          color: "#1890ff",
                          fontSize: "50px"
                        }}
                      />
                      <Icon
                        type="close-circle"
                        theme="outlined"
                        style={{
                          display: state.deployStatus === "FAILURE" ? "inline-block" : "none",
                          color: "#ff0000",
                          fontSize: "50px"
                        }}
                      />
                    </Col>
                    <Col span={14}>
                      <div>
                        类型：
                        {"安装"}
                      </div>
                      <div>
                        时间：
                        {historyDetails && historyDetails.data
                          ? historyDetails.data.buildBeginTime
                          : ""}
                      </div>
                    </Col>
                  </Row>
                </Col>
                {/* <Col span={12}>
                  <div>
                    模板名称：
                    {"9999"}
                  </div>
                </Col> */}
              </Row>
              <div style={{ marginBottom: "20px" }}>
                <h4>软件包URL</h4>
                <Table columns={this.urlColumns} pagination={false} dataSource={urlArr} />
              </div>
              <div style={{ marginBottom: "20px" }}>
                <h4>执行参数</h4>
                <Table
                  columns={this.paramsColumns}
                  pagination={false}
                  dataSource={
                    historyDetails.ips
                      ? historyDetails.ips.map((v, i) => {
                          v.order = i + 1;
                          return v;
                        })
                      : []
                  }
                />
              </div>
              <div style={{ marginBottom: "20px" }}>
                <h4>主机信息</h4>
                <Table
                  columns={this.hostInfoColumns}
                  pagination={false}
                  dataSource={
                    historyDetails.ips
                      ? historyDetails.ips.map((v, i) => {
                          v.order = i + 1;
                          return v;
                        })
                      : []
                  }
                />
              </div>
            </TabPane>
            <TabPane tab="部署日志" key="2">
              <div
                style={{
                  maxHeight: 500,
                  overflowY: "scroll"
                }}
              >
                <div dangerouslySetInnerHTML={{ __html: hisConsoleData }} />
              </div>
            </TabPane>
          </Tabs>
        </Modal>
        <Modal maskClosable={false}
          title="部署日志"
          visible={state.showLog}
          footer={null}
          width={1000}
          onCancel={this.closeLogVisual.bind(this)}
        >
          <div
            style={{
              maxHeight: 500,
              overflowY: "scroll"
            }}
          >
            <div
              dangerouslySetInnerHTML={{
                __html: consoleData1
              }}
            />
          </div>
        </Modal>
        <Modal maskClosable={false}
          title="pod日志"
          visible={state.showPodLog}
          footer={null}
          width={1000}
          key={state.podLogKey}
          onCancel={this.closePodLogVisual.bind(this)}
        >
          <div
            style={{
              maxHeight: 500,
              overflowY: "scroll"
            }}
          >
            <div dangerouslySetInnerHTML={{ __html: podLog }} />
          </div>
        </Modal>
        {/* 弹框部分结束 */}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    consoleData: state.Deploy.get("consoleData"),
    hisConsoleData: state.Deploy.get("hisConsoleData"),
    historyData: state.Deploy.get("historyData"),
    historyDetails: state.Deploy.get("historyDetails"),
    detailsData: state.Deploy.get("detailsData"),
    softBagList: state.MediumWarehouse.get("resData"),
    ipsList: state.Deploy.get("ipsList"),
    executeFlag: state.Deploy.get("executeFlag"),
    executeData: state.Deploy.get("executeData"),
    deployStatusCode: state.Deploy.get("deployStatusCode"),
    selectedHosts: state.Deploy.get("selectedHosts"),
    time: state.Deploy.get("time"),
    duratime: state.Deploy.get("duratime"),
    podData: state.Deploy.get("podData"),
    podLog: state.Deploy.get("podLog"),
    hisPageConfig: state.Deploy.get("pageConfig"),
    exception: state.Deploy.get("exception")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, mdactions, DeploymentManageActions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(DeploymentDetails);
