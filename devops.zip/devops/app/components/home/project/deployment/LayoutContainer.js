import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import DeploymentManage from "./DeploymentManage";
import NewDeployMent from "./NewDeployMent";
import DeploymentDetails from "./DeploymentDetails";
import DeploymentHistory from "./DeploymentHistory";
import DockerDeploymentDetails from "./DockerDeploymentDetails";
import * as buildActions from "../../../../actions/build/BuildManage";
import * as DeploymentManageActions from "../../../../actions/build/DeploymentManage";

class LayoutContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: 1,
      selectedRowData: {},
      key: 1,
      newKey: 666,
      extraData: "",
      deploymentName: ""
    };
    this.triggleStatus = this.triggleStatus.bind(this);
  }

  // 实例方法部分
  triggleStatus(show, editType, record) {
    this.setState({
      showRepository: show,
      editType
    });
    if (record) {
      this.setState({
        deploymentName: record.deploymentName,
        id: record.id,
        defName: record.deployDfName,
        record,
        instanceId: record.instanceId,
        deployDfId: record.deployDfId,
        deployType: record.deployType,
        compName: record.compName ? record.compName : ""
      });
    }
  }

  passInIpsData(data, allHosts) {
    this.setState({
      ipsData: data,
      allHosts
    });
  }

  render() {
    const { projectId, projectName, projectCode, flagData } = this.props;
    const { state } = this;
    return (
      <div style={{ padding: 20, background: "#fff", minHeight: 360 }}>
        {state.showRepository == 1 ? (
          <DeploymentManage
            projectName={projectName}
            projectId={projectId}
            selectedRow={state.selectedRowData}
            triggleStatus={this.triggleStatus}
            passInIpsData={this.passInIpsData.bind(this)}
            ecList={flagData != "" ? flagData : ""}
            key={state.key + 1}
          />
        ) : state.showRepository == 2 ? (
          <NewDeployMent
            projectId={projectId}
            projectName={projectName}
            projectCode={projectCode}
            // selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
            editType={state.editType}
            id={state.id}
            key={Math.random()}
          />
        ) : state.showRepository == 3 ? (
          <DeploymentDetails
            projectId={projectId}
            deploymentName={state.deploymentName}
            selectedRow={state.record}
            passInIpsData={state.ipsData}
            allHosts={state.allHosts}
            triggleStatus={this.triggleStatus}
            id={state.id}
            defName={state.defName}
            compName={state.compName}
            instanceId={state.instanceId}
            deployDfId={state.deployDfId}
            deployType={state.deployType}
            key={Math.random()}
          />
        ) : state.showRepository == 4 ? (
          <DeploymentHistory
            projectId={projectId}
            deploymentName={state.deploymentName}
            selectedRow={state.record}
            triggleStatus={this.triggleStatus}
            deployType={state.deployType}
            key={Math.random()}
          />
        ) : (
          ""
        )}
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    flagData: state.Build.get("flagData")
  };
};

const mapDispatchToProps = dispatch => {
  const combineAction = Object.assign({}, buildActions, DeploymentManageActions);
  return { actions: bindActionCreators(combineAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LayoutContainer);
