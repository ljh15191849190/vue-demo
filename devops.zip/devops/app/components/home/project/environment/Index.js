import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Popconfirm, Row, Col } from "antd";
import * as action from "../../../../actions/Environment";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form, typeData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增环境"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="环境名称：">
          {getFieldDecorator("envName", {
            rules: Validation.Rule_code
          })(<Input placeholder="请选择环境名称" maxLength={32} />)}
        </FormItem>
        <FormItem label="环境类型：">
          {getFieldDecorator("envType", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择环境类型" allowClear onChange={handleChange}>
              {typeData
                ? typeData.map(v => {
                    return (
                      <Option value={v} key={v}>
                        {v}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});
const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onCancel, handleChange, form, typeData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={updatavisible}
      title="编辑环境"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onUpdata}
    >
      <Form layout="vertical">
        <FormItem label="环境名称：">
          {getFieldDecorator("envName", {
            rules: Validation.Rule_code
          })(<Input maxLength={32} disabled />)}
        </FormItem>
        <FormItem label="环境类型：">
          {getFieldDecorator("envType", {
            rules: Validation.Rule_select
          })(
            <Select placeholder="请选择环境类型" allowClear onChange={handleChange}>
              {typeData
                ? typeData.map(v => {
                    return (
                      <Option value={v} key={v}>
                        {v}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
      </Form>
    </Modal>
  );
});

class Environment extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      projectDetailVisual: false,
      updataData: {},
      environmentValue: "",
      key: 1
    };
    const { TextArea } = Input;
    this.columns = [
      {
        title: "环境名称",
        dataIndex: "envName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "envName")
      },
      {
        title: "环境类型",
        dataIndex: "envType",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "envType")
      },
      {
        title: "虚拟机",
        dataIndex: "virtualCount",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "virtualCount")
      },
      {
        title: "容器命名空间",
        dataIndex: "dockerCount",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "dockerCount")
      },
      {
        title: "最后修改时间",
        dataIndex: "updateTime",
        width: "20%",
        render: (text, record) => this.renderColumns(text, record, "updateTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        width: "20%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">删除</a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
  }

  //   确认删除
  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteEnvironment(record.envId);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  //   控件搜索
  search() {
    const { actions, projectId } = this.props;
    const { environmentValue } = this.state;
    const environmentName = ReactDOM.findDOMNode(this.refs.environmentName).value;
    actions.getEnvironment({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        },
        {
          name: "envName",
          sopt: "cn",
          value: environmentName ? environmentName : ""
        },
        {
          name: "envType",
          sopt: "cn",
          value: environmentValue ? environmentValue : ""
        }
      ]
    });
  }

  handleChangeStatus(value) {
    this.setState({
      environmentValue: value
    });
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getEnvironment({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        }
      ]
    });
    actions.getEnvironmentType();
  }

  query() {
    const { actions, projectId } = this.props;
    actions.getEnvironment({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        }
      ]
    });
  }

  componentDidUpdate(nextProps) {
    const { delStatus, pageConfig, actions, projectId, addStatus, updataStatus } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      if (
        nextProps.pageConfig.total % nextProps.pageConfig.size === 1 &&
        nextProps.pageConfig.totalPage > 1
      ) {
        actions.getEnvironment({
          page: nextProps.pageConfig.totalPage - 1,
          conditions: [
            {
              name: "projectId",
              sopt: "eq",
              value: projectId
            }
          ]
        });
      } else {
        actions.getEnvironment({
          page: nextProps.pageConfig.page,
          conditions: [
            {
              name: "projectId",
              sopt: "eq",
              value: projectId
            }
          ]
        });
      }
    } else if (delStatus && delStatus === 2) {
      message.error("此环境有虚拟机不能删除");
      this.query();
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      this.query();
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      this.query();
    } else if (addStatus && addStatus === 3) {
      message.error("环境已存在");
      this.query();
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      this.query();
    } else if (updataStatus && updataStatus === 2) {
      message.error("修改失败");
      this.query();
    } else if (updataStatus && updataStatus === 3) {
      message.error("环境已存在");
      this.query();
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { environmentValue } = this.state;
    const { actions, projectId } = this.props;
    this.setState({ loading: true });
    const environmentName = ReactDOM.findDOMNode(this.refs.environmentName).value;
    actions.getEnvironment({
      page: pagination.current,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        },
        {
          name: "envName",
          sopt: "cn",
          value: environmentName ? environmentName : ""
        },
        {
          name: "envType",
          sopt: "cn",
          value: environmentValue ? environmentValue : ""
        }
      ]
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击修改弹框
  showEditModal(record) {
    this.form.setFieldsValue({
      envName: record.envName,
      envType: record.envType
    });
    this.setState({
      updataData: {
        envId: record.envId
      },
      loading: false,
      updatavisible: true
    });
  }

  // 确认修改updata
  handleUpdataOk(e) {
    const { actions, projectId } = this.props;
    const { updataData } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.envId = updataData.envId;
      values.projectId = projectId;
      actions.updateEnvironment(values);
      this.setState({ updatavisible: false });
    });
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const { actions, projectId } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.projectId = projectId;
      actions.addEnvironment(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.form.resetFields();
    this.setState({
      visible: false,
      updatavisible: false
    });
  }

  render() {
    const { resData, typeData } = this.props;
    const { pagination, loading, visible, updatavisible } = this.state;
    if (resData) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>环境名称:</span>
              <Input placeholder="环境名称" style={{ width: "70%" }} ref="environmentName" />
            </Col>
            <Col span={6}>
              <span style={{ marginRight: 10 }}>环境类型:</span>
              <Select
                allowClear
                placeholder="环境类型"
                style={{ width: "70%" }}
                className="padright"
                onChange={this.handleChangeStatus.bind(this)}
              >
                {typeData
                  ? typeData.map(v => {
                      return (
                        <Option value={v} key={v}>
                          {v}
                        </Option>
                      );
                    })
                  : ""}
              </Select>
            </Col>

            <Col span={10} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            typeData={typeData}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            typeData={typeData}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.Environment.get("resData"),
    pageConfig: state.Environment.get("pageConfig"),
    addStatus: state.Environment.get("AddStatus"),
    delStatus: state.Environment.get("delStatus"),
    updataStatus: state.Environment.get("UpdataStatus"),
    typeData: state.Environment.get("typeData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Environment);
