import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Input,
  Form,
  Select,
  Card,
  Tabs,
  Row,
  Col,
  Table,
  Tooltip,
  Icon,
  Button,
  message,
  Radio,
  Modal,
  Popconfirm
} from "antd";
import * as action from "../../../../actions/Resource";
import Validation from "../../../../utils/Validation";

const TabPane = Tabs.TabPane;
const FormItem = Form.Item;
const Option = Select.Option;
const RadioGroup = Radio.Group;
// 添加主机
const NewEngineForm = Form.create()(props => {
  const {
    visible,
    onCreate,
    onCancel,
    onTest,
    handleChange,
    userInfo,
    type,
    form,
    title,
    nameData
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      maskClosable={false}
      visible={visible}
      title={`${title}主机`}
      footer={null}
      onCancel={onCancel}
    >
      <Form layout="vertical">
        <FormItem label="主机角色：">
          {getFieldDecorator("nodeHostRole", {
            rules: Validation.Rule_select,
            initialValue: userInfo && type == "edit" ? userInfo.nodeHostRole : "Master"
          })(
            <RadioGroup>
              <Radio value="Master">管理主机</Radio>
              <Radio value="Worker">工作主机</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <FormItem>
          <Col span={17}>
            <FormItem label="主机IP：">
              {getFieldDecorator("nodeHostIp", {
                rules: Validation.Rule_ip,
                initialValue: userInfo && type == "edit" ? userInfo.nodeHostIp : ""
              })(<Input maxLength={128} />)}
            </FormItem>
          </Col>
          <Col span={2}>
            <span
              style={{ display: "inline-block", width: "100%", textAlign: "center", marginTop: 33 }}
            >
              -
            </span>
          </Col>
          <Col span={5}>
            <FormItem label="端口">
              {getFieldDecorator("nodeHostPort", {
                rules: Validation.Rule_number,
                initialValue: userInfo && type == "edit" ? userInfo.nodeHostPort : ""
              })(<Input maxLength={16} />)}
            </FormItem>
          </Col>
        </FormItem>
        <FormItem label="主机名称：">
          {getFieldDecorator("nodeNames", {
            rules: Validation.Rule_nodeName,
            initialValue: userInfo && type == "edit" ? userInfo.nodeName : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="用户名：">
          {getFieldDecorator("nodeHostUser", {
            rules: Validation.Rule_nochinese,
            initialValue: userInfo && type == "edit" ? userInfo.nodeHostUser : ""
          })(<Input maxLength={32} />)}
        </FormItem>
        <FormItem label="验证类型：">
          {getFieldDecorator("nodeCerType", {
            rules: Validation.Rule_select,
            initialValue: userInfo && type == "edit" ? userInfo.nodeCerType : 1
          })(
            <Select placeholder="请选择验证类型" allowClear>
              <Option value={1}>密码</Option>
            </Select>
          )}
        </FormItem>
        <FormItem label="密码：">
          {getFieldDecorator("nodeHostPwd", {
            rules: Validation.Rule_nochinese,
            initialValue: userInfo && type == "edit" ? userInfo.nodeHostPwd : ""
          })(<Input type="password" maxLength={32} />)}
        </FormItem>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onCreate} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});
// 添加工作区
const NewWorkSpaceForm = Form.create()(props => {
  const {
    workspacevisible,
    onCreate,
    onCancel,
    nameData,
    workSpaceInfo,
    title,
    type,
    handleChange,
    form
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal
      maskClosable={false}
      visible={workspacevisible}
      title={`${title}工作区`}
      footer={null}
      onCancel={onCancel}
    >
      <Form layout="vertical">
        <FormItem label="工作区名称：">
          {getFieldDecorator("namespaceName", {
            rules: Validation.Rule_nameSpace,
            initialValue: workSpaceInfo && type == "edit" ? workSpaceInfo.namespaceName : ""
          })(<Input disabled={workSpaceInfo && type == "edit" ? true : false} maxLength={32} />)}
        </FormItem>
        <FormItem label="环境名称：">
          {getFieldDecorator("envId", {
            rules: Validation.Rule_select,
            initialValue: workSpaceInfo && type == "edit" ? workSpaceInfo.envId : ""
          })(
            <Select
              placeholder="请选择环境名称"
              disabled={workSpaceInfo && type == "edit" ? true : false}
              allowClear
            >
              {nameData
                ? nameData.map(v => {
                    return (
                      <Option value={v.envId} key={v.envId}>
                        {v.envName}
                      </Option>
                    );
                  })
                : ""}
            </Select>
          )}
        </FormItem>
        <Tabs
          defaultActiveKey="1"
          tabBarExtraContent={
            <Tooltip title="建议CPU上限不超过下线5倍且不大于工作区配额，内存上限不超过下线的6倍且不大于工作区配额">
              <Icon type="question-circle" theme="filled" style={{ fontSize: "18px" }} />
            </Tooltip>
          }
        >
          <TabPane tab="工作区配额" key="1">
            <Row type="flex">
              <Col span={10}>
                <FormItem label="cpu(核)：">
                  {getFieldDecorator("quotaLimitCpu", {
                    rules: Validation.Rule_number,
                    initialValue:
                      workSpaceInfo && type == "edit" ? workSpaceInfo.quotaLimitCpu : "1"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
              <Col span={10} style={{ marginLeft: 20 }}>
                <FormItem label="内存(Gi)：">
                  {getFieldDecorator("quotaLimitMem", {
                    rules: Validation.Rule_number,
                    initialValue:
                      workSpaceInfo && type == "edit"
                        ? workSpaceInfo.quotaLimitMem.substr(
                            0,
                            workSpaceInfo.quotaLimitMem.length - 2
                          )
                        : "2"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab="pod全局配额" key="2">
            <Row type="flex">
              <Col span={10}>
                <FormItem label="CPU上限（核）：">
                  {getFieldDecorator("deploymentDefaultLimitCpu", {
                    rules: Validation.Rule_NumberPoint,
                    initialValue:
                      workSpaceInfo && type == "edit"
                        ? workSpaceInfo.deploymentDefaultLimitCpu
                        : "1"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
              <Col span={10} style={{ marginLeft: 20 }}>
                <FormItem label="内存上限（Mi）：">
                  {getFieldDecorator("deploymentDefaultLimitMem", {
                    rules: Validation.Rule_number,
                    initialValue:
                      workSpaceInfo && type == "edit"
                        ? workSpaceInfo.deploymentDefaultLimitMem.substr(
                            0,
                            workSpaceInfo.deploymentDefaultLimitMem.length - 2
                          )
                        : "600"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
              <Col span={10}>
                <FormItem label="CPU下限（核）：">
                  {getFieldDecorator("deploymentDefaultRequestCpu", {
                    rules: Validation.Rule_NumberPoint,
                    initialValue:
                      workSpaceInfo && type == "edit"
                        ? workSpaceInfo.deploymentDefaultRequestCpu
                        : "0.3"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
              <Col span={10} style={{ marginLeft: 20 }}>
                <FormItem label="内存下限（Mi）：">
                  {getFieldDecorator("deploymentDefaultRequestMem", {
                    rules: Validation.Rule_number,
                    initialValue:
                      workSpaceInfo && type == "edit"
                        ? workSpaceInfo.deploymentDefaultRequestMem.substr(
                            0,
                            workSpaceInfo.deploymentDefaultRequestMem.length - 2
                          )
                        : "100"
                  })(<Input maxLength={32} />)}
                </FormItem>
              </Col>
            </Row>
          </TabPane>
        </Tabs>
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onCreate} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});

class ComponentDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      nameSpacepagination: {},
      loading: false,
      visible: false,
      workspacevisible: false,
      updataData: {},
      userInfo: {}
    };
    // 主机
    this.columns = [
      {
        title: "主机名称",
        dataIndex: "nodeName",
        // render: (text, record) => this.renderColumns(text, record, "nodeName")
        render: (text, record) => {
          return <a onClick={this.nodeDetailClick.bind(this, record)}>{text}</a>;
        }
      },
      {
        title: "状态",
        dataIndex: "nodeStatus",
        render(state) {
          const config = {
            1: "正常",
            2: "异常"
          };
          return config[state];
        }
      },
      {
        title: "类型",
        dataIndex: "nodeHostRole",
        render(state) {
          const config = {
            Master: "管理主机",
            Worker: "工作主机"
          };
          return config[state];
        }
      },
      // {
      //   title: "Pod",
      //   dataIndex: "pod",
      //   render: (text, record) => this.renderColumns(text, record, "pod")
      // },
      {
        title: "IP",
        dataIndex: "nodeHostIp",
        render: (text, record) => this.renderColumns(text, record, "nodeHostIp")
      },
      {
        title: "CPU",
        dataIndex: "nodeTotalCpu",
        render: (text, record) => this.renderColumns(text, record, "nodeTotalCpu")
      },
      {
        title: "内存(MB)",
        dataIndex: "nodeTotalMem",
        render: (text, record) => this.renderColumns(text, record, "nodeTotalMem")
      },

      {
        title: "硬盘(GB)",
        dataIndex: "nodeDisk",
        render: (text, record) => this.renderColumns(text, record, "nodeDisk")
      },
      // {
      //   title: "维护模式",
      //   dataIndex: "nodeCerType",
      //   render: (text, record) => this.renderColumns(text, record, "nodeCerType")
      // },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEngineModal("edit", record);
                }}
                className="padright"
              >
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelNode(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">删除</a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    // 工作区
    this.workSpacecolumns = [
      {
        title: "工作区名称",
        dataIndex: "namespaceName",
        render: (text, record) => this.renderColumns(text, record, "namespaceName")
      },
      {
        title: "工作区配额",
        dataIndex: "quotaLimitCpu",
        render: (text, record) => this.renderColumns(text, record, "quotaLimitCpu")
      },
      {
        title: "pod全局配额上限",
        dataIndex: "deploymentDefaultLimitCpu",
        render: (text, record) => this.renderColumns(text, record, "deploymentDefaultLimitCpu")
      },
      {
        title: "所属环境",
        dataIndex: "envName",
        render: (text, record) => this.renderColumns(text, record, "envName")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showWorkSpaceModal("edit", record);
                }}
                className="padright"
              >
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelNameSpace(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">删除</a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
  }

  handleDelNode(record) {
    const { actions } = this.props;
    actions.deleteCaasNode({ id: record.id });
  }

  handleDelNameSpace(record) {
    const { actions } = this.props;
    actions.deleteCaasNamespace({ id: record.id });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "quotaLimitCpu") {
      // return record.quotaLimitCpu + record.quotaLimitMem;
      return `${record.quotaLimitCpu}核 / ${record.quotaLimitMem}`;
    } else if (column == "deploymentDefaultLimitCpu") {
      return `${record.deploymentDefaultLimitCpu}核 / ${record.deploymentDefaultLimitMem}`;
    } else {
      return text;
    }
  }

  // 生命周期
  componentDidMount() {
    const { actions, selectedRow } = this.props;
    this.queryNodeList();
    this.queryNameSpaceList();
    actions.findClusterInfos({
      clusterId: selectedRow.resClusterId
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.nodepageConfig) {
      this.setState({
        pagination: {
          total: nextProps.nodepageConfig.total,
          current: nextProps.nodepageConfig.page,
          pageSize: nextProps.nodepageConfig.size
        },
        loading: false
      });
    }
    if (nextProps.nameSpacepageConfig) {
      this.setState({
        nameSpacepagination: {
          total: nextProps.nameSpacepageConfig.total,
          current: nextProps.nameSpacepageConfig.page,
          pageSize: nextProps.nameSpacepageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidUpdate(nextProps) {
    const {
      deleteNodeStatus,
      nodepageConfig,
      addNodeStatus,
      actions,
      updateNodeStatus,
      testNodeStatus,
      deleteNameSpaceStatus,
      addNameSpaceStatus,
      updateNameSpaceStatus
    } = this.props;
    if (deleteNodeStatus && deleteNodeStatus === 1) {
      message.info("删除成功");
      if (
        nextProps.nodepageConfig.total % nextProps.nodepageConfig.size === 1 &&
        nextProps.nodepageConfig.totalPage > 1
      ) {
        actions.getCaasNodeList({
          page: nextProps.nodepageConfig.totalPage - 1,
          conditions: []
        });
      } else {
        actions.getCaasNodeList({
          page: nextProps.nodepageConfig.page,
          conditions: []
        });
      }
    } else if (deleteNodeStatus && deleteNodeStatus === 2) {
      message.error("有任务使用该资源不能删除");
      this.queryNodeList();
    }
    if (addNodeStatus && addNodeStatus === 1) {
      message.info("新增成功");
      this.queryNodeList();
    } else if (addNodeStatus && addNodeStatus === 2) {
      message.error("新增失败");
      this.queryNodeList();
    } else if (addNodeStatus && addNodeStatus === 3) {
      message.error("主机已存在");
      this.queryNodeList();
    } else if (addNodeStatus && addNodeStatus === 4) {
      message.error("连接测试失败无法新增");
      this.queryNodeList();
    }
    if (updateNodeStatus && updateNodeStatus === 1) {
      message.info("修改成功");
      this.queryNodeList();
    } else if (updateNodeStatus && updateNodeStatus === 2) {
      message.error("修改失败");
      this.queryNodeList();
    } else if (updateNodeStatus && updateNodeStatus === 3) {
      message.error("资源已存在");
      this.queryNodeList();
    }
    if (testNodeStatus && testNodeStatus === 1) {
      message.info("测试成功");
      this.queryNodeList();
    } else if (testNodeStatus && testNodeStatus === 2) {
      message.error("测试失败");
      this.queryNodeList();
    }
    // 工作区
    if (deleteNameSpaceStatus && deleteNameSpaceStatus === 1) {
      message.info("删除成功");
      this.queryNameSpaceList();
    } else if (deleteNameSpaceStatus && deleteNameSpaceStatus === 2) {
      message.error("删除失败");
      this.queryNameSpaceList();
    }
    if (addNameSpaceStatus && addNameSpaceStatus === 1) {
      message.info("新增成功");
      this.queryNameSpaceList();
    } else if (addNameSpaceStatus && addNameSpaceStatus === 2) {
      message.error("新增失败");
      this.queryNameSpaceList();
    } else if (addNameSpaceStatus && addNameSpaceStatus === 3) {
      message.error("工作区已存在");
      this.queryNameSpaceList();
    }
    if (updateNameSpaceStatus && updateNameSpaceStatus === 1) {
      message.info("修改成功");
      this.queryNameSpaceList();
    } else if (updateNameSpaceStatus && updateNameSpaceStatus === 2) {
      message.error("修改失败");
      this.queryNameSpaceList();
    } else if (updateNameSpaceStatus && updateNameSpaceStatus === 3) {
      message.error("工作区已存在");
      this.queryNameSpaceList();
    }
  }

  queryNodeList() {
    const { actions, selectedRow } = this.props;
    actions.getCaasNodeList({
      page: 1,
      conditions: [
        {
          name: "clusterId",
          sopt: "eq",
          value: selectedRow.resClusterId
        }
      ]
    });
  }

  queryNameSpaceList() {
    const { actions, selectedRow } = this.props;
    actions.getCaasNamespaceList({
      page: 1,
      size: 10,
      clusterId: selectedRow.resClusterId
    });
  }

  nodeDetailClick(record) {
    const { triggleStatus, selectedNodeRow } = this.props;
    triggleStatus(3);
    selectedNodeRow(record);
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(1);
  }

  callback(key) {
    if (key == 1) {
      this.queryNodeList();
    }
    if (key == 2) {
      this.queryNameSpaceList();
    }
  }

  // 弹框主机
  showEngineModal(type, record) {
    if (type == "create") {
      this.setState({
        title: "创建",
        visible: true,
        type: "create"
      });
    } else if (type == "edit") {
      this.setState({
        title: "编辑",
        userInfo: record,
        type: "edit",
        visible: true,
        updataData: {
          id: record.id,
          nodeId: record.nodeId
        }
      });
    }
  }

  // 弹框namespace
  showWorkSpaceModal(type, record) {
    if (type == "create") {
      this.setState({
        title: "创建",
        workspacevisible: true,
        type: "create"
      });
    } else if (type == "edit") {
      this.setState({
        title: "编辑",
        workSpaceInfo: record,
        type: "edit",
        workspacevisible: true,
        updataData: {
          namespace_id: record.id,
          namespaceId: record.namespaceId
        }
      });
    }
  }

  // 查询主机
  searchEngineModal() {
    const { actions } = this.props;
    const nodeNames = ReactDOM.findDOMNode(this.refs.nodeName).value;
    actions.getCaasNodeList({
      page: 1,
      conditions: [
        {
          name: "nodeName",
          sopt: "cn",
          value: nodeNames ? nodeNames : ""
        }
      ]
    });
  }

  searchWorkSpace() {
    const { selectedRow, actions } = this.props;
    const namespaceName = ReactDOM.findDOMNode(this.refs.namespaceName).value;
    actions.searchCaasNamespace({
      page: 1,
      clusterId: selectedRow.resClusterId,
      namespaceName
    });
  }

  saveFormRef(forms) {
    this.forms = forms;
  }

  workspaceFormRef(workspaceforms) {
    this.workspaceforms = workspaceforms;
  }

  // 保存
  handleEngineOk(e) {
    const forms = this.forms;
    const { selectedRow, actions } = this.props;
    const { updataData, userInfo, type, title } = this.state;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.clusterId = selectedRow.resClusterId;
      values.nodeName = values.nodeNames;
      values.id = updataData.id;
      values.nodeId = updataData.nodeId;
      values.createTime = userInfo.createTime;
      values.createUser = userInfo.createUser;
      if (type == "create") {
        actions.addCaasNode(values);
      } else {
        actions.updateCaasNode(values);
      }
      this.setState({ visible: false });
    });
  }

  // 测试
  handleEngineTest() {
    const forms = this.forms;
    const { selectedRow, actions } = this.props;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.clusterId = selectedRow.resClusterId;
      values.nodeName = values.nodeNames;
      actions.testCaasNode(values);
    });
  }

  workSpacehandleOk() {
    const workspaceforms = this.workspaceforms;
    const { selectedRow, actions } = this.props;
    const { updataData, type } = this.state;
    workspaceforms.validateFields((err, values) => {
      if (err) {
        return;
      }
      workspaceforms.resetFields();
      values.clusterId = selectedRow.resClusterId;
      values.quotaRequestCpu = values.quotaLimitCpu;
      values.deploymentDefaultLimitMem = `${values.deploymentDefaultLimitMem}Mi`;
      values.deploymentDefaultRequestMem = `${values.deploymentDefaultRequestMem}Mi`;
      values.quotaLimitMem = `${values.quotaLimitMem}Gi`;
      values.quotaRequestMem = values.quotaLimitMem;
      values.id = updataData.namespace_id;
      values.namespaceId = updataData.namespaceId;
      if (type == "create") {
        actions.addCaasNamespace(values);
      } else {
        actions.updateCaasNamespace(values);
      }

      this.setState({ workspacevisible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.workspaceforms.resetFields();
    this.setState({
      visible: false,
      workspacevisible: false
    });
  }

  // 主机分页
  handlePageNodeChange(pagination, filters, sorter) {
    const { actions } = this.props;
    this.setState({ loading: true });
    const nodeNames = ReactDOM.findDOMNode(this.refs.nodeName).value;
    actions.getCaasNodeList({
      page: pagination.current,
      conditions: [
        {
          name: "nodeName",
          sopt: "cn",
          value: nodeNames ? nodeNames : ""
        }
      ]
    });
  }

  // 工作区分页
  handlePageNameSpaceChange(nameSpacepagination, filters, sorter) {
    const { actions, selectedRow } = this.props;
    const namespaceName = ReactDOM.findDOMNode(this.refs.namespaceName).value;
    actions.searchCaasNamespace({
      page: nameSpacepagination.current,
      clusterId: selectedRow.resClusterId,
      namespaceName
    });
  }

  render() {
    const { clusterInfoData, nodeListData, nameSpaceListData, nameData } = this.props;
    const {
      pagination,
      loading,
      nameSpacepagination,
      visible,
      workspacevisible,
      workSpaceInfo,
      title,
      type,
      userInfo
    } = this.state;
    if (nodeListData) {
      nodeListData.map(item => {
        item.key = item.id;
      });
    }
    if (nameSpaceListData) {
      nameSpaceListData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div>
          <span onClick={() => this.goBack()}>
            <Icon type="left" style={{ fontSize: 16, color: "#08c" }} />
            返回
          </span>
          <span> /资源</span>
        </div>
        <Row>
          <Col span={18}>
            <Card bordered={false} style={{ width: "100%", padding: "0px 0px 0px 0px" }}>
              <Row>
                <Col span={4}>
                  <img src="/images/dashboard/C.png" alt="" />
                </Col>
                <Col span={20}>
                  <Row>
                    <Col span={4}>
                      <p>集群名称</p>
                      <p> {clusterInfoData.clusterName}</p>
                    </Col>
                    <Col span={4}>
                      <p>主机</p>
                      <p> {clusterInfoData.nodeNum}</p>
                    </Col>
                    <Col span={4}>
                      <p>工作区</p>
                      <p> {clusterInfoData.namespaceNum}</p>
                    </Col>
                    <Col span={4}>
                      <p>创建者</p>
                      <p> {clusterInfoData.createUser}</p>
                    </Col>
                    <Col span={4}>
                      <p>创建时间</p>
                      <p> {clusterInfoData.createTime}</p>
                    </Col>
                  </Row>
                </Col>
              </Row>
            </Card>
          </Col>
          {/* <Col span={5} style={{ textAlign: "right" }}>
            <Button type="primary" className="padright">
              删除
            </Button>
          </Col> */}
          <Col span={24}>
            <Tabs defaultActiveKey="1" onChange={this.callback.bind(this)}>
              <TabPane tab="主机" key="1">
                <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
                  <Col span={6}>
                    <span style={{ marginRight: 10 }}>主机:</span>
                    <Input placeholder="搜索主机" style={{ width: "70%" }} ref="nodeName" />
                  </Col>
                  <Col span={14} style={{ textAlign: "right" }}>
                    <Button
                      type="primary"
                      onClick={this.searchEngineModal.bind(this)}
                      className="padright"
                      style={{ marginRight: 10 }}
                    >
                      查询
                    </Button>
                    <Button
                      type="primary"
                      onClick={this.showEngineModal.bind(this, "create")}
                      className="padright"
                    >
                      添加主机
                    </Button>
                  </Col>
                </Row>
                <Table
                  style={{ marginTop: 20 }}
                  bordered
                  size="small"
                  columns={this.columns}
                  dataSource={nodeListData}
                  pagination={pagination}
                  loading={loading}
                  onChange={this.handlePageNodeChange.bind(this)}
                />
              </TabPane>
              <TabPane tab="工作区" key="2">
                <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
                  <Col span={6}>
                    <span style={{ marginRight: 10 }}>工作区:</span>
                    <Input placeholder="搜索工作区" style={{ width: "70%" }} ref="namespaceName" />
                  </Col>
                  <Col span={14} style={{ textAlign: "right" }}>
                    <Button
                      type="primary"
                      onClick={this.searchWorkSpace.bind(this)}
                      className="padright"
                      style={{ marginRight: 10 }}
                    >
                      查询
                    </Button>
                    <Button
                      type="primary"
                      onClick={this.showWorkSpaceModal.bind(this, "create")}
                      className="padright"
                    >
                      添加工作区
                    </Button>
                  </Col>
                </Row>
                <Table
                  style={{ marginTop: 20 }}
                  bordered
                  size="small"
                  columns={this.workSpacecolumns}
                  dataSource={nameSpaceListData}
                  pagination={nameSpacepagination}
                  loading={loading}
                  onChange={this.handlePageNameSpaceChange.bind(this)}
                />
              </TabPane>
            </Tabs>
          </Col>
        </Row>
        <NewEngineForm
          ref={this.saveFormRef.bind(this)}
          visible={visible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.handleEngineOk.bind(this)}
          onTest={this.handleEngineTest.bind(this)}
          userInfo={userInfo}
          type={type}
          title={title}
        />
        <NewWorkSpaceForm
          ref={this.workspaceFormRef.bind(this)}
          nameData={nameData}
          workspacevisible={workspacevisible}
          onCancel={this.handleCancel.bind(this)}
          onCreate={this.workSpacehandleOk.bind(this)}
          workSpaceInfo={workSpaceInfo}
          type={type}
          title={title}
          key={Math.random()}
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    nameData: state.Resource.get("nameData"),
    clusterInfoData: state.Resource.get("clusterInfoData"),
    addNodeStatus: state.Resource.get("addNodeStatus"),
    updateNodeStatus: state.Resource.get("updateNodeStatus"),
    deleteNodeStatus: state.Resource.get("deleteNodeStatus"),
    nodeListData: state.Resource.get("nodeListData"),
    nodepageConfig: state.Resource.get("nodepageConfig"),

    addNameSpaceStatus: state.Resource.get("addNameSpaceStatus"),
    nameSpaceListData: state.Resource.get("nameSpaceListData"),
    nameSpacepageConfig: state.Resource.get("nameSpacepageConfig"),
    updateNameSpaceStatus: state.Resource.get("updateNameSpaceStatus"),
    deleteNameSpaceStatus: state.Resource.get("deleteNameSpaceStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(action, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ComponentDetail);
