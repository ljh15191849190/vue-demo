import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Input, Card, Tabs, Row, Col, Table, Icon, Button, message, Modal } from "antd";
import moment from "moment";
import * as action from "../../../../actions/Resource";
import LineAreaChart from "../../../commons/LineChart/lineAreaChart";
import BasicInfo from "./podDetail/BasicInfo";
import EventInfor from "./podDetail/EventInfo";
import LineChart from "../../../commons/LineChart/LineChart";
// import CodeLogs from "./podDetail/CodeLogs";

const TabPane = Tabs.TabPane;
// 窗口
class CreateFormUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const {
      visible,
      onCancel,
      podBasicData,
      podEventData,
      podLogData,
      podMonitorData,
      namespaceData,
      clusterId
    } = this.props;
    const cpux = [];
    const cpuy = [];
    const buildx = [];
    const buildy = [];
    if (podMonitorData && podMonitorData.length > 0) {
      podMonitorData[0].dataPoints.map(item => {
        const x = moment(item.x * 1000).format("YYYY-MM-DD HH:mm:ss");
        cpux.push(x);
        cpuy.push(item.y / 1000);
      });
    }
    if (podMonitorData && podMonitorData.length > 0) {
      podMonitorData[1].dataPoints.map(item => {
        const x = moment(item.x * 1000).format("YYYY-MM-DD HH:mm:ss");
        buildx.push(x);
        buildy.push((item.y / 1024 / 1024).toFixed(3));
      });
    }

    return (
      <Modal maskClosable={false} visible={visible} onCancel={onCancel} title="状态信息" footer={null} width={980}>
        <Tabs
          defaultActiveKey="1"
          // activeKey={currentKey}
          // onChange={onChangeTab}
        >
          <TabPane tab="基本信息" key="1">
            <BasicInfo podBasicData={podBasicData} />
          </TabPane>
          <TabPane tab="监控" key="2">
            CPU
            <LineChart height="280px" width="805px" x={cpux} y={cpuy} unit=" " />
            内存
            <LineChart height="280px" width="805px" x={buildx} y={buildy} unit="单位/MB" />
          </TabPane>
          {/* <TabPane tab="日志" key="3">
            <CodeLogs podLogData={podLogData} namespaceData={namespaceData} clusterId={clusterId} />
          </TabPane> */}
          <TabPane tab="事件" key="4">
            <EventInfor podEventData={podEventData} />
          </TabPane>
        </Tabs>
      </Modal>
    );
  }
}

class PodList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      namespaceSelectRowData: {}
    };
    this.columns = [
      {
        title: "pod名称",
        dataIndex: "name",
        width: "30%",
        // render: (text, record) => this.renderColumns(text, record, "name")
        render: (text, record) => {
          return <a onClick={this.PodstatusClick.bind(this, record)}>{text}</a>;
        }
      },
      {
        title: "状态",
        dataIndex: "status",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "status")
        // render: (text, record) => {
        //   return <a onClick={this.PodstatusClick.bind(this, record)}>{text}</a>;
        // }
      },
      {
        title: "CPU(核)",
        dataIndex: "cpuUsage",
        width: "20%",
        // render: (text, record) => this.renderColumns(text, record, "cpuUsage")
        render: (text, record, index) => (
          <Row type="flex">
            <Col sm={16} md={16} lg={12}>
              <LineAreaChart
                key={Math.random()}
                UsageHistory={record.cpuUsageHistory}
                color="#00C752"
              />
            </Col>
            <Col sm={5} md={5} lg={8}>
              <span>{text}</span>
            </Col>
          </Row>
        )
      },
      {
        title: "内存(字节)",
        dataIndex: "memoryUsage",
        width: "20%",
        // render: (text, record) => this.renderColumns(text, record, "memoryUsage")
        render: (text, record, index) => (
          <Row type="flex">
            <Col sm={16} md={16} lg={12} style={{ textAlign: "right" }}>
              <LineAreaChart
                key={Math.random()}
                UsageHistory={record.memoryUsageHistory}
                color="#3f61e6"
              />
            </Col>
            <Col sm={5} md={5} lg={8}>
              <span>{`${text}Mi`}</span>
            </Col>
          </Row>
        )
      },
      {
        title: "创建时间",
        width: "20%",
        dataIndex: "creationTimestamp",
        render: (text, record) => this.renderColumns(text, record, "creationTimestamp")
      }
    ];
  }

  // 弹出框（监控日志）
  PodstatusClick(record) {
    const { actions, selectedRow } = this.props;
    const timestamp = new Date().toJSON();
    this.setState({
      namespaceSelectRowData: record,
      visible: true
    });
    actions.getmonitorPodBasic({
      podName: record.name,
      clusterId: selectedRow.clusterId,
      namespace: record.namespace
    });
    actions.getmonitorPodEvent({
      podName: record.name,
      clusterId: selectedRow.clusterId,
      namespace: record.namespace,
      page: "1",
      size: "10"
    });
    actions.getmonitorPodLog({
      podName: record.name,
      clusterId: selectedRow.clusterId,
      // timestamp: "2018-11-02T02:28:06Z",
      timestamp: "",
      namespace: record.namespace,
      page: "1",
      size: "10"
    });
    actions.getmonitorInfo({
      podName: record.name,
      clusterId: selectedRow.clusterId,
      namespace: record.namespace
    });
  }

  // 生命周期
  componentDidMount() {
    const { actions, selectedRow } = this.props;
    actions.findPodInfo({
      page: 1,
      nodeNames: selectedRow.nodeName,
      clusterId: selectedRow.clusterId,
      podeName: ""
    });
  }

  searchPodModal() {
    const { actions, selectedRow } = this.props;
    const podName = ReactDOM.findDOMNode(this.refs.podName).value;
    actions.findPodInfo({
      page: 1,
      nodeNames: selectedRow.nodeName,
      clusterId: selectedRow.clusterId,
      podeName: podName ? podName : ""
    });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "creationTimestamp") {
      return moment(record.creationTimestamp).format("YYYY-MM-DD HH:mm:ss");
    } else {
      return text;
    }
  }

  goBack() {
    const { triggleStatus } = this.props;
    triggleStatus(2);
  }

  render() {
    const { namespaceSelectRowData, visible, loading, pagination } = this.state;
    const {
      podBasicData,
      selectedRow,
      podEventData,
      podLogData,
      podMonitorData,
      podNumData,
      podInfoData
    } = this.props;

    const podInfoDatas = [];
    const totalItemPod = podNumData ? podNumData.totalItems : "";
    if (podInfoData) {
      podInfoData.map(item => {
        const obj = {};
        obj.cpuUsage = item.metrics.cpuUsage / 1000;
        obj.cpuUsageHistory = item.metrics.cpuUsageHistory;
        obj.memoryUsageHistory = item.metrics.memoryUsageHistory;
        obj.memoryUsage = (item.metrics.memoryUsage / 1024 / 1024).toFixed(3);
        obj.name = item.objectMeta.name;
        obj.namespace = item.objectMeta.namespace;
        obj.status = item.podStatus.status;
        obj.creationTimestamp = item.objectMeta.creationTimestamp;
        obj.key = Math.random();
        podInfoDatas.push(obj);
      });
    }
    return (
      <div>
        <div>
          <span onClick={() => this.goBack()}>
            <Icon type="left" style={{ fontSize: 16, color: "#08c" }} />
            返回
          </span>
          <span> /主机</span>
        </div>
        <Row>
          <Col span={24}>
            <Card bordered={false} style={{ width: "100%", padding: "0px 0px 0px 0px" }}>
              <Row>
                <Col span={3}>
                  <img src="/images/dashboard/H.png" alt="" />
                </Col>
                <Col span={21}>
                  <Row>
                    <Col span={3}>
                      <p>主机名称</p>
                      <p> {selectedRow.nodeName}</p>
                    </Col>
                    <Col span={3}>
                      <p>状态</p>
                      <p> {selectedRow.nodeStatus == 1 ? "正常" : "异常"}</p>
                    </Col>
                    <Col span={3}>
                      <p>角色</p>
                      <p> {selectedRow.nodeHostRole}</p>
                    </Col>
                    <Col span={3}>
                      <p>CPU</p>
                      <p> {selectedRow.nodeTotalCpu}</p>
                    </Col>
                    <Col span={3}>
                      <p>内存(MB)</p>
                      <p> {selectedRow.nodeTotalMem}</p>
                    </Col>
                    <Col span={3}>
                      <p>硬盘(GB)</p>
                      <p> {selectedRow.nodeDisk}</p>
                    </Col>
                    <Col span={3}>
                      <p>pod数量</p>
                      <p> {totalItemPod}</p>
                    </Col>
                    <Col span={3}>
                      <p>IP</p>
                      <p> {selectedRow.nodeHostIp}</p>
                    </Col>
                  </Row>
                </Col>
              </Row>
            </Card>
          </Col>
          <Col span={24}>
            <Tabs defaultActiveKey="1">
              <TabPane tab="pod" key="1">
                <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
                  <Col span={6}>
                    <span style={{ marginRight: 10 }}>pod:</span>
                    <Input placeholder="搜索pod" style={{ width: "70%" }} ref="podName" />
                  </Col>
                  <Col span={14} style={{ textAlign: "right" }}>
                    <Button
                      type="primary"
                      onClick={this.searchPodModal.bind(this)}
                      className="padright"
                      style={{ marginRight: 10 }}
                    >
                      查询
                    </Button>
                  </Col>
                </Row>
                <Table
                  style={{ marginTop: 20 }}
                  bordered
                  size="small"
                  columns={this.columns}
                  dataSource={podInfoDatas}
                  // pagination={pagination}
                  loading={loading}
                  // onChange={this.handlePodChange.bind(this)}
                />
              </TabPane>
            </Tabs>
          </Col>
        </Row>
        <CreateFormUp
          clusterId={selectedRow.clusterId}
          namespaceData={namespaceSelectRowData}
          podBasicData={podBasicData}
          podEventData={podEventData}
          podLogData={podLogData}
          podMonitorData={podMonitorData}
          visible={visible}
          onCancel={() => {
            this.setState({
              visible: false
            });
          }}
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    podInfoData: state.Resource.get("podInfoData"),
    podNumData: state.Resource.get("podNumData"),
    podBasicData: state.Resource.get("podBasicData"),
    podEventData: state.Resource.get("podEventData"),
    podLogData: state.Resource.get("podLogData"),
    podMonitorData: state.Resource.get("podMonitorData")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(action, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PodList);
