import React from "react";
import ResourceList from "./resourceList";
import ResourceDetail from "./resourceDetail";
import PodList from "./podList";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showRepository: 1,
      selectedRowData: {},
      selectedNodeRowData: {}
    };
    this.triggleStatus = this.triggleStatus.bind(this);
  }

  triggleStatus(show) {
    this.setState({
      showRepository: show
    });
  }

  selectedRow(record) {
    this.setState({
      selectedRowData: record
    });
  }

  selectedNodeRow(record) {
    this.setState({
      selectedNodeRowData: record
    });
  }

  componentDidMount() {}

  render() {
    const { showRepository, selectedRowData, selectedNodeRowData } = this.state;
    const { projectId } = this.props;
    return (
      <div>
        {showRepository == 1 ? (
          <ResourceList
            projectId={projectId}
            selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository == 2 ? (
          <ResourceDetail
            projectId={projectId}
            selectedRow={selectedRowData}
            selectedNodeRow={this.selectedNodeRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        ) : showRepository == 3 ? (
          <PodList
            projectId={projectId}
            selectedRow={selectedNodeRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : (
          ""
        )}

        {/* {this.state.showRepository ? (
          <ResourceDetail
            projectId={this.props.projectId}
            selectedRow={this.state.selectedRowData}
            triggleStatus={this.triggleStatus}
          />
        ) : (
          <ResourceList
            projectId={this.props.projectId}
            selectedRow={this.selectedRow.bind(this)}
            triggleStatus={this.triggleStatus}
          />
        )} */}
      </div>
    );
  }
}

export default Index;
