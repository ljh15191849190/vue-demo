import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  message,
  Popconfirm,
  Row,
  Col,
  Tabs,
  Tooltip,
  Icon
} from "antd";
import * as action from "../../../../actions/Resource";
import Validation from "../../../../utils/Validation";

const FormItem = Form.Item;
const Option = Select.Option;
const TabPane = Tabs.TabPane;

const UpdataForm = Form.create()(props => {
  const {
    updatavisible,
    onUpdata,
    onCancel,
    onTest,
    form,
    nameData,
    virtualorcontainer,
    handleConfirm,
    userInfo,
    type,
    title,
    handleChange
  } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false} visible={updatavisible} title={`${title}资源`} footer={null} onCancel={onCancel}>
      <Form layout="vertical">
        <FormItem label="资源类型：">
          {getFieldDecorator("resType", {
            rules: Validation.Rule_select,
            initialValue:
              userInfo && type == "edit" ? (userInfo.resType == 1 ? "虚拟机" : "容器云") : ""
          })(
            <Select
              disabled={userInfo && type == "edit" ? true : false}
              placeholder="请选择资源类型"
              allowClear
              onChange={handleChange}
            >
              <Option value="1">虚拟机</Option>
              <Option value="2">容器云</Option>
            </Select>
          )}
        </FormItem>
        {virtualorcontainer == 1 ? (
          <div>
            <FormItem label="环境名称：">
              {getFieldDecorator("envId", {
                rules: Validation.Rule_select,
                initialValue: userInfo && type == "edit" ? userInfo.envName : ""
              })(
                <Select placeholder="请选择环境名称" allowClear>
                  {nameData
                    ? nameData.map(v => {
                        return (
                          <Option value={v.envId} key={v.envId}>
                            {v.envName}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
            <FormItem label="资源名称：">
              {getFieldDecorator("resName", {
                rules: Validation.Rule_code,
                initialValue: userInfo && type == "edit" ? userInfo.resName : ""
              })(
                <Input
                  placeholder="请输入资源名称"
                  disabled={userInfo && type == "edit" ? true : false}
                  maxLength={32}
                />
              )}
            </FormItem>
            <FormItem>
              <Col span={17}>
                <FormItem label="主机IP：">
                  {getFieldDecorator("resHostIp", {
                    rules: Validation.Rule_ip,
                    initialValue: userInfo && type == "edit" ? userInfo.resHostIp : ""
                  })(<Input maxLength={128} />)}
                </FormItem>
              </Col>
              <Col span={2}>
                <span
                  style={{
                    display: "inline-block",
                    width: "100%",
                    textAlign: "center",
                    marginTop: 33
                  }}
                >
                  -
                </span>
              </Col>
              <Col span={5}>
                <FormItem label="端口">
                  {getFieldDecorator("resHostPort", {
                    rules: Validation.Rule_number,
                    initialValue: userInfo && type == "edit" ? userInfo.resHostPort : ""
                  })(<Input maxLength={16} />)}
                </FormItem>
              </Col>
            </FormItem>
            <FormItem label="用户名：">
              {getFieldDecorator("resHostUser", {
                rules: Validation.Rule_nochinese,
                initialValue: userInfo && type == "edit" ? userInfo.resHostUser : ""
              })(<Input maxLength={32} />)}
            </FormItem>
            <FormItem label="密码：">
              {getFieldDecorator("resHostPwd", {
                rules: Validation.Rule_nochinese,
                initialValue: userInfo && type == "edit" ? userInfo.resHostPwd : ""
              })(<Input type="password" maxLength={32} />)}
            </FormItem>
          </div>
        ) : (
          <div>
            <FormItem label="集群名称：">
              {getFieldDecorator("clusterName", {
                rules: Validation.Rule_NumLetter,
                initialValue: userInfo && type == "edit" ? userInfo.clusterName : ""
              })(<Input placeholder="请输入集群名称" maxLength={32} />)}
            </FormItem>
            <FormItem>
              <Col span={17}>
                <FormItem label="集群地址：">
                  {getFieldDecorator("clusterVipIp", {
                    rules: Validation.Rule_ip,
                    initialValue: userInfo && type == "edit" ? userInfo.clusterVipIp : ""
                  })(<Input maxLength={128} />)}
                </FormItem>
              </Col>
              <Col span={2}>
                <span
                  style={{
                    display: "inline-block",
                    width: "100%",
                    textAlign: "center",
                    marginTop: 33
                  }}
                >
                  -
                </span>
              </Col>
              <Col span={5}>
                <FormItem label="端口">
                  {getFieldDecorator("clusterVipPort", {
                    rules: Validation.Rule_number,
                    initialValue: userInfo && type == "edit" ? userInfo.clusterVipPort : ""
                  })(<Input maxLength={16} />)}
                </FormItem>
              </Col>
            </FormItem>
            <FormItem label="外网地址">
              {getFieldDecorator("clusterIngressVipIp", {
                rules: Validation.Rule_ip,
                initialValue: userInfo && type == "edit" ? userInfo.clusterIngressVipIp : ""
              })(<Input maxLength={128} />)}
            </FormItem>
            <FormItem label="认证方式：">
              {getFieldDecorator("clusterCerType", {
                rules: Validation.Rule_select,
                initialValue: 1
              })(
                <Select placeholder="请选择认证方式" allowClear>
                  <Option value={1}>CA</Option>
                </Select>
              )}
            </FormItem>
            <Tabs
              defaultActiveKey="1"
              tabBarExtraContent={
                <Tooltip title="四个选项请补充完整">
                  <Icon type="question-circle" theme="filled" style={{ fontSize: "18px" }} />
                </Tooltip>
              }
            >
              <TabPane tab="根证书" key="1">
                <FormItem label="根证书：">
                  {getFieldDecorator("clusterCa", {
                    rules: Validation.Rule_nochinese,
                    initialValue: userInfo && type == "edit" ? userInfo.clusterCa : ""
                  })(<Input.TextArea rows={3} maxLength={10000} />)}
                </FormItem>
              </TabPane>
              <TabPane tab="服务器证书" key="2">
                <FormItem label="服务器证书：">
                  {getFieldDecorator("clusterClientCa", {
                    // rules: Validation.Rule_nochinese,
                    rules: [
                      {
                        required: true,
                        pattern: /^[^\u4e00-\u9fa5]+$/,
                        // validator: handleConfirm,
                        message: "请输入非中文"
                      }
                    ],
                    initialValue: userInfo && type == "edit" ? userInfo.clusterClientCa : ""
                  })(<Input.TextArea rows={3} maxLength={10000} />)}
                </FormItem>
              </TabPane>
              <TabPane tab="私钥" key="3">
                <FormItem label="私钥：">
                  {getFieldDecorator("clusterClientKey", {
                    rules: Validation.Rule_nochinese,
                    initialValue: userInfo && type == "edit" ? userInfo.clusterClientKey : ""
                  })(<Input.TextArea rows={3} maxLength={10000} />)}
                </FormItem>
              </TabPane>
              <TabPane tab="OauthToken" key="4">
                <FormItem label="OauthToken：">
                  {getFieldDecorator("dashboardToken", {
                    rules: Validation.Rule_nochinese,
                    initialValue: userInfo && type == "edit" ? userInfo.dashboardToken : ""
                  })(<Input.TextArea rows={3} maxLength={10000} />)}
                </FormItem>
              </TabPane>
            </Tabs>
          </div>
        )}
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex" justify="end">
          <Col span={4}>
            <Button onClick={onCancel} style={{ marginLeft: 10 }}>
              取消
            </Button>
          </Col>
          <Col span={4}>
            <Button type="primary" onClick={onUpdata} style={{ marginLeft: 10 }}>
              确认
            </Button>
          </Col>
          <Col span={4}>
            <Button type="danger" onClick={onTest} style={{ marginLeft: 10 }}>
              连接测试
            </Button>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});

class Resource extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      updatavisible: false,
      updataData: {},
      resourceValue: "",
      key: 1,
      virtualorcontainer: 1
    };
    const { TextArea } = Input;
    this.columns = [
      {
        title: "资源名称",
        dataIndex: "resName",
        render: (text, record) => {
          return (
            // <a onClick={this.editClick.bind(this, record)}>{text}</a>
            <div>
              {record.resType == 2 ? (
                <a onClick={this.editClick.bind(this, record)}>{text}</a>
              ) : (
                text
              )}
            </div>
          );
        }
      },
      {
        title: "资源类型",
        dataIndex: "resType",
        render: (text, record) => this.renderColumns(text, record, "resType")
      },
      {
        title: "环境名称",
        dataIndex: "envName",
        // render: (text, record) => this.renderColumns(text, record, "envName")
        render: (text, record) => {
          return text == "null" ? "" : text;
        }
      },
      {
        title: "状态",
        dataIndex: "status",
        render: (text, record) => this.renderColumns(text, record, "status")
      },
      {
        title: "资源IP地址",
        dataIndex: "resHostIp",
        render: (text, record) => this.renderColumns(text, record, "resHostIp")
      },
      {
        title: "CPU",
        dataIndex: "resTotalCpu",
        render: (text, record) => this.renderColumns(text, record, "resTotalCpu")
      },
      {
        title: "内存",
        dataIndex: "resTotalMem",
        render: (text, record) => this.renderColumns(text, record, "resTotalMem")
      },
      {
        title: "硬盘",
        dataIndex: "resDist",
        render: (text, record) => this.renderColumns(text, record, "resDist")
      },
      {
        title: "所在集群",
        dataIndex: "resClusterName",
        render: (text, record) => this.renderColumns(text, record, "resClusterName")
      },
      {
        title: "最后修改时间",
        dataIndex: "resHostUptime",
        render: (text, record) => this.renderColumns(text, record, "resHostUptime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              <a
                onClick={() => {
                  this.showEditModal("edit", record);
                }}
                className="padright"
              >
                编辑
              </a>
              <Popconfirm
                title="确定删除吗？"
                onConfirm={() => this.handleDelOk(record)}
                okText="确定"
                cancelText="取消"
              >
                <a className="padright">删除</a>
              </Popconfirm>
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    // this.showEidtModal = this.showEditModal.bind(this);
    this.handleConfirm = this.handleConfirm.bind(this);
  }

  // 验证上传格式
  handleConfirm(rule, value, callback) {
    if (!value) {
      message.info("证书内容不能为空");
    }
  }

  // 确认删除
  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteResource(record.resId);
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "resType") {
      return text == "1" ? "虚拟机" : "容器云";
    } else if (column == "status") {
      return (
        <div>
          <span
            style={{
              backgroundColor: text == "0" ? "#52B036" : "#FF0000",
              padding: "2px 15px",
              color: "#fff",
              borderRadius: "6px"
            }}
          >
            {text == "0" ? "正常" : "异常"}
          </span>
        </div>
      );
    } else {
      return text;
    }
  }

  // 控件搜索
  search() {
    const { actions, projectId } = this.props;
    const { resourceValue } = this.state;
    const resourceName = ReactDOM.findDOMNode(this.refs.resourceName).value;
    actions.getResource({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        },
        {
          name: "resName",
          sopt: "cn",
          value: resourceName ? resourceName : ""
        },
        {
          name: "resType",
          sopt: "eq",
          value: resourceValue ? resourceValue : ""
        }
      ]
    });
  }

  handleChangeStatus(value) {
    this.setState({
      resourceValue: value
    });
  }

  // 生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getResource({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        }
      ]
    });
    actions.getEnvironmentName({
      projectId
    });
  }

  query() {
    const { actions, projectId } = this.props;
    actions.getResource({
      page: 1,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        }
      ]
    });
  }

  componentDidUpdate(nextProps) {
    const {
      delStatus,
      pageConfig,
      actions,
      projectId,
      addStatus,
      updataStatus,
      testData
    } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      if (
        nextProps.pageConfig.total % nextProps.pageConfig.size === 1 &&
        nextProps.pageConfig.totalPage > 1
      ) {
        actions.getResource({
          page: nextProps.pageConfig.totalPage - 1,
          conditions: [
            {
              name: "projectId",
              sopt: "eq",
              value: projectId
            }
          ]
        });
      } else {
        actions.getResource({
          page: nextProps.pageConfig.page,
          conditions: [
            {
              name: "projectId",
              sopt: "eq",
              value: projectId
            }
          ]
        });
      }
    } else if (delStatus && delStatus === 2) {
      message.error("有任务使用该资源不能删除");
      this.query();
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      this.query();
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      this.query();
    } else if (addStatus && addStatus === 3) {
      message.error("资源已存在");
      this.query();
    } else if (addStatus && addStatus === 4) {
      message.error("连接测试失败无法新增");
      this.query();
    } else if (addStatus && addStatus === 5) {
      message.error("容器云已存在");
      this.query();
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      this.query();
    } else if (updataStatus && updataStatus === 2) {
      message.error("修改失败");
      this.query();
    } else if (updataStatus && updataStatus === 3) {
      message.error("资源已存在");
      this.query();
    }
    if (testData && testData === 1) {
      message.info("测试成功");
      this.query();
    } else if (testData && testData === 2) {
      message.error("测试失败");
      this.query();
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { actions, projectId } = this.props;
    const { resourceValue } = this.state;
    this.setState({ loading: true });
    const resourceName = ReactDOM.findDOMNode(this.refs.resourceName).value;
    actions.getResource({
      page: pagination.current,
      conditions: [
        {
          name: "projectId",
          sopt: "eq",
          value: projectId
        },
        {
          name: "envName",
          sopt: "cn",
          value: resourceName ? resourceName : ""
        },
        {
          name: "envType",
          sopt: "cn",
          value: resourceValue ? resourceValue : ""
        }
      ]
    });
  }

  handleChange(value) {
    if (value == 1) {
      this.setState({
        virtualorcontainer: 1
      });
    } else {
      this.setState({
        virtualorcontainer: 2
      });
    }
  }

  updataFormRef(form) {
    this.form = form;
  }

  editClick(record) {
    const { triggleStatus, selectedRow } = this.props;
    if (record.resType == 2) {
      triggleStatus(2);
      selectedRow(record);
    }
  }

  // 点击修改弹框
  showEditModal(type, record) {
    const { triggleStatus, selectedRow } = this.props;
    if (type == "create") {
      this.setState({
        title: "创建",
        updatavisible: true,
        type: "create"
      });
    } else if (type == "edit") {
      this.setState({
        title: "编辑",
        userInfo: record,
        type: "edit",
        updataData: {
          id: record.id
        },
        loading: false
      });
      if (record.resType == 2) {
        // 容器云
        // this.setState({
        //   virtualorcontainer: 2
        // });
        triggleStatus(2);
        selectedRow(record);
      } else {
        this.setState({
          virtualorcontainer: 1,
          updatavisible: true
        });
      }
    }
  }

  // 确认修改updata
  handleUpdataOk() {
    const form = this.form;
    const { projectId, actions } = this.props;
    const { type, virtualorcontainer, updataData } = this.state;
    // console.log(type);
    if (type == "create") {
      form.validateFields((err, values) => {
        if (err) {
          return;
        }
        values.projectId = projectId;
        values.zoneId = "1";
        values.clusterResType = values.resType;
        if (virtualorcontainer === 1) {
          actions.addResource(values);
        } else {
          actions.addCluster(values);
        }
        form.resetFields();
        this.setState({ updatavisible: false });
      });
    } else {
      form.validateFields((err, values) => {
        if (err) {
          return;
        }
        values.resType = values.resType == "虚拟机" ? "1" : "2";
        values.id = updataData.id;
        values.projectId = projectId;
        values.zoneId = "1";
        values.clusterResType = values.resType;
        if (virtualorcontainer === 1) {
          actions.updateResource(values); // 编辑虚拟机
        } else {
          // actions.updateResource(values); //编辑容器云
        }
        form.resetFields();
        this.setState({ updatavisible: false });
      });
    }
  }

  // 取消
  handleCancel(e) {
    this.form.resetFields();
    this.setState(
      {
        updatavisible: false
      },
      () => {
        this.setState({
          virtualorcontainer: 1
        });
      }
    );
  }

  // 测试连接修改
  handleTestUp(e) {
    const { projectId, actions } = this.props;
    const { updataData, virtualorcontainer } = this.state;
    const form = this.form;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      values.resType = values.resType == "虚拟机" ? "1" : "2";
      values.id = updataData.id;
      values.projectId = projectId;
      values.zoneId = "1";
      values.clusterResType = values.resType;
      if (virtualorcontainer === 1) {
        actions.getResourceTest(values); // 虚拟机
      } else {
        actions.validateCluster(values); // 容器云
      }
    });
  }

  render() {
    const { resData, nameData } = this.props;
    const {
      updatavisible,
      virtualorcontainer,
      userInfo,
      type,
      title,
      pagination,
      loading
    } = this.state;
    if (resData) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>资源名称:</span>
              <Input placeholder="请输入环境名称" style={{ width: "70%" }} ref="resourceName" />
            </Col>
            <Col span={6}>
              <span style={{ marginRight: 10 }}>资源类型:</span>
              <Select
                allowClear
                placeholder="请选择资源类型"
                style={{ width: "70%" }}
                onChange={this.handleChangeStatus.bind(this)}
              >
                <Option value="1">虚拟机</Option>
                <Option value="2">容器云</Option>
              </Select>
            </Col>

            <Col span={10} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button
                type="primary"
                onClick={this.showEditModal.bind(this, "create")}
                className="padright"
              >
                新增
              </Button>
            </Col>
          </Row>

          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            nameData={nameData}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
            virtualorcontainer={virtualorcontainer}
            onTest={this.handleTestUp.bind(this)}
            handleChange={this.handleChange}
            handleConfirm={this.handleConfirm}
            userInfo={userInfo}
            type={type}
            title={title}
            // key={Math.random()}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.Resource.get("resData"),
    pageConfig: state.Resource.get("pageConfig"),
    addStatus: state.Resource.get("AddStatus"),
    delStatus: state.Resource.get("delStatus"),
    updataStatus: state.Resource.get("UpdataStatus"),
    nameData: state.Resource.get("nameData"),
    testData: state.Resource.get("testData"),
    testClusterStatus: state.Resource.get("testClusterStatus")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Resource);
