import React from "react";
import { Row, Col, Icon, Timeline, message } from "antd";
import moment from "moment";
import "./Index.css";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { podEventData } = this.props;

    return (
      <div>
        <Timeline>
          {podEventData != "" ? (
            podEventData.map((item, index) => {
              return (
                <Timeline.Item
                  key={Math.random()}
                  color="green"
                  dot={<Icon type="check-circle" style={{ fontSize: "16px" }} />}
                  style={{ marginLeft: 10 }}
                >
                  <Row type="flex">
                    <Col span={3}>
                      <p>{item.type}</p>
                    </Col>
                    <Col span={14}>
                      <p>
                        消息：
                        {item.message}
                      </p>
                    </Col>
                    <Col span={6}>
                      <p>
                        时间：
                        {moment(item.time).format("YYYY-MM-DD HH:mm:ss")}
                      </p>
                    </Col>
                  </Row>
                </Timeline.Item>
              );
            })
          ) : (
            <Timeline.Item className="NoTimelineItem">
              <span style={{ fontSize: 18, color: "#ccc" }}>无内容显示</span>
            </Timeline.Item>
          )}
        </Timeline>
      </div>
    );
  }
}

export default Index;
