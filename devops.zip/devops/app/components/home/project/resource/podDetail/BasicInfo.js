import React from "react";
import { Row, Col } from "antd";
import moment from "moment";

class BasicInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { podBasicData } = this.props;

    let detailInformation = {
      namespace: "",
      labels: ""
    };
    let detailInformationspec = { nodeName: "" };

    let creationTimestamptext = "";
    let statusInformation = {
      phase: "",
      qosClass: "",
      podIP: ""
    };
    const detailInformationArr = podBasicData;
    const detailInformationArrItems = detailInformationArr.items;
    if (
      detailInformationArrItems &&
      detailInformationArrItems.length !== 0 &&
      detailInformationArrItems[0]
    ) {
      detailInformation = detailInformationArrItems[0].metadata;
      creationTimestamptext = moment(
        detailInformationArrItems[0].metadata.creationTimestamp
      ).format("YYYY-MM-DD HH:mm:ss");

      statusInformation = detailInformationArrItems[0].status;
      detailInformationspec = detailInformationArrItems[0].spec.nodeName;
    }
    return (
      <div>
        <div style={{ padding: "10px", marginBottom: "10px" }}>
          <Row type="flex">
            <Col span={16}>
              <p>
                名称：
                {detailInformation.name}
              </p>
              <p>
                命名空间：
                {detailInformation.namespace}
              </p>
              <p>
                标签：
                {detailInformation.labels && detailInformation.labels.length !== 0
                  ? JSON.stringify(detailInformation.labels)
                  : ""}
              </p>
              <p>
                创建时间：
                {creationTimestamptext}
              </p>

              <p>
                状态：
                {statusInformation.phase}
              </p>
              <p>
                QOS等级：
                {statusInformation.qosClass}
              </p>
              <p>
                网络节点：
                {detailInformationspec.nodeName}
              </p>
              <p>
                网络IP：
                {statusInformation.podIP}
              </p>
            </Col>
          </Row>
        </div>
      </div>
    );
  }
}

export default BasicInfo;
