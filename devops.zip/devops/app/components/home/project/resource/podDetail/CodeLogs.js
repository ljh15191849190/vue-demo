import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Card, Icon, DatePicker, Tooltip, message } from "antd";
import * as action from "../../../../../actions/Resource";
import moment from "moment";
import CodeMirror from "react-codemirror";
import "codemirror/lib/codemirror.css";
import "codemirror/mode/yaml/yaml";
import "codemirror/mode/shell/shell";
import "codemirror/mode/jsx/jsx";
import "codemirror/addon/hint/show-hint.css";
import "codemirror/addon/hint/show-hint.js";
import "codemirror/addon/hint/sql-hint.js";
import "codemirror/theme/ambiance.css";
import "codemirror/addon/display/fullscreen.css";
import "codemirror/addon/display/fullscreen.js";

class CodeLogs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      size: 10
    };
  }
  componentDidUpdate() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setValue(this.props.podLogData);
  }
  ChangeCode() {
    const editorss = this.refs.editor.getCodeMirror();
    this.props.getValue(editorss.getValue());
  }
  // 放大
  getValue() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setOption("fullScreen", "true");
  }
  moreCheck() {
    this.setState({
      size: this.state.size + 10
    });
    if (this.state.TimeType) {
      this.props.actions.getmonitorPodLog({
        podName: this.props.namespaceData.name,
        clusterId: this.props.clusterId,
        timestamp: this.state.TimeType,
        namespace: this.props.namespaceData.namespace,
        page: "1",
        size: this.state.size + 10
      });
    } else {
      let timestamp = new Date().toJSON();
      this.props.actions.getmonitorPodLog({
        podName: this.props.namespaceData.name,
        clusterId: this.props.clusterId,
        timestamp: "",
        namespace: this.props.namespaceData.namespace,
        page: "1",
        size: this.state.size + 10
      });
    }
  }
  onChangeDate(date, dateString) {
    let timestamp = "";
    let TimeType = "";
    if (dateString != "") {
      timestamp = moment(dateString).format();
      TimeType = timestamp.substring(0, 19) + "Z";
    }
    this.setState({
      TimeType: TimeType
    });
    this.props.actions.getmonitorPodLog({
      podName: this.props.namespaceData.name,
      clusterId: this.props.clusterId,
      //   timestamp: "2018-11-01T02:28:06Z",
      timestamp: TimeType,
      namespace: this.props.namespaceData.namespace,
      page: "1",
      size: "10"
    });
  }
  render() {
    const options = {
      autofocus: true,
      lineNumbers: true, // 显示行号
      mode: { name: "yaml" }, // 定义mode
      extraKeys: { Ctrl: "autocomplete" }, // 自动提示配置
      lineWrapping: true, // 自动换行
      theme: "ambiance", // 选中的theme
      extraKeys: {
        F7: function(cm) {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        Esc: function(cm) {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
    };
    let YarnValue = this.props.podLogData;
    return (
      <div>
        <Card
          title="日志"
          extra={
            <div className="card-actionIcon">
              {/* <span className="card-actionIcon-more" onClick={this.moreCheck.bind(this)}>
                查看更多
              </span> */}
              <a onClick={this.moreCheck.bind(this)}>查看更多</a>
              <span style={{ margin: "0px 10px" }}>
                <DatePicker format="YYYY-MM-DD HH:mm:ss" onChange={this.onChangeDate.bind(this)} />
              </span>
              <Tooltip title="按键F7放大缩小">
                <Icon
                  type="question-circle"
                  theme="filled"
                  style={{ fontSize: "18px", color: "#08c" }}
                />
              </Tooltip>
              <a href="#" onClick={this.getValue.bind(this)} style={{ marginLeft: 10 }}>
                <Icon type="arrows-alt" style={{ fontSize: "18px", color: "#08c" }} />
              </a>
            </div>
          }
        >
          <CodeMirror
            ref="editor"
            value={YarnValue ? YarnValue : ""}
            options={options}
            onChange={() => this.ChangeCode()}
          />
        </Card>
      </div>
    );
  }
}

// export default CodeLogs;
const mapStateToProps = state => {
  return {
    podLogData: state.Resource.get("podLogData")
  };
};

const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(action, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeLogs);
