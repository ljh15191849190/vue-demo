import React from "react";
import ReactDOM from "react-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import {
  Table,
  Input,
  Select,
  Modal,
  Button,
  Form,
  message,
  Popconfirm,
  Row,
  Col,
  Tabs,
  Tree
} from "antd";
import * as action from "../../../../actions/Role";
import "antd/dist/antd.css";
import Validation from "../../../../utils/Validation";
import "./Index.css";

const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;
const { Option } = Select;
const { TabPane } = Tabs;

const NewForm = Form.create()(props => {
  const { visible, onCreate, onCancel, handleChange, form, getAllData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={visible}
      title="新增角色"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Form layout="vertical">
        <FormItem label="角色名称：">
          {getFieldDecorator("roleName", {
            rules: Validation.Rule_name
          })(<Input placeholder="请输入角色名称" maxLength={32} />)}
        </FormItem>
        <FormItem label="角色描述：">
          {getFieldDecorator("roleDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});
const UpdataForm = Form.create()(props => {
  const { updatavisible, onUpdata, onCancel, handleChange, form, getAllData } = props;
  const { getFieldDecorator } = form;
  return (
    <Modal maskClosable={false}
      visible={updatavisible}
      title="编辑角色"
      okText="确定"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onUpdata}
    >
      <Form layout="vertical">
        <FormItem label="角色名称：">
          {getFieldDecorator("roleName", {
            rules: Validation.Rule_name
          })(<Input placeholder="请输入角色名称" maxLength={32} />)}
        </FormItem>
        <FormItem label="角色描述：">
          {getFieldDecorator("roleDesc")(<Input type="textarea" maxLength={256} />)}
        </FormItem>
      </Form>
    </Modal>
  );
});

const Treerole = Form.create()(props => {
  const {
    treevisible,
    onCancel,
    onCreate,
    onCheck,
    reslist,
    selectData,
    onSelect,
    onExpand,
    expandedKeys,
    autoExpandParent,
    checkedKeys,
    selectedKeys
  } = props;

  const renderMethod = data => {
    if (data && data.length !== 0) {
      return data.map((item, key) => {
        if (item.childMenus && item.childMenus.length !== 0) {
          return (
            <TreeNode value={item.menuId} title={item.menuName} key={item.menuId}>
              {renderMethod(item.childMenus)}
            </TreeNode>
          );
        } else {
          return <TreeNode value={item.menuId} title={item.menuName} key={item.menuId} />;
        }
      });
    }
  };
  return (
    <Modal maskClosable={false}
      width="650px"
      height="600px"
      visible={treevisible}
      title="选择菜单"
      okText="保存"
      cancelText="取消"
      onCancel={onCancel}
      onOk={onCreate}
    >
      <Tabs type="card" style={{ height: "500px", overflowY: "auto" }}>
        {reslist ? (
          <TabPane tab="menu目录" key="key">
            <div>
              <Tree
                checkable
                expandedKeys={expandedKeys}
                autoExpandParent={autoExpandParent}
                checkedKeys={checkedKeys}
                selectedKeys={selectedKeys}
                onExpand={onExpand}
                onCheck={onCheck}
                onSelect={onSelect}
              >
                {renderMethod(reslist)}
              </Tree>
            </div>
          </TabPane>
        ) : (
          <TabPane tab="无数据" key={1}>
            无数据
          </TabPane>
        )}
      </Tabs>
    </Modal>
  );
});

class Role extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      visible: false,
      updatavisible: false,
      treevisible: false,
      projectDetailVisual: false,
      updataData: {},
      key: 1,
      selectRowData: {},
      // tree
      expandedKeys: [],
      autoExpandParent: true,
      checkedKeys: [],
      selectedKeys: [],
      // 树值
      treeSelectValue: []
    };
    const { TextArea } = Input;
    this.columns = [
      {
        title: "角色名称",
        dataIndex: "roleName",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "roleName")
      },
      {
        title: "描述",
        dataIndex: "roleDesc",
        width: "45%",
        render: (text, record) => this.renderColumns(text, record, "roleDesc")
      },

      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "20%",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      },
      {
        title: "操作",
        dataIndex: "operation",
        width: "20%",
        render: (text, record) => {
          this.online = record;
          return (
            <div className="editable-row-operations">
              {record.roleCode == "project-manager" ? (
                <span className="editable-row-operations-action">授权</span>
              ) : (
                <span
                  onClick={() => {
                    this.roleAuthorize(record);
                  }}
                  className="editable-row-operations-action-active"
                >
                  授权
                </span>
              )}
              <a
                onClick={() => {
                  this.showEditModal(record);
                }}
                className="padright"
              >
                编辑
              </a>

              {record.roleCode ? (
                <span className="editable-row-operations-action">删除</span>
              ) : (
                <span className="editable-row-operations-action-active">
                  <Popconfirm
                    title="确定删除吗？"
                    onConfirm={() => this.handleDelOk(record)}
                    okText="确定"
                    cancelText="取消"
                  >
                    删除
                  </Popconfirm>
                </span>
              )}
            </div>
          );
        }
      }
    ];
    this.handleChange = this.handleChange.bind(this);
    this.setState = this.setState.bind(this);
    this.showEidtModal = this.showEditModal.bind(this);
  }

  //   确认删除
  handleDelOk(record) {
    const { actions } = this.props;
    actions.deleteRole({ id: record.id });
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    return text;
  }

  //   控件搜索
  search() {
    const { actions, projectId } = this.props;
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    actions.getRole({
      roleName: encodeURIComponent(roleName),
      projectId,
      page: 1,
      size: 10,
      conditions: []
    });
  }

  //   生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getRole({
      roleName: "",
      projectId,
      page: 1,
      size: 10,
      conditions: []
    });
    actions.getAllMenu();
  }

  query() {
    const { projectId, actions } = this.props;
    actions.getRole({
      roleName: "",
      projectId,
      page: 1,
      size: 10,
      conditions: []
    });
  }

  componentDidUpdate(nextProps) {
    const { pageConfig, delStatus, projectId, addStatus, updataStatus, actions } = this.props;
    if (delStatus && delStatus === 1) {
      message.info("删除成功");
      if (
        nextProps.pageConfig.total % nextProps.pageConfig.size === 1 &&
        nextProps.pageConfig.totalPage > 1
      ) {
        actions.getRole({
          roleName: "",
          projectId,
          page: nextProps.pageConfig.totalPage - 1,
          size: 10,
          conditions: []
        });
      } else {
        actions.getRole({
          roleName: "",
          projectId,
          page: nextProps.pageConfig.page,
          size: 10,
          conditions: []
        });
      }
    }
    if (addStatus && addStatus === 1) {
      message.info("新增成功");
      this.query();
    } else if (addStatus && addStatus === 2) {
      message.error("新增失败");
      this.query();
    } else if (addStatus && addStatus === 3) {
      message.error("角色已存在");
      this.query();
    }
    if (updataStatus && updataStatus === 1) {
      message.info("修改成功");
      this.query();
    } else if (updataStatus && updataStatus === 2) {
      message.error("修改失败");
      this.query();
    } else if (updataStatus && updataStatus === 3) {
      message.error("角色已存在");
      this.query();
    }
  }

  // 分页
  handlePageChange(pagination, filters, sorter) {
    const { projectId, actions } = this.props;
    this.setState({ loading: true });
    const roleName = ReactDOM.findDOMNode(this.refs.roleName).value;
    actions.getRole({
      roleName,
      page: pagination.current,
      size: 10,
      projectId,
      conditions: []
    });
  }

  handleChange(value) {}

  saveFormRef(forms) {
    this.forms = forms;
  }

  updataFormRef(form) {
    this.form = form;
  }

  // 点击修改弹框
  showEditModal(record) {
    this.form.setFieldsValue({
      roleName: record.roleName,
      roleDesc: record.roleDesc
    });
    this.setState({
      updataData: {
        id: record.id,
        projectId: record.projectId
      },
      loading: false,
      updatavisible: true
    });
  }

  // 确认修改updata
  handleUpdataOk(e) {
    const form = this.form;
    const { updataData } = this.state;
    const { actions } = this.props;
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      form.resetFields();
      values.projectId = updataData.projectId;
      values.id = updataData.id;
      actions.updateRole(values);
      this.setState({ updatavisible: false });
    });
  }

  // 点击新增弹框
  showModal() {
    this.setState({
      visible: true
    });
  }

  // 保存
  handleOk(e) {
    const { projectId, actions } = this.props;
    const forms = this.forms;
    forms.validateFields((err, values) => {
      if (err) {
        return;
      }
      forms.resetFields();
      values.projectId = projectId;
      actions.addRole(values);
      this.setState({ visible: false });
    });
  }

  // 取消
  handleCancel(e) {
    this.forms.resetFields();
    this.form.resetFields();
    this.setState({
      visible: false,
      updatavisible: false,
      treevisible: false
    });
  }

  componentWillUnmount() {
    if (this.timer) {
      // 卸载定时器
      clearTimeout(this.timer);
    }
  }

  // 查出选中的ID
  findNode(datas, key, resultList) {
    let index = 0;
    while (index < datas.length) {
      const temp = datas[index];
      if (temp.menuId == key) {
        resultList.push(temp);
      }
      if (temp.childMenus) {
        if (temp.childMenus.length > 0) {
          this.findNode(temp.childMenus, key, resultList);
        }
      }
      index++;
    }
  }

  // 授权
  roleAuthorize(record) {
    const { actions } = this.props;
    actions.getSelectMenu({ roleId: record.id });
    this.setState({ treevisible: true, selectRowData: record });
    if (this.timer) {
      clearTimeout(this.timer);
    }
    // this.timer = setTimeout(() => {
    //   this.setState({
    //     checkedKeys: selectData ? selectData.menuIds : []
    //   }, () => {
    //     console.log("111", selectData, this.state.checkedKeys)
    //   });
    // }, 1000)
    this.timer = setTimeout((originList, showListMenuIds, resultList) => {
      const { getAllData, selectData } = this.props;
      originList = getAllData;
      showListMenuIds = selectData.menuIds;
      resultList = [];

      // 根据后台提供的ID查出数据源中的对象
      for (let j = showListMenuIds.length - 1; j >= 0; j--) {
        this.findNode(originList, showListMenuIds[j], resultList);
      }

      // 已知树状结构层级时
      // 第一级父树

      const halfShowListId = [];
      let child = {};
      let child1 = {};
      for (const m of resultList) {
        // 没有子树的选项

        if (m.childMenus) {
          // 可能半选状态

          child = m.childMenus.filter(item => showListMenuIds.indexOf(item.menuId) === -1); //
          if (child.length !== 0) {
            halfShowListId.push(m.menuId);
          }
          for (const n of m.childMenus) {
            // 找最外层的（三层的第一层）
            if (n.childMenus) {
              child1 = n.childMenus.filter(item => showListMenuIds.indexOf(item.menuId) === -1); //
              if (child1.length !== 0) {
                halfShowListId.push(m.menuId);
              }
            }
          }
        }
      }
      let halfShowListIdOnly = [];
      let showLastList = [];
      if (halfShowListId.length !== 0) {
        halfShowListIdOnly = [...new Set(halfShowListId)]; //  去重

        const parentItem = resultList.filter(
          itemId => halfShowListIdOnly.indexOf(itemId.menuId) !== -1
        );
        if (parentItem.length !== 0) {
          for (const n of parentItem) {
            halfShowListIdOnly.push(n.menuId);
          }
        }

        showLastList = showListMenuIds.filter(itemId => halfShowListIdOnly.indexOf(itemId) === -1);
      } else {
        showLastList = showListMenuIds; // 全树时的
      }

      this.setState({
        checkedKeys: { checked: showLastList, halfChecked: halfShowListIdOnly }
      });
    }, 600);
  }

  roleOk() {
    const { actions } = this.props;
    const { treeSelectValue, selectRowData } = this.state;
    const data = {
      menuIds: treeSelectValue,
      roleId: selectRowData.id
    };
    actions.saveSelectMenu(data);
    this.setState({ treevisible: false, checkedKeys: [] });
  }

  onExpand(expandedKeys) {
    this.setState({
      expandedKeys,
      autoExpandParent: false
    });
  }

  onCheck(checkedKeys, { halfCheckedKeys }) {
    this.setState({ checkedKeys });
    const checkedList = checkedKeys.concat(halfCheckedKeys);
    this.setState({ treeSelectValue: checkedList });
  }

  onSelect(selectedKeys, info) {
    this.setState({ selectedKeys });
  }

  render() {
    const { resData, getAllData, selectData } = this.props;
    const {
      pagination,
      loading,
      visible,
      updatavisible,
      treeSelectValue,
      treevisible,
      expandedKeys,
      autoExpandParent,
      checkedKeys,
      selectedKeys
    } = this.state;
    if (resData) {
      resData.map(item => {
        item.key = item.id;
      });
    } else {
      return false;
    }
    return (
      <div>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>角色名称:</span>
              <Input placeholder="角色名称" style={{ width: "70%" }} ref="roleName" />
            </Col>
            <Col span={16} style={{ textAlign: "right" }}>
              <Button
                type="primary"
                onClick={this.search.bind(this)}
                className="padright"
                style={{ marginRight: 10 }}
              >
                查询
              </Button>
              <Button type="primary" onClick={this.showModal.bind(this)} className="padright">
                新增
              </Button>
            </Col>
          </Row>

          <NewForm
            ref={this.saveFormRef.bind(this)}
            getAllData={getAllData}
            visible={visible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.handleOk.bind(this)}
          />
          <UpdataForm
            ref={this.updataFormRef.bind(this)}
            getAllData={getAllData}
            updatavisible={updatavisible}
            onCancel={this.handleCancel.bind(this)}
            onUpdata={this.handleUpdataOk.bind(this)}
          />
          <Treerole
            treeSelectValue={treeSelectValue}
            treevisible={treevisible}
            onCancel={this.handleCancel.bind(this)}
            onCreate={this.roleOk.bind(this)}
            reslist={getAllData ? getAllData : []}
            selectData={selectData ? selectData : []}
            expandedKeys={expandedKeys}
            autoExpandParent={autoExpandParent}
            checkedKeys={checkedKeys}
            selectedKeys={selectedKeys}
            onCheck={this.onCheck.bind(this)}
            onExpand={this.onExpand.bind(this)}
            onSelect={this.onSelect.bind(this)}
          />
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.Role.get("resData"),
    pageConfig: state.Role.get("pageConfig"),
    addStatus: state.Role.get("AddStatus"),
    delStatus: state.Role.get("delStatus"),
    updataStatus: state.Role.get("UpdataStatus"),
    getAllData: state.Role.get("getAllData"),
    selectData: state.Role.get("selectData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Role);
