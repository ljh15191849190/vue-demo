import React from "react";
import { Row, Col, Card, Tabs } from "antd";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as action from "../../../../actions/ListProjects";
import ColumnLineChart from "../../../commons/ColumnChart/ColumnLineChart";
import ChooseType from "../../../commons/ChooseType/Index";

const TabPane = Tabs.TabPane;

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  getValue() {}

  callback(key) {
    const { actions, projectId } = this.props;
    if (key == 1) {
      actions.getBuildstatement({
        projectId,
        code: 3
      });
    } else if (key == 2) {
      actions.getdeploystatement({
        projectId,
        code: 3
      });
    } else if (key == 3) {
      actions.getcodeCommit({
        projectId,
        code: 3
      });
    }
  }

  // 单选日期
  signDateBuild(type) {
    const { actions, projectId } = this.props;
    actions.getBuildstatement({
      projectId,
      code: type
    });
  }

  signDateDeploy(type) {
    const { actions, projectId } = this.props;
    actions.getdeploystatement({
      projectId,
      code: type
    });
  }

  signDateCommit(type) {
    const { actions, projectId } = this.props;
    actions.getcodeCommit({
      projectId,
      code: type
    });
  }

  componentDidMount() {
    const { actions, projectId } = this.props;
    actions.getBuildstatement({
      projectId,
      code: 3
    });
    actions.getdeploystatement({
      projectId,
      code: 3
    });
    actions.getcodeCommit({
      projectId,
      code: 3
    });
  }

  getEchartData(propsdata, lengend, xA, yA, codetype) {
    if (propsdata && propsdata.length > 0) {
      if (codetype == 1) {
        propsdata[0].time.map(result => {
          xA.push(result.substr(11, 2));
        });
      } else {
        propsdata[0].time.map(result => {
          xA.push(result);
        });
      }
      propsdata.map(item => {
        lengend.push(item.applicationName);
        const obj = {};
        obj.name = item.applicationName;
        obj.type = "bar";
        obj.stack = "haha";
        obj.data = item.counts;
        yA.push(obj);
      });
    } else {
      lengend = [];
      xA = [];
      yA = [];
    }
  }

  render() {
    const { buildData, deployData, commitData, buildcode, deploycode, commitcode } = this.props;

    // 构建
    const buildlegend = [];
    const buildx = [];
    const buildy = [];
    this.getEchartData(buildData, buildlegend, buildx, buildy, buildcode);
    // 部署
    const deploylegend = [];
    const deployx = [];
    const deployy = [];
    this.getEchartData(deployData, deploylegend, deployx, deployy, deploycode);
    // 代码提交树
    const commitlegend = [];
    const commitx = [];
    const commity = [];
    this.getEchartData(commitData, commitlegend, commitx, commity, commitcode);

    return (
      <div>
        <Tabs
          defaultActiveKey="1"
          onChange={this.callback.bind(this)}
          type="card"
          tabPosition="left"
        >
          <TabPane tab="构建时长" key="1">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card
                  title="构建时长"
                  extra={<ChooseType signDate={this.signDateBuild.bind(this)} />}
                >
                  <ColumnLineChart
                    unit="单位/秒"
                    height="60vh"
                    x={buildx}
                    y={buildy}
                    legendData={buildlegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab="部署时长" key="2">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card
                  title="部署时长"
                  extra={<ChooseType signDate={this.signDateDeploy.bind(this)} />}
                >
                  <ColumnLineChart
                    unit="单位/秒"
                    height="60vh"
                    x={deployx}
                    y={deployy}
                    legendData={deploylegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
          <TabPane tab="代码提交次数" key="3">
            <Row>
              <Col xl={24} lg={24} md={24}>
                <Card
                  title="代码提交次数"
                  extra={<ChooseType signDate={this.signDateCommit.bind(this)} />}
                >
                  <ColumnLineChart
                    unit="单位/次"
                    height="60vh"
                    x={commitx}
                    y={commity}
                    legendData={commitlegend}
                    key={Math.random()}
                  />
                </Card>
              </Col>
            </Row>
          </TabPane>
        </Tabs>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    buildData: state.listProjects.get("buildData"),
    deployData: state.listProjects.get("deployData"),
    qualityData: state.listProjects.get("qualityData"),
    commitData: state.listProjects.get("commitData"),

    buildcode: state.listProjects.get("buildcode"),
    deploycode: state.listProjects.get("deploycode"),
    commitcode: state.listProjects.get("commitcode")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Index);
