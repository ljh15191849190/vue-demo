import React from "react";
import ReactDOM from "react-dom";
import { NavLink } from "react-router-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Table, Input, Select, Modal, Button, Form, message, Popconfirm, Row, Col } from "antd";
// import * as action from "../../actions/ProjectList";
import * as projectAction from "../../actions/ListProjects";
import "antd/dist/antd.css";
import { compileStr } from "../../utils/commonFunction";

class ProjectApproval extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      pagination: {},
      loading: false,
      searchItem: {},
      visible: false,
      updatavisible: false,
      confirmLoading: false,
      updataData: {}
    };
    this.columns = [
      {
        title: "项目名称",
        dataIndex: "projectName",
        width: "15%",
        render: (text, record) => {
          const projectId = compileStr(record.projectId.toString());
          const urlLink = `/devops/project/${projectId}/${record.projectName}/${
            record.projectCode
          }`;
          return (
            <div>
              <NavLink to={urlLink} onClick={this.openProject.bind(this, record)}>
                {text}
              </NavLink>
            </div>
          );
        }
      },
      {
        title: "项目编号",
        dataIndex: "projectCode",
        width: "15%",
        render: (text, record) => this.renderColumns(text, record, "projectCode")
      },
      {
        title: "状态",
        dataIndex: "projectStatus",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "projectStatus")
      },
      {
        title: "组件个数",
        dataIndex: "appCount",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "appCount")
      },
      {
        title: "项目经理",
        dataIndex: "projectOwner",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "projectOwner")
      },
      {
        title: "项目描述",
        dataIndex: "projectDesc",
        width: "30%",
        render: (text, record) => this.renderColumns(text, record, "projectDesc")
      },
      {
        title: "创建时间",
        dataIndex: "createTime",
        width: "10%",
        render: (text, record) => this.renderColumns(text, record, "createTime")
      }
    ];
  }

  // 表格展示列数据
  renderColumns(text, record, column) {
    if (column == "projectStatus") {
      return text == "0" ? "未审核" : text == "1" ? "已审核" : "已驳回";
    } else {
      return text;
    }
  }

  // 跳转项目
  openProject(record) {
    const { actions } = this.props;
    // sessionStorage.setItem("projectName", record.projectName);
    actions.updateProjectName(record.projectName);
  }

  // 搜索
  search() {
    const { actions } = this.props;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;
    actions.getAllProjects({
      // userId: 1,
      page: 1,
      searchValue,
      conditions: []
    });
  }

  // 生命周期
  componentWillReceiveProps(nextProps) {
    if (nextProps.pageConfig) {
      this.setState({
        pagination: {
          total: nextProps.pageConfig.total,
          current: nextProps.pageConfig.page,
          pageSize: nextProps.pageConfig.size
        },
        loading: false
      });
    }
  }

  componentDidMount() {
    const { actions } = this.props;
    actions.getAllProjects({
      // userId: 1,
      page: 1,
      searchValue: "",
      conditions: []
    });
  }

  // 分页1
  handlePageChange(pagination, filters, sorter) {
    const { actions } = this.props;
    const searchValue = ReactDOM.findDOMNode(this.refs.projectCode).value;
    this.setState({ loading: true });
    actions.getAllProjects({
      page: pagination.current,
      searchValue
    });
  }

  render() {
    const { resData } = this.props;
    const { pagination, loading } = this.state;
    if (resData.length > 0) {
      resData.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div style={{ backgroundColor: "#fff", padding: 20 }}>
        <div className="searchbar">
          <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
            <Col span={6}>
              <span style={{ marginRight: 10 }}>编号或名称:</span>
              <Input
                placeholder="项目编号或者项目名称"
                style={{ width: "70%" }}
                ref="projectCode"
              />
            </Col>
            <Col span={2} style={{ textAlign: "right" }}>
              <Button type="primary" onClick={this.search.bind(this)} className="padright">
                查询
              </Button>
            </Col>
          </Row>
        </div>
        <div />
        <Table
          bordered
          size="small"
          columns={this.columns}
          dataSource={resData}
          pagination={pagination}
          loading={loading}
          onChange={this.handlePageChange.bind(this)}
        />
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    resData: state.listProjects.get("projects"),
    pageConfig: state.listProjects.get("pageConfig")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(projectAction, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProjectApproval);
