import React from "react";
import { Menu, Dropdown, Icon } from "antd";
import moment from "moment";
import { withRouter } from "react-router";
import { NavLink, Link } from "react-router-dom";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import history from "../../routes/history";
import { Image } from "react-bootstrap";
import * as actionsheader from "../../actions/index";
import * as projectAction from "../../actions/ListProjects";
import "../../assets/css/header.css";
import * as menuAction from "../../actions/systemManageAction";
import { compileStr } from "../../utils/commonFunction";

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: "mail",
      Productvalue: sessionStorage.getItem("projectName")
        ? sessionStorage.getItem("projectName")
        : "项目",
      userInfo: JSON.parse(sessionStorage.getItem("userInfo"))
        ? JSON.parse(sessionStorage.getItem("userInfo"))
        : {}
    };
    this.onLogout = this.onLogout.bind(this);
    this.config = this.config.bind(this);
    this.handleMenuClick = this.handleMenuClick.bind(this);
    this.handleMenuAllClick = this.handleMenuAllClick.bind(this);
  }

  onLogout() {
    const { actions } = this.props;
    localStorage.clear();
    actions.logout();
    // this.props.actions.add(null, null, "");
  }

  config() {
    history.push("/devops/admin");
  }

  componentDidMount() {
    const { actions } = this.props;
    // 菜单显示
    const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
    actions.add(null, { useId: 10 }, "userMenuAll");
    actions.getAllProjects({
      userId: 1,
      page: 1,
      searchValue: "",
      conditions: []
    });
  }

  componentWillReceiveProps(nextProps) {
    const { match } = this.props;
    const urlList = nextProps.location.pathname.split("/");
    let projectId = "";
    let projectName = "";
    let projectBoolen = "";
    for (let i = 0; i < urlList.length; i++) {
      projectId = urlList[i - 2];
      projectBoolen = urlList[i - 3];
      projectName = urlList[i - 1];
    }
    // sessionStorage.setItem("projectKey", JSON.stringify({ key: "project/sub1", openSubKey: "" }));  //设置为空的理由？

    if (projectBoolen === "project") {
      this.setState({
        Productvalue: projectName
      });
    } else if (projectBoolen !== "project" && projectName === "dashboard") {
      this.setState({
        Productvalue: "项目"
      });
      // if (projectName === "dashboard") {
      //   this.setState({
      //     Productvalue: "项目"
      //   });
      // } else if (projectName === "projectAll") {
      //   this.setState({
      //     Productvalue: "查看全部"
      //   });
      // }
    } else if (projectBoolen !== "project" && projectName === "projectAll") {
      this.setState({
        Productvalue: "查看全部"
      });
    }
    const preciousProjectId = match.params.projectId;
    const currentProjectId = nextProps.match.params.projectId;
    if (preciousProjectId === currentProjectId) {
      return;
    }
  }

  handleClick(e) {
    const { shouldFresh } = this.props;
    this.setState({
      current: e.key,
      Productvalue: e.key
    });
    shouldFresh();
  }

  handleMenuClick(p, e) {
    const { actions } = this.props;
    this.setState({
      Productvalue: p.projectName
    });
    sessionStorage.setItem("projectName", p.projectName);
    // get userId/ projectId
    const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));
    actions.add(null, { useId: 10, projectId: p.projectId }, "pjmMenuList");
    // 概览页面
    const mouthstart = `${moment()
      .add("month", 0)
      .format("YYYY-MM")}-01 00:00:00`;

    const mouthend = `${moment(mouthstart)
      .add("month", 1)
      .add("days", -1)
      .format("YYYY-MM-DD")} 23:59:59`;
    const todaystart = `${moment(new Date()).format("YYYY-MM-DD")} 00:00:00`;
    const todayend = `${moment(new Date()).format("YYYY-MM-DD")} 23:59:59`;
    actions.getProjectsOvewview({
      projectId: p.projectId,
      date: todaystart,
      sDate: todayend
    });
    actions.getProjectsbuildtop({
      projectId: p.projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsdeploytop({
      projectId: p.projectId,
      dataJson: {
        type: "self",
        start: mouthstart,
        end: mouthend
      }
    });
    actions.getProjectsRate({ projectId: p.projectId });
  }

  handleMenuAllClick() {
    this.setState({
      Productvalue: "查看全部"
    });
    // sessionStorage.setItem("projectKey", JSON.stringify({ key: "", openSubKey: "" }));
    sessionStorage.setItem("projectKey", JSON.stringify({ key: "project/sub1", openSubKey: "" })); // 再次进入项目时的展示
    sessionStorage.setItem("projectName", "查看全部");
  }

  companyNameLink() {
    sessionStorage.setItem("projectName", "");
    this.setState({
      Productvalue: "项目"
    });
  }

  render() {
    const { current, Productvalue, userInfo } = this.state;
    const { Projects } = this.props;
    const loginuserInfo = JSON.parse(sessionStorage.getItem("userInfo"));
    const userName = loginuserInfo ? (loginuserInfo.userName ? loginuserInfo.userName : "") : "";
    const SystemMenu = (
      <Menu>
        <Menu.Item key="0">
          <span className="logout" onClick={this.onLogout}>
            退出
          </span>
        </Menu.Item>
      </Menu>
    );
    const menu = (
      <Menu selectedKeys={[current]}>
        {Projects.map(p => {
          if (p.projectStatus === 1) {
            const projectIdStr = compileStr(p.projectId.toString());
            return (
              <Menu.Item key={Math.random()}>
                <NavLink
                  to={`/devops/project/${projectIdStr}/${p.projectName}/${p.projectCode}`}
                  onClick={this.handleMenuClick.bind(this, p)}
                >
                  {p.projectName}
                </NavLink>
              </Menu.Item>
            );
          }
        })}
        <Menu.Item>
          <NavLink to="/devops/projectAll" onClick={this.handleMenuAllClick.bind(this)}>
            {"查看全部>>"}
          </NavLink>
        </Menu.Item>
      </Menu>
    );
    return (
      <div className="header-top">
        <div className="header-logo">
          <Link to="/devops/dashboard">
            {/* <span className="logo-title" onClick={this.companyNameLink.bind(this)}>
              西安华信DevOps平台
            </span> */}
            <img src="/images/dashboard/logo.png" className="logo-title" alt="logo" />
          </Link>
          <div className="navul">
            <Dropdown overlay={menu}>
              <a className="ant-dropdown-link menu-title" href="#">
                {/* {intl.get("main.topBar.project")} */}
                <span className="pj_icon" />
                <span className="pj_name">
                  {Productvalue
                    ? Productvalue
                    : sessionStorage.getItem("projectName")
                    ? sessionStorage.getItem("projectName")
                    : "项目"}
                </span>
                <Icon type="down" />
              </a>
            </Dropdown>
          </div>
        </div>

        <div className="dropmeau">
          {userInfo.managerFlag && userInfo.managerFlag === true ? (
            <span style={{ cursor: "pointer" }}>
              <span>
                <Icon
                  type="setting"
                  onClick={this.config}
                  style={{ fontSize: 20, marginRight: 29, color: "#93a1c6" }}
                />
              </span>
            </span>
          ) : (
            ""
          )}
          <span className="spliter" />
          <ol>
            <li>
              <span className="dropli">
                <Image src="/images/dashboard/people.png" circle />
                <span className="dropli-userName">{userName}</span>

                <Dropdown overlay={SystemMenu}>
                  <Icon type="down" className="dropli-iconStyle" />
                </Dropdown>
              </span>
            </li>
          </ol>
        </div>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    userInfo: state.login.get("userInfo"),
    Logout: state.login,
    Projects: state.listProjects.get("projects"),
    projectName: state.login.get("projectName")
  };
};
const mapDispatchToProps = dispatch => {
  return {
    actions: bindActionCreators(
      Object.assign({}, actionsheader, projectAction, menuAction),
      dispatch
    )
  };
};

export default withRouter(
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(Header)
);
