// 动态数据 + 时间坐标轴;

import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
import * as action from "../../actions/maitananceManageAction";

const echarts = require("echarts");

class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }

  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    function randomData() {
      var test_now1 = +now;
      console.log("now---", now, test_now1);
      if (test_now1 === 876931200000) {
        // 到达指定时间时，数据设为初始值
        now = new Date(1997, 9, 3);
        // data = [];
        // 放置五个值？？？
        // for (var i = 0; i < 5; i++) {
        //   data.push(randomData());
        // }
        // value = value + Math.random() * 21 - 10; // y轴的随机值
        // return {
        //   name: now.toString(),
        //   value: [
        //     [now.getFullYear(), now.getMonth() + 1, now.getDate()].join("/"),
        //     Math.round(value)
        //   ]
        // }; // y轴的显示值

        console.log("now-00", data, now);
      } else {
        now = new Date(+now + oneDay);

        console.log("now-111", data, now);
      }
      // console.log("now00000000---", now);
      value = value + Math.random() * 21 - 10; // y轴的随机值
      console.log("now___11", now.toString());
      return {
        name: now.toString(),
        value: [[now.getFullYear(), now.getMonth() + 1, now.getDate()].join("/"), Math.round(value)]
      }; // y轴的显示值
    }

    var data = [];
    var now = +new Date(1997, 9, 3);

    var oneDay = 24 * 3600 * 1000;
    var value = Math.random() * 1000;
    // 此处for循环设置x轴坐标值的个数 ---i的最大值就是x轴的个数
    for (let i = 0; i < 5; i++) {
      data.push(randomData());
    }

    myChart.setOption({
      title: {
        text: "动态数据 + 时间坐标轴"
      },
      tooltip: {
        trigger: "axis",
        formatter: function(params) {
          params = params[0];
          var date = new Date(params.name);
          return (
            date.getDate() +
            "/" +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear() +
            " : " +
            params.value[1]
          );
        },
        axisPointer: {
          animation: false
        }
      },
      xAxis: {
        type: "time",
        splitLine: {
          show: false
        }
      },
      yAxis: {
        type: "value",
        boundaryGap: [0, "100%"],
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: "模拟数据",
          type: "line",
          showSymbol: false,
          hoverAnimation: false,
          data: data
        }
      ]
    });
    this.timer = setInterval(function() {
      // for (var i = 0; i < 1; i++) {
      data.shift();
      // const testDATA = randomData();
      // console.log("randomData", testDATA);
      data.push(randomData());
      console.log("testDATA", data);
      // }
      myChart.setOption({
        series: [
          {
            data: data
          }
        ]
      });
    }, 3000);
  }

  componentDidUpdate() {
    console.log("componentDidUpdate");
    this.queryData();
  }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
    // 调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    // this.props.actions.sceneEvaluateRate(this.state.queryParam);
    // let visualMonitorListCPU = this.props.visualMonitorListDataCPU.get("visualMonitorListCPU");
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    console.log("echarts");
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        <Row span={12}>
          <div
            id="myChart"
            ref="lineChart"
            style={{ width: "805px", height: "580px" }}
            // backgroundColor: "#24397e"
          />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    // visualMonitorListDataCPU: state.MaitananceManage.get("visualMonitorListDataCPU"),
    // visualMonitorListDataMEM: state.MaitananceManage.get("visualMonitorListDataMEM"),
    // caasPodsInfoMonitorListData: state.MaitananceManage.get("caasPodsInfoMonitorListData"),
    // caasServicesMetricsListData: state.MaitananceManage.get("caasServicesMetricsListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
