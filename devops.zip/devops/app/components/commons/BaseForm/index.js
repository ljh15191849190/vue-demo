import React from "react";
import { Input, Select, Form, Button, Col, Row } from "antd";
const FormItem = Form.Item;
const Option = Select.Option;

class FilterForm extends React.Component {
  handleFilterSubmit() {
    let fieldsValue = this.props.form.getFieldsValue();
    this.props.filterSubmit(fieldsValue);
  }
  showModalMeth() {
    this.props.showModal();
  }

  initFormList() {
    const { getFieldDecorator } = this.props.form;
    const formList = this.props.formList;
    const formItemList = [];
    if (formList && formList.length > 0) {
      formList.forEach((item, i) => {
        let label = item.label;
        let field = item.field;
        let initialValue = item.initialValue || "";
        let placeholder = item.placeholder;
        let width = item.width;
        if (item.type == "INPUT") {
          const INPUT = (
            <FormItem label={label} key={field}>
              {getFieldDecorator(field, {
                initialValue: initialValue
              })(
                <Input
                  placeholder={placeholder}
                  style={{ width: width, marginRight: 20 }}
                  type="text"
                />
              )}
            </FormItem>
          );
          formItemList.push(INPUT);
        } else if (item.type == "SELECT") {
          const SELECT = (
            <FormItem label={label} key={field}>
              {getFieldDecorator(field, {
                initialValue: initialValue
              })(
                <Select placeholder={placeholder} style={{ width: width, marginRight: 20 }}>
                  {item.list
                    ? item.list.map(v => {
                        return (
                          <Option value={v.id} key={v.value}>
                            {v.value}
                          </Option>
                        );
                      })
                    : ""}
                </Select>
              )}
            </FormItem>
          );
          formItemList.push(SELECT);
        }
      });
    }
    return formItemList;
  }
  render() {
    return (
      <Form layout="inline">
        <Row style={{ marginTop: "10px", padding: "0 20px" }} type="flex">
          <Col span={19}>{this.initFormList()}</Col>
          <Col span={5} style={{ textAlign: "right" }}>
            <span>
              <Button
                type="primary"
                style={{ margin: "5px 20px" }}
                onClick={this.handleFilterSubmit.bind(this)}
              >
                查询
              </Button>
              {this.props.showModal ? (
                <Button
                  type="primary"
                  style={{ margin: "5px 20px" }}
                  onClick={this.showModalMeth.bind(this)}
                >
                  新增
                </Button>
              ) : (
                ""
              )}
            </span>
          </Col>
        </Row>
      </Form>
    );
  }
}
export default Form.create({})(FilterForm);

// //雷子
// const formList = [
//   {
//     type: "INPUT",
//     label: "海慧寺",
//     field: "name",
//     placeholder: "全部",
//     initialValue: "",
//     width: 200
//   },
//   {
//     type: "SELECT",
//     label: "城市",
//     field: "city",
//     placeholder: "全部",
//     width: 200,
//     list: [
//       { id: "ww", value: "全部" },
//       { id: "ss", value: "北京" },
//       { id: "dd", value: "天津" },
//       { id: "ff", value: "上海" }
//     ]
//   },
//   {
//     type: "SELECT",
//     label: "订单状态",
//     field: "order_status",
//     placeholder: "全部",
//     width: 200,
//     list: [
//       { id: "ee", value: "全部" },
//       { id: "rr", value: "进行中" },
//       { id: "g", value: "结束行程" }
//     ]
//   }
// ];

//   //查询
//   handleFilter(params) {
//     this.params = params;
//     console.log(this.params);
//     // this.requestList();
//   }
//    //组件
// <BaseForm
//   formList={formList}
//   filterSubmit={this.handleFilter.bind(this)}
//   showModal={this.showModal.bind(this)}
// />;
