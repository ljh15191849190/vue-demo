//按钮权限用的 按钮组件（封装用）
/*
用法：
  导入Button组件（import Button）
  删掉ant里面的Button组件
  改变页面组件重要属性有 value（按钮名称）、readyOnly（是否显示）、type（按钮样式类型） onClick（点击事件）
*/
import React from "react";
import { Button } from "antd";

export default class FormButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  onClick() {
    const { onClick } = this.props;
    onClick();
  }

  render() {
    const { readyOnly, size, loading, icon, disabled, type, value } = this.props;
    return (
      <span>
        {readyOnly == 0 ? (
          ""
        ) : (
          <Button
            style={{ marginLeft: 10 }}
            type={type ? type : ""}
            disabled={disabled ? disabled : false}
            size={size ? size : "default"}
            loading={loading ? loading : false}
            icon={icon ? icon : ""}
            onClick={() => this.onClick()}
          >
            {value}
          </Button>
        )}
      </span>
    );
  }
}
