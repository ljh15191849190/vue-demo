export const tableData = [
  {
    line: 1,
    code: '<span class="k">package</span> com.hxzh.build.db;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 2,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 3,
    code:
      '<span class="k">import</span> com.alibaba.fastjson.annotation.<span class="sym-1 sym">JSONField</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 4,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 5,
    code: '<span class="k">import</span> javax.persistence.*;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 6,
    code: '<span class="k">import</span> java.io.<span class="sym-2 sym">Serializable</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 7,
    code: '<span class="k">import</span> java.math.<span class="sym-3 sym">BigDecimal</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 8,
    code: '<span class="k">import</span> java.sql.<span class="sym-4 sym">Date</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 9,
    code: '<span class="k">import</span> java.sql.<span class="sym-5 sym">Timestamp</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 10,
    code: '<span class="k">import</span> java.util.<span class="sym-6 sym">List</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 11,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 12,
    code: '<span class="j">/**</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 13,
    code: '<span class="j"> *构建定义</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 14,
    code: '<span class="j"> */</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 15,
    code: '<span class="a">@Entity</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 16,
    code: '<span class="a">@Table</span>(name = <span class="s">"devops_build_definition"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 17,
    code:
      '<span class="k">public</span> <span class="k">class</span> <span class="sym-7 sym">DpsBuildDefinition</span>  <span class="k">implements</span> <span class="sym-2 sym">Serializable</span>, Cloneable{',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 18,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 19,
    code: '    <span class="j">/**</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 20,
    code: '<span class="j">     * CREATE TABLE `devops_build_definition` (</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: true
  },
  {
    line: 21,
    code: '<span class="j">     *   `id` int(11) NOT NULL AUTO_INCREMENT,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 22,
    code: '<span class="j">     *   version_id varchar(64) not null,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 23,
    code: '<span class="j">     *   `definition_id` bigint(20) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 24,
    code: '<span class="j">     *   `pipeline_tp_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 25,
    code: '<span class="j">     *   `definition_name` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 26,
    code: '<span class="j">     *   `branch_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 27,
    code: '<span class="j">     *   `pipelime_tp_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 28,
    code: '<span class="j">     *   `pipeline_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 29,
    code: '<span class="j">     *   `project_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 30,
    code: '<span class="j">     *   `enging_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 31,
    code: '<span class="j">     *   `priority` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 32,
    code: '<span class="j">     *   `definition_desc` varchar(256) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 33,
    code: '<span class="j">     *   `trigger_type` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 34,
    code: '<span class="j">     *   `trigger_regex` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 35,
    code: '<span class="j">     *   `retention` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 36,
    code: '<span class="j">     *   `variable_define` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 37,
    code: '<span class="j">     *   `notification_regex` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 38,
    code: '<span class="j">     *   `build_number_format` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 39,
    code: '<span class="j">     *   `timeout_scope` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 40,
    code: '<span class="j">     *   `building` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 41,
    code: '<span class="j">     *   `expect_duration_time` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 42,
    code: '<span class="j">     *   `last_build_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 43,
    code: '<span class="j">     *   `last_successful` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 44,
    code: '<span class="j">     *   `last_failed` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 45,
    code: '<span class="j">     *   `last_duration_time` datetime DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 46,
    code: '<span class="j">     *   `total_successful` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 47,
    code: '<span class="j">     *   `total_failed` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 48,
    code: '<span class="j">     *   `total_recovery` decimal(8,2) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 49,
    code: '<span class="j">     *   `average_duration_time` datetime DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 50,
    code: '<span class="j">     *   `average_recovery` decimal(8,2) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 51,
    code: '<span class="j">     *   `repository` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 52,
    code: '<span class="j">     *   `tag` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 53,
    code: '<span class="j">     *   `status` int(11) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 54,
    code: '<span class="j">     *   `create_user` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 55,
    code: '<span class="j">     *   `create_time` datetime DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 56,
    code: '<span class="j">     *   `update_time` datetime DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 57,
    code: '<span class="j">     *   `update_user` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 58,
    code: '<span class="j">     *   `tenant_id` varchar(64) DEFAULT NULL,</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 59,
    code: '<span class="j">     *   PRIMARY KEY (`id`)</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 60,
    code:
      "<span class=\"j\">     * ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='构建定义';</span>",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 61,
    code: '<span class="j">     */</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 62,
    code: '    <span class="cd">/*物理主键*/</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 63,
    code: '    <span class="a">@Id</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 64,
    code: '    <span class="a">@GeneratedValue</span>(strategy = GenerationType.IDENTITY)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 65,
    code: '    <span class="k">private</span> Integer <span class="sym-8 sym">id</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 66,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 67,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"definition_id"</span>, unique = <span class="k">true</span>, nullable = <span class="k">false</span>, updatable = <span class="k">false</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 68,
    code: '    <span class="k">private</span> Long <span class="sym-9 sym">definitionId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 69,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 70,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"definition_name"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 71,
    code:
      '    <span class="k">private</span> String <span class="sym-10 sym">definitionName</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 72,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 73,
    code: '    <span class="a">@Column</span>(name = <span class="s">"version_id"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 74,
    code: '    <span class="k">private</span> String <span class="sym-11 sym">versionId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 75,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 76,
    code: '    <span class="a">@Column</span>(name = <span class="s">"application_name"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 77,
    code:
      '    <span class="k">private</span> String <span class="sym-12 sym">applicationName</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 78,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 79,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"pipeline_tp_id"</span>, length = <span class="c">64</span>, nullable = <span class="k">false</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 80,
    code: '    <span class="k">private</span> String <span class="sym-13 sym">pLineTpId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 81,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 82,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"branch_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 83,
    code: '    <span class="k">private</span> String <span class="sym-14 sym">branchId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 84,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 85,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"pipeline_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 86,
    code: '    <span class="k">private</span> String <span class="sym-15 sym">pLineId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 87,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 88,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"project_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 89,
    code: '    <span class="k">private</span> String <span class="sym-16 sym">projectId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 90,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 91,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"enging_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 92,
    code: '    <span class="k">private</span> String <span class="sym-17 sym">engingId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 93,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 94,
    code: '    <span class="a">@Column</span>(name = <span class="s">"priority"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 95,
    code:
      '    <span class="k">private</span> <span class="k">int</span> <span class="sym-18 sym">priority</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 96,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 97,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"definition_desc"</span>, length = <span class="c">256</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 98,
    code:
      '    <span class="k">private</span> String <span class="sym-19 sym">definitionDesc</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 99,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 100,
    code: '    <span class="a">@Column</span>(name = <span class="s">"trigger_type"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 101,
    code:
      '    <span class="k">private</span> <span class="k">int</span> <span class="sym-20 sym">triggerType</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 102,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 103,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"trigger_regex"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 104,
    code: '    <span class="k">private</span> String <span class="sym-21 sym">triggerRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 105,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 106,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"retention"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 107,
    code: '    <span class="k">private</span> String <span class="sym-22 sym">retention</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 108,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 109,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"variable_define"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 110,
    code:
      '    <span class="k">private</span> String <span class="sym-23 sym">variableDefine</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 111,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 112,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"notification_type"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 113,
    code:
      '    <span class="k">private</span> String <span class="sym-24 sym">notificationType</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 114,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 115,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"notification_regex"</span>, length = <span class="c">256</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 116,
    code:
      '    <span class="k">private</span> String <span class="sym-25 sym">notificationRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 117,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 118,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"build_number_format"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 119,
    code:
      '    <span class="k">private</span> String <span class="sym-26 sym">buildNumberFormat</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 120,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 121,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"timeout_scope"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 122,
    code: '    <span class="k">private</span> String <span class="sym-27 sym">timeOutScope</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 123,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 124,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"building"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 125,
    code: '    <span class="k">private</span> String <span class="sym-28 sym">building</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 126,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 127,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"expect_duration_time"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 128,
    code:
      '    <span class="k">private</span> <span class="k">int</span> <span class="sym-29 sym">expectDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 129,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 130,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"last_build_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 131,
    code: '    <span class="k">private</span> String <span class="sym-30 sym">lastBuildId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 132,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 133,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"last_successful"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 134,
    code:
      '    <span class="k">private</span> String <span class="sym-31 sym">lastSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 135,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 136,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"last_failed"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 137,
    code: '    <span class="k">private</span> String <span class="sym-32 sym">lastFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 138,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 139,
    code: '    <span class="a">@Column</span>(name = <span class="s">"last_duration_time"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 140,
    code:
      '    <span class="k">private</span> <span class="sym-4 sym">Date</span> <span class="sym-33 sym">lastDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 141,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 142,
    code: '    <span class="a">@Column</span>(name = <span class="s">"total_successful"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 143,
    code:
      '    <span class="k">private</span> <span class="k">int</span> <span class="sym-34 sym">totalSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 144,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 145,
    code: '    <span class="a">@Column</span>(name = <span class="s">"total_failed"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 146,
    code:
      '    <span class="k">private</span> <span class="k">int</span> <span class="sym-35 sym">totalFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 147,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 148,
    code: '    <span class="a">@Column</span>(name = <span class="s">"total_recovery"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 149,
    code:
      '    <span class="k">private</span> <span class="sym-3 sym">BigDecimal</span> <span class="sym-36 sym">totalRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 150,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 151,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"average_duration_time"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 152,
    code:
      '    <span class="k">private</span> <span class="sym-4 sym">Date</span> <span class="sym-37 sym">avgDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 153,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 154,
    code: '    <span class="a">@Column</span>(name = <span class="s">"average_recovery"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 155,
    code:
      '    <span class="k">private</span> <span class="sym-3 sym">BigDecimal</span> <span class="sym-38 sym">avgRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 156,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 157,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"repository"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 158,
    code: '    <span class="k">private</span> String <span class="sym-39 sym">repository</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 159,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 160,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"tag"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 161,
    code: '    <span class="k">private</span> String <span class="sym-40 sym">tag</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 162,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 163,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"status"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 164,
    code: '    <span class="k">private</span> String <span class="sym-41 sym">status</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 165,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 166,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"create_user"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 167,
    code: '    <span class="k">private</span> String <span class="sym-42 sym">createUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 168,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 169,
    code: '    <span class="a">@Column</span>(name = <span class="s">"create_time"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 170,
    code:
      '    <span class="k">private</span> <span class="sym-5 sym">Timestamp</span> <span class="sym-43 sym">createTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 171,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 172,
    code: '    <span class="a">@Column</span>(name = <span class="s">"update_time"</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 173,
    code:
      '    <span class="k">private</span> <span class="sym-5 sym">Timestamp</span> <span class="sym-44 sym">updateTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 174,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 175,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"update_user"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 176,
    code: '    <span class="k">private</span> String <span class="sym-45 sym">updateUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 177,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 178,
    code:
      '    <span class="a">@Column</span>(name = <span class="s">"tenant_id"</span>, length = <span class="c">64</span>)',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 179,
    code: '    <span class="k">private</span> String <span class="sym-46 sym">tenantId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 180,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 181,
    code:
      '<span class="cd">//    @OneToMany(cascade = CascadeType.ALL, mappedBy = "dpsBuildDefinition", fetch = FetchType.EAGER)</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 182,
    code: '<span class="cd">//    @JSONField(serialize = false)</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 183,
    code:
      '<span class="cd">//    private List&lt;DpsBuildInstance&gt; dpsBuildInstanceList;</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 184,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 185,
    code: '    <span class="k">public</span> Integer <span class="sym-47 sym">getId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 186,
    code: '        <span class="k">return</span> <span class="sym-8 sym">id</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 187,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 188,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 189,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-48 sym">setId</span>(Integer <span class="sym-49 sym">id</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 190,
    code:
      '        <span class="k">this</span>.<span class="sym-8 sym">id</span> = <span class="sym-49 sym">id</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 191,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 192,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 193,
    code:
      '    <span class="k">public</span> Long <span class="sym-50 sym">getDefinitionId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 194,
    code: '        <span class="k">return</span> <span class="sym-9 sym">definitionId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 195,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 196,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 197,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-51 sym">setDefinitionId</span>(Long <span class="sym-52 sym">definitionId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 198,
    code:
      '        <span class="k">this</span>.<span class="sym-9 sym">definitionId</span> = <span class="sym-52 sym">definitionId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 199,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 200,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 201,
    code:
      '    <span class="k">public</span> String <span class="sym-53 sym">getApplicationName</span>() { <span class="k">return</span> <span class="sym-12 sym">applicationName</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 202,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 203,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-54 sym">setApplicationName</span>(String <span class="sym-55 sym">applicationName</span>) { <span class="k">this</span>.<span class="sym-12 sym">applicationName</span> = <span class="sym-55 sym">applicationName</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 204,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 205,
    code:
      '    <span class="k">public</span> String <span class="sym-56 sym">getVersionId</span>() { <span class="k">return</span> <span class="sym-11 sym">versionId</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 206,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 207,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-57 sym">setVersionId</span>(String <span class="sym-58 sym">versionId</span>) { <span class="k">this</span>.<span class="sym-11 sym">versionId</span> = <span class="sym-58 sym">versionId</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 208,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 209,
    code:
      '    <span class="k">public</span> String <span class="sym-59 sym">getpLineTpId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 210,
    code: '        <span class="k">return</span> <span class="sym-13 sym">pLineTpId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 211,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 212,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 213,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-60 sym">setpLineTpId</span>(String <span class="sym-61 sym">pLineTpId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 214,
    code:
      '        <span class="k">this</span>.<span class="sym-13 sym">pLineTpId</span> = <span class="sym-61 sym">pLineTpId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 215,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 216,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 217,
    code:
      '    <span class="k">public</span> String <span class="sym-62 sym">getDefinitionName</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 218,
    code: '        <span class="k">return</span> <span class="sym-10 sym">definitionName</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 219,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 220,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 221,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-63 sym">setDefinitionName</span>(String <span class="sym-64 sym">definitionName</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 222,
    code:
      '        <span class="k">this</span>.<span class="sym-10 sym">definitionName</span> = <span class="sym-64 sym">definitionName</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 223,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 224,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 225,
    code:
      '    <span class="k">public</span> String <span class="sym-65 sym">getBranchId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 226,
    code: '        <span class="k">return</span> <span class="sym-14 sym">branchId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 227,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 228,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 229,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-66 sym">setBranchId</span>(String <span class="sym-67 sym">branchId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 230,
    code:
      '        <span class="k">this</span>.<span class="sym-14 sym">branchId</span> = <span class="sym-67 sym">branchId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 231,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 232,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 233,
    code: '    <span class="k">public</span> String <span class="sym-68 sym">getpLineId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 234,
    code: '        <span class="k">return</span> <span class="sym-15 sym">pLineId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 235,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 236,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 237,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-69 sym">setpLineId</span>(String <span class="sym-70 sym">pLineId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 238,
    code:
      '        <span class="k">this</span>.<span class="sym-15 sym">pLineId</span> = <span class="sym-70 sym">pLineId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 239,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 240,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 241,
    code:
      '    <span class="k">public</span> String <span class="sym-71 sym">getProjectId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 242,
    code: '        <span class="k">return</span> <span class="sym-16 sym">projectId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 243,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 244,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 245,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-72 sym">setProjectId</span>(String <span class="sym-73 sym">projectId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 246,
    code:
      '        <span class="k">this</span>.<span class="sym-16 sym">projectId</span> = <span class="sym-73 sym">projectId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 247,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 248,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 249,
    code:
      '    <span class="k">public</span> String <span class="sym-74 sym">getEngingId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 250,
    code: '        <span class="k">return</span> <span class="sym-17 sym">engingId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 251,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 252,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 253,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-75 sym">setEngingId</span>(String <span class="sym-76 sym">engingId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 254,
    code:
      '        <span class="k">this</span>.<span class="sym-17 sym">engingId</span> = <span class="sym-76 sym">engingId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 255,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 256,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 257,
    code:
      '    <span class="k">public</span> <span class="k">int</span> <span class="sym-77 sym">getPriority</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 258,
    code: '        <span class="k">return</span> <span class="sym-18 sym">priority</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 259,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 260,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 261,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-78 sym">setPriority</span>(<span class="k">int</span> <span class="sym-79 sym">priority</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 262,
    code:
      '        <span class="k">this</span>.<span class="sym-18 sym">priority</span> = <span class="sym-79 sym">priority</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 263,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 264,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 265,
    code:
      '    <span class="k">public</span> String <span class="sym-80 sym">getDefinitionDesc</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 266,
    code: '        <span class="k">return</span> <span class="sym-19 sym">definitionDesc</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 267,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 268,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 269,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-81 sym">setDefinitionDesc</span>(String <span class="sym-82 sym">definitionDesc</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 270,
    code:
      '        <span class="k">this</span>.<span class="sym-19 sym">definitionDesc</span> = <span class="sym-82 sym">definitionDesc</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 271,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 272,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 273,
    code:
      '    <span class="k">public</span> <span class="k">int</span> <span class="sym-83 sym">getTriggerType</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 274,
    code: '        <span class="k">return</span> <span class="sym-20 sym">triggerType</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 275,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 276,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 277,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-84 sym">setTriggerType</span>(<span class="k">int</span> <span class="sym-85 sym">triggerType</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 278,
    code:
      '        <span class="k">this</span>.<span class="sym-20 sym">triggerType</span> = <span class="sym-85 sym">triggerType</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 279,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 280,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 281,
    code:
      '    <span class="k">public</span> String <span class="sym-86 sym">getTriggerRegex</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 282,
    code: '        <span class="k">return</span> <span class="sym-21 sym">triggerRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 283,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 284,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 285,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-87 sym">setTriggerRegex</span>(String <span class="sym-88 sym">triggerRegex</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 286,
    code:
      '        <span class="k">this</span>.<span class="sym-21 sym">triggerRegex</span> = <span class="sym-88 sym">triggerRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 287,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 288,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 289,
    code:
      '    <span class="k">public</span> String <span class="sym-89 sym">getRetention</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 290,
    code: '        <span class="k">return</span> <span class="sym-22 sym">retention</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 291,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 292,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 293,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-90 sym">setRetention</span>(String <span class="sym-91 sym">retention</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 294,
    code:
      '        <span class="k">this</span>.<span class="sym-22 sym">retention</span> = <span class="sym-91 sym">retention</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 295,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 296,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 297,
    code:
      '    <span class="k">public</span> String <span class="sym-92 sym">getVariableDefine</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 298,
    code: '        <span class="k">return</span> <span class="sym-23 sym">variableDefine</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 299,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 300,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 301,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-93 sym">setVariableDefaine</span>(String <span class="sym-94 sym">variableDefaine</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 302,
    code:
      '        <span class="k">this</span>.<span class="sym-23 sym">variableDefine</span> = <span class="sym-23 sym">variableDefine</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 303,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 304,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 305,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-95 sym">setVariableDefine</span>(String <span class="sym-96 sym">variableDefine</span>) { <span class="k">this</span>.<span class="sym-23 sym">variableDefine</span> = <span class="sym-96 sym">variableDefine</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 306,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 307,
    code:
      '    <span class="k">public</span> String <span class="sym-97 sym">getNotificationType</span>() { <span class="k">return</span> <span class="sym-24 sym">notificationType</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 308,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 309,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-98 sym">setNotificationType</span>(String <span class="sym-99 sym">notificationType</span>) { <span class="k">this</span>.<span class="sym-24 sym">notificationType</span> = <span class="sym-99 sym">notificationType</span>; }',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 310,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 311,
    code:
      '    <span class="k">public</span> String <span class="sym-100 sym">getNotificationRegex</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 312,
    code:
      '        <span class="k">return</span> <span class="sym-25 sym">notificationRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 313,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 314,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 315,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-101 sym">setNotificationRegex</span>(String <span class="sym-102 sym">notificationRegex</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 316,
    code:
      '        <span class="k">this</span>.<span class="sym-25 sym">notificationRegex</span> = <span class="sym-102 sym">notificationRegex</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 317,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 318,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 319,
    code:
      '    <span class="k">public</span> String <span class="sym-103 sym">getBuildNumberFormat</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 320,
    code:
      '        <span class="k">return</span> <span class="sym-26 sym">buildNumberFormat</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 321,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 322,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 323,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-104 sym">setBuildNumberFormat</span>(String <span class="sym-105 sym">buildNumberFormat</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 324,
    code:
      '        <span class="k">this</span>.<span class="sym-26 sym">buildNumberFormat</span> = <span class="sym-105 sym">buildNumberFormat</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 325,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 326,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 327,
    code:
      '    <span class="k">public</span> String <span class="sym-106 sym">getTimeOutScope</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 328,
    code: '        <span class="k">return</span> <span class="sym-27 sym">timeOutScope</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 329,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 330,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 331,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-107 sym">setTimeOutScope</span>(String <span class="sym-108 sym">timeOutScope</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 332,
    code:
      '        <span class="k">this</span>.<span class="sym-27 sym">timeOutScope</span> = <span class="sym-108 sym">timeOutScope</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 333,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 334,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 335,
    code:
      '    <span class="k">public</span> String <span class="sym-109 sym">getBuilding</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 336,
    code: '        <span class="k">return</span> <span class="sym-28 sym">building</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 337,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 338,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 339,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-110 sym">setBuilding</span>(String <span class="sym-111 sym">building</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 340,
    code:
      '        <span class="k">this</span>.<span class="sym-28 sym">building</span> = <span class="sym-111 sym">building</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 341,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 342,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 343,
    code:
      '    <span class="k">public</span> <span class="k">int</span> <span class="sym-112 sym">getExpectDurationTime</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 344,
    code:
      '        <span class="k">return</span> <span class="sym-29 sym">expectDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 345,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 346,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 347,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-113 sym">setExpectDurationTime</span>(<span class="k">int</span> <span class="sym-114 sym">expectDurationTime</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 348,
    code:
      '        <span class="k">this</span>.<span class="sym-29 sym">expectDurationTime</span> = <span class="sym-114 sym">expectDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 349,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 350,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 351,
    code:
      '    <span class="k">public</span> String <span class="sym-115 sym">getLastBuildId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 352,
    code: '        <span class="k">return</span> <span class="sym-30 sym">lastBuildId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 353,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 354,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 355,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-116 sym">setLastBuildId</span>(String <span class="sym-117 sym">lastBuildId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 356,
    code:
      '        <span class="k">this</span>.<span class="sym-30 sym">lastBuildId</span> = <span class="sym-117 sym">lastBuildId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 357,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 358,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 359,
    code:
      '    <span class="k">public</span> String <span class="sym-118 sym">getLastSuccessful</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 360,
    code: '        <span class="k">return</span> <span class="sym-31 sym">lastSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 361,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 362,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 363,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-119 sym">setLastSuccessful</span>(String <span class="sym-120 sym">lastSuccessful</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 364,
    code:
      '        <span class="k">this</span>.<span class="sym-31 sym">lastSuccessful</span> = <span class="sym-120 sym">lastSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 365,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 366,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 367,
    code:
      '    <span class="k">public</span> String <span class="sym-121 sym">getLastFailed</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 368,
    code: '        <span class="k">return</span> <span class="sym-32 sym">lastFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 369,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 370,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 371,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-122 sym">setLastFailed</span>(String <span class="sym-123 sym">lastFailed</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 372,
    code:
      '        <span class="k">this</span>.<span class="sym-32 sym">lastFailed</span> = <span class="sym-123 sym">lastFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 373,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 374,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 375,
    code:
      '    <span class="k">public</span> <span class="sym-4 sym">Date</span> <span class="sym-124 sym">getLastDurationTime</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 376,
    code: '        <span class="k">return</span> <span class="sym-33 sym">lastDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 377,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 378,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 379,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-125 sym">setLastDurationTime</span>(<span class="sym-4 sym">Date</span> <span class="sym-126 sym">lastDurationTime</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 380,
    code:
      '        <span class="k">this</span>.<span class="sym-33 sym">lastDurationTime</span> = <span class="sym-126 sym">lastDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 381,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 382,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 383,
    code:
      '    <span class="k">public</span> <span class="k">int</span> <span class="sym-127 sym">getTotalSuccessful</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 384,
    code: '        <span class="k">return</span> <span class="sym-34 sym">totalSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 385,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 386,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 387,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-128 sym">setTotalSuccessful</span>(<span class="k">int</span> <span class="sym-129 sym">totalSuccessful</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 388,
    code:
      '        <span class="k">this</span>.<span class="sym-34 sym">totalSuccessful</span> = <span class="sym-129 sym">totalSuccessful</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 389,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 390,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 391,
    code:
      '    <span class="k">public</span> <span class="k">int</span> <span class="sym-130 sym">getTotalFailed</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 392,
    code: '        <span class="k">return</span> <span class="sym-35 sym">totalFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 393,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 394,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 395,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-131 sym">setTotalFailed</span>(<span class="k">int</span> <span class="sym-132 sym">totalFailed</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 396,
    code:
      '        <span class="k">this</span>.<span class="sym-35 sym">totalFailed</span> = <span class="sym-132 sym">totalFailed</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 397,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 398,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 399,
    code:
      '    <span class="k">public</span> <span class="sym-3 sym">BigDecimal</span> <span class="sym-133 sym">getTotalRecovery</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 400,
    code: '        <span class="k">return</span> <span class="sym-36 sym">totalRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 401,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 402,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 403,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-134 sym">setTotalRecovery</span>(<span class="sym-3 sym">BigDecimal</span> <span class="sym-135 sym">totalRecovery</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 404,
    code:
      '        <span class="k">this</span>.<span class="sym-36 sym">totalRecovery</span> = <span class="sym-135 sym">totalRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 405,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 406,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 407,
    code:
      '    <span class="k">public</span> <span class="sym-4 sym">Date</span> <span class="sym-136 sym">getAvgDurationTime</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 408,
    code: '        <span class="k">return</span> <span class="sym-37 sym">avgDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 409,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 410,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 411,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-137 sym">setAvgDurationTime</span>(<span class="sym-4 sym">Date</span> <span class="sym-138 sym">avgDurationTime</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 412,
    code:
      '        <span class="k">this</span>.<span class="sym-37 sym">avgDurationTime</span> = <span class="sym-138 sym">avgDurationTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 413,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 414,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 415,
    code:
      '    <span class="k">public</span> <span class="sym-3 sym">BigDecimal</span> <span class="sym-139 sym">getAvgRecovery</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 416,
    code: '        <span class="k">return</span> <span class="sym-38 sym">avgRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 417,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 418,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 419,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-140 sym">setAvgRecovery</span>(<span class="sym-3 sym">BigDecimal</span> <span class="sym-141 sym">avgRecovery</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 420,
    code:
      '        <span class="k">this</span>.<span class="sym-38 sym">avgRecovery</span> = <span class="sym-141 sym">avgRecovery</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 421,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 422,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 423,
    code:
      '    <span class="k">public</span> String <span class="sym-142 sym">getRepository</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 424,
    code: '        <span class="k">return</span> <span class="sym-39 sym">repository</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 425,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 426,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 427,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-143 sym">setRepository</span>(String <span class="sym-144 sym">repository</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 428,
    code:
      '        <span class="k">this</span>.<span class="sym-39 sym">repository</span> = <span class="sym-144 sym">repository</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 429,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 430,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 431,
    code: '    <span class="k">public</span> String <span class="sym-145 sym">getTag</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 432,
    code: '        <span class="k">return</span> <span class="sym-40 sym">tag</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 433,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 434,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 435,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-146 sym">setTag</span>(String <span class="sym-147 sym">tag</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 436,
    code:
      '        <span class="k">this</span>.<span class="sym-40 sym">tag</span> = <span class="sym-147 sym">tag</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 437,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 438,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 439,
    code: '    <span class="k">public</span> String <span class="sym-148 sym">getStatus</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 440,
    code: '        <span class="k">return</span> <span class="sym-41 sym">status</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 441,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 442,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 443,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-149 sym">setStatus</span>(String <span class="sym-150 sym">status</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 444,
    code:
      '        <span class="k">this</span>.<span class="sym-41 sym">status</span> = <span class="sym-150 sym">status</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 445,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 446,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 447,
    code:
      '    <span class="k">public</span> String <span class="sym-151 sym">getCreateUser</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 448,
    code: '        <span class="k">return</span> <span class="sym-42 sym">createUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 449,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 450,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 451,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-152 sym">setCreateUser</span>(String <span class="sym-153 sym">createUser</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 452,
    code:
      '        <span class="k">this</span>.<span class="sym-42 sym">createUser</span> = <span class="sym-153 sym">createUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 453,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 454,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 455,
    code:
      '    <span class="k">public</span> <span class="sym-5 sym">Timestamp</span> <span class="sym-154 sym">getCreateTime</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 456,
    code: '        <span class="k">return</span> <span class="sym-43 sym">createTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 457,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 458,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 459,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-155 sym">setCreateTime</span>(<span class="sym-5 sym">Timestamp</span> <span class="sym-156 sym">createTime</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 460,
    code:
      '        <span class="k">this</span>.<span class="sym-43 sym">createTime</span> = <span class="sym-156 sym">createTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 461,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 462,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 463,
    code:
      '    <span class="k">public</span> <span class="sym-5 sym">Timestamp</span> <span class="sym-157 sym">getUpdateTime</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 464,
    code: '        <span class="k">return</span> <span class="sym-44 sym">updateTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 465,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 466,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 467,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-158 sym">setUpdateTime</span>(<span class="sym-5 sym">Timestamp</span> <span class="sym-159 sym">updateTime</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 468,
    code:
      '        <span class="k">this</span>.<span class="sym-44 sym">updateTime</span> = <span class="sym-159 sym">updateTime</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 469,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 470,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 471,
    code:
      '    <span class="k">public</span> String <span class="sym-160 sym">getUpdateUser</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 472,
    code: '        <span class="k">return</span> <span class="sym-45 sym">updateUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 473,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 474,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 475,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-161 sym">setUpdateUser</span>(String <span class="sym-162 sym">updateUser</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 476,
    code:
      '        <span class="k">this</span>.<span class="sym-45 sym">updateUser</span> = <span class="sym-162 sym">updateUser</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 477,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 478,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 479,
    code:
      '    <span class="k">public</span> String <span class="sym-163 sym">getTenantId</span>() {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 480,
    code: '        <span class="k">return</span> <span class="sym-46 sym">tenantId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 481,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 482,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 483,
    code:
      '    <span class="k">public</span> <span class="k">void</span> <span class="sym-164 sym">setTenantId</span>(String <span class="sym-165 sym">tenantId</span>) {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 484,
    code:
      '        <span class="k">this</span>.<span class="sym-46 sym">tenantId</span> = <span class="sym-165 sym">tenantId</span>;',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 485,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 486,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 487,
    code:
      '<span class="cd">//    public List&lt;DpsBuildInstance&gt; getDpsBuildInstanceList() {</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 488,
    code: '<span class="cd">//        return dpsBuildInstanceList;</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 489,
    code: '<span class="cd">//    }</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 490,
    code: '<span class="cd">//</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 491,
    code:
      '<span class="cd">//    public void setDpsBuildInstanceList(List&lt;DpsBuildInstance&gt; dpsBuildInstanceList) {</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 492,
    code: '<span class="cd">//        this.dpsBuildInstanceList = dpsBuildInstanceList;</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 493,
    code: '<span class="cd">//    }</span>',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 494,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 495,
    code:
      '    <span class="k">public</span> Object <span class="sym-166 sym">clone</span>() <span class="k">throws</span> CloneNotSupportedException {',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 496,
    code: '        <span class="k">return</span> <span class="k">super</span>.clone();',
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    utLineHits: 0,
    lineHits: 0,
    duplicated: false
  },
  {
    line: 497,
    code: "    }",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 498,
    code: "}",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  },
  {
    line: 499,
    code: "",
    scmAuthor: "lib@aixahc.com",
    scmRevision: "f8bf06402dd95ffaa24a7445f84705521ccb0e62",
    scmDate: "2018-08-02T23:16:52-0400",
    duplicated: false
  }
];

export const issues = [
  {
    key: "AWTuJZC19M0TqgCPRAC8",
    rule: "squid:CommentedOutCodeLine",
    severity: "MAJOR",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 183,
    hash: "4d5879b43b44486c550640cb01e5316a",
    textRange: {
      startLine: 183,
      endLine: 183,
      startOffset: 0,
      endOffset: 58
    },
    flows: [],
    status: "OPEN",
    message: "This block of commented-out lines of code should be removed.",
    effort: "5min",
    debt: "5min",
    author: "lib@aixahc.com",
    tags: ["misra", "unused"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-30T22:22:54-0400",
    updateDate: "2018-07-30T22:22:54-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  },
  {
    key: "AWSsxhJ8IDyr2OcgcLnC",
    rule: "squid:S1172",
    severity: "MAJOR",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 301,
    hash: "4d7a583ee1264ae41afbcaba647b4ffb",
    textRange: {
      startLine: 301,
      endLine: 301,
      startOffset: 42,
      endOffset: 57
    },
    flows: [
      {
        locations: [
          {
            component:
              "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
            textRange: {
              startLine: 301,
              endLine: 301,
              startOffset: 42,
              endOffset: 57
            },
            msg: 'Remove this unused method parameter variableDefaine".'
          }
        ]
      }
    ],
    status: "OPEN",
    message: 'Remove this unused method parameter "variableDefaine".',
    effort: "5min",
    debt: "5min",
    author: "lib@aixahc.com",
    tags: ["cert", "misra", "unused"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-09T04:34:27-0400",
    updateDate: "2018-07-18T05:43:26-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  },
  {
    key: "AWSsxhJ8IDyr2OcgcLnB",
    rule: "squid:S4165",
    severity: "MAJOR",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 302,
    hash: "43c9110576a9eaaae3683c99c87cb5a3",
    textRange: {
      startLine: 302,
      endLine: 302,
      startOffset: 8,
      endOffset: 44
    },
    flows: [],
    status: "OPEN",
    message:
      'Remove this useless assignment; "variableDefine" already holds the assigned value along all execution paths.',
    effort: "5min",
    debt: "5min",
    author: "lib@aixahc.com",
    tags: ["redundant"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-10T03:45:45-0400",
    updateDate: "2018-07-18T05:43:26-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  },
  {
    key: "AWTuJZC19M0TqgCPRAC9",
    rule: "squid:CommentedOutCodeLine",
    severity: "MAJOR",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 487,
    hash: "9610fabb1d5052d7da2c4426a040bbb4",
    textRange: {
      startLine: 487,
      endLine: 487,
      startOffset: 0,
      endOffset: 63
    },
    flows: [],
    status: "OPEN",
    message: "This block of commented-out lines of code should be removed.",
    effort: "5min",
    debt: "5min",
    author: "lib@aixahc.com",
    tags: ["misra", "unused"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-30T22:22:54-0400",
    updateDate: "2018-07-30T22:22:54-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  },
  {
    key: "AWTuJZC19M0TqgCPRAC-",
    rule: "squid:CommentedOutCodeLine",
    severity: "MAJOR",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 491,
    hash: "57825a19d1e9a651e27cb9dc0ec51415",
    textRange: {
      startLine: 491,
      endLine: 491,
      startOffset: 0,
      endOffset: 88
    },
    flows: [],
    status: "OPEN",
    message: "This block of commented-out lines of code should be removed.",
    effort: "5min",
    debt: "5min",
    author: "lib@aixahc.com",
    tags: ["misra", "unused"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-30T22:22:54-0400",
    updateDate: "2018-07-30T22:22:54-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  },
  {
    key: "AWTuJZC19M0TqgCPRAC7",
    rule: "squid:S2975",
    severity: "BLOCKER",
    component:
      "Devops:Build:Devops:Db-Build:src/main/java/com/hxzh/build/db/DpsBuildDefinition.java",
    project: "Devops:Build",
    subProject: "Devops:Build:Devops:Db-Build",
    line: 495,
    hash: "0638059409510b68e415badd59f0746d",
    textRange: {
      startLine: 495,
      endLine: 495,
      startOffset: 18,
      endOffset: 23
    },
    flows: [],
    status: "OPEN",
    message: 'Remove this "clone" implementation; use a copy constructor or copy factory instead.',
    effort: "30min",
    debt: "30min",
    author: "lib@aixahc.com",
    tags: ["suspicious"],
    transitions: [],
    actions: [],
    comments: [],
    creationDate: "2018-07-30T22:22:54-0400",
    updateDate: "2018-07-30T22:22:54-0400",
    type: "CODE_SMELL",
    organization: "default-organization"
  }
];
export const comment = {
  rule: {
    key: "squid:CommentedOutCodeLine",
    repo: "squid",
    name: "Sections of code should not be commented out",
    createdAt: "2018-06-22T03:52:40-0400",
    htmlDesc:
      '<p>Programmers should not comment out code as it bloats programs and reduces readability.</p>\n<p>Unused code should be deleted and can be retrieved from source control history if required.</p>\n<h2>See</h2>\n<ul>\n  <li> MISRA C:2004, 2.4 - Sections of code should not be "commented out". </li>\n  <li> MISRA C++:2008, 2-7-2 - Sections of code shall not be "commented out" using C-style comments. </li>\n  <li> MISRA C++:2008, 2-7-3 - Sections of code should not be "commented out" using C++ comments. </li>\n  <li> MISRA C:2012, Dir. 4.4 - Sections of code should not be "commented out" </li>\n</ul>',
    mdDesc:
      '<p>Programmers should not comment out code as it bloats programs and reduces readability.</p>\n<p>Unused code should be deleted and can be retrieved from source control history if required.</p>\n<h2>See</h2>\n<ul>\n  <li> MISRA C:2004, 2.4 - Sections of code should not be "commented out". </li>\n  <li> MISRA C++:2008, 2-7-2 - Sections of code shall not be "commented out" using C-style comments. </li>\n  <li> MISRA C++:2008, 2-7-3 - Sections of code should not be "commented out" using C++ comments. </li>\n  <li> MISRA C:2012, Dir. 4.4 - Sections of code should not be "commented out" </li>\n</ul>',
    severity: "MAJOR",
    status: "READY",
    internalKey: "S125",
    isTemplate: false,
    tags: [],
    sysTags: ["misra", "unused"],
    lang: "java",
    langName: "Java",
    params: [],
    defaultDebtRemFnType: "CONSTANT_ISSUE",
    defaultDebtRemFnOffset: "5min",
    debtOverloaded: false,
    debtRemFnType: "CONSTANT_ISSUE",
    debtRemFnOffset: "5min",
    defaultRemFnType: "CONSTANT_ISSUE",
    defaultRemFnBaseEffort: "5min",
    remFnType: "CONSTANT_ISSUE",
    remFnBaseEffort: "5min",
    remFnOverloaded: false,
    scope: "MAIN",
    isExternal: false,
    type: "CODE_SMELL"
  },
  actives: []
};
