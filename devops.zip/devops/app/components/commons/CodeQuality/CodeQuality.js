import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Drawer, Tooltip, Icon } from "antd";
import "./CodeQuality.css";
import * as action from "../../../actions/build/BuildManage";

class CodeQuality extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentLine: null,
      drawerVisible: false
      // comment: config.comment
    };
    this.showEssiue = this.showEssiue.bind(this);
    this.showDrawer = this.showDrawer.bind(this);
    this.Close = this.Close.bind(this);
  }

  showDrawer(issueExist) {
    const { actions } = this.props;
    this.setState({
      drawerVisible: true
    });
    actions.getcomponentRule({
      key: issueExist[0].rule
    });
  }

  Close() {
    this.setState({
      drawerVisible: false
    });
  }

  componentDidMount() {}

  showEssiue(issue) {
    const { SourceData } = this.props;
    SourceData.sourceData.map(d => {
      if (d.line == issue[0].line && !d.isOpen) {
        d.isOpen = true;
      } else if (d.line == issue[0].line && d.isOpen) {
        d.isOpen = false;
      }
      return d;
    });
    this.setState({
      currentLine: issue[0].line
    });
  }

  render() {
    const { RuleData, SourceData, actions } = this.props;
    const { drawerVisible } = this.state;
    // this.issues = config.issues;
    this.issues = SourceData ? SourceData.issuresData.issues : [];
    // this.tableData = config.tableData;
    this.tableData = SourceData ? SourceData.sourceData : [];
    const self = this;
    const context = this.tableData.map((d, index) => {
      const code = d.code;
      const lineNum = d.line;
      const issueExist = self.issues.filter(issue => {
        return issue.line == lineNum;
      });
      return (
        <tr key={Math.random()}>
          <td className="source-line-number bg">
            <span>{lineNum}</span>
          </td>
          <td className="bg" title={d.scmAuthor}>
            {index == 0 ? (
              <span className="source-line-scm bg">{d.scmAuthor}</span>
            ) : (
              <span className="clear-background bg" />
            )}
          </td>
          <td className="source-line-coverage bg">
            {d.utLineHits == 0 ? (
              <Tooltip placement="right" title="单元测试为覆盖">
                <span className="source-line-bar " />
              </Tooltip>
            ) : (
              ""
            )}
          </td>
          <td className="source-line-coverage bg">
            {d.duplicated == true ? (
              <Tooltip placement="right" title="代码重复">
                <span className="source-line-duplicate " />
              </Tooltip>
            ) : (
              ""
            )}
          </td>
          <td className="bg">
            {issueExist.length > 0 ? (
              <span
                className="source-line-with-issues"
                onClick={() => {
                  self.showEssiue(issueExist);
                }}
              />
            ) : (
              ""
            )}
          </td>
          <td className="source-code">
            {issueExist.length > 0 ? (
              <span className="source-line-code" dangerouslySetInnerHTML={{ __html: code }} />
            ) : (
              <span dangerouslySetInnerHTML={{ __html: code }} />
            )}
            {d.isOpen ? (
              <div className="issue-list">
                <div className="issue-row">
                  <span>{issueExist.length > 0 && issueExist[0].message}</span>
                  <button
                    type="button"
                    style={{ background: "rgba(75,159,213,.3)", height: "22px" }}
                  >
                    <Icon
                      type="menu-fold"
                      style={{ fontSize: "16px" }}
                      onClick={() => {
                        self.showDrawer(issueExist);
                      }}
                    />
                  </button>
                </div>
              </div>
            ) : (
              ""
            )}
          </td>
        </tr>
      );
    });
    const styles = {
      border: "1px solid #cdcdcd",
      maxHeight: "600px",
      overflowY: "scroll"
    };
    return (
      <div style={styles}>
        <table className="w">
          <tbody>{context}</tbody>
        </table>
        <Drawer
          title={RuleData ? RuleData.rule.name : ""}
          width={420}
          placement="right"
          onClose={this.Close}
          maskClosable={true}
          visible={drawerVisible}
        >
          <div
            dangerouslySetInnerHTML={{
              __html: RuleData ? RuleData.rule.htmlDesc : ""
            }}
          />
        </Drawer>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    RuleData: state.Build.get("RuleData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CodeQuality);
