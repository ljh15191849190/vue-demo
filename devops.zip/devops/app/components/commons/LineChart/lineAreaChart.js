import React from "react";

const echarts = require("echarts");

class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  query() {
    const { UsageHistory, color } = this.props;
    const x = [];
    if (UsageHistory) {
      UsageHistory.map(item => {
        const obj = item.value;
        x.push(obj);
      });
    }
    const myChart = echarts.init(this.refs.lineChart);
    myChart.setOption({
      grid: {
        x: 2,
        y: 2,
        x2: 2,
        y2: 2,
        borderWidth: 1
      },
      xAxis: {
        show: false,
        type: "category",
        boundaryGap: false,
        // data: [820, 932, 901, 934, 1290, 1330, 1320]
        data: x
      },
      yAxis: {
        show: false,
        type: "value"
      },
      series: [
        {
          // data: [200, 200, 300, 400, 300, 300, 300],
          type: "line",
          symbol: "none",
          smooth: true,
          data: x,
          areaStyle: { color },
          lineStyle: { color },
          itemStyle: {
            normal: {
              lineStyle: {
                width: 1, // 折线宽度
                color // 折线颜色
              }
            }
          }
        }
      ]
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    return <div id="myChart" ref="lineChart" style={{ width: "120px", height: "25px" }} />;
  }
}
export default LineChart;
