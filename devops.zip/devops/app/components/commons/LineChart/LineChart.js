import React from "react";

const echarts = require("echarts");

class ColumnChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    const { x, y, unit } = this.props;
    const myChart = echarts.init(this.refs.lineChart);
    myChart.setOption({
      tooltip: {
        trigger: "axis"
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        axisLabel: {
          rotate: 10
        },
        data: x
      },
      yAxis: {
        type: "value",
        name: unit ? unit : "单位/秒",
        min: 0
      },
      grid: {
        left: "10%",
        right: "4%",
        bottom: "3%",
        containLabel: true
      },
      series: [
        {
          type: "line",
          data: y
        }
      ]
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return <div id="myChart" ref="lineChart" style={{ width: "100%", height }} />;
  }
}
export default ColumnChart;
