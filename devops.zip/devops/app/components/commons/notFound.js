import React from "react";
// import { withRouter } from "react-router";
import { Link } from "react-router-dom";

// class NotFound extends React.PureComponent {
//   render() {
function NotFound() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "row",
        alignItem: "center",
        justifyContent: "center"
      }}
    >
      <img
        style={{ width: "500px", height: "500px" }}
        src="https://gw.alipayobjects.com/zos/rmsportal/KpnpchXsobRgLElEozzI.svg"
        alt=""
      />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          padding: "70px",
          justifyContent: "center"
        }}
      >
        {/* <div style={{fontSize:"72px", lineHeight:"72px"}}>404</div> */}
        <div style={{ fontSize: "20px", lineHeight: "44px" }}>敬请期待，功能正在开发中</div>
        <Link to="/devops/dashboard">
          <div
            style={{
              width: "100px",
              lineHeight: "32px",
              fontSize: "14px",
              textAlign: "center",
              borderRadius: "3px",
              background: "#1890ff",
              color: "#fff"
            }}
          >
            返回首页
          </div>
        </Link>
      </div>
    </div>
  );
}
// }

export default NotFound;

// export default withRouter(NotFound);
