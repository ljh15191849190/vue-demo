import React from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import "./Index.css";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      text: null
    };
    this.modules = {
      toolbar: [
        [{ header: [1, 2, 3, 4, false] }],
        [{ font: [] }],
        ["bold", "italic", "underline", "strike"], // toggled buttons
        ["blockquote", "code-block"],
        [{ align: [] }],
        [{ list: "ordered" }, { list: "bullet" }, { indent: "-1" }, { indent: "+1" }],
        [{ color: [] }, { background: [] }], // dropdown with defaults from theme
        ["image"],
        ["clean"]
      ]
    };
    this.formats = [
      "header",
      "font",
      "size",
      "bold",
      "italic",
      "underline",
      "code-block",
      "strike",
      "blockquote",
      "list",
      "bullet",
      "indent",
      "link",
      "image",
      "color",
      "align",
      "background",
      "raw"
    ];
    this.handleChange = this.handleChange.bind(this);
  }

  componentWillMount() {
    const { EditorData } = this.props;
    this.setState({
      text: EditorData ? EditorData : ""
    });
  }

  componentDidUpdate() {
    const { getValue } = this.props;
    const { text } = this.state;
    if (getValue) {
      getValue(text);
    }
  }

  handleChange(value) {
    this.setState({ text: value });
  }

  render() {
    const { text } = this.state;
    return (
      <div className="text-editor">
        <ReactQuill
          style={{ minHeight: 250 }}
          theme="snow"
          modules={this.modules}
          formats={this.formats}
          value={text}
          onChange={this.handleChange}
        />
      </div>
    );
  }
}
export default Index;
