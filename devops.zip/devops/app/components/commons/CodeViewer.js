import React from "react";
import { Icon } from "antd";
import "./codeViewer.css";

class CodeViewer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { ecList, getDeepFile, getFileContent } = this.props;
    if (ecList && ecList.length > 0) {
      ecList.map(item => {
        item.key = item.id;
      });
    }
    return (
      <div className="cv-outer">
        <div className="cv-header">
          <span>名称</span>
          <span>提交信息</span>
          <span>提交者</span>
          <span>提交时间</span>
        </div>
        {ecList.map(resp => {
          return (
            <div className="cv-content" key={resp.id}>
              <span
                onClick={() => {
                  if (resp.type == "tree") {
                    getDeepFile(resp);
                  } else if (resp.type == "blob") {
                    getFileContent(resp);
                  }
                }}
              >
                {resp.type == "tree" ? <Icon type="folder" /> : <Icon type="file" />}
                {resp.name}
              </span>
              <span>{resp.message}</span>
              <span>{resp.author}</span>
              <span>{resp.lastUpdate}</span>
            </div>
          );
        })}
      </div>
    );
  }
}

export default CodeViewer;
