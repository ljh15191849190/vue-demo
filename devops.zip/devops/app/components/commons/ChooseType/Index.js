import React from "react";
import "./Index.css";

class ChooseType extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rangePickerValue: "3"
    };
  }

  isActive(type) {
    const { rangePickerValue } = this.state;
    if (rangePickerValue == type) {
      return "currentDate";
    }
  }

  // 点击年月日
  selectDate(type) {
    const { signDate } = this.props;
    this.setState({
      rangePickerValue: type
    });
    signDate(type);
  }

  render() {
    return (
      <div style={{ float: "right" }}>
        <div className="salesExtra">
          <a className={this.isActive("1")} onClick={() => this.selectDate("1")}>
            今日
          </a>
          <a className={this.isActive("2")} onClick={() => this.selectDate("2")}>
            本周
          </a>
          <a className={this.isActive("3")} onClick={() => this.selectDate("3")}>
            近15天
          </a>
        </div>
      </div>
    );
  }
}
export default ChooseType;
