//带timeLine的柱状图
// 注意时间轴数据的设置

import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
import * as action from "../../actions/maitananceManageAction";

const echarts = require("echarts");

class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }

  queryData() {
    const myChart = echarts.init(this.refs.lineChart);

    var dataMap = {};
    function dataFormatter(obj) {
      var pList = [
        "北京",
        "天津",
        "河北",
        "山西",
        "内蒙古",
        "辽宁",
        "吉林",
        "黑龙江",
        "上海",
        "江苏",
        "浙江"
      ];
      var temp;
      for (var year = 2002; year <= 2011; year++) {
        var max = 0;
        var sum = 0;
        temp = obj[year];
        for (var i = 0, l = temp.length; i < l; i++) {
          max = Math.max(max, temp[i]);
          sum += temp[i];
          obj[year][i] = {
            name: pList[i],
            value: temp[i]
          };
        }
        obj[year + "max"] = Math.floor(max / 100) * 100;
        obj[year + "sum"] = sum;
      }
      return obj;
    }

    dataMap.dataGDP = dataFormatter({
      //max : 60000,
      2011: [
        16251.93,
        11307.28,
        24515.76,
        11237.55,
        14359.88,
        22226.7,
        10568.83,
        12582,
        19195.69,
        49110.27,
        32318.85
      ],
      2010: [
        14113.58,
        9224.46,
        20394.26,
        9200.86,
        11672,
        18457.27,
        8667.58,
        10368.6,
        17165.98,
        41425.48,
        27722.31
      ],
      2009: [
        12153.03,
        7521.85,
        17235.48,
        7358.31,
        9740.25,
        15212.49,
        7278.75,
        8587,
        15046.45,
        34457.3,
        22990.35
      ],
      2008: [
        11115,
        6719.01,
        16011.97,
        7315.4,
        8496.2,
        13668.58,
        6426.1,
        8314.37,
        14069.87,
        30981.98,
        21462.69
      ],
      2007: [
        9846.81,
        5252.76,
        13607.32,
        6024.45,
        6423.18,
        11164.3,
        5284.69,
        7104,
        12494.01,
        26018.48,
        18753.73
      ],
      2006: [
        8117.78,
        4462.74,
        11467.6,
        4878.61,
        4944.25,
        9304.52,
        4275.12,
        6211.8,
        10572.24,
        21742.05,
        15718.47
      ],
      2005: [669.52, 395.64, 112.11, 230.53, 395.03, 847.26, 362.27, 513.7, 247.66, 598.69, 417.68],
      2004: [633.21, 310.97, 877.63, 371.37, 341.07, 672, 322.01, 750.6, 872.83, 503.6, 648.7],
      2003: [507.21, 578.03, 621.29, 855.23, 288.38, 602.54, 662.08, 457.4, 694.23, 142.87, 975.02],
      2002: [4315, 215.76, 618.28, 324.8, 940.94, 558.22, 348.54, 637.2, 541.03, 166.85, 803.67]
    });

    dataMap.dataPI = dataFormatter({
      //max : 4000,
      2011: [136.27, 159.72, 905.73, 641.42, 306.3, 915.57, 277.44, 701.5, 124.94, 364.78, 583.04],
      2010: [124.36, 145.58, 562.81, 554.48, 195.28, 631.08, 150.15, 302.9, 114.15, 540.1, 360.56],
      2009: [118.29, 128.85, 227.34, 477.59, 929.6, 414.9, 980.57, 1154.33, 113.82, 221.86, 163.08],
      2008: [112.83, 122.58, 234.59, 313.58, 907.95, 132.02, 916.72, 188.94, 111.8, 210.11, 195.96],
      2007: [101.26, 110.19, 804.72, 311.97, 762.1, 1133.42, 783.8, 915.38, 101.84, 816.31, 986.02],
      2006: [88.8, 103.35, 1461.81, 276.77, 634.94, 939.43, 672.76, 750.14, 93.81, 1545.05, 925.1],
      2005: [88.68, 112.38, 1400, 262.42, 589.56, 882.41, 625.61, 684.6, 90.26, 1461.51, 892.83],
      2004: [87.36, 105.28, 1370.43, 276.3, 522.8, 798.43, 568.69, 605.79, 83.45, 1367.58, 814.1],
      2003: [84.11, 89.91, 717.85, 749.4, 692.94, 560, 494.6, 40.7, 48.47, 55.63, 412.9],
      2002: [82.44, 84.21, 197.8, 590.2, 474.2, 79.68, 281.1, 39.75, 47.31, 52.95, 305]
    });

    dataMap.dataSI = dataFormatter({
      //max : 26600,
      2011: [352.48, 575.32, 74.5, 5543.04, 294.33, 380.32, 208.79, 237.83, 975.18, 156.15, 325.9],
      2010: [
        3388.38,
        4840.23,
        7343.19,
        4511.68,
        571,
        1800.06,
        3223.49,
        163.92,
        5446.1,
        744.63,
        827.91
      ],
      2009: [
        2855.55,
        3987.84,
        3993.8,
        5114,
        443.43,
        136.63,
        4236.42,
        1527.24,
        575.33,
        662.32,
        1929.59
      ],
      2008: [
        2626.41,
        3709.78,
        4242.36,
        3037.74,
        423.55,
        1370.03,
        2452.75,
        115.56,
        1470.34,
        557.12,
        609.98
      ],
      2007: [
        2509.4,
        364.26,
        2368.53,
        4648.79,
        1124.79,
        2038.39,
        98.48,
        2986.46,
        1279.32,
        419.03,
        455.04
      ],
      2006: [
        3187.05,
        1878.56,
        308.62,
        1871.65,
        3775.14,
        967.54,
        1705.83,
        80.1,
        331.91,
        351.58,
        1459.3
      ],
      2005: [3869.4, 1580.83, 4381.2, 240.83, 1564, 821.16, 1426.42, 63.52, 838.56, 264.61, 281.05],
      2004: [1919.4, 1844.9, 1566.4, 1253.7, 205.6, 681.5, 52.74, 713.3, 211.7, 244.05, 914.47],
      2003: [
        967.49,
        984.08,
        175.82,
        1135.31,
        2014.8,
        569.37,
        47.64,
        572.02,
        171.92,
        194.27,
        719.54
      ],
      2002: [754.78, 943.49, 6143.4, 846.89, 148.88, 958.87, 481.96, 32.72, 501.69, 144.51, 153.06]
    });

    dataMap.dataTI = dataFormatter({
      //max : 25000,
      2011: [
        5219.24,
        8483.17,
        3960.87,
        5015.89,
        3679.91,
        3701.79,
        322.57,
        4355.81,
        1963.79,
        540.18,
        861.92
      ],
      2010: [
        3412.38,
        4209.03,
        3383.11,
        953.67,
        2881.08,
        2177.07,
        2892.31,
        274.82,
        1536.5,
        470.88,
        702.45
      ],
      2009: [
        9179.19,
        3405.16,
        6068.31,
        2886.92,
        3696.65,
        5891.25,
        2756.26,
        3371.95,
        8930.85,
        629.07,
        918.78
      ],
      2008: [
        835.76,
        886.65,
        5276.04,
        759.46,
        3212.06,
        207.72,
        2412.26,
        2905.68,
        7872.23,
        188.53,
        899.31
      ],
      2007: [
        7236.15,
        2250.04,
        4600.72,
        2257.99,
        2467.41,
        4486.74,
        2025.44,
        2493.04,
        6821.11,
        9730.91,
        7613.46
      ],
      2006: [
        5837.55,
        1902.31,
        3895.36,
        1846.18,
        1934.35,
        3798.26,
        1687.07,
        2096.35,
        5508.48,
        7914.11,
        6281.86
      ],
      2005: [854.33, 658.19, 340.54, 611.07, 542.26, 395.45, 413.83, 857.42, 776.2, 662.22, 612.22],
      2004: [
        4092.27,
        1319.76,
        2805.47,
        1375.67,
        1270,
        2811.95,
        1223.64,
        1657.77,
        4097.26,
        5198.03,
        4584.22
      ],
      2003: [435.95, 150.81, 439.68, 176.65, 100.79, 287.85, 175.48, 467.9, 404.19, 493.31, 890.79],
      2002: [982.57, 997.47, 249.75, 992.69, 811.47, 258.17, 958.88, 1319.4, 338.9, 891.92, 227.99]
    });

    dataMap.dataEstate = dataFormatter({
      //max : 3600,
      2011: [174.93, 411.46, 918.02, 224.91, 384.76, 876.12, 238.61, 492.1, 119.68, 747.89, 677.13],
      2010: [106.52, 377.59, 697.79, 192, 309.25, 733.37, 212.32, 391.89, 1002.5, 260.95, 618.17],
      2009: [162.47, 308.73, 612.4, 173.31, 286.65, 605.27, 200.14, 301.18, 237.56, 225.39, 316.84],
      2008: [844.59, 227.88, 513.81, 166.04, 273.3, 500.81, 182.7, 244.47, 939.34, 1626.13],
      2007: [821.5, 183.44, 467.97, 134.12, 191.01, 410.43, 153.03, 225.81, 958.06, 365.71, 981.42],
      2006: [658.3, 156.64, 397.14, 117.01, 136.5, 318.54, 131.01, 194.7, 773.61, 1017.91, 794.41],
      2005: [493.73, 122.67, 330.87, 106, 98.75, 256.77, 112.29, 163.34, 715.97, 799.73, 688.86],
      2004: [436.11, 106.14, 231.08, 95.1, 73.81, 203.1, 97.93, 137.74, 666.3, 534.17, 587.83],
      2003: [341.88, 92.31, 185.19, 78.73, 61.05, 188.49, 91.99, 127.2, 487.82, 447.47, 473.16],
      2002: [298.02, 73.04, 140.89, 65.83, 51.48, 130.94, 76.11, 118.7, 384.86, 371.09, 360.63]
    });

    dataMap.dataFinancial = dataFormatter({
      //max : 3200,
      2011: [
        2215.41,
        756.5,
        746.01,
        519.32,
        447.46,
        755.57,
        207.65,
        370.78,
        2277.4,
        2600.11,
        357.44
      ],
      2010: [
        1863.61,
        572.99,
        615.42,
        448.3,
        346.44,
        639.27,
        190.12,
        304.59,
        1950.96,
        2105.92,
        2326.58
      ],
      2009: [
        1603.63,
        461.2,
        525.67,
        361.64,
        291.1,
        560.2,
        180.83,
        227.54,
        1804.28,
        1596.98,
        1899.33
      ],
      2008: [
        1519.19,
        368.1,
        420.74,
        290.91,
        219.09,
        455.07,
        147.24,
        177.43,
        1414.21,
        1298.48,
        1653.45
      ],
      2007: [
        1302.77,
        288.17,
        347.65,
        218.73,
        148.3,
        386.34,
        126.03,
        155.48,
        1209.08,
        1054.25,
        218.73
      ],
      2006: [982.37, 186.87, 284.04, 169.63, 108.21, 303.41, 100.75, 74.17, 825.2, 653.25, 906.37],
      2005: [840.2, 147.4, 213.47, 135.07, 72.52, 232.85, 83.63, 35.03, 675.12, 492.4, 686.32],
      2004: [713.79, 136.97, 209.1, 110.29, 55.89, 188.04, 77.17, 32.2, 612.45, 440.5, 523.49],
      2003: [635.56, 112.79, 199.87, 118.48, 55.89, 145.38, 73.15, 32.2, 517.97, 392.11, 451.54],
      2002: [561.91, 76.86, 179.6, 124.1, 48.39, 137.18, 75.45, 31.6, 485.25, 368.86, 347.53]
    });

    myChart.setOption({
      baseOption: {
        timeline: {
          // y: 0,
          // axisType: 'category',
          // realtime: false,
          // loop: false,
          autoPlay: true, // currentIndex: 2,
          playInterval: 1000, // controlStyle: {
          //     position: 'left'
          // },
          data: [
            "2002-01-01",
            "2003-01-01",
            "2004-01-01",
            {
              value: "2005-01-01",
              tooltip: { formatter: "{b} GDP达到一个高度" },
              symbol: "diamond",
              symbolSize: 16
            },
            "2006-01-01",
            "2007-01-01",
            "2008-01-01",
            "2009-01-01",
            "2010-01-01",
            {
              value: "2011-01-01",
              tooltip: {
                formatter: function(params) {
                  return params.name + "GDP达到又一个高度";
                }
              },
              symbol: "diamond",
              symbolSize: 18
            }
          ],
          label: {
            formatter: function(s) {
              return new Date(s).getFullYear();
            }
          }
        },
        title: { subtext: "数据来自国家统计局" },
        tooltip: {},
        legend: {
          x: "right",
          data: ["第一产业", "第二产业", "第三产业", "GDP", "金融", "房地产"],
          selected: { GDP: false, 金融: false, 房地产: false }
        },
        calculable: true,
        grid: {
          top: 80,
          bottom: 100,
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "shadow",
              label: {
                show: true,
                formatter: function(params) {
                  return params.value.replace("\n", "");
                }
              }
            }
          }
        },
        xAxis: [
          {
            type: "category",
            axisLabel: { interval: 0 },
            data: [
              "北京",
              "\n天津",
              "河北",
              "\n山西",
              "内蒙古",
              "\n辽宁",
              "吉林",
              "\n黑龙江",
              "上海",
              "\n江苏",
              "浙江",
              "\n安徽"
            ],
            splitLine: { show: false }
          }
        ],
        yAxis: [{ type: "value", name: "GDP（亿元）" }],
        series: [
          { name: "GDP", type: "bar" },
          { name: "金融", type: "bar" },
          { name: "房地产", type: "bar" },
          { name: "第一产业", type: "bar" },
          { name: "第二产业", type: "bar" },
          { name: "第三产业", type: "bar" }
        ]
      },
      options: [
        {
          title: { text: "2002全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2002"] },
            { data: dataMap.dataFinancial["2002"] },
            { data: dataMap.dataEstate["2002"] },
            { data: dataMap.dataPI["2002"] },
            { data: dataMap.dataSI["2002"] },
            { data: dataMap.dataTI["2002"] }
          ]
        },
        {
          title: { text: "2003全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2003"] },
            { data: dataMap.dataFinancial["2003"] },
            { data: dataMap.dataEstate["2003"] },
            { data: dataMap.dataPI["2003"] },
            { data: dataMap.dataSI["2003"] },
            { data: dataMap.dataTI["2003"] }
          ]
        },
        {
          title: { text: "2004全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2004"] },
            { data: dataMap.dataFinancial["2004"] },
            { data: dataMap.dataEstate["2004"] },
            { data: dataMap.dataPI["2004"] },
            { data: dataMap.dataSI["2004"] },
            { data: dataMap.dataTI["2004"] }
          ]
        },
        {
          title: { text: "2005全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2005"] },
            { data: dataMap.dataFinancial["2005"] },
            { data: dataMap.dataEstate["2005"] },
            { data: dataMap.dataPI["2005"] },
            { data: dataMap.dataSI["2005"] },
            { data: dataMap.dataTI["2005"] }
          ]
        },
        {
          title: { text: "2006全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2006"] },
            { data: dataMap.dataFinancial["2006"] },
            { data: dataMap.dataEstate["2006"] },
            { data: dataMap.dataPI["2006"] },
            { data: dataMap.dataSI["2006"] },
            { data: dataMap.dataTI["2006"] }
          ]
        },
        {
          title: { text: "2007全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2007"] },
            { data: dataMap.dataFinancial["2007"] },
            { data: dataMap.dataEstate["2007"] },
            { data: dataMap.dataPI["2007"] },
            { data: dataMap.dataSI["2007"] },
            { data: dataMap.dataTI["2007"] }
          ]
        },
        {
          title: { text: "2008全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2008"] },
            { data: dataMap.dataFinancial["2008"] },
            { data: dataMap.dataEstate["2008"] },
            { data: dataMap.dataPI["2008"] },
            { data: dataMap.dataSI["2008"] },
            { data: dataMap.dataTI["2008"] }
          ]
        },
        {
          title: { text: "2009全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2009"] },
            { data: dataMap.dataFinancial["2009"] },
            { data: dataMap.dataEstate["2009"] },
            { data: dataMap.dataPI["2009"] },
            { data: dataMap.dataSI["2009"] },
            { data: dataMap.dataTI["2009"] }
          ]
        },
        {
          title: { text: "2010全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2010"] },
            { data: dataMap.dataFinancial["2010"] },
            { data: dataMap.dataEstate["2010"] },
            { data: dataMap.dataPI["2010"] },
            { data: dataMap.dataSI["2010"] },
            { data: dataMap.dataTI["2010"] }
          ]
        },
        {
          title: { text: "2011全国宏观经济指标" },
          series: [
            { data: dataMap.dataGDP["2011"] },
            { data: dataMap.dataFinancial["2011"] },
            { data: dataMap.dataEstate["2011"] },
            { data: dataMap.dataPI["2011"] },
            { data: dataMap.dataSI["2011"] },
            { data: dataMap.dataTI["2011"] }
          ]
        }
      ]
    });
  }

  componentDidUpdate() {
    console.log("componentDidUpdate");
    this.queryData();
  }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
    // 调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    // this.props.actions.sceneEvaluateRate(this.state.queryParam);
    // let visualMonitorListCPU = this.props.visualMonitorListDataCPU.get("visualMonitorListCPU");
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    console.log("echarts");
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        <Row span={12}>
          <div id="myChart" ref="lineChart" style={{ width: "805px", height: "580px" }} />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    // visualMonitorListDataCPU: state.MaitananceManage.get("visualMonitorListDataCPU"),
    // visualMonitorListDataMEM: state.MaitananceManage.get("visualMonitorListDataMEM"),
    // caasPodsInfoMonitorListData: state.MaitananceManage.get("caasPodsInfoMonitorListData"),
    // caasServicesMetricsListData: state.MaitananceManage.get("caasServicesMetricsListData")
  };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
