import React, { Component } from "react";
import { Row, Col, Card } from "antd";

export default class CardItem extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { title, colors, count, picUrl, backgroundImg } = this.props;

    const styles = {
      navItem: {
        height: 74,
        display: "flex",
        alignItems: "center",
        justifyContent: "flex-start",
        color: "#fff"
      },
      container: {
        height: 158,
        borderRadius: 8,
        // background: `linear-gradient(to right,${colors[0]},${colors[1]})`
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "100% 100%"
      },
      title: {
        fontSize: 14,
        marginLeft: 30,
        color: "#fff"
      },
      count: {
        fontSize: 24,
        color: "#fff",
        marginLeft: 30,
        marginTop: 10
      }
    };

    return (
      <Row style={styles.container}>
        <Col span={20}>
          <div style={styles.count}>{count}</div>
          <div style={styles.title}>{title}</div>
        </Col>
        <Col span={4} style={{ height: 42 }}>
          <img src={picUrl} style={{ width: 49, height: 40, position: "relative", top: "22px" }} />
        </Col>

        <Col span={24} style={styles.navItem}>
          {/* <div id="myChart" ref="cardBar" style={{ width: "100%", height: "100%" }} /> */}
        </Col>
      </Row>
    );
  }
}
