// 需求燃尽图
import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
const echarts = require("echarts");

class LineStyleChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    function changeDate(changeTime) {
      return `${new Date(changeTime).getMonth() + 1}-${
        Number(new Date(changeTime).getDate()) > 9
          ? Number(new Date(changeTime).getDate())
          : `0${Number(new Date(changeTime).getDate())}`
      }\n${new Date(changeTime).getFullYear()}`;
    }
    myChart.setOption({
      title: {
        text: "需求燃尽图",
        left: 15,
        textStyle: {
          fontFamily: "Microsoft YaHei",
          fontWeight: 500,
          fontSize: 14,
          // fontWeight: "normal",
          color: "rgb(139, 235, 249)"
        }
      },
      tooltip: {
        trigger: "axis"
      },
      legend: {
        right: "5%",
        itemGap: 38,
        itemWidth: 14,
        itemHeight: 14,
        textStyle: { color: "#ccc" },
        data: [
          {
            name: "进度线"
          },
          {
            name: "基准线"
          }
        ]
      },
      grid: {
        left: "3%",
        right: "4%",
        top: 40,
        bottom: "3%",
        containLabel: true
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        axisLabel: { color: "#6777a8" },
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        data: [
          changeDate("2018-12-03"),
          changeDate("2018-12-04"),
          changeDate("2018-12-05"),
          changeDate("2018-12-06"),
          changeDate("2018-12-07"),
          changeDate("2018-12-08"),
          changeDate("2018-12-09")
        ]
      },
      yAxis: {
        type: "value",
        min: 0,
        splitNumber: 3,
        axisLabel: { color: "#6777a8" },
        nameTextStyle: { color: "#6777a8" },
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: "dashed",
            color: "#6777a8"
          }
        }
      },
      series: [
        {
          name: "进度线",
          type: "line",
          // stack: "总量",
          data: [60, 55, 39, 36, 28, 6, 0],
          smooth: true,
          symbol: "roundrect",
          itemStyle: {
            color: "#fa9797"
          },
          lineStyle: { color: "#fa9797" },
          areaStyle: {
            // 线性渐变，前四个参数分别是 x0, y0, x2, y2, 范围从 0 - 1，相当于在图形包围盒中的百分比，如果 globalCoord 为 `true`，则该四个值是绝对的像素位置
            color: {
              type: "linear",
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                {
                  offset: 0,
                  color: "#f3e817" // 0% 处的颜色
                },
                {
                  offset: 1,
                  color: "#a3c0fc" // 100% 处的颜色
                }
              ],
              global: false // 缺省为 false
            }
          }
        },
        {
          name: "基准线",
          type: "line",
          // stack: "总量",
          symbol: "roundrect",
          itemStyle: {
            color: "#ccc"
          },
          data: [60, 50, 40, 30, 20, 10, 0],
          smooth: false,
          lineStyle: { color: "#ccc", type: "dashed" }
        }
      ]
    });
  }

  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    // console.log("componentDidMount");

    this.queryData();
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    // console.log("echarts");
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        <Row span={12}>
          <div id="myChart" ref="lineChart" style={{ width: "100%", height: this.props.height }} />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators({}, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineStyleChart);

// export default LineChart;
