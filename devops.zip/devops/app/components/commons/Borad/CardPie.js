import React, { Component } from "react";
import { Row, Col, Card } from "antd";
import { relative } from "path";
const echarts = require("echarts");

export default class CardPie extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.drawChart = this.drawChart.bind(this);
  }

  componentDidMount() {
    this.drawChart();
  }
  drawChart() {
    const { title, value, colors } = this.props;

    const chart = echarts.init(this.refs.cardPie);
    const color = `linear-gradient(to right,${colors[0]},${colors[1]})`;

    let option = {
      background: color,
      tooltip: {
        trigger: "item",
        formatter: "{a}{b}:{c}%"
      },
      animation: false,
      color: ["rgba(255,255,255,0.7)", "rgba(255,255,255,0.4)"],
      label: {
        normal: {
          textStyle: {
            fontWeight: "normal",
            fontSize: 16
          }
        }
      },
      grid: {
        top: 0
      },
      series: [
        {
          name: title || "",
          type: "pie",
          radius: "55%",
          data: value,
          itemStyle: {
            // emphasis: {
            //   shadowBlur: 10,
            //   shadowOffsetX: 0,
            //   shadowColor: "rgba(0, 0, 0, 0.5)"
            // },
            normal: {
              label: {
                show: true,
                color: "#fff",
                // position: "inside", //如果不显示在里面可以把这里去掉
                formatter: "{b} : {c}"
              },
              labelLine: { show: true }
            }
          }
        }
      ]
    };
    chart.setOption(option);
  }

  render() {
    const { title, colors, backgroundImg } = this.props;

    const styles = {
      navItem: {
        position: "relative",
        top: -20,
        height: 140,
        width: 410,
        // display: "flex",
        // alignItems: "center",
        // justifyContent: "flex-start",
        color: "#fff"
      },
      container: {
        height: 158,
        borderRadius: 8,
        // background: `linear-gradient(to right,${colors[0]},${colors[1]})`
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "100% 100%"
      },
      title: {
        display: "inline-block",
        paddingTop: 16,
        paddingLeft: 16,
        fontSize: 16,
        color: "#fff"
      },
      count: {
        fontSize: 24,
        color: "#fff",
        paddingTop: 16,
        marginLeft: 8
      }
    };
    return (
      <Row style={styles.container}>
        <Col span={24}>
          <span style={styles.title}>{title}</span>
        </Col>
        <Col span={24} style={styles.navItem}>
          <div id="myChart" ref="cardPie" style={{ width: "100%", height: "100%" }} />
        </Col>
        <Col />
      </Row>
    );
  }
}
