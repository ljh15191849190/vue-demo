import React, { Component } from "react";
import { Row, Col } from "antd";

const echarts = require("echarts");

export default class CardArea extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.drawChart = this.drawChart.bind(this);
  }

  componentDidMount() {
    this.drawChart();
  }

  drawChart() {
    const { x, y, colors } = this.props;

    const chart = echarts.init(this.refs.cardArea);
    const color = `linear-gradient(to right,${colors[0]},${colors[1]})`;

    chart.setOption({
      background: color,
      tooltip: {
        trigger: "axis",
        formatter: "{b}:{c}",
        axisPointer: {
          lineStyle: {
            color: "#fff"
          }
        }
      },
      grid: {
        left: "1%",
        right: "1%",
        bottom: "1%",
        containLabel: true
      },
      xAxis: [
        {
          show: false,
          splitLine: {
            show: false
          },
          data: x
        }
      ],
      yAxis: [
        {
          name: "",
          show: false,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: "",
          type: "line",
          smooth: true,
          symbol: "circle",
          symbolSize: 5,
          color: "#fadd86", // 圆点颜色
          showSymbol: false,
          lineStyle: {
            normal: {
              color: "rgba(255,255,255,0.48)"
            }
          },
          areaStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                1,
                0,
                [
                  {
                    offset: 0,
                    color: "rgba(255,255,255, 0.18)"
                  },
                  {
                    offset: 0,
                    color: "rgba(255,255,255, 0.45)"
                  }
                ],
                false
              ),
              shadowColor: "rgba(0, 0, 0, 0.1)",
              shadowBlur: 10
            }
          },

          data: y
        }
      ]
    });
  }

  render() {
    const { title, colors, count, picUrl, backgroundImg } = this.props;

    const styles = {
      navItem: {
        height: "100%",
        width: 340,
        // display: "flex",
        // alignItems: "center",
        // justifyContent: "flex-start",
        color: "#fff",
        position: "relative",
        top: "-85px"
      },
      container: {
        height: 158,
        borderRadius: 8,
        // background: `linear-gradient(to right,${colors[0]},${colors[1]})`
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "100% 100%"
      },
      title: {
        fontSize: 14,
        marginLeft: 30,
        color: "#fff"
      },
      count: {
        fontSize: 24,
        color: "#fff",
        marginLeft: 30,
        marginTop: 10
      }
    };

    return (
      <Row style={styles.container}>
        <Col span={20}>
          <div style={styles.count}>{count}</div>
          <div style={styles.title}>{title}</div>
        </Col>
        <Col span={4}>
          <img src={picUrl} style={{ width: 49, height: 40, position: "relative", top: "22px" }} />
        </Col>
        <Col span={24} style={styles.navItem}>
          <div id="myChart" ref="cardArea" style={{ width: "100%", height: "100%" }} />
        </Col>
      </Row>
    );
  }
}
