import React from "react";
import { Row, Col } from "antd";

const echarts = require("echarts");

class ColumndashChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    const { x, y } = this.props;
    // const y = [2220, 1682, 2791, 3000, 4090];
    // const x = ["Sun", "Mon", "Tue", "Wed", "Thu"];
    const myChart = echarts.init(this.refs.columChart);
    myChart.setOption({
      tooltip: {
        // trigger: "axis",
        // formatter: "{b} {a}: {c}"
      },
      grid: {
        left: "4%",
        right: "4%",
        bottom: "4%",
        containLabel: true
      },
      xAxis: {
        type: "category",
        data: x,
        axisLine: {
          show: true,
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: {
          color: "#6777a8"
        }
      },
      yAxis: {
        name: "单位（秒）",
        type: "value",
        splitLine: {
          show: true,
          lineStyle: {
            type: "dashed",
            color: "#6777a8"
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: {
          color: "#6777a8" // 坐标字体
        }
      },
      series: [
        {
          data: y,
          type: "line",
          symbol: "circle",
          symbolSize: 10,
          color: "#fadd86", // 圆点颜色
          lineStyle: {
            color: "#affee5" // 上线
          },
          label: {
            show: true,
            position: "top",
            textStyle: {
              color: "#fadd86", // 上数字颜色
              fontSize: 12
            }
          },
          areaStyle: {
            // color: "rgba(27,201,142,0.52)" // 面积内
            color: {
              type: "linear",
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                {
                  offset: 0,
                  color: "#94fcd9" // 0% 处的颜色(上)
                },
                {
                  offset: 1,
                  color: "rgba(27,201,142,0.52)" // 100% 处的颜色（下）
                }
              ],
              globalCoord: false // 缺省为 false
            }
          }
        },
        {
          type: "bar",
          animation: false,
          barWidth: 1,
          hoverAnimation: false,
          data: y,
          tooltip: {
            show: false
          },
          itemStyle: {
            normal: {
              color: {
                type: "linear",
                x: 0,
                y: 0,
                x2: 0,
                y2: 1,
                colorStops: [
                  {
                    offset: 0,
                    color: "#affee5" // 0% 处的颜色(上)
                  },
                  {
                    offset: 1,
                    color: "#d1fcee" // 100% 处的颜色（下）
                  }
                ],
                globalCoord: false // 缺省为 false
              },
              label: {
                show: false
              }
            }
          }
        }
      ]
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return (
      <Row>
        <Col span={24}>
          <div
            id="myChart"
            ref="columChart"
            style={{ width: "100%", height }} // backgroundColor: "#24397e"
          />
        </Col>
      </Row>
    );
  }
}
export default ColumndashChart;
