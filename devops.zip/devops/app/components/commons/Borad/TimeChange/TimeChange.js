import React from "react";
import { DatePicker } from "antd";
import moment from "moment";
import "./TimeChange.css";

const { RangePicker } = DatePicker;
class TimeChange extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // rangePickerValue: [],
      rangePickerValue: this.getTimeDistance("month")
    };
  }

  fixedZero(val) {
    return val * 1 < 10 ? `0${val}` : val;
  }

  getTimeDistance(type) {
    const now = new Date();
    const oneDay = 1000 * 60 * 60 * 24;

    if (type === "today") {
      now.setHours(0);
      now.setMinutes(0);
      now.setSeconds(0);
      return [moment(now), moment(now).add("days", 1)];
    }

    if (type === "week") {
      let day = now.getDay();
      now.setHours(0);
      now.setMinutes(0);
      now.setSeconds(0);

      if (day === 0) {
        day = 6;
      } else {
        day -= 1;
      }

      const beginTime = now.getTime() - day * oneDay;
      return [moment(beginTime), moment(beginTime + (7 * oneDay - 1000))];
      // return [moment(beginTime).format("x"), moment(beginTime + (7 * oneDay - 1000)).format("x")];
    }

    if (type === "month") {
      const year = now.getFullYear();
      const month = now.getMonth();
      const nextDate = moment(now).add(1, "months");
      const nextYear = nextDate.year();
      const nextMonth = nextDate.month();

      return [
        moment(`${year}-${this.fixedZero(month + 1)}-01 00:00:00`),
        moment(moment(`${nextYear}-${this.fixedZero(nextMonth + 1)}-01 00:00:00`).valueOf() - 1000)
      ];
    }

    if (type === "year") {
      const year = now.getFullYear();

      return [moment(`${year}-01-01 00:00:00`), moment(`${year}-12-31 23:59:59`)];
    }
  }

  isActive(type) {
    const { rangePickerValue } = this.state;
    const value = this.getTimeDistance(type);
    if (!rangePickerValue[0] || !rangePickerValue[1]) {
      return;
    }
    if (
      rangePickerValue[0].isSame(value[0], "day") &&
      rangePickerValue[1].isSame(value[1], "day")
    ) {
      return "currentDate";
    }
  }

  // 点击年月日
  selectDate(type) {
    const { signDate } = this.props;
    this.setState({
      rangePickerValue: this.getTimeDistance(type)
    });
    signDate(this.getTimeDistance(type), type);
    // console.log(this.getTimeDistance(type)[0].format("YYYY-MM-DD HH:mm:ss"));
    // console.log(this.getTimeDistance(type)[1].format("YYYY-MM-DD HH:mm:ss"));
  }

  // 自己选择日期
  handleRangePickerChange(rangePickerValue) {
    const { dbDate } = this.props;
    this.setState({
      rangePickerValue
    });
    dbDate(rangePickerValue);
  }

  render() {
    const { rangePickerValue } = this.state;
    return (
      <div className="containner" style={{ float: "right" }}>
        <div className="changesalesExtra">
          <a className={this.isActive("today")} onClick={() => this.selectDate("today")}>
            今日
          </a>
          <a className={this.isActive("week")} onClick={() => this.selectDate("week")}>
            本周
          </a>
          <a className={this.isActive("month")} onClick={() => this.selectDate("month")}>
            本月
          </a>
        </div>
        <RangePicker
          value={rangePickerValue}
          onChange={this.handleRangePickerChange.bind(this)}
          style={{ width: 256 }}
        />
      </div>
    );
  }
}
export default TimeChange;
