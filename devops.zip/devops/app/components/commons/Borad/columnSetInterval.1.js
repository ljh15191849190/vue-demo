// 动态数据 + 时间坐标轴;
// 注意X轴数据的类型，及数据的规律性
import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
const echarts = require("echarts");
const dataJson = [
  { xTime: 1538582400000, yValue: [320, 220] }, // 4
  { xTime: 1538668800000, yValue: [39, 82] }, // 5
  { xTime: 1538755200000, yValue: [332, 382] }, // 6
  { xTime: 1538841600000, yValue: [192, 128] }, // 7
  { xTime: 1538928000000, yValue: [92, 52] }, // 8
  { xTime: 1539014400000, yValue: [22, 72] }, // 9
  { xTime: 1539129600000, yValue: [132, 18] }, // 10
  { xTime: 1539216000000, yValue: [32, 12] }, // 11
  { xTime: 1539302400000, yValue: [2, 82] }, // 12
  { xTime: 1539388800000, yValue: [32, 182] }, // 13
  { xTime: 1539475200000, yValue: [332, 82] }, // 14
  { xTime: 1539561600000, yValue: [32, 182] } // 15
];
class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    function randomData(typeData) {
      const maxLength = dataJson.length;
      if (typeData === "valueData1") {
        if (currentIndex1 === maxLength) {
          currentIndex = 0;
          // 因为时间轴问题   重新取数据

          data1 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data1.push(randomData("valueData1"));
          }
          //   console.log("data1__0", data1);
          // } else if (typeData === "valueData2") {
          //   data2 = [];
          //   // 初始化页面值
          //   for (var i = 0; i < 5; i++) {
          //     data2.push(randomData("valueData2"));
          //   }
          //   console.log("data2__0", data2);
        } else {
          // 取用当前的数据值
          const thisIndex = currentIndex1;
          // 每次改变索引值
          currentIndex1 = currentIndex1 + 1;
          // if (typeData === "valueData1") {
          //   const dataAA = [
          //     [
          //       new Date(dataJson[thisIndex].xTime).getFullYear(),
          //       new Date(dataJson[thisIndex].xTime).getMonth() + 1,
          //       new Date(dataJson[thisIndex].xTime).getDate()
          //     ].join("/"),
          //     dataJson[thisIndex].yValue[0]
          //   ];
          return {
            // name: new Date(dataJson[thisIndex].xTime).toString(),
            value: [
              [
                new Date(dataJson[thisIndex].xTime).getFullYear(),
                new Date(dataJson[thisIndex].xTime).getMonth() + 1,
                new Date(dataJson[thisIndex].xTime).getDate()
              ].join("/"),
              dataJson[thisIndex].yValue[0]
            ]
          };
        }
        // } else if (typeData === "valueData2") {
        //   return {
        //     // name: new Date(dataJson[thisIndex].xTime).toString(),
        //     value: [
        //       [
        //         new Date(dataJson[thisIndex].xTime).getFullYear(),
        //         new Date(dataJson[thisIndex].xTime).getMonth() + 1,
        //         new Date(dataJson[thisIndex].xTime).getDate()
        //       ].join("/"),
        //       dataJson[thisIndex].yValue[1]
        //     ]
        //   };
        // }
        // return {
        //   // name: new Date(dataJson[thisIndex].xTime).toString(),
        //   value: [
        //     [
        //       new Date(dataJson[thisIndex].xTime).getFullYear(),
        //       new Date(dataJson[thisIndex].xTime).getMonth() + 1,
        //       new Date(dataJson[thisIndex].xTime).getDate()
        //     ].join("/"),
        //     dataJson[thisIndex].yValue
        //   ]
        // };
      } else if (typeData === "valueData2") {
        if (currentIndex1 === maxLength) {
          currentIndex = 0;
          // 因为时间轴问题   重新取数据

          data1 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data1.push(randomData("valueData1"));
          }
          //   console.log("data1__0", data1);
          // } else if (typeData === "valueData2") {
          //   data2 = [];
          //   // 初始化页面值
          //   for (var i = 0; i < 5; i++) {
          //     data2.push(randomData("valueData2"));
          //   }
          //   console.log("data2__0", data2);
        }
      } else {
        // 取用当前的数据值
        const thisIndex = currentIndex1;
        // 每次改变索引值
        currentIndex1 = currentIndex1 + 1;
        // if (typeData === "valueData1") {
        //   const dataAA = [
        //     [
        //       new Date(dataJson[thisIndex].xTime).getFullYear(),
        //       new Date(dataJson[thisIndex].xTime).getMonth() + 1,
        //       new Date(dataJson[thisIndex].xTime).getDate()
        //     ].join("/"),
        //     dataJson[thisIndex].yValue[0]
        //   ];
        return {
          // name: new Date(dataJson[thisIndex].xTime).toString(),
          value: [
            [
              new Date(dataJson[thisIndex].xTime).getFullYear(),
              new Date(dataJson[thisIndex].xTime).getMonth() + 1,
              new Date(dataJson[thisIndex].xTime).getDate()
            ].join("/"),
            dataJson[thisIndex].yValue[0]
          ]
        };
      }
    }

    var data1 = [];
    var data2 = [];
    var currentIndex1 = 0;
    var currentIndex2 = 0;

    for (let i = 0; i < 5; i++) {
      data1.push(randomData("valueData1"));
      data2.push(randomData("valueData2"));
    }

    myChart.setOption({
      color: ["#003366", "#006699", "#4cabce", "#e5323e"],
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      grid: {
        left: "3%",
        right: "4%",
        top: 30,
        bottom: "3%",
        containLabel: true
      },
      legend: {
        data: ["Forest", "Steppe"]
      },
      xAxis: [
        {
          type: "category",
          axisTick: { show: false }
          // data: ["2012", "2013", "2014", "2015", "2016"]
        }
      ],
      yAxis: [
        {
          type: "value"
        }
      ],
      series: [
        {
          name: "Forest",
          type: "bar",
          barGap: 0,
          // label: labelOption,
          // data: [320, 332, 301, 334, 390],
          data: data1 // 含有，X的值
        },
        {
          name: "Steppe",
          type: "bar",
          // label: labelOption,
          // data: [220, 182, 191, 234, 290]
          data: data2
        }
      ]
    });
    this.timer = setInterval(function() {
      // for (var i = 0; i < 1; i++) {
      data1.shift();

      data1.push(randomData("valueData1"));
      data2.shift();
      data2.push(randomData("valueData2"));
      console.log("data1__1", data1);
      console.log("data2__2", data2);

      // console.log("testDATA", data);
      // }
      myChart.setOption({
        series: [
          {
            data: data1
          },
          {
            data: data2
          }
        ]
      });
    }, 6000);
  }

  // componentDidUpdate() {
  //   // 项目中未渲染
  //   console.log("componentDidUpdate");
  //   this.queryData();
  // }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    console.log("echarts");
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        <Row span={12}>
          <div
            id="myChart"
            ref="lineChart"
            style={{ Width: "100%", height: "200px" }}
            // backgroundColor: "#24397e"
          />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
