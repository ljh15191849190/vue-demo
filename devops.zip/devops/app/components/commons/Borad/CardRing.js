import React, { Component } from "react";
import { Row, Col } from "antd";
const echarts = require("echarts");

export default class CardRing extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.drawChart = this.drawChart.bind(this);
  }

  componentDidMount() {
    this.drawChart();
  }
  drawChart() {
    const { title, value, colors } = this.props;

    const chart = echarts.init(this.refs.cardRing);
    const color = `linear-gradient(to right,${colors[0]},${colors[1]})`;

    const option = {
      background: color,
      color: ["rgba(255,255,255,0.7)", "rgba(255,255,255,0.4)"],
      tooltip: {
        // trigger: "item",
        // formatter: "{b}: {c} ({d}%)"
      },
      grid: {
        left: 10
      },
      series: [
        {
          name: title || "",
          type: "pie",
          center: ["40%", "50%"],
          radius: ["40%", "60%"],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: true,
              color: "#fff",
              position: "outter",
              formatter: "{b}:{c}"
            }
          },
          labelLine: {
            normal: {
              show: true
            }
          },
          data: value
        }
      ]
    };
    chart.setOption(option);
  }

  render() {
    const { title, colors, backgroundImg } = this.props;

    const styles = {
      navItem: {
        position: "relative",
        top: 0,
        left: 35,
        height: 140,
        width: 410,
        // display: "flex",
        // alignItems: "center",
        // justifyContent: "flex-start",
        color: "#fff"
      },
      container: {
        height: 158,
        borderRadius: 8,
        // background: `linear-gradient(to right,${colors[0]},${colors[1]})`
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "100% 100%"
      },
      title: {
        display: "inline-block",
        paddingTop: 16,
        paddingLeft: 16,
        fontSize: 16,
        color: "#fff"
      }
    };
    return (
      <Row style={styles.container}>
        {/* <Col span={23}>
          <span style={styles.title}>{title}</span>
        </Col> */}
        <Col span={24} style={styles.navItem}>
          <div id="myChart" ref="cardRing" style={{ width: "100%", height: "100%" }} />
        </Col>
        <Col />
      </Row>
    );
  }
}
