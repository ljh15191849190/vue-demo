import React, { Component } from "react";
import { Row, Col } from "antd";

export default class Board extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const navigations = [
      {
        img: "/images/dashboard/component.png",
        title: "组件数量",
        color: "#f8623b",
        count: "30"
      },
      {
        img: "/images/dashboard/component.png",
        title: "运行实例树",
        color: "#37D1AB",
        count: "120"
      },
      {
        img: "/images/dashboard/component.png",
        title: "构建次数",
        color: "#ffa001",
        count: "160"
      },
      {
        img: "/images/dashboard/component.png",
        title: "部署次数",
        color: "#42C0EA",
        count: "69"
      }
    ];
    const { navigation } = this.props;
    const styles = {
      navItem: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#fff"
      },
      imgWrap: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "62px",
        height: "62px",
        borderRadius: "50%",
        background: "#fff"
      },
      img: {
        width: "30px"
      },
      infoWrap: {
        display: "flex",
        flexDirection: "column",
        marginLeft: "15px"
      },
      count: {
        fontWeight: "bold",
        fontSize: "25px",
        margin: "0"
      },
      title: {
        margin: "2px 0"
      }
    };

    return (
      <Row gutter={20}>
        {navigation.map((item, index) => {
          return (
            <Col xs={12} lg={6} key={Math.random()}>
              <div style={{ background: item.color, borderRadius: 6, padding: 20 }}>
                <div style={styles.navItem}>
                  <div style={styles.imgWrap}>
                    <img src={item.img} alt="" style={styles.img} />
                  </div>
                  <div style={styles.infoWrap}>
                    <p style={styles.count}>{item.count}</p>
                    <span style={styles.title}>{item.title}</span>
                  </div>
                </div>
              </div>
            </Col>
          );
        })}
      </Row>
    );
  }
}
