import React from "react";
import { Row, Col } from "antd";
import total from "../../../assets/images/bigScreen/total.png";
import underway from "../../../assets/images/bigScreen/underway.png";
import complete from "../../../assets/images/bigScreen/complete.png";
import unsolve from "../../../assets/images/bigScreen/unsolve.png";
import solved from "../../../assets/images/bigScreen/solved.png";

const echarts = require("echarts");

class PieChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };

    const { height, typeData } = props;
    const dataJsonComplete = [
      // { value: 0, name: "总计" },
      { value: 18, name: "进行中" },
      { value: 20, name: "已完成" }
    ];
    const dataJsonDefective = [{ value: 8, name: "待解决" }, { value: 18, name: "已解决" }];

    this.dataJson = typeData === "dataJsonComplete" ? dataJsonComplete : dataJsonDefective;
    this.titleText = typeData === "dataJsonComplete" ? "完成率" : "解决率";
    this.colorListArray =
      typeData === "dataJsonComplete" ? ["#86fe9d", "#acc7dd"] : ["#2ef5c4", "#acc7dd"];
  }

  query() {
    const myChart = echarts.init(this.refs.PieChart);

    const option = {
      tooltip: { trigger: "item", formatter: "{a} <br/>{b}: {c} ({d}%)" },
      grid: { left: "center", top: "middle", containLabel: true },
      series: [
        {
          name: "",
          type: "pie",
          center: ["50%", "50%"],
          radius: ["50%", "85%"],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: true,
              position: "center",
              formatter: argument => {
                const arrays = option.series[0].data;
                let value = 0;
                let totalData = arrays[0].value + arrays[1].value;

                for (let i = 0; i < arrays.length; i++) {
                  let typeName = arrays[i].name;
                  value += arrays[i].value;
                  const division = (arrays[i].value / value) * 100;
                  if (typeName == argument) {
                    return `${typeName}\r\r\r\r${
                      arrays[i].value > 9 ? arrays[i].value : `  ${arrays[i].value}`
                    }\r\r\r\r${(division * 100).toFixed(2)}%`;
                  }
                }
                const completeRate = (arrays[1].value / totalData) * 100;
                return ` ${value ? `${completeRate.toFixed(2)}%` : 0}\n\n${this.titleText}`;
              },
              textStyle: { fontSize: 14, color: "#fff" }
            },
            emphasis: { show: true, textStyle: { fontWeight: "bold" } }
          },
          labelLine: { normal: { show: true } },
          data: this.dataJson,
          itemStyle: {
            normal: {
              // 随机显示
              // color:function(d){return "#"+Math.floor(Math.random()*(256*256*256-1)).toString(16);}
              // 定制显示（按顺序）
              color: params => {
                // const colorList = ["#73fac2", "#fe9999"];
                const colorList = this.colorListArray;
                return colorList[params.dataIndex];
              }
            }
          }
        }
      ]
    };
    myChart.setOption(option);
  }

  componentDidUpdate() {
    this.query();
  }

  componentDidMount() {
    this.query();
  }

  render() {
    const { typeData } = this.props;
    return (
      <div>
        <Row>
          <Col span={11}>
            {/* <div style={{ position: "relative" }}> */}
            <div id="myChart" ref="PieChart" style={{ width: "100%", height: "150px" }} />
            {/* </div> */}
          </Col>
          <Col span={13}>
            <div
              style={
                {
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-around"
                } // padding: "10px",
              }
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center"
                }}
              >
                <img
                  style={{ width: "100%" }}
                  src={require("../../../assets/images/bigScreen/total.png")}
                />
                <p style={{ fontSize: "14px", color: "#ccc", padding: "5px 0" }}>总计</p>
                <p style={{ fontSize: "14px", color: "#6587f6" }}>
                  {Number(this.dataJson[0].value) + Number(this.dataJson[1].value)}
                </p>
              </div>
              <div
                style={
                  {
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    height: "150px"
                  } // padding: "10px",
                }
              >
                <img
                  style={{ width: "30px", height: "30px" }}
                  src={
                    typeData === "dataJsonComplete"
                      ? require("../../../assets/images/bigScreen/underway.png")
                      : require("../../../assets/images/bigScreen/unsolve.png")
                  }
                />
                <p style={{ fontSize: "14px", color: "#ccc", padding: "5px 0" }}>
                  {this.dataJson[0].name}
                </p>
                <p
                  style={{
                    fontSize: "14px",
                    color: typeData === "dataJsonComplete" ? "#8addfc" : "#fcbd4d"
                  }}
                >
                  {Number(this.dataJson[0].value)}
                </p>
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center"
                }}
              >
                <img
                  style={{ width: "30px", height: "30px" }}
                  src={
                    typeData === "dataJsonComplete"
                      ? require("../../../assets/images/bigScreen/complete.png")
                      : require("../../../assets/images/bigScreen/solved.png")
                  }
                />
                <p style={{ fontSize: "14px", color: "#ccc", padding: "5px 0" }}>
                  {this.dataJson[1].name}
                </p>
                <p style={{ fontSize: "14px", color: "#2ef5c4" }}>
                  {Number(this.dataJson[1].value)}
                </p>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    );
  }
}
export default PieChart;
