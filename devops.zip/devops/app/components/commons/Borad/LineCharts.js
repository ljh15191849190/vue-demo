import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Carousel, Divider, Dropdown, Icon, Menu, Button } from "antd";

const echarts = require("echarts");

class LineCharts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    const { text, Linecolor } = this.props;
    // const datas = this.props.datas;
    const datas = [
      { time: "2018-12-30", Value: 50 },
      { time: "2018-12-29", Value: 120 },
      { time: "2018-12-28", Value: 300 },
      { time: "2018-12-27", Value: 30 },
      { time: "2018-12-26", Value: 160 },
      { time: "2018-12-25", Value: 60 },
      { time: "2018-12-24", Value: 80 },
      { time: "2018-12-23", Value: 200 },
      { time: "2018-12-22", Value: 300 },
      { time: "2018-12-21", Value: 80 }
    ];
    function randomData() {
      if (currentIndex === datas.length) {
        currentIndex = 0;
        data = [];
        for (var i = 0; i < 5; i++) {
          data.push(randomData());
        }
      } else {
        const Index = currentIndex;
        currentIndex = currentIndex + 1;
        return {
          value: [
            [
              new Date(datas[Index].time).getFullYear(),
              new Date(datas[Index].time).getMonth() + 1,
              new Date(datas[Index].time).getDate()
            ].join("/"),
            datas[Index].Value
          ]
        };
      }
    }

    var data = [];
    var currentIndex = 0;
    for (var i = 0; i < 5; i++) {
      data.push(randomData());
    }

    myChart.setOption({
      grid: {
        left: "2%",
        right: "4%",
        bottom: "1%",
        containLabel: true
      },
      tooltip: {
        trigger: "axis",
        // formatter: function(params) {
        //   params = params[0];
        //   var date = new Date(params.name);
        //   return (
        //     date.getDate() +
        //     "/" +
        //     (date.getMonth() + 1) +
        //     "/" +
        //     date.getFullYear() +
        //     " : " +
        //     params.value[1]
        //   );
        // },
        axisPointer: {
          animation: false
        }
      },
      xAxis: {
        type: "time",
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: false
        }
      },
      title: {
        text: text,
        padding: [25, 0, 0, 0],
        textStyle: {
          fontStyle: "normal",
          color: "#8bebf9",
          fontSize: 12
        }
      },
      yAxis: {
        type: "value",
        // boundaryGap: [0, "100%"],
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: {
          margin: 10
        },
        splitLine: {
          show: false
        }
      },
      series: [
        {
          // name: "模拟数据",
          type: "bar",
          barWidth: 20,
          barGap: "10",
          barCategoryGap: "20",
          showSymbol: false,
          hoverAnimation: false,
          data: data,
          itemStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 1, color: Linecolor.bottomColor },
                { offset: 0, color: Linecolor.topColor }
              ])
            }
          }
        }
      ]
    });
    this.timer = setInterval(function() {
      for (var i = 0; i < 5; i++) {
        data.shift();
        data.push(randomData());
      }

      myChart.setOption({
        series: [
          {
            data: data
          }
        ]
      });
    }, 3000);
  }

  componentDidUpdate() {
    console.log("componentDidUpdate");
    this.queryData();
  }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
    // 调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    // this.props.actions.sceneEvaluateRate(this.state.queryParam);
    // let visualMonitorListCPU = this.props.visualMonitorListDataCPU.get("visualMonitorListCPU");
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
  render() {
    const { width, height } = this.props;
    return (
      <div>
        <div
          id="myChart"
          ref="lineChart"
          style={{ width: width ? width : "100%", height: height ? height : "100%" }}
          // backgroundColor: "#24397e"
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};
const mapDispatchToProps = dispatch => {
  return {
    //   actions: bindActionCreators(projectAction, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineCharts);
