// 动态数据 + 时间坐标轴;
// 注意X轴数据的类型，及数据的规律性
import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
const echarts = require("echarts");
const dataJson = [
  { xTime: 1543795200000, yValue: 25 }, // 4
  { xTime: 1543881600000, yValue: 6 }, // 5
  { xTime: 1543968000000, yValue: 27 }, // 6
  { xTime: 1544054400000, yValue: 13 }, // 7
  { xTime: 1544140800000, yValue: 22 }, // 8
  { xTime: 1544227200000, yValue: 30 }, // 9
  { xTime: 1544313600000, yValue: 21 }, // 10
  { xTime: 1544400000000, yValue: 32 }, // 11
  { xTime: 1544572800000, yValue: 8 }, // 12
  { xTime: 1544659200000, yValue: 36 }, // 13
  { xTime: 1544745600000, yValue: 26 }, // 14
  { xTime: 1544832000000, yValue: 33 } // 15
];
class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    function randomData() {
      const maxLength = dataJson.length;
      if (currentIndex === maxLength) {
        currentIndex = 0;
        // 因为时间轴问题   重新取数据
        data = [];
        // 初始化页面值
        for (var i = 0; i < 5; i++) {
          data.push(randomData());
        }
      } else {
        // 取用当前的数据值
        const thisIndex = currentIndex;
        // 每次改变索引值
        currentIndex = currentIndex + 1;
        return {
          name: new Date(dataJson[thisIndex].xTime).toString(),
          value: [
            [
              new Date(dataJson[thisIndex].xTime).getFullYear(),
              new Date(dataJson[thisIndex].xTime).getMonth() + 1,
              new Date(dataJson[thisIndex].xTime).getDate()
            ].join("/"),
            dataJson[thisIndex].yValue
          ]
        };
      } // value: dataJson[currentIndex].yValue // y轴的显示值
    }

    var data = [];
    var currentIndex = 0;
    for (let i = 0; i < 5; i++) {
      data.push(randomData());
    }

    myChart.setOption({
      title: {
        text: "代码提交趋势",
        textStyle: {
          fontFamily: "Microsoft YaHei",
          fontWeight: 500,
          fontSize: 14,
          // fontWeight: "normal",
          color: "rgb(139, 235, 249)"
        }
      },
      grid: {
        left: "3%",
        right: "6%",
        top: 40,
        bottom: "3%",
        containLabel: true
      },
      tooltip: {
        trigger: "axis",
        formatter: function(params) {
          params = params[0];
          var date = new Date(params.name);
          return (
            date.getDate() +
            "/" +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear() +
            " : " +
            params.value[1]
          );
        },
        axisPointer: {
          animation: false
        }
      },
      xAxis: {
        type: "time",
        axisLabel: { color: "#6777a8" },
        nameTextStyle: {
          color: "#6777a8"
        },
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: false
        }
      },
      yAxis: {
        type: "value",
        boundaryGap: [0, "100%"],
        splitNumber: 3,
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: { color: "#6777a8" },
        splitLine: {
          show: true,
          lineStyle: {
            type: "dashed",
            color: "#6777a8"
          }
        }
      },
      series: [
        {
          name: "模拟数据",
          type: "line",
          showSymbol: false,
          hoverAnimation: false,
          data: data,
          smooth: true,
          lineStyle: { color: "#fa9797" },
          areaStyle: {
            // 线性渐变，前四个参数分别是 x0, y0, x2, y2, 范围从 0 - 1，相当于在图形包围盒中的百分比，如果 globalCoord 为 `true`，则该四个值是绝对的像素位置
            color: {
              type: "linear",
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                {
                  offset: 0,
                  color: "#f3e817" // 0% 处的颜色
                },
                {
                  offset: 1,
                  color: "#a3c0fc" // 100% 处的颜色
                }
              ],
              global: false // 缺省为 false
            }
          }
        }
      ]
    });
    this.timer = setInterval(function() {
      // for (var i = 0; i < 1; i++) {
      data.shift();
      data.push(randomData());
      // }
      myChart.setOption({
        series: [
          {
            data: data
          }
        ]
      });
    }, 6000);
  }

  // componentDidUpdate() {
  //   // 项目中未渲染

  //   this.queryData();
  // }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    this.queryData();
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    return (
      <div style={{ padding: "10px 15px" }}>
        <Row span={12}>
          <div id="myChart" ref="lineChart" style={{ height: this.props.height }} />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
