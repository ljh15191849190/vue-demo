import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col, Card, Carousel, Divider, Dropdown, Icon, Menu, Button } from "antd";

const echarts = require("echarts");

class LineCharts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    const { text, Linecolor } = this.props;
    // const datas = this.props.datas;
    const dataJson = [
      { xTime: "2018-12-30", yValue: [12, 50] },
      { xTime: "2018-12-29", yValue: [30, 80] },
      { xTime: "2018-12-28", yValue: [30, 100] },
      { xTime: "2018-12-27", yValue: [8, 120] },
      { xTime: "2018-12-26", yValue: [45, 150] },
      { xTime: "2018-12-25", yValue: [12, 180] },
      { xTime: "2018-12-24", yValue: [44, 130] },
      { xTime: "2018-12-23", yValue: [16, 100] },
      { xTime: "2018-12-22", yValue: [32, 80] },
      { xTime: "2018-12-21", yValue: [20, 90] }
    ];
    function randomData(typeData) {
      let maxLength = dataJson.length;
      if (typeData == "valueData1") {
        if (currentIndex1 == maxLength) {
          currentIndex1 = 0;
          data1 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data1.push(randomData("valueData1"));
          }
        } else {
          // 取用当前的数据值
          const thisIndex1 = currentIndex1;
          // 每次改变索引值
          currentIndex1 = currentIndex1 + 1;
          return {
            value: [
              [
                new Date(dataJson[thisIndex1].xTime).getFullYear(),
                new Date(dataJson[thisIndex1].xTime).getMonth() + 1,
                new Date(dataJson[thisIndex1].xTime).getDate()
              ].join("/"),
              dataJson[thisIndex1].yValue[0]
            ]
          };
        }
      } else if (typeData == "valueData2") {
        if (currentIndex2 == maxLength) {
          currentIndex2 = 0;
          data2 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data2.push(randomData("valueData2"));
          }
        } else {
          // 取用当前的数据值
          const thisIndex2 = currentIndex2;
          // 每次改变索引值
          currentIndex2 = currentIndex2 + 1;
          return {
            value: [
              [
                new Date(dataJson[thisIndex2].xTime).getFullYear(),
                new Date(dataJson[thisIndex2].xTime).getMonth() + 1,
                new Date(dataJson[thisIndex2].xTime).getDate()
              ].join("/"),
              dataJson[thisIndex2].yValue[1]
            ]
          };
        }
      }
    }

    var data1 = [];
    var data2 = [];
    var currentIndex1 = 0;
    var currentIndex2 = 0;
    for (let i = 0; i < 5; i++) {
      data1.push(randomData("valueData1"));
      data2.push(randomData("valueData2"));
    }

    myChart.setOption({
      grid: {
        left: "2%",
        right: "4%",
        bottom: "1%",
        containLabel: true
      },
      tooltip: {
        trigger: "axis",
        formatter: function(params) {
          params = params[0];
          var date = new Date(params.name);
          return (
            date.getDate() +
            "/" +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear() +
            " : " +
            params.value[1]
          );
        },
        axisPointer: {
          animation: false
        }
      },
      legend: {
        x: "56%",
        y: "10%",
        // itemGap: 50,
        data: ["Forest", "Steppe"],
        textStyle: {
          color: "#f9f9f9",
          borderColor: "#fff"
        }
      },
      title: {
        text: text,
        padding: [20, 0, 0, 0],
        textStyle: {
          fontStyle: "normal",
          color: "#8bebf9",
          fontSize: 12
        }
      },
      xAxis: {
        type: "time",
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: false
        }
      },

      yAxis: {
        type: "value",
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: "次数",
          type: "bar",
          barWidth: 20,
          showAllSymbol: true,
          symbol: "emptyCircle",
          symbolSize: 6,
          lineStyle: {
            normal: {
              color: "#28ffb3" // 线条颜色
            },
            borderColor: "#f0f"
          },
          label: {
            show: true,
            position: "top",
            textStyle: {
              color: "#fff"
            }
          },
          // itemStyle: {
          //   normal: {
          //     color: "#28ffb3"
          //   }
          // },
          itemStyle: {
            normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 1, color: Linecolor.bottomColor },
                { offset: 0, color: Linecolor.topColor }
              ])
            }
          },
          tooltip: {
            show: false
          },
          areaStyle: {
            //区域填充样式
            normal: {
              //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                0,
                1,
                [
                  {
                    offset: 0,
                    color: "rgba(0,154,120,1)"
                  },
                  {
                    offset: 1,
                    color: "rgba(0,0,0, 0)"
                  }
                ],
                false
              ),
              shadowColor: "rgba(53,142,215, 0.9)", //阴影颜色
              shadowBlur: 20 //shadowBlur设图形阴影的模糊大小。配合shadowColor,shadowOffsetX/Y, 设置图形的阴影效果。
            }
          },
          data: data1 // 含有，X的值
        },
        {
          name: "成功率",
          type: "line",
          showAllSymbol: true,
          symbol: "emptyCircle",
          symbolSize: 6,
          lineStyle: {
            normal: {
              color: "#28ffb3", // 线条颜色,
              width: 1 // 线条宽,
            },
            borderColor: "#f0f"
          },
          label: {
            show: true,
            position: "top",
            textStyle: {
              color: "#fff"
            }
          },
          itemStyle: {
            normal: {
              color: "#28ffb3"
            }
          },
          tooltip: {
            show: false
          },
          areaStyle: {
            //区域填充样式
            normal: {
              //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                0,
                1,
                [
                  {
                    offset: 0,
                    color: "rgba(0,154,120,1)"
                  },
                  {
                    offset: 1,
                    color: "rgba(0,0,0, 0)"
                  }
                ],
                false
              ),
              shadowColor: "rgba(53,142,215, 0.9)", //阴影颜色
              shadowBlur: 20 //shadowBlur设图形阴影的模糊大小。配合shadowColor,shadowOffsetX/Y, 设置图形的阴影效果。
            }
          },
          data: data2
        }
      ]
    });
    this.timer = setInterval(function() {
      for (var i = 0; i < 5; i++) {
        data1.shift();
        data1.push(randomData("valueData1"));
        data2.shift();
        data2.push(randomData("valueData2"));
      }

      myChart.setOption({
        series: [
          {
            data: data1
          },
          {
            data: data2
          }
        ]
      });
    }, 3000);
  }

  componentDidUpdate() {
    console.log("componentDidUpdate");
    this.queryData();
  }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
    // 调用redux中action中的ajax方法，调用相对应的java的方法获取返回数据
    // this.props.actions.sceneEvaluateRate(this.state.queryParam);
    // let visualMonitorListCPU = this.props.visualMonitorListDataCPU.get("visualMonitorListCPU");
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
  render() {
    const { width, height } = this.props;
    return (
      <div>
        <div
          id="myChart"
          ref="lineChart"
          style={{ width: width ? width : "100%", height: height ? height : "100%" }}
          // backgroundColor: "#24397e"
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};
const mapDispatchToProps = dispatch => {
  return {
    //   actions: bindActionCreators(projectAction, dispatch)
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineCharts);
