import React from "react";
import { Row, Col } from "antd";

const echarts = require("echarts");

class ColumnChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    const { x, y, title, type } = this.props;
    const yplus = y.map(item => Number(item) - 2);
    let seriesData = [];
    if (type == "showDashbook") {
      seriesData = [
        {
          name: "",
          type: "bar",
          barWidth: 60,
          barGap: "-100%",
          data: y ? y : []
        },
        {
          name: "",
          type: "bar",
          barWidth: 60,
          data: yplus ? yplus : [],
          itemStyle: {
            normal: {
              color: "#71defc"
            },
            emphasis: {
              color: "#71defc"
            }
          }
        }
      ];
    } else {
      seriesData = [
        {
          name: "",
          type: "bar",
          barWidth: 60,
          data: y ? y : [],
          itemStyle: {
            normal: {
              color: "rgba(113,222,253,0.38)"
            }
          }
        }
      ];
    }
    const myChart = echarts.init(this.refs.lineChart);
    myChart.setOption({
      // 柱状图头信息
      title: {
        text: title ? title : "",
        textStyle: {
          fontStyle: "normal",
          fontWeight: "lighter",
          fontFamily: "san-serif",
          fontSize: 14
        }
      },
      tooltip: {
        trigger: "axis",
        formatter: "{b} {a}: {c}"
      },
      color: ["#1195f4", "#71defc"],
      grid: {
        left: "4%",
        right: "4%",
        bottom: "4%",
        containLabel: true
      },
      xAxis: {
        data: x ? x : [],
        type: "category",
        axisLine: {
          show: true,
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: {
          color: "#6777a8"
        }
      },
      yAxis: {
        name: "单位/秒",
        type: "value",
        splitLine: {
          show: true,
          lineStyle: {
            type: "dashed",
            color: "#6777a8"
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#6777a8"
          }
        },
        axisLabel: {
          color: "#6777a8" // 坐标字体
        }
      },
      series: seriesData ? seriesData : []
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return (
      <Row>
        <Col span={24}>
          <div id="myChart" ref="lineChart" style={{ width: "100%", height }} />
        </Col>
      </Row>
    );
  }
}
export default ColumnChart;
