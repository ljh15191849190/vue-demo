// 动态数据 + 时间坐标轴;
// 注意X轴数据的类型，及数据的规律性
import React from "react";
import { connect } from "react-redux";
const echarts = require("echarts");
const dataJson = [
  { xTime: "2018-12-03", yValue: [8, 7] },
  { xTime: "2018-12-04", yValue: [9, 8] },
  { xTime: "2018-12-05", yValue: [2, 1] },
  { xTime: "2018-12-06", yValue: [9, 8] },
  { xTime: "2018-12-07", yValue: [9, 5] },
  { xTime: "2018-12-08", yValue: [4, 5] },
  { xTime: "2018-12-09", yValue: [6, 5] },
  { xTime: "2018-12-10", yValue: [3, 2] },
  { xTime: "2018-12-11", yValue: [5, 5] },
  { xTime: "2018-12-12", yValue: [1, 1] }
];
class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);

    var data1 = [];
    var data2 = [];
    var currentIndex1 = 0;
    var currentIndex2 = 0;
    for (let i = 0; i < 5; i++) {
      data1.push(randomData("valueData1"));
      data2.push(randomData("valueData2"));
    }

    function randomData(typeData) {
      let maxLength = dataJson.length;
      if (typeData == "valueData1") {
        if (currentIndex1 == maxLength) {
          currentIndex1 = 0;
          data1 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data1.push(randomData("valueData1"));
          }
        } else {
          // 取用当前的数据值
          const thisIndex1 = currentIndex1;
          // 每次改变索引值
          currentIndex1 = currentIndex1 + 1;
          return {
            value: [
              [
                new Date(dataJson[thisIndex1].xTime).getFullYear(),
                new Date(dataJson[thisIndex1].xTime).getMonth() + 1,
                new Date(dataJson[thisIndex1].xTime).getDate()
              ].join("/"),
              dataJson[thisIndex1].yValue[0]
            ]
          };
        }
      } else if (typeData == "valueData2") {
        if (currentIndex2 == maxLength) {
          currentIndex2 = 0;
          data2 = [];
          // 初始化页面值
          for (var i = 0; i < 5; i++) {
            data2.push(randomData("valueData2"));
          }
        } else {
          // 取用当前的数据值
          const thisIndex2 = currentIndex2;
          // 每次改变索引值
          currentIndex2 = currentIndex2 + 1;
          return {
            value: [
              [
                new Date(dataJson[thisIndex2].xTime).getFullYear(),
                new Date(dataJson[thisIndex2].xTime).getMonth() + 1,
                new Date(dataJson[thisIndex2].xTime).getDate()
              ].join("/"),
              dataJson[thisIndex2].yValue[1]
            ]
          };
        }
      }
    }

    myChart.setOption({
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow"
        }
      },
      title: {
        text: "迭代新增/解决缺陷",
        left: 15,
        textStyle: {
          fontFamily: "Microsoft YaHei",
          fontWeight: 500,
          fontSize: 14,
          // fontWeight: "normal",
          color: "rgb(139, 235, 249)"
        }
      },
      legend: {
        right: "5%",
        itemGap: 38,
        itemWidth: 14,
        itemHeight: 14,
        textStyle: { color: "#ccc" },
        data: [
          {
            name: "新增缺陷"
          },
          {
            name: "解决缺陷"
          }
        ]
      },
      grid: {
        left: "3%",
        right: "4%",
        top: 40,
        bottom: "3%",
        containLabel: true
      },

      xAxis: {
        type: "time",
        axisTick: { show: false },
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: false
        }
      },
      yAxis: {
        type: "value",
        boundaryGap: [0, "100%"],
        splitNumber: 3,
        axisLine: {
          lineStyle: {
            color: "#6777a8"
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            type: "dashed",
            color: "#6777a8"
          }
        }
      },
      series: [
        {
          name: "新增缺陷",
          type: "bar",
          barGap: 0,
          barWidth: 15,
          showAllSymbol: true,
          symbol: "emptyCircle",
          symbolSize: 6,
          lineStyle: {
            normal: {
              color: "#28ffb3"
            },
            borderColor: "#f0f"
          },
          label: {
            show: false,
            position: "top",
            textStyle: {
              color: "#fff"
            }
          },

          tooltip: {
            show: false
          },
          itemStyle: {
            color: "#fa9797"
          },
          data: data1 // 含有，X的值
        },
        {
          name: "解决缺陷",
          type: "bar",
          barGap: 0,
          barWidth: 15,
          tooltip: {
            show: false
          },
          label: {
            show: false,
            position: "top",
            textStyle: {
              color: "#fff"
            }
          },
          itemStyle: {
            normal: {
              color: "#a5f8e0"
            }
          },
          data: data2
        }
      ]
    });
    this.timer = setInterval(function() {
      for (var i = 0; i < 5; i++) {
        data1.shift();
        data1.push(randomData("valueData1"));
        data2.shift();
        data2.push(randomData("valueData2"));
      }
      myChart.setOption({
        series: [
          {
            data: data1
          },
          {
            data: data2
          }
        ]
      });
    }, 3000);
  }

  componentDidUpdate() {
    // 项目中未渲染
    this.queryData();
  }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    this.queryData();
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    return (
      <div>
        <div
          id="myChart"
          ref="lineChart"
          style={{ Width: "100%", height: "200px" }}
          // backgroundColor: "#24397e"
        />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
