import React, { Component } from "react";
import { Row, Col } from "antd";

const echarts = require("echarts");

export default class CardBar extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.drawChart = this.drawChart.bind(this);
  }

  componentDidMount() {
    this.drawChart();
  }

  drawChart() {
    const { title, x, y, colors } = this.props;

    const chart = echarts.init(this.refs.cardBar);
    const color = `linear-gradient(to right,${colors[0]},${colors[1]})`;

    chart.setOption({
      background: color,
      // 柱状图头信息
      title: {
        textStyle: {
          fontStyle: "normal",
          fontWeight: "lighter",
          fontFamily: "san-serif",
          fontSize: 14
        }
      },
      tooltip: {},
      grid: {
        left: "4%",
        right: "4%",
        bottom: "4%",
        containLabel: true
      },
      xAxis: [
        {
          show: false,
          data: x,
          splitLine: {
            show: false
          }
        }
      ],
      yAxis: {
        name: "",
        show: false,
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: "",
          type: "bar",
          barWidth: 30,
          data: y,
          itemStyle: {
            normal: {
              color: "rgba(255, 255, 255, 0.36)"
            }
          }
        }
      ]
    });
  }

  render() {
    const { title, colors, count, backgroundImg } = this.props;

    const styles = {
      navItem: {
        height: "100%",
        // display: "flex",
        // alignItems: "center",
        // justifyContent: "flex-start",
        color: "#fff",
        position: "relative",
        top: "-75px"
      },
      grid: {
        left: "1%",
        right: "1%",
        bottom: "1%",
        containLabel: true
      },
      container: {
        height: 158,
        borderRadius: 8,
        // background: `linear-gradient(to right,${colors[0]},${colors[1]})`
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "100% 100%"
      },
      title: {
        fontSize: 14,
        marginLeft: 30,
        color: "#fff"
      },
      count: {
        fontSize: 24,
        color: "#fff",
        marginLeft: 30,
        marginTop: 10
      }
    };

    return (
      <Row style={styles.container}>
        <Col span={20}>
          <div style={styles.count}>{count}</div>
          <div style={styles.title}>{title}</div>
        </Col>

        {/* <Col span={4} style={{ height: 42 }}>
          <img src={picUrl} style={{ width: 42, height: 42, position: "relative", top: "22px" }} />
        </Col> */}
        <Col span={24} style={styles.navItem}>
          <div id="myChart" ref="cardBar" style={{ width: "100%", height: "100%" }} />
        </Col>
      </Row>
    );
  }
}
