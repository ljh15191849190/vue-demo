import React from "react";

const echarts = require("echarts");

class ColumnChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    const { x, y, unit, legendData } = this.props;
    const myChart = echarts.init(this.refs.lineChart);
    myChart.setOption({
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      legend: {
        data: legendData
      },
      // toolbox: {
      //   show: true,
      //   orient: "vertical",
      //   left: "right",
      //   top: "center",
      //   feature: {
      //     // mark: { show: true },
      //     // dataView: { show: true, readOnly: false },
      //     magicType: { show: true, type: ["stack", "bar"] },
      //     restore: { show: true },
      //     saveAsImage: { show: true }
      //   }
      // },
      grid: {
        left: "1%",
        right: "1%",
        bottom: "3%",
        containLabel: true
      },
      xAxis: [
        {
          type: "category",
          data: x
          // name: "时间"
        }
      ],

      yAxis: {
        type: "value",
        name: unit ? unit : ""
      },
      series: y
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return <div id="myChart" ref="lineChart" style={{ width: "100%", height }} />;
  }
}
export default ColumnChart;
