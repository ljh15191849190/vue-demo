import React from "react";
import { Row, Col } from "antd";

const echarts = require("echarts");

class ColumnChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    const { x, y, title, type } = this.props;
    const yplus = y.map(item => Number(item) - 2);
    let seriesData = [];
    if (type == "showDashbook") {
      seriesData = [
        {
          name: "",
          type: "bar",
          barWidth: 60,
          barGap: "-100%",
          data: y ? y : []
        },
        {
          name: "",
          type: "bar",
          barWidth: 60,
          data: yplus ? yplus : [],
          itemStyle: {
            normal: {
              color: "#71defc"
            },
            emphasis: {
              color: "#71defc"
            }
          }
        }
      ];
    } else {
      seriesData = [
        {
          name: "",
          type: "bar",
          barWidth: 60,
          data: y ? y : [],
          itemStyle: {
            normal: {
              // 随机显示
              // color:function(d){return "#"+Math.floor(Math.random()*(256*256*256-1)).toString(16);}
              // 定制显示（按顺序）
              color: params => {
                const colorList = ["#ff0000", "#f74242", "#f76565", "#f78f8f", "#f4abab"];
                return colorList[params.dataIndex];
              }
            }
          }
        }
      ];
    }
    const myChart = echarts.init(this.refs.lineChart);
    myChart.setOption({
      // 柱状图头信息
      title: {
        text: title ? title : "",
        textStyle: {
          fontStyle: "normal",
          fontWeight: "lighter",
          fontFamily: "san-serif",
          fontSize: 14
        }
      },
      tooltip: {
        trigger: "axis",
        formatter: "{b} {a}: {c}"
      },
      color: ["#1195f4", "#71defc"],
      grid: {
        left: "4%",
        right: "4%",
        bottom: "4%",
        containLabel: true
      },
      xAxis: {
        data: x ? x : []
      },
      yAxis: [
        {
          name: "单位/秒"
        }
      ],
      series: seriesData ? seriesData : []
    });
  }

  componentDidMount() {
    this.query();
  }

  componentDidUpdate() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return (
      <Row>
        <Col span={24}>
          <div id="myChart" ref="lineChart" style={{ width: "100%", height }} />
        </Col>
      </Row>
    );
  }
}
export default ColumnChart;
