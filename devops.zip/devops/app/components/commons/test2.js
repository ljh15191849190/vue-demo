// 动态数据 + 时间坐标轴;
// 注意X轴数据的类型，及数据的规律性
import React from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { Row, Col } from "antd";
import * as action from "../../actions/maitananceManageAction";
const echarts = require("echarts");
const dataJson = [
  { xTime: 875894400000, yValue: 256.23 }, // 4
  { xTime: 875980800000, yValue: 66.23 }, // 5
  { xTime: 876067200000, yValue: 276.23 }, // 6
  { xTime: 876153600000, yValue: 283.23 }, // 7
  { xTime: 876240000000, yValue: 292.23 }, // 8
  { xTime: 876326400000, yValue: 306.23 }, // 9
  { xTime: 876412800000, yValue: 216.23 }, // 10
  { xTime: 876499200000, yValue: 326.23 }, // 11
  { xTime: 876585600000, yValue: 86.23 }, // 12
  { xTime: 876672000000, yValue: 386.23 }, // 13
  { xTime: 876758400000, yValue: 166.23 }, // 14
  { xTime: 876844800000, yValue: 336.23 } // 15
];
class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.queryData = this.queryData.bind(this);
  }
  queryData() {
    const myChart = echarts.init(this.refs.lineChart);
    function randomData() {
      const maxLength = dataJson.length;
      if (currentIndex === maxLength) {
        currentIndex = 0;
        // 因为时间轴问题   重新取数据
        data = [];
        // 初始化页面值
        for (var i = 0; i < 5; i++) {
          data.push(randomData());
        }
      } else {
        // 取用当前的数据值
        const thisIndex = currentIndex;
        // 每次改变索引值
        currentIndex = currentIndex + 1;
        return {
          name: new Date(dataJson[thisIndex].xTime).toString(),
          value: [
            [
              new Date(dataJson[thisIndex].xTime).getFullYear(),
              new Date(dataJson[thisIndex].xTime).getMonth() + 1,
              new Date(dataJson[thisIndex].xTime).getDate()
            ].join("/"),
            dataJson[thisIndex].yValue
          ]
        };
      } // value: dataJson[currentIndex].yValue // y轴的显示值
    }

    var data = [];
    var currentIndex = 0;
    for (let i = 0; i < 5; i++) {
      data.push(randomData());
    }

    myChart.setOption({
      title: {
        text: "动态数据 + 时间坐标轴"
      },
      tooltip: {
        trigger: "axis",
        formatter: function(params) {
          params = params[0];
          var date = new Date(params.name);
          return (
            date.getDate() +
            "/" +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear() +
            " : " +
            params.value[1]
          );
        },
        axisPointer: {
          animation: false
        }
      },
      xAxis: {
        type: "time",
        splitLine: {
          show: false
        }
      },
      yAxis: {
        type: "value",
        boundaryGap: [0, "100%"],
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: "模拟数据",
          type: "line",
          showSymbol: false,
          hoverAnimation: false,
          data: data
        }
      ]
    });
    this.timer = setInterval(function() {
      // for (var i = 0; i < 1; i++) {
      data.shift();
      data.push(randomData());
      // console.log("testDATA", data);
      // }
      myChart.setOption({
        series: [
          {
            data: data
          }
        ]
      });
    }, 6000);
  }

  // componentDidUpdate() {
  //   // 项目中未渲染
  //   console.log("componentDidUpdate");
  //   this.queryData();
  // }
  // 组件渲染之前调用方法获取数据
  componentDidMount() {
    console.log("componentDidMount");

    this.queryData();
  }

  componentWilUnmount() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  render() {
    const { paddingLeft } = this.props;
    console.log("echarts");
    return (
      <div style={{ paddingLeft: paddingLeft ? paddingLeft : "" }}>
        <Row span={12}>
          <div
            id="myChart"
            ref="lineChart"
            style={{ width: "805px", height: "580px" }}
            // backgroundColor: "#24397e"
          />
        </Row>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(action, dispatch) };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LineChart);

// export default LineChart;
