/**
 * 仪表盘
 */

import React from "react";
import { Col } from "antd";
const echarts = require("echarts");

class GaugeChart extends React.Component {
  constructor(props) {
    super(props);
    this.drawChart = this.drawChart.bind(this);
  }

  componentDidMount() {
    this.drawChart();
  }
  drawChart() {
    const { title, value } = this.props;

    const chart = echarts.init(this.refs.gaugeChart);

    let option = {
      tooltip: {
        formatter: "{a} <br/>{b} : {c}%"
      },
      series: [
        {
          name: title,
          type: "gauge",
          detail: { formatter: "{value}%" },
          axisLine: {
            lineStyle: {
              width: 10
            }
          },
          splitLine: {
            show: false
          },
          data: [value]
        }
      ]
    };
    chart.setOption(option);
  }
  render() {
    return (
      <div>
        <Col span={8} style={{ height: "230px" }}>
          <div id="gaugeChart" ref="gaugeChart" style={{ width: "100%", height: "100%" }} />
        </Col>
      </div>
    );
  }
}

export default GaugeChart;
