import React from "react";
import { Row, Col } from "antd";
import piegreenpoint from "../../../assets/images/login/piegreenpoint.png";
import pieredpoint from "../../../assets/images/login/pieredpoint.png";

const echarts = require("echarts");

class PieChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      number: "250"
    };
  }

  query() {
    // let data = [];
    // let obj = {}
    // if (this.props.Times) {
    //   obj.totalSuccess = this.props.Times.totalSuccess
    // }
    const myChart = echarts.init(this.refs.PieChart);
    const { Times, type } = this.props;
    let legenddata = [];
    if (type == "showDashbook") {
      legenddata = [
        {
          name: "成功",
          textStyle: {
            fontSize: 14
            // color: "#cccccc"
          },
          icon: `image://${piegreenpoint}` // circle
        },
        {
          name: "失败",
          textStyle: {
            fontSize: 14
            // color: "#cccccc"
          },
          icon: `image://${pieredpoint}`
        }
      ];
    } else {
      legenddata = ["成功", "失败"];
    }
    const option = {
      tooltip: {
        trigger: "item",
        formatter: "{a} <br/>{b}: {c} ({d}%)"
      },
      legend: {
        orient: "vertical",
        x: "46%",
        y: "30%",
        itemGap: 25,
        data: legenddata,

        formatter: name => {
          const arrays = option.series[0].data;
          let totalvalue = 0;

          for (let i = 0; i < arrays.length; i++) {
            // 名称
            const typeName = arrays[i].name;
            // 值
            const value = arrays[i].value ? parseFloat(arrays[i].value) : 0;
            totalvalue =
              parseFloat(arrays[0].value) + parseFloat(arrays[1].value) == 0
                ? 1
                : parseFloat(arrays[0].value) + parseFloat(arrays[1].value);
            const division = value / totalvalue;
            if (typeName == name) {
              return `${name}\r\r\r\r${value > 9 ? value : `  ${value}`}次\r\r\r\r${(
                division * 100
              ).toFixed(2)}%`;
              // name + "\r\r\r\r" + value + "次" + "\r\r\r\r" + (division * 100).toFixed(2) + "%"
            }
          }
        }
      },
      series: [
        {
          name: "",
          type: "pie",
          center: ["20%", "50%"],
          radius: ["40%", "70%"],
          avoidLabelOverlap: false,
          label: {
            normal: {
              show: true,
              position: "center",
              formatter: argument => {
                const arrays = option.series[0].data;
                let value = 0;
                for (let i = 0; i < arrays.length; i++) {
                  // //名称
                  // let typeName = arrays[i].name;
                  // 值
                  value += arrays[i].value;
                }
                // (value ? value : 0) + "次";
                return `${value ? value : 0}次`;
              },
              textStyle: {
                fontSize: 15,
                color: "#00c0ef"
              }
            },
            emphasis: {
              show: true,
              textStyle: {
                fontSize: "15",
                fontWeight: "bold"
              }
            }
          },
          labelLine: {
            normal: {
              show: false
            }
          },
          data: [{ value: Times.success, name: "成功" }, { value: Times.fail, name: "失败" }],
          itemStyle: {
            normal: {
              // 随机显示
              // color:function(d){return "#"+Math.floor(Math.random()*(256*256*256-1)).toString(16);}
              // 定制显示（按顺序）
              color: params => {
                const colorList = ["#98D87D", "#F3857B"];
                return colorList[params.dataIndex];
              }
            }
          }
        }
      ]
    };
    myChart.setOption(option);
  }

  componentDidUpdate() {
    this.query();
  }

  componentDidMount() {
    this.query();
  }

  render() {
    const { height } = this.props;
    return (
      <div>
        <Row>
          <Col span={24}>
            <div style={{ position: "relative" }}>
              <div id="myChart" ref="PieChart" style={{ width: "100%", height }} />
            </div>
          </Col>
        </Row>
      </div>
    );
  }
}
export default PieChart;
