import React from "react";
import PropTypes from "prop-types";
import MonacoEditor from "react-monaco-editor";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.editorDidMount = this.editorDidMount.bind(this);
    this.onChange = this.onChange.bind(this);
    // this.editorValue = this.props.code;
  }

  editorDidMount(editor, monaco) {
    editor.focus();
    // this.props.changeEdit(newValue);
  }

  onChange(newValue, e) {
    // console.log("newValue", newValue);
    // this.editorValue = newValue;
    // if (this.props.changeEdit) {
    //   this.props.changeEdit(newValue);
    // }
  }

  render() {
    const options = {
      selectOnLineNumbers: true
    };
    const { extention, code } = this.props;
    return (
      <MonacoEditor
        width="100%"
        height="600"
        language={extention}
        theme="vs-dark"
        value={code}
        options={options}
        onChange={this.onChange}
        editorDidMount={this.editorDidMount}
      />
    );
  }
}
App.propTypes = {
  // code: PropTypes.string
};
App.defaultProps = {
  //   repositories: [
  //     {
  //       name: "repo1",
  //       commit: "this is a demo",
  //       commitor: "hyw",
  //       date: "2018-8-3 12:12:23"
  //     },
  //     {
  //       name: "repo2",
  //       commit: "this is devops repo",
  //       commitor: "hyw",
  //       date: "2018-8-3 02:12:23"
  //     }
  //   ]
};
export default App;
