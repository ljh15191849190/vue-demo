import React from "react";
import { Card, Icon, Tooltip } from "antd";
import CodeMirror from "react-codemirror";
import "codemirror/lib/codemirror.css";
import "codemirror/mode/yaml/yaml";
import "codemirror/mode/shell/shell";
import "codemirror/addon/hint/show-hint.css";
import "codemirror/addon/hint/show-hint";
import "codemirror/addon/hint/sql-hint";
import "codemirror/theme/ambiance.css";
import "codemirror/addon/display/fullscreen.css";
import "codemirror/addon/display/fullscreen";

class Index extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    const editorss = this.refs.editor.getCodeMirror();
  }

  componentDidUpdate() {
    const { serviceOrchestrationYml, getValue } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setValue(serviceOrchestrationYml);

    if (getValue) {
      getValue(editorss.getValue());
    }
  }

  ChangeCode() {
    const { getValue } = this.props;
    const editorss = this.refs.editor.getCodeMirror();
    if (getValue) {
      getValue(editorss.getValue());
    }
    // // editor.setValue('这里是新的sql内容');
    // this.CodeMirrorEditor.setSize(width,height)
    // this.CodeMirrorEditor.refresh()   //刷新
  }

  // 放大
  getValue() {
    const editorss = this.refs.editor.getCodeMirror();
    editorss.setOption("fullScreen", "true");
  }

  render() {
    const { readOnly, autofocus } = this.props;
    const options = {
      readOnly: readOnly ? readOnly : false,
      Autofocus: autofocus ? autofocus : true,
      lineNumbers: true, // 显示行号
      mode: { name: "yaml" }, // 定义mode
      // extraKeys: { Ctrl: "autocomplete" }, // 自动提示配置
      lineWrapping: true, // 自动换行
      theme: "ambiance", // 选中的theme
      extraKeys: {
        F7: cm => {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        Esc: cm => {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
    };
    const value = "kind: Service\napiVersion: v1\nmetadata:\n  name: gitlab\n;";
    const { title, serviceOrchestrationYml } = this.props;
    return (
      <div>
        <Card
          title={title ? title : "YAML"}
          extra={
            <div>
              <Tooltip title="按键F7放大缩小">
                <Icon
                  type="question-circle"
                  theme="filled"
                  style={{ fontSize: "18px", color: "#08c" }}
                />
              </Tooltip>
              <a href="#" onClick={this.getValue.bind(this)} style={{ marginLeft: 15 }}>
                <Icon type="arrows-alt" style={{ fontSize: "18px", color: "#08c" }} />
              </a>
            </div>
          }
        >
          <CodeMirror
            ref="editor"
            value={serviceOrchestrationYml ? serviceOrchestrationYml : ""}
            options={options}
            onChange={() => this.ChangeCode()}
          />
        </Card>
      </div>
    );
  }
}

export default Index;
