import React, { Component } from "react";
import { Row, Col } from "antd";

export default class Bug extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { width } = this.props;
    return (
      <div style={{ width: 150 }}>
        <Row>
          <Col span={24}>
            <span
              style={{
                display: "inline-block",
                width: `${width.yanzhong}%`,
                height: "15px",
                background: "#D1210A"
              }}
            />
            <span
              style={{
                display: "inline-block",
                width: `${width.zhongdeng}%`,
                height: "15px",
                background: "#FFA500"
              }}
            />
            <span
              style={{
                display: "inline-block",
                width: `${width.jiaodi}%`,
                height: "15px",
                background: "#FFFF00"
              }}
            />
            <span
              style={{
                display: "inline-block",
                width: `${width.weizhi}%`,
                height: "15px",
                background: "#848484"
              }}
            />
            <span
              style={{
                display: "inline-block",
                width: `${width.wu}%`,
                height: "15px",
                background: "#008000"
              }}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

// const styles = {
//   Item: {
//     background: "#ff0000"
//   }
// };
