import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  deploymentPageList,
  deploymentSave,
  deploymentUpdate,
  deploymentDelete,
  getRunningEnvList,
  getHostList,
  getShell,
  cloneDeployment,
  findDefination,
  updateDeployStatus,
  findIpsListById,
  getDeployConsole,
  getHistoryList,
  getHistoryListDetails,
  executeDeployment,
  findDeployStatus,
  getUserlistById,
  updateHosts,
  getDeployHisConsole,
  getYmlTmp,
  getPodList,
  getPodConsole,
  getImagelist
} from "./apiCall";

// 定义列表
export function* deployDefinationList(payload) {
  try {
    const deploymentPageListStatus = yield call(deploymentPageList, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_LIST_ALL_SAGA,
      deploymentPageListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deployDefinationListFlow({ payload }) {
  const response = yield call(deployDefinationList, payload);
}
// 获取运行环境
export function* getEnvList(payload) {
  try {
    const getRuningEnvListStatus = yield call(getRunningEnvList, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_RUNNINGENV_LIST_SAGA,
      getRuningEnvListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEnvListFlow({ payload }) {
  const response = yield call(getEnvList, payload);
}
// 获取主机列表
export function* getHostListData(payload) {
  try {
    const hostStatus = yield call(getHostList, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_HOST_LIST_SAGA,
      hostStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getHostListDataFlow({ payload }) {
  const response = yield call(getHostListData, payload);
}
// 更新定义
export function* updateDepDefination(payload) {
  try {
    const deployUpdateStatus = yield call(deploymentUpdate, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_UPDATE_SAGA,
      deployUpdateStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateDeployFlow({ payload }) {
  const response = yield call(updateDepDefination, payload);
}
// 保存定义
export function* deployDefinationSave(payload) {
  try {
    const deploymentSaveStatus = yield call(deploymentSave, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_SAVE_SAGA,
      deploymentSaveStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deployDefinationSaveFlow({ payload }) {
  const response = yield call(deployDefinationSave, payload);
}
// 获取shell脚本
export function* getShellContent(payload) {
  try {
    const shellStatus = yield call(getShell, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_SHELL_SAGA,
      shellStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getShellContentFlow({ payload }) {
  const response = yield call(getShellContent, payload);
}
// 删除定义
export function* deleteDeploy(payload) {
  try {
    const deleteStatus = yield call(deploymentDelete, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_DELETE_SAGA,
      deleteStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteDeploytFlow({ payload }) {
  const response = yield call(deleteDeploy, payload);
}
// 克隆定义
export function* cloneDeploy(payload) {
  try {
    const cloneDeployStatus = yield call(cloneDeployment, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_CLONE_SAGA,
      cloneDeployStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* cloneDeploytFlow({ payload }) {
  const response = yield call(cloneDeploy, payload);
}
// 查找定义
export function* findDeploy(payload) {
  try {
    const detailsStatus = yield call(findDefination, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_FIND_BY_ID_SAGA,
      detailsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findDeployFlow({ payload }) {
  const response = yield call(findDeploy, payload);
}
// 更新实例状态
export function* deployStatusUpdate(payload) {
  try {
    const deployStatusData = yield call(updateDeployStatus, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_UPDATE_STATUS_SAGA,
      deployStatusData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deployStatusUpdateFlow({ payload }) {
  const response = yield call(deployStatusUpdate, payload);
}
// 根据id查询主机列表
export function* findIpsById(payload) {
  try {
    const ipsData = yield call(findIpsListById, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_FIND_IPSLIST_BY_ID_SAGA,
      ipsData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findIpsByIdFlow({ payload }) {
  const response = yield call(findIpsById, payload);
}
// 查询日志
export function* getConsole(payload) {
  try {
    const consoleData = yield call(getDeployConsole, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_CONSOLE_SAGA,
      consoleData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getConsoleFlow({ payload }) {
  const response = yield call(getConsole, payload);
}
// 查询日志
export function* getHisConsole(payload) {
  try {
    const hisConsoleData = yield call(getDeployHisConsole, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_HIS_CONSOLE_SAGA,
      hisConsoleData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getHisConsoleFlow({ payload }) {
  const response = yield call(getHisConsole, payload);
}
// 部署历史
export function* deployHistory(payload) {
  try {
    const historyData = yield call(getHistoryList, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_HISTORY_SAGA,
      historyData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deployHistoryFlow({ payload }) {
  const response = yield call(deployHistory, payload);
}
// 部署历史详情
export function* deployHistoryDetails(payload) {
  try {
    const historyDetails = yield call(getHistoryListDetails, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_HISTORY_DETAILS_SAGA,
      historyDetails
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deployHistoryDetailsFlow({ payload }) {
  const response = yield call(deployHistoryDetails, payload);
}
// 执行部署
export function* executeDeploy(payload) {
  try {
    const executeStatus = yield call(executeDeployment, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_EXECUTE_SAGA,
      executeStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* executeDeployFlow({ payload }) {
  const response = yield call(executeDeploy, payload);
}
// 重置状态
export function* resetState() {
  try {
    yield put({
      type: actionTypes.XAHC_DEPLOY_RESETSTATE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetDepStateFlow() {
  const response = yield call(resetState);
}
// 重置部署详情
export function* resetDetailsData() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_DETAIL_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetDetailsDataFlow() {
  const response = yield call(resetDetailsData);
}
// 重置部署状态
export function* resetDeployState() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_DEPLOY_STATE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetDeployStateFlow() {
  const response = yield call(resetDeployState);
}
// 重置部署日志
export function* resetDeployConsole() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_CONSOLE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetDeployConsoleFlow() {
  const response = yield call(resetDeployConsole);
}
// 重置错误信息
export function* resetErrorStatus() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_ENV_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetErrorStatusFlow() {
  const response = yield call(resetErrorStatus);
}
// 实例状态查询
export function* findDeploymentStatus(payload) {
  try {
    const deployStatusCode = yield call(findDeployStatus, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_FIND_STATUS_SAGA,
      deployStatusCode
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findDeploymentStatusFlow({ payload }) {
  const response = yield call(findDeploymentStatus, payload);
}
// 根据项目Id查询用户信息列表
export function* userlistByIdStatus(payload) {
  try {
    const getUserlistByIdStatus = yield call(getUserlistById, payload);
    yield put({
      type: actionTypes.XAHC_TEAM_USER_LIST_BY_PROJECTID_SAGA,
      getUserlistByIdStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* userlistByIdStatusFlow({ payload }) {
  const response = yield call(userlistByIdStatus, payload);
}
// 更新主机列表
export function* updateHostStatus(payload) {
  try {
    const updateHostStatusList = yield call(updateHosts, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_UPDATE_HOSTS_SAGA,
      updateHostStatusList
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateHostStatusFlow({ payload }) {
  const response = yield call(updateHostStatus, payload);
}
// 获取yml文件
export function* findDeployYmlTmp(payload) {
  try {
    const ymlTmpData = yield call(getYmlTmp, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_YML_TMP_SAGA,
      ymlTmpData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findDeployYmlTmpFlow({ payload }) {
  const response = yield call(findDeployYmlTmp, payload);
}
// pod组信息
export function* getPodDataList(payload) {
  try {
    const podData = yield call(getPodList, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_POD_LIST_SAGA,
      podData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getPodDataListFlow({ payload }) {
  const response = yield call(getPodDataList, payload);
}
// pod日志
export function* getPodLog(payload) {
  try {
    const podLog = yield call(getPodConsole, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_POD_LOG_SAGA,
      podLog
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getPodlogFlow({ payload }) {
  const response = yield call(getPodLog, payload);
}
// 部署镜像
export function* getImageHouse(payload) {
  try {
    const imageList = yield call(getImagelist, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_IMAGE_SAGA,
      imageList
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getImageHouseFlow({ payload }) {
  const response = yield call(getImageHouse, payload);
}
export function* setCurrentPage(payload) {
  try {
    yield put({
      type: actionTypes.XAHC_SET_CURRENT_PAGE_SAGA,
      currentPage: payload.data
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* setCurrentPageFlow({ payload }) {
  const response = yield call(setCurrentPage, payload);
}
