import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getAllDefinationList,
  cloneDefination,
  deleteDefination,
  baseDefination,
  updateDefination,
  saveBuildParams,
  updateBuildParams,
  buildParamsList,
  deleteParams,
  getAlltemplates,
  getPipeTemplates,
  getAllStages,
  buildTaskSave,
  buildTaskUpdate,
  getDefinationById,
  baseUpdate,
  getStageDetailsById,
  buildHistoryMethod,
  getPerformeConsole,
  getPerformeStatus,
  getPerformeLogs,
  getPerformeFlag,
  getPerformeFindjar,
  deleteStage,
  getStageNameplan,
  buildcomponentMeasures,
  buildcomponentTree,
  buildcomponentSource,
  buildcomponentRule,
  buildattrParams,
  updateJobStatus,
  buildTaskBatchSave,
  getSonarQubeServerList,
  getNexusList,
  getImageServerList,
  getMediumdownload
} from "./apiCall";

export function* allDefinationList(payload) {
  try {
    const definationListStatus = yield call(getAllDefinationList, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_LIST_ALL_SAGA,
      definationListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* allDefinationListFlow({ payload }) {
  const response = yield call(allDefinationList, payload);
}

export function* cloneDefinations(payload) {
  try {
    const definationCloneStatus = yield call(cloneDefination, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_CLONE_SAGA,
      definationCloneStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* cloneDefinationFlow({ payload }) {
  const response = yield call(cloneDefinations, payload);
}

export function* deleteDefinations(payload) {
  try {
    const deleteDefinationStatus = yield call(deleteDefination, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_DELETE_SAGA,
      deleteDefinationStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteDefinationFlow({ payload }) {
  const response = yield call(deleteDefinations, payload);
}
export function* baseDefinations(payload) {
  try {
    const baseDefinationStatus = yield call(baseDefination, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_BASE_SAGA,
      baseDefinationStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* baseDefinationFlow({ payload }) {
  const response = yield call(baseDefinations, payload);
}
export function* updateDefinations(payload) {
  try {
    const updateDefinationStatus = yield call(updateDefination, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_UPDATE_SAGA,
      updateDefinationStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateDefinationFlow({ payload }) {
  const response = yield call(updateDefinations, payload);
}
export function* saveParams(payload) {
  try {
    const saveParamsStatus = yield call(saveBuildParams, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PARAMS_SAVE_SAGA,
      saveParamsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* saveParamsFlow({ payload }) {
  const response = yield call(saveParams, payload);
}
export function* updateParams(payload) {
  try {
    const updateParamsStatus = yield call(updateBuildParams, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PARAMS_UPDATE_SAGA,
      updateParamsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateParamsFlow({ payload }) {
  const response = yield call(updateParams, payload);
}
export function* paramsLists(payload) {
  try {
    const paramsListStatus = yield call(buildParamsList, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PARAMS_LIST_SAGA,
      paramsListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* paramsListsFlow({ payload }) {
  const response = yield call(paramsLists, payload);
}
export function* paramsDelete(payload) {
  try {
    const paramsDeleteStatus = yield call(deleteParams, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PARAMS_DELETE_SAGA,
      paramsDeleteStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* paramsDeleteFlow({ payload }) {
  const response = yield call(paramsDelete, payload);
}
export function* allTemplates(payload) {
  try {
    const templatesStatus = yield call(getAlltemplates, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_TEMPLATES_SAGA,
      templatesStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* allTemplatesFlow({ payload }) {
  const response = yield call(allTemplates, payload);
}
export function* pipeTemplates(payload) {
  try {
    const pipeTemplatesStatus = yield call(getPipeTemplates, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PIPELINE_TEMPLATE_SAGA,
      pipeTemplatesStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* pipeTemplatesFlow({ payload }) {
  const response = yield call(pipeTemplates, payload);
}
export function* getCurrentStages(payload) {
  try {
    const stageStatus = yield call(getAllStages, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_STAGE_SAGA,
      stageStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getCurrentStagesFlow({ payload }) {
  const response = yield call(getCurrentStages, payload);
}
export function* buildMissonSave(payload) {
  try {
    const buildTaskSaveStatus = yield call(buildTaskSave, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_MISSION_SAVE_SAGA,
      buildTaskSaveStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildMissonSaveFlow({ payload }) {
  const response = yield call(buildMissonSave, payload);
}
export function* buildMissonUpdate(payload) {
  try {
    const buildTaskUpdateStatus = yield call(buildTaskUpdate, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_MISSION_UPDATE_SAGA,
      buildTaskUpdateStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildMissonUpdateFlow({ payload }) {
  const response = yield call(buildMissonUpdate, payload);
}
// 构建任务批量保存及更新
export function* buildMissonBatchSave(payload) {
  try {
    const buildTaskBatchSaveStatus = yield call(buildTaskBatchSave, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_MISSION_BATCH_SAVE_SAGA,
      buildTaskBatchSaveStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildMissonBatchSaveFlow({ payload }) {
  const response = yield call(buildMissonBatchSave, payload);
}
export function* getDefinationDetails(payload) {
  try {
    const getDefinationDetailsStatus = yield call(getDefinationById, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_GET_DEFINATION_BY_ID_SAGA,
      getDefinationDetailsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getDefinationDetailsFlow({ payload }) {
  const response = yield call(getDefinationDetails, payload);
}
export function* definationUpdate(payload) {
  try {
    const baseUpdateStatus = yield call(baseUpdate, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_BASE_UPDATE_SAGA,
      baseUpdateStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* definationUpdateFlow({ payload }) {
  const response = yield call(definationUpdate, payload);
}
export function* getStageDetails(payload) {
  try {
    const getStageDetailsStatus = yield call(getStageDetailsById, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_MISSION_DETAILS_SAGA,
      getStageDetailsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getStageDetailsFlow({ payload }) {
  const response = yield call(getStageDetails, payload);
}
export function* deleteStageMethod(payload) {
  try {
    const deleteStageStatus = yield call(deleteStage, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_STAGE_DELETE_SAGA,
      deleteStageStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteStageMethodFlow({ payload }) {
  const response = yield call(deleteStageMethod, payload);
}
export function* buildHistory(payload) {
  try {
    const historyData = yield call(buildHistoryMethod, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_HISTORY_SAGA,
      historyData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildHistoryFlow({ payload }) {
  const response = yield call(buildHistory, payload);
}
// 构建执行console
export function* buildConsole(payload) {
  try {
    const consoleListStatus = yield call(getPerformeConsole, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_CONSOLE_SAGA,
      consoleListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildConsoleFlow({ payload }) {
  const response = yield call(buildConsole, payload);
}
// 构建执行概要
export function* buildStatus(payload) {
  try {
    const StatusListStatus = yield call(getPerformeStatus, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_STATUS_SAGA,
      StatusListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildStatusFlow({ payload }) {
  const response = yield call(buildStatus, payload);
}
// 构建执行概要日志
export function* buildLogs(payload) {
  try {
    const LogsListStatus = yield call(getPerformeLogs, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_LOGS_SAGA,
      LogsListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildLogsFlow({ payload }) {
  const response = yield call(buildLogs, payload);
}
// 介质下载
export function* Mediumdownload(payload) {
  try {
    const downloadData = yield call(getMediumdownload, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_MEDIUM_DOWNLOAD_SAGA,
      downloadData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* MediumdownloadFlow({ payload }) {
  const response = yield call(Mediumdownload, payload);
}
// 下载
export function* buildFindjar(payload) {
  try {
    const JarListStatus = yield call(getPerformeFindjar, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_FINDJAR_SAGA,
      JarListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildFindjarFlow({ payload }) {
  const response = yield call(buildFindjar, payload);
}
// 点击构建执行
export function* buildFlag(payload) {
  try {
    const FlagListStatus = yield call(getPerformeFlag, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_FLAG_SAGA,
      FlagListStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildFlagFlow({ payload }) {
  const response = yield call(buildFlag, payload);
}
// 构建计划概要
export function* buildStagenameplan(payload) {
  try {
    const StageNameStatus = yield call(getStageNameplan, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_STAGENAME_PLAN_SAGA,
      StageNameStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildStagenameplanFlow({ payload }) {
  const response = yield call(buildStagenameplan, payload);
}
// 构建质量展示
export function* getcomponentMeasures(payload) {
  try {
    const MeasuresStatus = yield call(buildcomponentMeasures, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_QUALITY_MEASURES_SAGA,
      MeasuresStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcomponentMeasuresFlow({ payload }) {
  const response = yield call(getcomponentMeasures, payload);
}
// 构建质量树
export function* getcomponentTree(payload) {
  try {
    const TreeStatus = yield call(buildcomponentTree, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_QUALITY_TREE_SAGA,
      TreeStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcomponentTreeFlow({ payload }) {
  const response = yield call(getcomponentTree, payload);
}
// 构建质量树daima
export function* getcomponentSource(payload) {
  try {
    const SourceStatus = yield call(buildcomponentSource, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_QUALITY_SOURCE_SAGA,
      SourceStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcomponentSourceFlow({ payload }) {
  const response = yield call(getcomponentSource, payload);
}
// 构建质量树daimabug
export function* getcomponentRule(payload) {
  try {
    const RuleStatus = yield call(buildcomponentRule, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_QUALITY_RULE_SAGA,
      RuleStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcomponentRuleFlow({ payload }) {
  const response = yield call(getcomponentRule, payload);
}

// 参数配置
export function* getattrParams(payload) {
  try {
    const ParamsStatus = yield call(buildattrParams, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_ATTR_PARAMS_SAGA,
      ParamsStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getattrParamsFlow({ payload }) {
  const response = yield call(getattrParams, payload);
}
// 构建计划概要清空
export function* buildStagenameplanempty(payload) {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_PERFORME_STATUS_EMPTY_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* buildStagenameplanemptyFlow({ payload }) {
  const response = yield call(buildStagenameplanempty, payload);
}
// 重置状态
export function* resetState() {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_RESETSTATE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetStateFlow() {
  const response = yield call(resetState);
}
// 重置数据
export function* resetData() {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_RESETDATA_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetDataFlow() {
  const response = yield call(resetData);
}
// 重置构建表单
export function* resetImage() {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_RESET_IMAGE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetImageFlow() {
  const response = yield call(resetImage);
}
// 重置通知选择邮件列表
export function* resetEmail() {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_RESET_EMAIL_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetEmailFlow() {
  const response = yield call(resetEmail);
}
// 重置保存数据
export function* resetBasicSaveData() {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_RESET_SAVE_DATA_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetBasicSaveDataFlow() {
  const response = yield call(resetBasicSaveData);
}
export function* updateStatus(payload) {
  try {
    const jobStatus = yield call(updateJobStatus, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_UPDATE_STATUS_SAGA,
      jobStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateStatusFlow({ payload }) {
  const response = yield call(updateStatus, payload);
}
export function* getSonarQubeServer(payload) {
  try {
    const sonarQubeServerList = yield call(getSonarQubeServerList, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_SONAR_SERVER_LIST_SAGA,
      sonarQubeServerList
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getSonarQubeServerFlow({ payload }) {
  const response = yield call(getSonarQubeServer, payload);
}
export function* getNexusDataList(payload) {
  try {
    const nexusList = yield call(getNexusList, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_NEXUS_LIST_SAGA,
      nexusList
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getNexusDataListFlow({ payload }) {
  const response = yield call(getNexusDataList, payload);
}
export function* getImageServer(payload) {
  try {
    const imageServerList = yield call(getImageServerList, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_IMAGE_SERVER_LIST_SAGA,
      imageServerList
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getImageServerFlow({ payload }) {
  const response = yield call(getImageServer, payload);
}
export function* setBuildCurrentPage(payload) {
  try {
    yield put({
      type: actionTypes.XAHC_BUILD_SET_CURRENT_PAGE_SAGA,
      currentPage: payload.data
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* setBuildCurrentPageFlow({ payload }) {
  const response = yield call(setBuildCurrentPage, payload);
}
