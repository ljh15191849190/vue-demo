import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getResourceRequest,
  addResourceRequest,
  deleteResourceRequest,
  getEnvironmentNameRequest,
  updateResourceRequest,
  testResourceRequest,
  addClusterRequest,
  testClusterRequest,
  addCaasNodeRequest,
  deleteCaasNodeRequest,
  updateCaasNodeRequest,
  testCaasNodeRequest,
  getCaasNodeListRequest,
  addCaasNamespaceRequest,
  getCaasNamespaceListRequest,
  getmarketAppListRequest,
  getmarketAppDetailRequest,
  deleteCaasNamespaceRequest,
  searchCaasNamespaceListRequest,
  updateCaasNamespaceRequest,
  findClusterInfoRequest,
  findPodInfoRequest,
  getClusterListsByProjectId,
  getCaasNamespacePodListByClusterId,
  getmonitorPodEventRequest,
  getmonitorPodLogRequest,
  getmonitorPodBasicRequest,
  getmonitorInfoRequest,
  findMarketdeployRequest
} from "./apiCall";

export function* getResource(payload) {
  try {
    const resData = yield call(getResourceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_LIST_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getResourceFlow({ payload }) {
  const response = yield call(getResource, payload);
}
export function* addResource(payload) {
  try {
    const addStatus = yield call(addResourceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_ADD_SAGA, addStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addResourceFlow({ payload }) {
  const response = yield call(addResource, payload);
}
export function* updateResource(payload) {
  try {
    const updataStatus = yield call(updateResourceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_UPDATE_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateResourceFlow({ payload }) {
  const response = yield call(updateResource, payload);
}
export function* deleteResource(payload) {
  try {
    const deleteStatus = yield call(deleteResourceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_DELETE_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteResourceFlow({ payload }) {
  const response = yield call(deleteResource, payload);
}

export function* getEnvironmentName(payload) {
  try {
    const nameData = yield call(getEnvironmentNameRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_NAME_SAGA, nameData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEnvironmentNameFlow({ payload }) {
  const response = yield call(getEnvironmentName, payload);
}

export function* testResource(payload) {
  try {
    const testData = yield call(testResourceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_TEST_SAGA, testData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* testResourceFlow({ payload }) {
  const response = yield call(testResource, payload);
}
// 容器云

export function* addCluster(payload) {
  try {
    const addClusterStatus = yield call(addClusterRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CLUSTER_ADD_SAGA, addClusterStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addClusterFlow({ payload }) {
  const response = yield call(addCluster, payload);
}
// 容器信息
export function* findClusterInfo(payload) {
  try {
    const clusterInfoData = yield call(findClusterInfoRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_FIND_CLUSTER_INFO_SAGA,
      clusterInfoData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findClusterInfoFlow({ payload }) {
  const response = yield call(findClusterInfo, payload);
}
export function* testCluster(payload) {
  try {
    const testClusterStatus = yield call(testClusterRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CLUSTER_TEST_SAGA, testClusterStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* testClusterFlow({ payload }) {
  const response = yield call(testCluster, payload);
}
// 主机
export function* addCaasNode(payload) {
  try {
    const addNodeStatus = yield call(addCaasNodeRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NODE_ADD_SAGA, addNodeStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addCaasNodeFlow({ payload }) {
  const response = yield call(addCaasNode, payload);
}
// 主机删除
export function* deleteCaasNode(payload) {
  try {
    const deleteNodeStatus = yield call(deleteCaasNodeRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NODE_DELETE_SAGA, deleteNodeStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteCaasNodeFlow({ payload }) {
  const response = yield call(deleteCaasNode, payload);
}
// 主机修改
export function* updateCaasNode(payload) {
  try {
    const updateNodeStatus = yield call(updateCaasNodeRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NODE_UPDATE_SAGA, updateNodeStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateCaasNodeFlow({ payload }) {
  const response = yield call(updateCaasNode, payload);
}
// 主机测试
export function* testCaasNode(payload) {
  try {
    const testNodeStatus = yield call(testCaasNodeRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NODE_TEST_SAGA, testNodeStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* testCaasNodeFlow({ payload }) {
  const response = yield call(testCaasNode, payload);
}
// 主机查询
export function* getCaasNodeList(payload) {
  try {
    const nodeListData = yield call(getCaasNodeListRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NODE_LIST_SAGA, nodeListData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getCaasNodeListFlow({ payload }) {
  const response = yield call(getCaasNodeList, payload);
}
// 主机信息
export function* findPodInfo(payload) {
  try {
    const podInfoData = yield call(findPodInfoRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_FIND_POD_INFO_SAGA,
      podInfoData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findPodInfoFlow({ payload }) {
  const response = yield call(findPodInfo, payload);
}
// 工作区
export function* addCaasNamespace(payload) {
  try {
    const addNameSpaceStatus = yield call(addCaasNamespaceRequest, payload);
    yield put({ type: actionTypes.XAHC_RESOURCE_CAAS_NAMESPACE_ADD_SAGA, addNameSpaceStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addCaasNamespaceFlow({ payload }) {
  const response = yield call(addCaasNamespace, payload);
}
// 工作区shanchu
export function* deleteCaasNamespace(payload) {
  try {
    const deleteNameSpaceStatus = yield call(deleteCaasNamespaceRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_CAAS_NAMESPACE_DELETE_SAGA,
      deleteNameSpaceStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteCaasNamespaceFlow({ payload }) {
  const response = yield call(deleteCaasNamespace, payload);
}
// 工作区修改
export function* updateCaasNamespace(payload) {
  try {
    const updateNameSpaceStatus = yield call(updateCaasNamespaceRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_CAAS_NAMESPACE_UPDATE_SAGA,
      updateNameSpaceStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateCaasNamespaceFlow({ payload }) {
  const response = yield call(updateCaasNamespace, payload);
}
// 查询name
export function* searchCaasNamespaceList(payload) {
  try {
    const searchnameSpaceListData = yield call(searchCaasNamespaceListRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_CAAS_NAMESPACE_SEARCH_SAGA,
      searchnameSpaceListData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* searchCaasNamespaceListFlow({ payload }) {
  const response = yield call(searchCaasNamespaceList, payload);
}
// 查询
export function* getCaasNamespaceList(payload) {
  try {
    const nameSpaceListData = yield call(getCaasNamespaceListRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_CAAS_NAMESPACE_LIST_SAGA,
      nameSpaceListData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getCaasNamespaceListFlow({ payload }) {
  const response = yield call(getCaasNamespaceList, payload);
}
// 应用市场
// 查询
export function* getmarketAppList(payload) {
  try {
    const appListData = yield call(getmarketAppListRequest, payload);
    yield put({
      type: actionTypes.XAHC_CAAS_MARKETAPPS_LIST_SAGA,
      appListData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmarketAppListFlow({ payload }) {
  const response = yield call(getmarketAppList, payload);
}
// 查询detail
export function* getmarketAppDetail(payload) {
  try {
    const appDetailData = yield call(getmarketAppDetailRequest, payload);
    yield put({
      type: actionTypes.XAHC_CAAS_MARKETAPPS_DETAIL_SAGA,
      appDetailData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmarketAppDetailFlow({ payload }) {
  const response = yield call(getmarketAppDetail, payload);
}
// 部署
export function* findMarketdeploy(payload) {
  try {
    const deployData = yield call(findMarketdeployRequest, payload);
    yield put({
      type: actionTypes.XAHC_DEPLOY_MARKETAPPS_DEPLOY_SAGA,
      deployData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findMarketdeployFlow({ payload }) {
  const response = yield call(findMarketdeploy, payload);
}
// 根据projectId查找集群信息
export function* findClusterByProjectId(payload) {
  try {
    const clusterData = yield call(getClusterListsByProjectId, payload);
    yield put({
      type: actionTypes.XAHC_FIND_CLUSTER_BY_ID_SAGA,
      clusterData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* findClusterByProjectIdFlow({ payload }) {
  const response = yield call(findClusterByProjectId, payload);
}
// 根据clusterId查询命名空间
export function* getNamespacePodListByClusterId(payload) {
  try {
    const nameSpacePodData = yield call(getCaasNamespacePodListByClusterId, payload);
    yield put({
      type: actionTypes.XAHC_FIND_NAMESPACE_BY_CLUSTER_ID_SAGA,
      nameSpacePodData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getNamespacePodListByClusterIdFlow({ payload }) {
  const response = yield call(getNamespacePodListByClusterId, payload);
}
// pod操作
// 基本信息
export function* getmonitorPodBasic(payload) {
  try {
    const podBasicData = yield call(getmonitorPodBasicRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_POD_BASIC_INFO_SAGA,
      podBasicData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmonitorPodBasicFlow({ payload }) {
  const response = yield call(getmonitorPodBasic, payload);
}
// 事件
export function* getmonitorPodEvent(payload) {
  try {
    const podEventData = yield call(getmonitorPodEventRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_POD_EVENT_INFO_SAGA,
      podEventData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmonitorPodEventFlow({ payload }) {
  const response = yield call(getmonitorPodEvent, payload);
}
// log
export function* getmonitorPodLog(payload) {
  try {
    const podLogData = yield call(getmonitorPodLogRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_POD_LOG_INFO_SAGA,
      podLogData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmonitorPodLogFlow({ payload }) {
  const response = yield call(getmonitorPodLog, payload);
}
// 监控
export function* getmonitorInfo(payload) {
  try {
    const podMonitorData = yield call(getmonitorInfoRequest, payload);
    yield put({
      type: actionTypes.XAHC_RESOURCE_POD_MONITOR_INFO_SAGA,
      podMonitorData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getmonitorInfoFlow({ payload }) {
  const response = yield call(getmonitorInfo, payload);
}
// 重置所在集群
export function* resetClusterData() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_CLUSTER_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetClusterDataFlow() {
  const response = yield call(resetClusterData);
}
// 重置命名空间下拉数据
export function* resetNameSpaceData() {
  try {
    yield put({
      type: actionTypes.XAHC_RESET_NAMESPACE_SAGA
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetNameSpaceDataFlow() {
  const response = yield call(resetNameSpaceData);
}
