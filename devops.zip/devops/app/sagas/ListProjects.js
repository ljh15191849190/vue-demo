import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  listAllProjectsMethod,
  getProjectsOvewviewRequest,
  getProjectsdeploytopRequest,
  getProjectsbuildtopRequest,
  getProjectsRateRequest,
  getBuildstatementRequest,
  getdeploystatementRequest,
  getcodequalityRequest,
  getcodeCommitRequest
} from "./apiCall";

export function* listAllProjects(payload) {
  try {
    const projects = yield call(listAllProjectsMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_ALL_PROJECTS_SAGA, projects });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* listAllProjectsFlow({ payload }) {
  const response = yield call(listAllProjects, payload);
}
// 概览
export function* getProjectsOvewview(payload) {
  try {
    const resData = yield call(getProjectsOvewviewRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_OVERVIEW_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getProjectsOvewviewFlow({ payload }) {
  const response = yield call(getProjectsOvewview, payload);
}
// 概览
export function* getProjectsdeploytop(payload) {
  try {
    const topData = yield call(getProjectsdeploytopRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_DEPLOYTOP_SAGA, topData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getProjectsdeploytopFlow({ payload }) {
  const response = yield call(getProjectsdeploytop, payload);
}
// 概览
export function* getProjectsbuildtop(payload) {
  try {
    const topbuildData = yield call(getProjectsbuildtopRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_BUILD_DEPLOYTOP_SAGA, topbuildData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getProjectsbuildtopFlow({ payload }) {
  const response = yield call(getProjectsbuildtop, payload);
}
// 概览
export function* getProjectsRate(payload) {
  try {
    const rateData = yield call(getProjectsRateRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_RATE_SAGA, rateData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getProjectsRateFlow({ payload }) {
  const response = yield call(getProjectsRate, payload);
}

// update projectName
export function* updateProjectName(payload) {
  try {
    yield put({ type: actionTypes.XAHC_UPDATE_PROJECT_NAME_SAGA, projectName: payload.name });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* upateProjectNameFlow({ payload }) {
  const response = yield call(updateProjectName, payload);
}
// 报表
// 构建
export function* getBuildstatement(payload) {
  try {
    const buildData = yield call(getBuildstatementRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_BUILDSTATEMENT_SAGA, buildData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getBuildstatementFlow({ payload }) {
  const response = yield call(getBuildstatement, payload);
}
// 部署
export function* getdeploystatement(payload) {
  try {
    const deployData = yield call(getdeploystatementRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_DEPLOYSTATEMENT_SAGA, deployData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getdeploystatementFlow({ payload }) {
  const response = yield call(getdeploystatement, payload);
}
// 质量
export function* getcodequality(payload) {
  try {
    const qualityData = yield call(getcodequalityRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_CODEQUALITY_SAGA, qualityData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcodequalityFlow({ payload }) {
  const response = yield call(getcodequality, payload);
}
// 代码提交
export function* getcodeCommit(payload) {
  try {
    const commitData = yield call(getcodeCommitRequest, payload);
    yield put({ type: actionTypes.XAHC_PROJECT_CODECOMMIT_SAGA, commitData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getcodeCommitFlow({ payload }) {
  const response = yield call(getcodeCommit, payload);
}
