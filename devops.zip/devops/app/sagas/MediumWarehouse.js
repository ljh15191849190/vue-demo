import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  findMediumMethod,
  uploadMediumMethod,
  getMediumMethod,
  searchNameSystemTypeMethod,
  repListByNameMethod,
  uploadSoftBag
} from "./apiCall";

export function* findMedium(payload) {
  try {
    const resData = yield call(findMediumMethod, payload);
    yield put({ type: actionTypes.XAHC_BUILD_MEDIUM_WH_FIND_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* uploadMedium(payload) {
  try {
    const uploadStatus = yield call(uploadMediumMethod, payload);
    yield put({ type: actionTypes.XAHC_BUILD_MEDIUM_WH_UPLOAD_SAGA, uploadStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getSearchMedium(payload) {
  try {
    const resData = yield call(getMediumMethod, payload);
    yield put({ type: actionTypes.XAHC_BUILD_SEARCH_WH_FIND_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* searchNameSystemType(payload) {
  try {
    const systemTypeData = yield call(searchNameSystemTypeMethod, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_SEARCH_NAME_SYSTEM_TYPE_SAGA,
      systemTypeData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* repListByName(payload) {
  try {
    const repListData = yield call(repListByNameMethod, payload);
    yield put({ type: actionTypes.XAHC_BUILD_REP_LIST_BYNAME_SAGA, repListData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* findMediumFlow({ payload }) {
  const response = yield call(findMedium, payload);
}
export function* uploadMediumFlow({ payload }) {
  const response = yield call(uploadMedium, payload);
}
export function* getSearchMediumFlow({ payload }) {
  const response = yield call(getSearchMedium, payload);
}

export function* repListByNameFlow({ payload }) {
  const response = yield call(repListByName, payload);
}
export function* searchNameSystemTypeFlow({ payload }) {
  const response = yield call(searchNameSystemType, payload);
}
export function* uploadSoft(payload) {
  try {
    const uploadStatus = yield call(uploadSoftBag, payload);
    yield put({
      type: actionTypes.XAHC_BUILD_UPLOAD_SOFT_SAGA,
      uploadStatus
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* uploadSoftFlow({ payload }) {
  const response = yield call(uploadSoft, payload);
}
