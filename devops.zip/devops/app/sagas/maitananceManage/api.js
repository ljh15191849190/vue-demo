import ServiceApi from "../../api/serviceApi";

export const addApi = param => {
  return ServiceApi.maitananceAdd(param).then(res => res);
};

export const delApi = param => {
  return ServiceApi.maitananceDel(param).then(res => res);
};

export const getApi = param => {
  return ServiceApi.maitananceGet(param).then(res => res);
};

export const updateApi = param => {
  return ServiceApi.maitananceUpdate(param).then(res => res);
};

export const searchApi = param => {
  return ServiceApi.maitananceSearch(param).then(res => res);
};
