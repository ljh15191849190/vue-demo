import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getRoleRequest,
  addRoleRequest,
  deleteRoleRequest,
  updateRoleRequest,
  getAllMenuRequest,
  getSelectMenuRequest,
  saveSelectMenuRequest,
  getTeamRequest,
  addTeamRequest,
  deleteTeamRequest,
  authorizeTeamRequest,
  userAllTeamRequest
} from "./apiCall";

export function* getRole(payload) {
  try {
    const resData = yield call(getRoleRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_LIST_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getRoleFlow({ payload }) {
  const response = yield call(getRole, payload);
}
export function* addRole(payload) {
  try {
    const addStatus = yield call(addRoleRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_ADD_SAGA, addStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addRoleFlow({ payload }) {
  const response = yield call(addRole, payload);
}

export function* deleteRole(payload) {
  try {
    const deleteStatus = yield call(deleteRoleRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_DELETE_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteRoleFlow({ payload }) {
  const response = yield call(deleteRole, payload);
}

export function* updateRole(payload) {
  try {
    const updataStatus = yield call(updateRoleRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_UPDATE_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateRoleFlow({ payload }) {
  const response = yield call(updateRole, payload);
}
// 授权
export function* getAllMenu(payload) {
  try {
    const getAllData = yield call(getAllMenuRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_ALL_MENU_SAGA, getAllData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getAllMenuFlow({ payload }) {
  const response = yield call(getAllMenu, payload);
}

export function* getSelectMenu(payload) {
  try {
    const selectData = yield call(getSelectMenuRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_SELECT_MENU_SAGA, selectData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getSelectMenuFlow({ payload }) {
  const response = yield call(getSelectMenu, payload);
}

export function* saveSelectMenu(payload) {
  try {
    const selectStatus = yield call(saveSelectMenuRequest, payload);
    yield put({ type: actionTypes.XAHC_ROLE_SAVE_SELECT_MENU_SAGA, selectStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* saveSelectMenuFlow({ payload }) {
  const response = yield call(saveSelectMenu, payload);
}

// 团队
export function* getTeam(payload) {
  try {
    const resData = yield call(getTeamRequest, payload);
    yield put({ type: actionTypes.XAHC_TEAM_LIST_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getTeamFlow({ payload }) {
  const response = yield call(getTeam, payload);
}
export function* addTeam(payload) {
  try {
    const addStatus = yield call(addTeamRequest, payload);
    yield put({ type: actionTypes.XAHC_TEAM_ADD_SAGA, addStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addTeamFlow({ payload }) {
  const response = yield call(addTeam, payload);
}

export function* deleteTeam(payload) {
  try {
    const deleteStatus = yield call(deleteTeamRequest, payload);
    yield put({ type: actionTypes.XAHC_TEAM_DELETE_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteTeamFlow({ payload }) {
  const response = yield call(deleteTeam, payload);
}
// 授权
export function* authorizeTeam(payload) {
  try {
    const authorStatus = yield call(authorizeTeamRequest, payload);
    yield put({ type: actionTypes.XAHC_TEAM_AUTHORIZE_SAGA, authorStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* authorizeTeamFlow({ payload }) {
  const response = yield call(authorizeTeam, payload);
}
// 成员
export function* userallTeam(payload) {
  try {
    const userallData = yield call(userAllTeamRequest, payload);
    yield put({ type: actionTypes.XAHC_TEAM_TEAM_USER_ALL_SAGA, userallData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* userallTeamFlow({ payload }) {
  const response = yield call(userallTeam, payload);
}
