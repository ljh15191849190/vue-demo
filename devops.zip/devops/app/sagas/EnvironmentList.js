import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getEnvironmentRequest,
  addEnvironmentRequest,
  deleteEnvironmentRequest,
  updateEnvironmentRequest,
  getEnvironmentTypeRequest
} from "./apiCall";

export function* getEnvironment(payload) {
  try {
    const resData = yield call(getEnvironmentRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_LIST_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getEnvironmentFlow({ payload }) {
  const response = yield call(getEnvironment, payload);
}
export function* addEnvironment(payload) {
  try {
    const addStatus = yield call(addEnvironmentRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_ADD_SAGA, addStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addEnvironmentFlow({ payload }) {
  const response = yield call(addEnvironment, payload);
}

export function* deleteEnvironment(payload) {
  try {
    const deleteStatus = yield call(deleteEnvironmentRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_DELETE_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteEnvironmentFlow({ payload }) {
  const response = yield call(deleteEnvironment, payload);
}

export function* updateEnvironment(payload) {
  try {
    const updataStatus = yield call(updateEnvironmentRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_UPDATE_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateEnvironmentFlow({ payload }) {
  const response = yield call(updateEnvironment, payload);
}

export function* getEnvironmentType(payload) {
  try {
    const typeData = yield call(getEnvironmentTypeRequest, payload);
    yield put({ type: actionTypes.XAHC_ENVIRONMENT_TYPE_SAGA, typeData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getEnvironmentTypeFlow({ payload }) {
  const response = yield call(getEnvironmentType, payload);
}
