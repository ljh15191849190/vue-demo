import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import { getSysInteRepertoryCall } from "./apiCall";

export function* getSysInteRepertory(payload) {
  try {
    const resData = yield call(getSysInteRepertoryCall, payload);
    yield put({ type: actionTypes.XAHC_SYS_INTE_REPERTORY_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getSysInteRepertoryFlow({ payload }) {
  const response = yield call(getSysInteRepertory, payload);
}
