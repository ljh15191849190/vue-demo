import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getComponentList,
  addComponentRequest,
  updateComponentRequest,
  deleteComponentRequest,
  getModuleDetailRequest,
  addressComponentRequest
} from "./apiCall";

export function* getPjmComponent(payload) {
  try {
    const resData = yield call(getComponentList, payload);
    yield put({ type: actionTypes.XAHC_PJM_COMPONENT_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getPjmComponentFlow({ payload }) {
  const response = yield call(getPjmComponent, payload);
}
export function* addPjmComponent(payload) {
  try {
    const appStatus = yield call(addComponentRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_ADD_COMPONENT_SAGA, appStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addPjmComponentFlow({ payload }) {
  const response = yield call(addPjmComponent, payload);
}
export function* updatePjmComponent(payload) {
  try {
    const updataStatus = yield call(updateComponentRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_UPDATE_COMPONENT_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updatePjmComponentFlow({ payload }) {
  const response = yield call(updatePjmComponent, payload);
}
export function* deletePjmComponent(payload) {
  try {
    const deleteStatus = yield call(deleteComponentRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_DELETE_COMPONENT_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deletePjmComponentFlow({ payload }) {
  const response = yield call(deletePjmComponent, payload);
}
export function* addressPjmComponent(payload) {
  try {
    const addressStatus = yield call(addressComponentRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_COMPONENT_ADDRESS_SAGA, addressStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addressPjmComponentFlow({ payload }) {
  const response = yield call(addressPjmComponent, payload);
}
// 详情
export function* getModuleDetail(payload) {
  try {
    const detailData = yield call(getModuleDetailRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_COMPONENT_MODULE_DETAIL_SAGA, detailData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getModuleDetailFlow({ payload }) {
  const response = yield call(getModuleDetail, payload);
}
