import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getAllSystemList,
  addSystemRequest,
  deleteSystemRequest,
  updateSystemRequest,
  searchByNameSystemRequest,
  categorySystemRequest,
  testSystemRequest
} from "./apiCall";

export function* getSystemList(payload) {
  try {
    const resData = yield call(getAllSystemList, payload);
    yield put({ type: actionTypes.XAHC_SYSTEM_SEARCH_LIST_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getSystemListFlow({ payload }) {
  const response = yield call(getSystemList, payload);
}

export function* addSystem(payload) {
  try {
    const appStatus = yield call(addSystemRequest, payload);
    yield put({ type: actionTypes.XAHC_ADD_SYSTEM_SEARCH_LIST_SAGA, appStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addSystemFlow({ payload }) {
  const response = yield call(addSystem, payload);
}
export function* deleteSystem(payload) {
  try {
    const deleteStatus = yield call(deleteSystemRequest, payload);
    yield put({ type: actionTypes.XAHC_DELETE_SYSTEM_SEARCH_LIST_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteSystemFlow({ payload }) {
  const response = yield call(deleteSystem, payload);
}
export function* updateSystem(payload) {
  try {
    const updataStatus = yield call(updateSystemRequest, payload);
    yield put({ type: actionTypes.XAHC_UPDATE_SYSTEM_SEARCH_LIST_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateSystemFlow({ payload }) {
  const response = yield call(updateSystem, payload);
}
export function* searchByNameSystem(payload) {
  try {
    const resData = yield call(searchByNameSystemRequest, payload);
    yield put({ type: actionTypes.XAHC_SYSTEMTYPE_SEARCHBYNAME_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* searchByNameSystemFlow({ payload }) {
  const response = yield call(searchByNameSystem, payload);
}

export function* categorySystem(payload) {
  try {
    const categoryData = yield call(categorySystemRequest, payload);
    yield put({ type: actionTypes.XAHC_SYSTEMTYPE_CATEGORY_SAGA, categoryData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* categorySystemFlow({ payload }) {
  const response = yield call(categorySystem, payload);
}
export function* testSystem(payload) {
  try {
    const testStatus = yield call(testSystemRequest, payload);
    yield put({ type: actionTypes.XAHC_TESE_SYSTEM_SEARCH_LIST_SAGA, testStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* testSystemFlow({ payload }) {
  const response = yield call(testSystem, payload);
}
export function* resetFields(payload) {
  try {
    yield put({ type: actionTypes.XAHC_RESET_SYSTEM_FIELDS_SAGA, resetName: payload });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* resetFieldsFlow({ payload }) {
  const response = yield call(resetFields, payload.name);
}
