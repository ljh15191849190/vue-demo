import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import { loginMethod, logoutMethod } from "./apiCall";

export function* logout() {
  try {
    const logoutStatus = yield call(logoutMethod);
    yield put({ type: actionTypes.LOGOUT_SAGA, logoutStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* logoutFlow() {
  yield call(logout);
}
