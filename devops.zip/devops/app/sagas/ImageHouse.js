import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  houseCollectRequest,
  gethouseCollectListRequest,
  gethouseImageInfoRequest,
  gethouseImageListRequest,
  houseImageSyncRequest,
  houseImageScanRequest,
  houseImageTagsRequest,
  gethouseImagePublicListRequest,
  houseImageUpdateRequest,
  houseImageScanTagRequest,
  houseImageScanTagsRequest,
  houseImageUpdateScanRequest
} from "./apiCall";
// 收藏
export function* houseCollect(payload) {
  try {
    const houseStatus = yield call(houseCollectRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_COLLECT_SAGA, houseStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseCollectFlow({ payload }) {
  const response = yield call(houseCollect, payload);
}
// 收藏列表
export function* gethouseCollectList(payload) {
  try {
    const collectsData = yield call(gethouseCollectListRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_COLLECTS_LIST_SAGA, collectsData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* gethouseCollectListFlow({ payload }) {
  const response = yield call(gethouseCollectList, payload);
}
// 镜像信息
export function* gethouseImageInfo(payload) {
  try {
    const imageInfoData = yield call(gethouseImageInfoRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_IMAGEINFO_SAGA, imageInfoData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* gethouseImageInfoFlow({ payload }) {
  const response = yield call(gethouseImageInfo, payload);
}
// 镜像公有私有列表
export function* gethouseImageList(payload) {
  try {
    const houseimageData = yield call(gethouseImageListRequest, payload);
    yield put({
      type: actionTypes.XAHC_CAAS_HOUSE_IMAGES_LIST_SAGA,
      houseimageData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* gethouseImageListFlow({ payload }) {
  const response = yield call(gethouseImageList, payload);
}
// 镜像公有私有列表
export function* gethouseImagePublicList(payload) {
  try {
    const houseimagePubData = yield call(gethouseImagePublicListRequest, payload);
    yield put({
      type: actionTypes.XAHC_CAAS_HOUSE_IMAGES_PUBLIC_LIST_SAGA,
      houseimagePubData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* gethouseImagePublicListFlow({ payload }) {
  const response = yield call(gethouseImagePublicList, payload);
}
// 镜像同步
export function* houseImageSync(payload) {
  try {
    const houseSyncStatus = yield call(houseImageSyncRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_SYNC_SAGA, houseSyncStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageSyncFlow({ payload }) {
  const response = yield call(houseImageSync, payload);
}
// 扫描镜像
export function* houseImageScan(payload) {
  try {
    const houseScanStatus = yield call(houseImageScanRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_SCAN_SAGA, houseScanStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageScanFlow({ payload }) {
  const response = yield call(houseImageScan, payload);
}
// 扫描镜像1
export function* houseImageScanTag(payload) {
  try {
    const ScanTagStatus = yield call(houseImageScanTagRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_SCAN_TAG_SAGA, ScanTagStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageScanTagFlow({ payload }) {
  const response = yield call(houseImageScanTag, payload);
}
// 扫描镜像2
export function* houseImageScanTags(payload) {
  try {
    const ScanTagsData = yield call(houseImageScanTagsRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_SCAN_TAGS_SAGA, ScanTagsData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageScanTagsFlow({ payload }) {
  const response = yield call(houseImageScanTags, payload);
}
// 扫描镜像3
export function* houseImageUpdateScan(payload) {
  try {
    const ScanUpdateStatus = yield call(houseImageUpdateScanRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_SCAN_UPDATETAG_SAGA, ScanUpdateStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageUpdateScanFlow({ payload }) {
  const response = yield call(houseImageUpdateScan, payload);
}

// 镜像(版本)
export function* houseImageTags(payload) {
  try {
    const houseTagsData = yield call(houseImageTagsRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_TAGS_SAGA, houseTagsData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageTagsFlow({ payload }) {
  const response = yield call(houseImageTags, payload);
}
// 镜像保存
export function* houseImageUpdate(payload) {
  try {
    const addStatus = yield call(houseImageUpdateRequest, payload);
    yield put({ type: actionTypes.XAHC_CAAS_HOUSE_UPDATE_SAGA, addStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* houseImageUpdateFlow({ payload }) {
  const response = yield call(houseImageUpdate, payload);
}
