import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getRepoTypeMethod,
  getConponentsMethod,
  getCRConponentsListMethod,
  saveCRConponentMethod,
  delCRRelationMethod,
  updateCRRelationMethod,
  enterCRRepoMethod,
  getCRFileContentMethod,
  getTagData,
  addTag,
  deleteTag,
  downloadFile,
  searchRepMethod
} from "./apiCall";

export function* getRepoType() {
  try {
    const types = yield call(getRepoTypeMethod);
    yield put({ type: actionTypes.XAHC_GET_REPO_TYPE_SAGA, types });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getConponents(payload) {
  try {
    const types = yield call(getConponentsMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_COMPONENT_REQ_SAGA, types });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getRCConponentsList(payload) {
  try {
    const components = yield call(getCRConponentsListMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_RC_COMPONENT_SAGA, components });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* saveRCConponent(payload) {
  try {
    const saveStatus = yield call(saveCRConponentMethod, payload);
    yield put({ type: actionTypes.XAHC_SAVE_RC_COMPONENT_SAGA, saveStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* delRCRelation(payload) {
  try {
    const delStatus = yield call(delCRRelationMethod, payload);
    yield put({ type: actionTypes.XAHC_DEL_RC_RELACTION_SAGA, delStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updateRCRelation(payload) {
  try {
    const updateStatus = yield call(updateCRRelationMethod, payload);
    yield put({ type: actionTypes.XAHC_UPDATE_RC_COMPONENT_SAGA, updateStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* enterCRRepo(payload) {
  try {
    const ecList = yield call(enterCRRepoMethod, payload);
    yield put({ type: actionTypes.XAHC_ENTER_RC_REPO_SAGA, ecList });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getCRFileConten(payload) {
  try {
    const fileContent = yield call(getCRFileContentMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_FILE_CONTENT_SAGA, fileContent });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* searchRep(payload) {
  try {
    const searchReps = yield call(searchRepMethod, payload);
    yield put({ type: actionTypes.XAHC_SEARCH_REP_SAGA, searchRep: searchReps });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getRepoTypeFlow() {
  yield call(getRepoType);
}
export function* getConponentsFlow({ payload }) {
  yield call(getConponents, payload);
}
export function* getRCConponentsListFlow({ payload }) {
  yield call(getRCConponentsList, payload);
}
export function* saveRCConponentFlow({ payload }) {
  yield call(saveRCConponent, payload);
}
export function* delRCRelationFlow({ repoId }) {
  yield call(delRCRelation, repoId);
}
export function* updateRCRelationFlow({ payload }) {
  yield call(updateRCRelation, payload);
}
export function* enterCRRepoFlow({ payload }) {
  yield call(enterCRRepo, payload);
}
export function* getCRFileContentFlow({ payload }) {
  yield call(getCRFileConten, payload);
}
export function* searchRepFlow({ payload }) {
  yield call(searchRep, payload);
}

export function* getTagListData(payload) {
  try {
    const tagListData = yield call(getTagData, payload);
    yield put({
      type: actionTypes.XAHC_CODE_GET_TAG_LIST_SAGA,
      tagListData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* getTagListDataFlow({ payload }) {
  const response = yield call(getTagListData, payload);
}
export function* createTag(payload) {
  try {
    const tagAddData = yield call(addTag, payload);
    yield put({
      type: actionTypes.XAHC_CODE_GET_TAG_ADD_SAGA,
      tagAddData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* createTagFlow({ payload }) {
  const response = yield call(createTag, payload);
}
export function* deleteTags(payload) {
  try {
    const tagDeleteData = yield call(deleteTag, payload);
    yield put({
      type: actionTypes.XAHC_CODE_GET_TAG_DELETE_SAGA,
      tagDeleteData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteTagsFlow({ payload }) {
  const response = yield call(deleteTags, payload);
}
export function* downLoadTagFile(payload) {
  try {
    const downLoadFileData = yield call(downloadFile, payload);
    yield put({
      type: actionTypes.XAHC_CODE_GET_TAG_DOWNLOAD_SAGA,
      downLoadFileData
    });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* downLoadTagFileFlow({ payload }) {
  const response = yield call(downLoadTagFile, payload);
}
