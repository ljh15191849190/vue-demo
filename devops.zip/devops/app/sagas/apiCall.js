import ajaxServiceApi from "../api/serviceApi";

export const loginMethod = payload => {
  return ajaxServiceApi.login(payload).then(res => res);
};

// 退出登录
export const logoutMethod = payload => {
  return ajaxServiceApi.logout(payload).then(res => res);
};

// 概览
export const getProjectsOvewviewRequest = payload => {
  return ajaxServiceApi.getProjectsOvewviewRequest(payload).then(res => res);
};
export const getProjectsdeploytopRequest = payload => {
  return ajaxServiceApi.getProjectsdeploytopRequest(payload).then(res => res);
};
export const getProjectsbuildtopRequest = payload => {
  return ajaxServiceApi.getProjectsbuildtopRequest(payload).then(res => res);
};
export const getProjectsRateRequest = payload => {
  return ajaxServiceApi.getProjectsRateRequest(payload).then(res => res);
};
// 报表
export const getBuildstatementRequest = payload => {
  return ajaxServiceApi.getBuildstatementRequest(payload).then(res => res);
};
export const getdeploystatementRequest = payload => {
  return ajaxServiceApi.getdeploystatementRequest(payload).then(res => res);
};
export const getcodequalityRequest = payload => {
  return ajaxServiceApi.getcodequalityRequest(payload).then(res => res);
};
export const getcodeCommitRequest = payload => {
  return ajaxServiceApi.getcodeCommitRequest(payload).then(res => res);
};

export const getSysInteRepertoryCall = payload => {
  return ajaxServiceApi.getSysInteRepertory(payload).then(res => res);
};
export const getAllProjects = payload => {
  return ajaxServiceApi.getAllProjects(payload).then(res => res);
};
// pjm保存
export const addProjectsRequest = payload => {
  return ajaxServiceApi.addProjectsRequest(payload).then(res => res);
};
// pjm删除
export const deleteEquip = payload => {
  return ajaxServiceApi.deleteEquip(payload).then(res => res);
};
// pjm修改
export const updataProjectsRequest = payload => {
  return ajaxServiceApi.updataProjectsRequest(payload).then(res => res);
};
// pjmcodeorname
export const codeornameProjectsRequest = payload => {
  return ajaxServiceApi.codeornameProjectsRequest(payload).then(res => res);
};
// searchSystemUserAllRequest
export const searchSystemUserAllRequest = payload => {
  return ajaxServiceApi.searchSystemUserAllRequest(payload).then(res => res);
};
// 组件模块
export const getComponentList = payload => {
  return ajaxServiceApi.getComponentList(payload).then(res => res);
};
// 保存
export const addComponentRequest = payload => {
  return ajaxServiceApi.addComponentRequest(payload).then(res => res);
};
// 组件修改
export const updateComponentRequest = payload => {
  return ajaxServiceApi.updateComponentRequest(payload).then(res => res);
};
// 删除
export const deleteComponentRequest = payload => {
  return ajaxServiceApi.deleteComponentRequest(payload).then(res => res);
};
// 详情 下载
export const addressComponentRequest = payload => {
  return ajaxServiceApi.addressComponentRequest(payload).then(res => res);
};
// 详情
export const getModuleDetailRequest = payload => {
  return ajaxServiceApi.getModuleDetailRequest(payload).then(res => res);
};

/**
 * 构建相关
 */
export const getAllDefinationList = payload => {
  return ajaxServiceApi.getAllDefinationList(payload).then(res => res);
};
export const cloneDefination = payload => {
  return ajaxServiceApi.cloneDefination(payload).then(res => res);
};
export const deleteDefination = payload => {
  return ajaxServiceApi.deleteDefination(payload).then(res => res);
};
export const baseDefination = payload => {
  return ajaxServiceApi.baseDefination(payload).then(res => res);
};
export const updateDefination = payload => {
  return ajaxServiceApi.updateDefination(payload).then(res => res);
};
export const saveBuildParams = payload => {
  return ajaxServiceApi.saveParams(payload).then(res => res);
};
export const updateBuildParams = payload => {
  return ajaxServiceApi.updateParams(payload).then(res => res);
};
export const buildParamsList = payload => {
  return ajaxServiceApi.getParmasList(payload).then(res => res);
};
export const deleteParams = payload => {
  return ajaxServiceApi.deleteParmas(payload).then(res => res);
};
export const getAlltemplates = payload => {
  return ajaxServiceApi.getAllTemplates(payload).then(res => res);
};
export const getPipeTemplates = payload => {
  return ajaxServiceApi.getPipeTemplates(payload).then(res => res);
};
export const getAllStages = payload => {
  return ajaxServiceApi.getCurrentStage(payload).then(res => res);
};
export const buildTaskSave = payload => {
  return ajaxServiceApi.buildTaskSave(payload).then(res => res);
};
// 构建任务批量保存
export const buildTaskBatchSave = payload => {
  return ajaxServiceApi.buildTaskBatchSave(payload).then(res => res);
};
// 构建执行console
export const getPerformeConsole = payload => {
  return ajaxServiceApi.getPerformeConsole(payload).then(res => res);
};
// 构建执行概要
export const getPerformeStatus = payload => {
  return ajaxServiceApi.getPerformeStatus(payload).then(res => res);
};
// 下载
export const getPerformeFindjar = payload => {
  return ajaxServiceApi.getPerformeFindjar(payload).then(res => res);
};
// 介质下载
export const getMediumdownload = payload => {
  return ajaxServiceApi.getMediumdownload(payload).then(res => res);
};
// 构建执行概要日志
export const getPerformeLogs = payload => {
  return ajaxServiceApi.getPerformeLogs(payload).then(res => res);
};
// 点击构建执行
export const getPerformeFlag = payload => {
  return ajaxServiceApi.getPerformeFlag(payload).then(res => res);
};
// 质量信息
export const buildcomponentMeasures = payload => {
  return ajaxServiceApi.buildcomponentMeasures(payload).then(res => res);
};
// 质量树
export const buildcomponentTree = payload => {
  return ajaxServiceApi.buildcomponentTree(payload).then(res => res);
};
// 质量daima
export const buildcomponentSource = payload => {
  return ajaxServiceApi.buildcomponentSource(payload).then(res => res);
};

// 质量daimabug
export const buildcomponentRule = payload => {
  return ajaxServiceApi.buildcomponentRule(payload).then(res => res);
};
// 参数配置
export const buildattrParams = payload => {
  return ajaxServiceApi.buildattrParams(payload).then(res => res);
};

export const buildHistoryMethod = payload => {
  return ajaxServiceApi.buildHistory(payload).then(res => res);
};
export const deleteStage = payload => {
  return ajaxServiceApi.deleteStage(payload).then(res => res);
};
export const updateJobStatus = payload => {
  return ajaxServiceApi.updateJobStatus(payload).then(res => res);
};

// 介质仓库
export const buildTaskUpdate = payload => {
  return ajaxServiceApi.buildTaskUpdate(payload).then(res => res);
};
export const getStageDetailsById = payload => {
  return ajaxServiceApi.getStageDetails(payload).then(res => res);
};

export const findMediumMethod = payload => {
  return ajaxServiceApi.findMediumWH(payload).then(res => res);
};
export const uploadMediumMethod = payload => {
  return ajaxServiceApi.uploadMediumWH(payload).then(res => res);
};
// 介质仓库搜索
export const getMediumMethod = payload => {
  return ajaxServiceApi.getMediumMethod(payload).then(res => res);
};
export const searchNameSystemTypeMethod = payload => {
  return ajaxServiceApi.searchNameSystemType(payload).then(res => res);
};
export const repListByNameMethod = payload => {
  return ajaxServiceApi.repListByName(payload).then(res => res);
};
// 构建计划末班
export const getStageNameplan = payload => {
  return ajaxServiceApi.getStageNameplan(payload).then(res => res);
};

// 系统集成查询
export const getAllSystemList = payload => {
  return ajaxServiceApi.getAllSystemList(payload).then(res => res);
};
// 系统集成保存
export const addSystemRequest = payload => {
  return ajaxServiceApi.addSystemRequest(payload).then(res => res);
};
// 系统集成删除;
export const deleteSystemRequest = payload => {
  return ajaxServiceApi.deleteSystemRequest(payload).then(res => res);
};
// 集成修改
export const updateSystemRequest = payload => {
  return ajaxServiceApi.updateSystemRequest(payload).then(res => res);
};
// 集成搜索补全查询
export const searchByNameSystemRequest = payload => {
  return ajaxServiceApi.searchByNameSystemRequest(payload).then(res => res);
};
// 系统集成类别单选;
export const categorySystemRequest = payload => {
  return ajaxServiceApi.categorySystemRequest(payload).then(res => res);
};
// 系统集成测试
export const testSystemRequest = payload => {
  return ajaxServiceApi.testSystemRequest(payload).then(res => res);
};
export const getDefinationById = payload => {
  return ajaxServiceApi.getDefinationById(payload).then(res => res);
};
export const baseUpdate = payload => {
  return ajaxServiceApi.baseUpdate(payload).then(res => res);
};
export const listAllProjectsMethod = payload => {
  return ajaxServiceApi.listAllProjects(payload).then(res => res);
};
/**
 * code relation
 */
export const getRepoTypeMethod = () => {
  return ajaxServiceApi.getRepoType().then(res => res);
};
export const getConponentsMethod = payload => {
  return ajaxServiceApi.getConponents(payload).then(res => res);
};
export const getCRConponentsListMethod = payload => {
  return ajaxServiceApi.getCRConponentsList(payload).then(res => res);
};
export const saveCRConponentMethod = payload => {
  return ajaxServiceApi.saveCRConponent(payload).then(res => res);
};
export const delCRRelationMethod = payload => {
  return ajaxServiceApi.delCRRelation(payload).then(res => res);
};
export const updateCRRelationMethod = payload => {
  return ajaxServiceApi.updateCRRelation(payload).then(res => res);
};
export const enterCRRepoMethod = payload => {
  return ajaxServiceApi.enterCRRepo(payload).then(res => res);
};
export const getCRFileContentMethod = payload => {
  return ajaxServiceApi.getCRFileContent(payload).then(res => res);
};
export const searchRepMethod = payload => {
  return ajaxServiceApi.searchRep(payload).then(res => res);
};

export const getCRBranchMethod = payload => {
  return ajaxServiceApi.getBranchList(payload).then(res => res);
};
export const getBranchDelMethod = payload => {
  return ajaxServiceApi.getBranchDel(payload).then(res => res);
};
export const createBranchMethod = payload => {
  return ajaxServiceApi.createBranch(payload).then(res => res);
};

export const getBranchUnprotectMethod = payload => {
  return ajaxServiceApi.getBranchUnprotect(payload).then(res => res);
};
export const getBranchProtectMethod = payload => {
  return ajaxServiceApi.getBranchProtect(payload).then(res => res);
};
export const getTagData = payload => {
  return ajaxServiceApi.getTagList(payload).then(res => res);
};
export const addTag = payload => {
  return ajaxServiceApi.addTag(payload).then(res => res);
};
export const deleteTag = payload => {
  return ajaxServiceApi.deleteTag(payload).then(res => res);
};
export const downloadFile = payload => {
  return ajaxServiceApi.downloadFile(payload).then(res => res);
};
// code relaction end
/**
 * 环境
 */
// 查询
export const getEnvironmentRequest = payload => {
  return ajaxServiceApi.getEnvironmentRequest(payload).then(res => res);
};
// 保存
export const addEnvironmentRequest = payload => {
  return ajaxServiceApi.addEnvironmentRequest(payload).then(res => res);
};
// 删除
export const deleteEnvironmentRequest = payload => {
  return ajaxServiceApi.deleteEnvironmentRequest(payload).then(res => res);
};
// 修改
export const updateEnvironmentRequest = payload => {
  return ajaxServiceApi.updateEnvironmentRequest(payload).then(res => res);
};
// 类型
export const getEnvironmentTypeRequest = payload => {
  return ajaxServiceApi.getEnvironmentTypeRequest(payload).then(res => res);
};
/**
 * 角色
 */
// 查询
export const getRoleRequest = payload => {
  return ajaxServiceApi.getRoleRequest(payload).then(res => res);
};
// 保存
export const addRoleRequest = payload => {
  return ajaxServiceApi.addRoleRequest(payload).then(res => res);
};
// 删除
export const deleteRoleRequest = payload => {
  return ajaxServiceApi.deleteRoleRequest(payload).then(res => res);
};
// 修改
export const updateRoleRequest = payload => {
  return ajaxServiceApi.updateRoleRequest(payload).then(res => res);
};
// 全部角色
export const getAllMenuRequest = payload => {
  return ajaxServiceApi.getAllMenuRequest(payload).then(res => res);
};
export const getSelectMenuRequest = payload => {
  return ajaxServiceApi.getSelectMenuRequest(payload).then(res => res);
};
export const saveSelectMenuRequest = payload => {
  return ajaxServiceApi.saveSelectMenuRequest(payload).then(res => res);
};
/**
 * 团队
 */
// 查询
export const getTeamRequest = payload => {
  return ajaxServiceApi.getTeamRequest(payload).then(res => res);
};
// 保存
export const addTeamRequest = payload => {
  return ajaxServiceApi.addTeamRequest(payload).then(res => res);
};
// 删除
export const deleteTeamRequest = payload => {
  return ajaxServiceApi.deleteTeamRequest(payload).then(res => res);
};
// 删除
export const authorizeTeamRequest = payload => {
  return ajaxServiceApi.authorizeTeamRequest(payload).then(res => res);
};
// 成员
export const userAllTeamRequest = payload => {
  return ajaxServiceApi.userAllTeamRequest(payload).then(res => res);
};
/**
 * 资源
 */
// 查询
export const getResourceRequest = payload => {
  return ajaxServiceApi.getResourceRequest(payload).then(res => res);
};
// 保存
export const addResourceRequest = payload => {
  return ajaxServiceApi.addResourceRequest(payload).then(res => res);
};
// 删除
export const deleteResourceRequest = payload => {
  return ajaxServiceApi.deleteResourceRequest(payload).then(res => res);
};
// 修改
export const updateResourceRequest = payload => {
  return ajaxServiceApi.updateResourceRequest(payload).then(res => res);
};
// 环境名称
export const getEnvironmentNameRequest = payload => {
  return ajaxServiceApi.getEnvironmentNameRequest(payload).then(res => res);
};
// 测试
export const testResourceRequest = payload => {
  return ajaxServiceApi.testResourceRequest(payload).then(res => res);
};
/**
 * 资源容器云
 */
// 新增容器
export const addClusterRequest = payload => {
  return ajaxServiceApi.addClusterRequest(payload).then(res => res);
};
// 新增容器测试
export const testClusterRequest = payload => {
  return ajaxServiceApi.testClusterRequest(payload).then(res => res);
};
// 容器信息
export const findClusterInfoRequest = payload => {
  return ajaxServiceApi.findClusterInfoRequest(payload).then(res => res);
};
// 主机add
export const addCaasNodeRequest = payload => {
  return ajaxServiceApi.addCaasNodeRequest(payload).then(res => res);
};
// 主机delete
export const deleteCaasNodeRequest = payload => {
  return ajaxServiceApi.deleteCaasNodeRequest(payload).then(res => res);
};
// 主机update
export const updateCaasNodeRequest = payload => {
  return ajaxServiceApi.updateCaasNodeRequest(payload).then(res => res);
};
// 主机test
export const testCaasNodeRequest = payload => {
  return ajaxServiceApi.testCaasNodeRequest(payload).then(res => res);
};
// 主机list
export const getCaasNodeListRequest = payload => {
  return ajaxServiceApi.getCaasNodeListRequest(payload).then(res => res);
};
// 主机信息
export const findPodInfoRequest = payload => {
  return ajaxServiceApi.findPodInfoRequest(payload).then(res => res);
};
// 工作区save
export const addCaasNamespaceRequest = payload => {
  return ajaxServiceApi.addCaasNamespaceRequest(payload).then(res => res);
};
// 工作区delete
export const deleteCaasNamespaceRequest = payload => {
  return ajaxServiceApi.deleteCaasNamespaceRequest(payload).then(res => res);
};
// 工作区name查询
export const searchCaasNamespaceListRequest = payload => {
  return ajaxServiceApi.searchCaasNamespaceListRequest(payload).then(res => res);
};
// 工作区update
export const updateCaasNamespaceRequest = payload => {
  return ajaxServiceApi.updateCaasNamespaceRequest(payload).then(res => res);
};
// 工作区list
export const getCaasNamespaceListRequest = payload => {
  return ajaxServiceApi.getCaasNamespaceListRequest(payload).then(res => res);
};
// 根据集群id查询命名空间pod资源限制值
export const getCaasNamespacePodListByClusterId = payload => {
  return ajaxServiceApi.getCaasNamespacePodListByClusterId(payload).then(res => res);
};
/**
 * 应用市场
 */
// 基本信息
export const getmonitorPodBasicRequest = payload => {
  return ajaxServiceApi.getmonitorPodBasicRequest(payload).then(res => res);
};
// 事件
export const getmonitorPodEventRequest = payload => {
  return ajaxServiceApi.getmonitorPodEventRequest(payload).then(res => res);
};
// 事件
export const getmonitorPodLogRequest = payload => {
  return ajaxServiceApi.getmonitorPodLogRequest(payload).then(res => res);
};
// 监控
export const getmonitorInfoRequest = payload => {
  return ajaxServiceApi.getmonitorInfoRequest(payload).then(res => res);
};
/**
 * 应用市场
 */
// list
export const getmarketAppListRequest = payload => {
  return ajaxServiceApi.getmarketAppListRequest(payload).then(res => res);
};
// detail
export const getmarketAppDetailRequest = payload => {
  return ajaxServiceApi.getmarketAppDetailRequest(payload).then(res => res);
};
// 部署
export const findMarketdeployRequest = payload => {
  return ajaxServiceApi.findMarketdeployRequest(payload).then(res => res);
};
/**
 * 镜像仓库
 */
// 收藏
export const houseCollectRequest = payload => {
  return ajaxServiceApi.houseCollectRequest(payload).then(res => res);
};
// 收藏列表
export const gethouseCollectListRequest = payload => {
  return ajaxServiceApi.gethouseCollectListRequest(payload).then(res => res);
};
// 镜像信息
export const gethouseImageInfoRequest = payload => {
  return ajaxServiceApi.gethouseImageInfoRequest(payload).then(res => res);
};
// 镜像公有私有列表
export const gethouseImageListRequest = payload => {
  return ajaxServiceApi.gethouseImageListRequest(payload).then(res => res);
};
// 镜像公有私有列表
export const gethouseImagePublicListRequest = payload => {
  return ajaxServiceApi.gethouseImagePublicListRequest(payload).then(res => res);
};
// 镜像同步
export const houseImageSyncRequest = payload => {
  return ajaxServiceApi.houseImageSyncRequest(payload).then(res => res);
};

// 扫描镜像
export const houseImageScanRequest = payload => {
  return ajaxServiceApi.houseImageScanRequest(payload).then(res => res);
};
// 扫描镜像1
export const houseImageScanTagRequest = payload => {
  return ajaxServiceApi.houseImageScanTagRequest(payload).then(res => res);
};
// 扫描镜像2
export const houseImageScanTagsRequest = payload => {
  return ajaxServiceApi.houseImageScanTagsRequest(payload).then(res => res);
};
// 扫描镜像3
export const houseImageUpdateScanRequest = payload => {
  return ajaxServiceApi.houseImageUpdateScanRequest(payload).then(res => res);
};

// 镜像(版本)
export const houseImageTagsRequest = payload => {
  return ajaxServiceApi.houseImageTagsRequest(payload).then(res => res);
};
// 镜像保存
export const houseImageUpdateRequest = payload => {
  return ajaxServiceApi.houseImageUpdateRequest(payload).then(res => res);
};
/**
 * 部署
 */
// 分页查找部署实例定义
export const deploymentPageList = payload => {
  return ajaxServiceApi.deploymentPageList(payload).then(res => res);
};
// 部署定义保存
export const deploymentSave = payload => {
  return ajaxServiceApi.deploymentSave(payload).then(res => res);
};
// 部署定义更新
export const deploymentUpdate = payload => {
  return ajaxServiceApi.deploymentUpdate(payload).then(res => res);
};
// 新增部署定义删除
export const deploymentDelete = payload => {
  return ajaxServiceApi.deploymentDelete(payload).then(res => res);
};
// 获取运行环境
export const getRunningEnvList = payload => {
  return ajaxServiceApi.getRuningEnvList(payload).then(res => res);
};
// 上传软件包
export const uploadSoftBag = payload => {
  return ajaxServiceApi.uploadSoft(payload).then(res => res);
};
// 获取主机列表
export const getHostList = payload => {
  return ajaxServiceApi.getHostList(payload).then(res => res);
};
// 获取shell脚本
export const getShell = payload => {
  return ajaxServiceApi.getShell(payload).then(res => res);
};
// 克隆定义
export const cloneDeployment = payload => {
  return ajaxServiceApi.cloneDeployMent(payload).then(res => res);
};
// 查找定义
export const findDefination = payload => {
  return ajaxServiceApi.findDefination(payload).then(res => res);
};
// 更新部署实例状态
export const updateDeployStatus = payload => {
  return ajaxServiceApi.updateDeployStatus(payload).then(res => res);
};
// 部署日志
export const getDeployConsole = payload => {
  return ajaxServiceApi.getDeployLog(payload).then(res => res);
};
// pod日志
export const getPodConsole = payload => {
  return ajaxServiceApi.findPodLog(payload).then(res => res);
};
// pod组信息
export const getPodList = payload => {
  return ajaxServiceApi.getPodList(payload).then(res => res);
};
// 部署历史日志
export const getDeployHisConsole = payload => {
  return ajaxServiceApi.getDeployHisLog(payload).then(res => res);
};
// 根据id查询主机列表
export const findIpsListById = payload => {
  return ajaxServiceApi.findIpListById(payload).then(res => res);
};
// 部署历史
export const getHistoryList = payload => {
  return ajaxServiceApi.getHistoryList(payload).then(res => res);
};
// 部署历史详情
export const getHistoryListDetails = payload => {
  return ajaxServiceApi.getHistoryListDetails(payload).then(res => res);
};
// 部署执行
export const executeDeployment = payload => {
  return ajaxServiceApi.executeDeployment(payload).then(res => res);
};
// 部署状态查询
export const findDeployStatus = payload => {
  return ajaxServiceApi.findDeployStatus(payload).then(res => res);
};
// 根据项目Id查询用户信息列表
export const getUserlistById = payload => {
  return ajaxServiceApi.getUserlistById(payload).then(res => res);
};
// 更新主机信息
export const updateHosts = payload => {
  return payload;
};
// 获取yml文件
export const getYmlTmp = payload => {
  return ajaxServiceApi.getYmlTmp(payload).then(res => res);
};
// 获取部署镜像列表
export const getImagelist = payload => {
  return ajaxServiceApi.deployImageList(payload).then(res => res);
};
// SonarQube服务器
export const getSonarQubeServerList = payload => {
  return ajaxServiceApi.getAllSystemList(payload).then(res => res);
};
// nexus地址
export const getNexusList = payload => {
  return ajaxServiceApi.getAllSystemList(payload).then(res => res);
};
// 镜像服务器
export const getImageServerList = payload => {
  return ajaxServiceApi.getAllSystemList(payload).then(res => res);
};
// 集群相关
// 根据projectId查找集群信息
export const getClusterListsByProjectId = payload => {
  return ajaxServiceApi.getClusterListsByProjectId(payload).then(res => res);
};
