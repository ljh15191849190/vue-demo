import { put, call, take } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getCRBranchMethod,
  getBranchProtectMethod,
  getBranchUnprotectMethod,
  getBranchDelMethod,
  createBranchMethod
} from "./apiCall";

export function* getCRBranch(payload) {
  try {
    const branchList = yield call(getCRBranchMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_BRANCH_SAGA, branchList });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* BranchDel(payload) {
  try {
    const delBranStatus = yield call(getBranchDelMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_BRANCH_DEL_SAGA, delBranStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* createBranch(payload) {
  try {
    const createStatus = yield call(createBranchMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_BRANCH_CREATE_SAGA, createStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* BranchUnprotect(payload) {
  try {
    const unprotectStatus = yield call(getBranchUnprotectMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_BRANCH_UNPROTECT_SAGA, unprotectStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* BranchProtect(payload) {
  try {
    const protectStatus = yield call(getBranchProtectMethod, payload);
    yield put({ type: actionTypes.XAHC_GET_BRANCH_PROTECT_SAGA, protectStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getBranchListFlow({ payload }) {
  yield call(getCRBranch, payload);
}
export function* BranchDelFlow({ payload }) {
  yield call(BranchDel, payload);
}
export function* createBranchFlow({ payload }) {
  yield call(createBranch, payload);
}
export function* BranchUnprotectFlow({ payload }) {
  yield call(BranchUnprotect, payload);
}
export function* BranchProtectFlow({ payload }) {
  yield call(BranchProtect, payload);
}
