import { put, call } from "redux-saga/effects";
import * as actionTypes from "../constants/ActionTypes";
import {
  getAllProjects,
  addProjectsRequest,
  deleteEquip,
  updataProjectsRequest,
  codeornameProjectsRequest,
  searchSystemUserAllRequest
} from "./apiCall";

export function* getPjmProjects(payload) {
  try {
    const resData = yield call(getAllProjects, payload);
    yield put({ type: actionTypes.XAHC_PJM_PROJECT_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}

export function* getPjmProjectsFlow({ payload }) {
  const response = yield call(getPjmProjects, payload);
}
export function* addProjects(payload) {
  try {
    const appStatus = yield call(addProjectsRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_ADD_PROJECT_SAGA, appStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* addProjectsFlow({ payload }) {
  const response = yield call(addProjects, payload);
}

export function* deleteProjects(payload) {
  try {
    const deleteStatus = yield call(deleteEquip, payload);
    yield put({ type: actionTypes.XAHC_PJM_DELETE_PROJECT_SAGA, deleteStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* deleteProjectsFlow({ payload }) {
  const response = yield call(deleteProjects, payload);
}

export function* updataProjects(payload) {
  try {
    const updataStatus = yield call(updataProjectsRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_UPDATA_PROJECT_SAGA, updataStatus });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* updataProjectsFlow({ payload }) {
  const response = yield call(updataProjects, payload);
}

export function* codenameProjects(payload) {
  try {
    const resData = yield call(codeornameProjectsRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_CODEORNAME_PROJECT_SAGA, resData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* codenameProjectsFlow({ payload }) {
  const response = yield call(codenameProjects, payload);
}

export function* searchSystemUserAll(payload) {
  try {
    const userallData = yield call(searchSystemUserAllRequest, payload);
    yield put({ type: actionTypes.XAHC_PJM_PROJECT_USERALL_SAGA, userallData });
  } catch (err) {
    yield put({ type: actionTypes.ERROR });
  }
}
export function* searchSystemUserAllFlow({ payload }) {
  const response = yield call(searchSystemUserAll, payload);
}
