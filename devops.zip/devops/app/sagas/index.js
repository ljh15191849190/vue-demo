import "babel-polyfill";
import { takeEvery, takeLatest } from "redux-saga/effects";
import * as types from "../constants/ActionTypes";
import { loginFlow } from "./login";
import { logoutFlow } from "./logout";
import { getSysInteRepertoryFlow } from "./SysInteRepertory";
import {
  houseCollectFlow,
  gethouseCollectListFlow,
  gethouseImageInfoFlow,
  gethouseImageListFlow,
  houseImageSyncFlow,
  houseImageScanFlow,
  houseImageTagsFlow,
  houseImageUpdateFlow,
  gethouseImagePublicListFlow,
  houseImageScanTagFlow,
  houseImageScanTagsFlow,
  houseImageUpdateScanFlow
} from "./ImageHouse";
import {
  getPjmProjectsFlow,
  addProjectsFlow,
  deleteProjectsFlow,
  updataProjectsFlow,
  codenameProjectsFlow,
  searchSystemUserAllFlow
} from "./PjmProjectList";
import {
  getPjmComponentFlow,
  addPjmComponentFlow,
  updatePjmComponentFlow,
  deletePjmComponentFlow,
  getModuleDetailFlow,
  addressPjmComponentFlow
} from "./PjmComponentList";
import {
  allDefinationListFlow,
  cloneDefinationFlow,
  deleteDefinationFlow,
  baseDefinationFlow,
  updateDefinationFlow,
  saveParamsFlow,
  paramsListsFlow,
  paramsDeleteFlow,
  allTemplatesFlow,
  buildMissonSaveFlow,
  getDefinationDetailsFlow,
  definationUpdateFlow,
  updateParamsFlow,
  buildMissonUpdateFlow,
  getStageDetailsFlow,
  buildHistoryFlow,
  buildConsoleFlow,
  buildStatusFlow,
  buildLogsFlow,
  buildFindjarFlow,
  buildFlagFlow,
  getCurrentStagesFlow,
  deleteStageMethodFlow,
  pipeTemplatesFlow,
  buildStagenameplanFlow,
  resetStateFlow,
  resetDataFlow,
  buildStagenameplanemptyFlow,
  getcomponentMeasuresFlow,
  getcomponentTreeFlow,
  getcomponentSourceFlow,
  getattrParamsFlow,
  getcomponentRuleFlow,
  updateStatusFlow,
  resetImageFlow,
  resetEmailFlow,
  buildMissonBatchSaveFlow,
  resetBasicSaveDataFlow,
  getSonarQubeServerFlow,
  getNexusDataListFlow,
  getImageServerFlow,
  setBuildCurrentPageFlow,
  MediumdownloadFlow
} from "./Build";
import {
  deployDefinationListFlow,
  deployDefinationSaveFlow,
  getEnvListFlow,
  getHostListDataFlow,
  getShellContentFlow,
  deleteDeploytFlow,
  cloneDeploytFlow,
  findDeployFlow,
  updateDeployFlow,
  deployStatusUpdateFlow,
  findIpsByIdFlow,
  getConsoleFlow,
  deployHistoryFlow,
  deployHistoryDetailsFlow,
  executeDeployFlow,
  resetDepStateFlow,
  findDeploymentStatusFlow,
  resetDeployStateFlow,
  userlistByIdStatusFlow,
  updateHostStatusFlow,
  getHisConsoleFlow,
  findDeployYmlTmpFlow,
  getPodDataListFlow,
  getPodlogFlow,
  resetDetailsDataFlow,
  getImageHouseFlow,
  resetDeployConsoleFlow,
  resetErrorStatusFlow,
  setCurrentPageFlow
} from "./Deploy";
import {
  getSystemListFlow,
  addSystemFlow,
  deleteSystemFlow,
  updateSystemFlow,
  searchByNameSystemFlow,
  categorySystemFlow,
  testSystemFlow,
  resetFieldsFlow
} from "./SystemList";
import {
  listAllProjectsFlow,
  getProjectsOvewviewFlow,
  getProjectsdeploytopFlow,
  getProjectsbuildtopFlow,
  getProjectsRateFlow,
  upateProjectNameFlow,
  getBuildstatementFlow,
  getdeploystatementFlow,
  getcodequalityFlow,
  getcodeCommitFlow
} from "./ListProjects";
import {
  uploadMediumFlow,
  findMediumFlow,
  getSearchMediumFlow,
  repListByNameFlow,
  searchNameSystemTypeFlow,
  uploadSoftFlow
} from "./MediumWarehouse";
import {
  getRepoTypeFlow,
  getConponentsFlow,
  getRCConponentsListFlow,
  saveRCConponentFlow,
  delRCRelationFlow,
  updateRCRelationFlow,
  enterCRRepoFlow,
  getCRFileContentFlow,
  searchRepFlow,
  getTagListDataFlow,
  createTagFlow,
  deleteTagsFlow,
  downLoadTagFileFlow
} from "./CodeRelaction";
import {
  getBranchListFlow,
  BranchDelFlow,
  BranchUnprotectFlow,
  BranchProtectFlow,
  createBranchFlow
} from "./Branch";

import {
  addMethod,
  delMethod,
  getMethod,
  updateMethod,
  searchMethod
} from "./systemManage/callApi";

import {
  addMethodMaitanance,
  delMethodMaitanance,
  getMethodMaitanance,
  updateMethodMaitanance,
  searchMethodMaitanance
} from "./maitananceManage/callApi";

import {
  getEnvironmentFlow,
  addEnvironmentFlow,
  deleteEnvironmentFlow,
  updateEnvironmentFlow,
  getEnvironmentTypeFlow
} from "./EnvironmentList";

import {
  getRoleFlow,
  addRoleFlow,
  deleteRoleFlow,
  updateRoleFlow,
  getAllMenuFlow,
  getSelectMenuFlow,
  saveSelectMenuFlow,
  getTeamFlow,
  addTeamFlow,
  deleteTeamFlow,
  authorizeTeamFlow,
  userallTeamFlow
} from "./RoleList";
import {
  getResourceFlow,
  addResourceFlow,
  deleteResourceFlow,
  testResourceFlow,
  updateResourceFlow,
  getEnvironmentNameFlow,
  addClusterFlow,
  testClusterFlow,
  addCaasNodeFlow,
  getCaasNodeListFlow,
  deleteCaasNodeFlow,
  updateCaasNodeFlow,
  testCaasNodeFlow,
  deleteCaasNamespaceFlow,
  updateCaasNamespaceFlow,
  searchCaasNamespaceListFlow,
  addCaasNamespaceFlow,
  getCaasNamespaceListFlow,
  getmarketAppListFlow,
  getmarketAppDetailFlow,
  findClusterInfoFlow,
  findPodInfoFlow,
  findClusterByProjectIdFlow,
  getNamespacePodListByClusterIdFlow,
  getmonitorPodBasicFlow,
  getmonitorPodEventFlow,
  getmonitorPodLogFlow,
  getmonitorInfoFlow,
  findMarketdeployFlow,
  resetClusterDataFlow,
  resetNameSpaceDataFlow
} from "./ResourceList";

export default function* mySaga() {
  yield [
    takeEvery(types.XAHC_LOGIN, loginFlow),
    takeEvery(types.XAHC_LOGOUT, logoutFlow),
    takeEvery(types.XAHC_GET_ALL_PROJECTS, listAllProjectsFlow),
    takeEvery(types.XAHC_PROJECT_OVERVIEW, getProjectsOvewviewFlow), // 概览
    takeEvery(types.XAHC_PROJECT_DEPLOYTOP, getProjectsdeploytopFlow), // 概览
    takeEvery(types.XAHC_PROJECT_BUILD_DEPLOYTOP, getProjectsbuildtopFlow), // 概览
    takeEvery(types.XAHC_PROJECT_RATE, getProjectsRateFlow), // 概览
    takeEvery(types.XAHC_PROJECT_BUILDSTATEMENT, getBuildstatementFlow), // 报表
    takeEvery(types.XAHC_PROJECT_DEPLOYSTATEMENT, getdeploystatementFlow), // 报表
    takeEvery(types.XAHC_PROJECT_CODEQUALITY, getcodequalityFlow), // 报表
    takeEvery(types.XAHC_PROJECT_CODECOMMIT, getcodeCommitFlow), // 报表
    takeEvery(types.XAHC_UPDATE_PROJECT_NAME, upateProjectNameFlow), // projectName update
    takeEvery(types.XAHC_SYS_INTE_REPERTORY, getSysInteRepertoryFlow),
    takeEvery(types.XAHC_PJM_PROJECT, getPjmProjectsFlow),
    takeEvery(types.XAHC_PJM_ADD_PROJECT, addProjectsFlow),
    takeEvery(types.XAHC_PJM_DELETE_PROJECT, deleteProjectsFlow),
    takeEvery(types.XAHC_PJM_UPDATA_PROJECT, updataProjectsFlow),
    takeEvery(types.XAHC_PJM_CODEORNAME_PROJECT, codenameProjectsFlow),
    takeEvery(types.XAHC_PJM_PROJECT_USERALL, searchSystemUserAllFlow),
    takeEvery(types.XAHC_PJM_COMPONENT, getPjmComponentFlow),
    takeEvery(types.XAHC_PJM_ADD_COMPONENT, addPjmComponentFlow),
    takeEvery(types.XAHC_PJM_UPDATE_COMPONENT, updatePjmComponentFlow),
    takeEvery(types.XAHC_PJM_DELETE_COMPONENT, deletePjmComponentFlow),
    takeEvery(types.XAHC_PJM_COMPONENT_ADDRESS, addressPjmComponentFlow),
    takeEvery(types.XAHC_PJM_COMPONENT_MODULE_DETAIL, getModuleDetailFlow),
    takeEvery(types.XAHC_BUILD_LIST_ALL, allDefinationListFlow),
    takeEvery(types.XAHC_BUILD_CLONE, cloneDefinationFlow),
    takeEvery(types.XAHC_BUILD_DELETE, deleteDefinationFlow),
    takeEvery(types.XAHC_BUILD_BASE, baseDefinationFlow),
    takeEvery(types.XAHC_BUILD_UPDATE, updateDefinationFlow),
    takeEvery(types.XAHC_BUILD_PARAMS_SAVE, saveParamsFlow),
    takeEvery(types.XAHC_BUILD_PARAMS_LIST, paramsListsFlow),
    takeEvery(types.XAHC_BUILD_PARAMS_DELETE, paramsDeleteFlow),
    takeEvery(types.XAHC_BUILD_TEMPLATES, allTemplatesFlow),
    takeEvery(types.XAHC_BUILD_MISSION_SAVE, buildMissonSaveFlow),
    takeEvery(types.XAHC_BUILD_GET_DEFINATION_BY_ID, getDefinationDetailsFlow),
    takeEvery(types.XAHC_BUILD_BASE_UPDATE, definationUpdateFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_CONSOLE, buildConsoleFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_STATUS, buildStatusFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_LOGS, buildLogsFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_FLAG, buildFlagFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_FINDJAR, buildFindjarFlow),
    takeEvery(types.XAHC_BUILD_HISTORY, buildHistoryFlow),
    takeEvery(types.XAHC_SYSTEM_SEARCH_LIST, getSystemListFlow),
    takeEvery(types.XAHC_ADD_SYSTEM_SEARCH_LIST, addSystemFlow),
    takeEvery(types.XAHC_DELETE_SYSTEM_SEARCH_LIST, deleteSystemFlow),
    takeEvery(types.XAHC_UPDATE_SYSTEM_SEARCH_LIST, updateSystemFlow),
    takeEvery(types.XAHC_SYSTEMTYPE_SEARCHBYNAME, searchByNameSystemFlow),
    takeEvery(types.XAHC_SYSTEMTYPE_CATEGORY, categorySystemFlow),
    takeEvery(types.XAHC_TESE_SYSTEM_SEARCH_LIST, testSystemFlow),
    takeEvery(types.XAHC_RESET_SYSTEM_FIELDS, resetFieldsFlow),
    takeEvery(types.XAHC_BUILD_RESETDATA, resetDataFlow),
    takeEvery(types.XAHC_BUILD_GET_DEFINATION_BY_ID, getDefinationDetailsFlow),
    takeEvery(types.XAHC_BUILD_GET_DEFINATION_BY_ID, getDefinationDetailsFlow),
    takeEvery(types.XAHC_BUILD_MEDIUM_WH_UPLOAD, uploadMediumFlow),
    takeEvery(types.XAHC_BUILD_MEDIUM_WH_FIND, findMediumFlow),
    takeEvery(types.XAHC_BUILD_SEARCH_WH_FIND, getSearchMediumFlow),
    takeEvery(types.XAHC_BUILD_SEARCH_NAME_SYSTEM_TYPE, searchNameSystemTypeFlow),
    takeEvery(types.XAHC_BUILD_REP_LIST_BYNAME, repListByNameFlow),
    takeEvery(types.XAHC_BUILD_PARAMS_UPDATE, updateParamsFlow),
    takeEvery(types.XAHC_GET_REPO_TYPE, getRepoTypeFlow),
    takeEvery(types.XAHC_GET_COMPONENT_REQ, getConponentsFlow),
    takeEvery(types.XAHC_GET_RC_COMPONENT, getRCConponentsListFlow),
    takeEvery(types.XAHC_BUILD_MISSION_UPDATE, buildMissonUpdateFlow),
    takeEvery(types.XAHC_BUILD_MISSION_DETAILS, getStageDetailsFlow),
    takeEvery(types.XAHC_SAVE_RC_COMPONENT, saveRCConponentFlow),
    takeEvery(types.XAHC_DEL_RC_RELACTION, delRCRelationFlow),
    takeEvery(types.XAHC_UPDATE_RC_COMPONENT, updateRCRelationFlow),
    takeEvery(types.XAHC_ENTER_RC_REPO, enterCRRepoFlow),
    takeEvery(types.XAHC_BUILD_STAGE, getCurrentStagesFlow),
    takeEvery(types.XAHC_GET_FILE_CONTENT, getCRFileContentFlow),
    takeEvery(types.XAHC_SEARCH_REP, searchRepFlow),
    takeEvery(types.XAHC_GET_BRANCH, getBranchListFlow),
    takeEvery(types.XAHC_GET_BRANCH_DEL, BranchDelFlow),
    takeEvery(types.XAHC_GET_BRANCH_CREATE, createBranchFlow),
    takeEvery(types.XAHC_GET_BRANCH_PROTECT, BranchProtectFlow),
    takeEvery(types.XAHC_GET_BRANCH_UNPROTECT, BranchUnprotectFlow),
    takeEvery(types.XAHC_CODE_GET_TAG_LIST, getTagListDataFlow),
    takeEvery(types.XAHC_CODE_GET_TAG_ADD, createTagFlow),
    takeEvery(types.XAHC_CODE_GET_TAG_DELETE, deleteTagsFlow),
    takeEvery(types.XAHC_CODE_GET_TAG_DOWNLOAD, downLoadTagFileFlow),
    takeEvery(types.XAHC_BUILD_STAGE_DELETE, deleteStageMethodFlow),
    takeEvery(types.XAHC_BUILD_PIPELINE_TEMPLATE, pipeTemplatesFlow),
    takeEvery(types.XAHC_BUILD_STAGENAME_PLAN, buildStagenameplanFlow),
    takeEvery(types.XAHC_BUILD_RESETSTATE, resetStateFlow),
    takeEvery(types.XAHC_BUILD_PERFORME_STATUS_EMPTY, buildStagenameplanemptyFlow),
    takeEvery(types.XAHC_BUILD_QUALITY_MEASURES, getcomponentMeasuresFlow),
    takeEvery(types.XAHC_BUILD_QUALITY_TREE, getcomponentTreeFlow),
    takeEvery(types.XAHC_BUILD_QUALITY_SOURCE, getcomponentSourceFlow),
    takeEvery(types.XAHC_BUILD_QUALITY_RULE, getcomponentRuleFlow),
    takeEvery(types.XAHC_BUILD_ATTR_PARAMS, getattrParamsFlow),
    takeEvery(types.XAHC_BUILD_UPLOAD_SOFT, uploadSoftFlow),
    takeEvery(types.XAHC_BUILD_UPDATE_STATUS, updateStatusFlow),
    takeEvery(types.XAHC_BUILD_MISSION_BATCH_SAVE, buildMissonBatchSaveFlow),
    takeEvery(types.XAHC_RESET_DETAIL, resetDetailsDataFlow),
    takeEvery(types.XAHC_BUILD_RESET_SAVE_DATA, resetBasicSaveDataFlow),
    takeEvery(types.XAHC_BUILD_SONAR_SERVER_LIST, getSonarQubeServerFlow), //  SonarQube服务器
    takeEvery(types.XAHC_BUILD_NEXUS_LIST, getNexusDataListFlow), //  nexus地址
    takeEvery(types.XAHC_BUILD_IMAGE_SERVER_LIST, getImageServerFlow), //  镜像服务器
    takeEvery(types.XAHC_BUILD_SET_CURRENT_PAGE, setBuildCurrentPageFlow), //  镜像服务器
    takeEvery(types.XAHC_BUILD_MEDIUM_DOWNLOAD, MediumdownloadFlow), //  介质下载

    // 角色
    takeEvery(types.XAHC_ROLE_LIST, getRoleFlow),
    takeEvery(types.XAHC_ROLE_ADD, addRoleFlow),
    takeEvery(types.XAHC_ROLE_DELETE, deleteRoleFlow),
    takeEvery(types.XAHC_ROLE_UPDATE, updateRoleFlow),
    takeEvery(types.XAHC_ROLE_ALL_MENU, getAllMenuFlow),
    takeEvery(types.XAHC_ROLE_SELECT_MENU, getSelectMenuFlow),
    takeEvery(types.XAHC_ROLE_SAVE_SELECT_MENU, saveSelectMenuFlow),
    // 团队
    takeEvery(types.XAHC_TEAM_LIST, getTeamFlow),
    takeEvery(types.XAHC_TEAM_ADD, addTeamFlow),
    takeEvery(types.XAHC_TEAM_DELETE, deleteTeamFlow),
    takeEvery(types.XAHC_TEAM_AUTHORIZE, authorizeTeamFlow),
    takeEvery(types.XAHC_TEAM_TEAM_USER_ALL, userallTeamFlow),

    // system
    takeEvery(types.XAHC_ADD, addMethod),
    takeEvery(types.XAHC_DEL, delMethod),
    takeEvery(types.XAHC_GET, getMethod),
    takeEvery(types.XAHC_UPDATE, updateMethod),
    takeEvery(types.XAHC_SEARCHGET, searchMethod),

    takeEvery(types.XAHC_ENVIRONMENT_LIST, getEnvironmentFlow),
    takeEvery(types.XAHC_ENVIRONMENT_ADD, addEnvironmentFlow),
    takeEvery(types.XAHC_ENVIRONMENT_DELETE, deleteEnvironmentFlow),
    takeEvery(types.XAHC_ENVIRONMENT_UPDATE, updateEnvironmentFlow),
    takeEvery(types.XAHC_ENVIRONMENT_TYPE, getEnvironmentTypeFlow),
    // 资源
    takeEvery(types.XAHC_RESOURCE_LIST, getResourceFlow),
    takeEvery(types.XAHC_RESOURCE_ADD, addResourceFlow),
    takeEvery(types.XAHC_RESOURCE_UPDATE, updateResourceFlow),
    takeEvery(types.XAHC_RESOURCE_DELETE, deleteResourceFlow),
    takeEvery(types.XAHC_RESOURCE_TEST, testResourceFlow),
    takeEvery(types.XAHC_ENVIRONMENT_NAME, getEnvironmentNameFlow),
    // 资源容器云
    takeEvery(types.XAHC_RESOURCE_CLUSTER_ADD, addClusterFlow),
    takeEvery(types.XAHC_RESOURCE_CLUSTER_TEST, testClusterFlow),
    takeEvery(types.XAHC_RESOURCE_FIND_CLUSTER_INFO, findClusterInfoFlow),
    takeEvery(types.XAHC_RESOURCE_FIND_POD_INFO, findPodInfoFlow),
    takeEvery(types.XAHC_FIND_CLUSTER_BY_ID, findClusterByProjectIdFlow),
    takeEvery(types.XAHC_FIND_NAMESPACE_BY_CLUSTER_ID, getNamespacePodListByClusterIdFlow),
    // pod操作信息
    takeEvery(types.XAHC_RESOURCE_POD_BASIC_INFO, getmonitorPodBasicFlow),
    takeEvery(types.XAHC_RESOURCE_POD_EVENT_INFO, getmonitorPodEventFlow),
    takeEvery(types.XAHC_RESOURCE_POD_LOG_INFO, getmonitorPodLogFlow),
    takeEvery(types.XAHC_RESOURCE_POD_MONITOR_INFO, getmonitorInfoFlow),
    // 主机
    takeEvery(types.XAHC_RESOURCE_CAAS_NODE_ADD, addCaasNodeFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NODE_LIST, getCaasNodeListFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NODE_DELETE, deleteCaasNodeFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NODE_UPDATE, updateCaasNodeFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NODE_TEST, testCaasNodeFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NAMESPACE_DELETE, deleteCaasNamespaceFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NAMESPACE_SEARCH, searchCaasNamespaceListFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NAMESPACE_UPDATE, updateCaasNamespaceFlow),
    takeEvery(types.XAHC_RESET_CLUSTER, resetClusterDataFlow),
    takeEvery(types.XAHC_RESET_NAMESPACE, resetNameSpaceDataFlow),

    takeEvery(types.XAHC_RESOURCE_CAAS_NAMESPACE_ADD, addCaasNamespaceFlow),
    takeEvery(types.XAHC_RESOURCE_CAAS_NAMESPACE_LIST, getCaasNamespaceListFlow),
    // 应用市场
    takeEvery(types.XAHC_CAAS_MARKETAPPS_LIST, getmarketAppListFlow),
    takeEvery(types.XAHC_CAAS_MARKETAPPS_DETAIL, getmarketAppDetailFlow),
    takeEvery(types.XAHC_DEPLOY_MARKETAPPS_DEPLOY, findMarketdeployFlow),
    // 镜像仓库
    takeEvery(types.XAHC_CAAS_HOUSE_COLLECT, houseCollectFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_COLLECTS_LIST, gethouseCollectListFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_IMAGEINFO, gethouseImageInfoFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_IMAGES_LIST, gethouseImageListFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_SYNC, houseImageSyncFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_SCAN, houseImageScanFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_SCAN_TAG, houseImageScanTagFlow), // 扫描
    takeEvery(types.XAHC_CAAS_HOUSE_SCAN_TAGS, houseImageScanTagsFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_SCAN_UPDATETAG, houseImageUpdateScanFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_TAGS, houseImageTagsFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_UPDATE, houseImageUpdateFlow),
    takeEvery(types.XAHC_CAAS_HOUSE_IMAGES_PUBLIC_LIST, gethouseImagePublicListFlow),

    // 部署
    takeEvery(types.XAHC_DEPLOY_LIST_ALL, deployDefinationListFlow), // 分页查找部署实例定义
    takeEvery(types.XAHC_DEPLOY_SAVE, deployDefinationSaveFlow), // 保存部署实例
    takeEvery(types.XAHC_DEPLOY_RUNNINGENV_LIST, getEnvListFlow), // 获取运行环境
    takeEvery(types.XAHC_DEPLOY_HOST_LIST, getHostListDataFlow), // 获取主机列表
    takeEvery(types.XAHC_DEPLOY_SHELL, getShellContentFlow), // 获取shell脚本
    takeEvery(types.XAHC_DEPLOY_DELETE, deleteDeploytFlow), // 删除部署任务
    takeEvery(types.XAHC_DEPLOY_CLONE, cloneDeploytFlow), // 克隆部署任务
    takeEvery(types.XAHC_DEPLOY_FIND_BY_ID, findDeployFlow), // 查找部署任务
    takeEvery(types.XAHC_DEPLOY_UPDATE, updateDeployFlow), // 更新部署定义
    takeEvery(types.XAHC_DEPLOY_UPDATE_STATUS, deployStatusUpdateFlow), // 更新部署状态
    takeEvery(types.XAHC_DEPLOY_FIND_IPSLIST_BY_ID, findIpsByIdFlow), // 根据id查询主机列表
    takeEvery(types.XAHC_DEPLOY_CONSOLE, getConsoleFlow), // 查询日志
    takeEvery(types.XAHC_DEPLOY_HIS_CONSOLE, getHisConsoleFlow), // 查询历史日志
    takeEvery(types.XAHC_DEPLOY_HISTORY, deployHistoryFlow), // 部署历史
    takeEvery(types.XAHC_DEPLOY_HISTORY_DETAILS, deployHistoryDetailsFlow), // 部署历史详情
    takeEvery(types.XAHC_DEPLOY_EXECUTE, executeDeployFlow), // 部署历史详情
    takeEvery(types.XAHC_DEPLOY_RESETSTATE, resetDepStateFlow), // 部署状态重置
    takeEvery(types.XAHC_RESET_DEPLOY_STATE, resetDeployStateFlow), // 部署状态重置
    takeEvery(types.XAHC_DEPLOY_FIND_STATUS, findDeploymentStatusFlow), // 部署状态查询
    takeEvery(types.XAHC_DEPLOY_UPDATE_HOSTS, updateHostStatusFlow), // 部署状态查询
    takeEvery(types.XAHC_BUILD_RESET_IMAGE, resetImageFlow), //  重置镜像构建表单
    takeEvery(types.XAHC_BUILD_RESET_EMAIL, resetEmailFlow), //  重置email构建表单
    takeEvery(types.XAHC_DEPLOY_YML_TMP, findDeployYmlTmpFlow), //  yml文件
    takeEvery(types.XAHC_DEPLOY_POD_LIST, getPodDataListFlow), //  pod组
    takeEvery(types.XAHC_DEPLOY_POD_LOG, getPodlogFlow), //  pod日志
    takeEvery(types.XAHC_DEPLOY_IMAGE, getImageHouseFlow), //  镜像仓库
    takeEvery(types.XAHC_RESET_CONSOLE, resetDeployConsoleFlow), //  重置部署日志
    takeEvery(types.XAHC_RESET_ENV, resetErrorStatusFlow), //  重置错误信息
    takeEvery(types.XAHC_SET_CURRENT_PAGE, setCurrentPageFlow), //  设置部署分页当前页
    // 项目成员
    takeEvery(types.XAHC_TEAM_USER_LIST_BY_PROJECTID, userlistByIdStatusFlow), // 根据项目Id查询用户信息列表

    // maitanance
    takeEvery(types.XAHC_MAITANANCE_ADD, addMethodMaitanance),
    takeEvery(types.XAHC_MAITANANCE_DEL, delMethodMaitanance),
    takeEvery(types.XAHC_MAITANANCE_GET, getMethodMaitanance),
    takeEvery(types.XAHC_MAITANANCE_UPDATE, updateMethodMaitanance),
    takeEvery(types.XAHC_MAITANANCE_SEARCHGET, searchMethodMaitanance)
  ];
}
