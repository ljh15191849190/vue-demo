import Immutable from "immutable";
import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {}
});

const Branch = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_GET_BRANCH_SAGA:
      if (action.branchList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.branchList.res.data)
          .set("pageConfig", action.branchList.res.pageBean)
          .set("delBranStatus", 0)
          .set("protectStatus", 0)
          .set("unprotectStatus", 0)
          .set("createStatus", 0);
      }
      return state;
    case types.XAHC_GET_BRANCH_DEL_SAGA:
      if (action.delBranStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delBranStatus", 1);
      } else if (action.delBranStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("delBranStatus", 0);
      }
      return state.set("delBranStatus", 0);
    case types.XAHC_GET_BRANCH_PROTECT_SAGA:
      if (action.protectStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("protectStatus", 1);
      } else if (action.protectStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("protectStatus", 0);
      }
      return state.set("protectStatus", 0);
    case types.XAHC_GET_BRANCH_UNPROTECT_SAGA:
      if (action.unprotectStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("unprotectStatus", 1);
      } else if (action.unprotectStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("unprotectStatus", 0);
      }
      return state.set("unprotectStatus", 0);
    case types.XAHC_GET_BRANCH_CREATE_SAGA:
      if (action.createStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("createStatus", 1);
      } else if (action.createStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("createStatus", 0);
      }
      return state.set("createStatus", 0);
    case types.XAHC_BUILD_UPDATE_STATUS_SAGA:
      if (action.jobStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("jobStatus", 1);
      } else if (action.jobStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("jobStatus", 0);
      }
      return state;
    default:
      return state;
  }
};

export default Branch;
