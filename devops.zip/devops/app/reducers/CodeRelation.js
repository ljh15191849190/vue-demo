import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  repoTypes: [],
  components: [],
  rcComponents: [],
  pageConfig: {},
  saveStatus: 0,
  delStatus: 0,
  updateStatus: 0,
  enterCodeList: [],
  fileContent: ""
});

const CodeRelaction = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_GET_REPO_TYPE_SAGA:
      if (action.types.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("repoTypes", action.types.res.data)
          .set("enterCodeList", [])
          .set("saveStatus", 0)
          .set("delStatus", 0);
      }
      return state
        .set("repoTypes", [])
        .set("enterCodeList", [])
        .set("delStatus", 0)
        .set("saveStatus", 0);
    case types.XAHC_GET_COMPONENT_REQ_SAGA:
      if (action.types.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("components", action.types.res.data)
          .set("delStatus", 0)
          .set("enterCodeList", [])
          .set("saveStatus", 0);
      }
      return state
        .set("components", [])
        .set("delStatus", 0)
        .set("saveStatus", 0);
    case types.XAHC_GET_RC_COMPONENT_SAGA:
      if (action.components.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("rcComponents", action.components.res.data)
          .set("enterCodeList", [])
          .set("pageConfig", action.components.pageBean)
          .set("delStatus", 0)
          .set("saveStatus", 0)
          .set("updateStatus", 0);
      }
      return state;
    case types.XAHC_SAVE_RC_COMPONENT_SAGA:
      if (action.saveStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("saveStatus", 1);
      } else if (action.saveStatus.res.rtn_code == 84017) {
        return state.set("saveStatus", 2);
      } else if (action.saveStatus.res.rtn_code == 84015) {
        return state.set("saveStatus", 3);
      } else if (action.saveStatus.res.rtn_code == 84020) {
        return state.set("saveStatus", 4);
      } else if (action.saveStatus.res.rtn_code == 4001) {
        message.error("新增失败当前组件已被关联");
      } else if (action.saveStatus.res.rtn_code == 4007) {
        message.error("新增失败该代码库已在其他项目关联");
      } else {
        return state.set("saveStatus", 5);
      }
      return state;
    case types.XAHC_DEL_RC_RELACTION_SAGA:
      if (action.delStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      } else if (action.delStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("delStatus", 2);
      } else if (action.delStatus.res.rtn_code == "4006") {
        message.info("解除失败，有构建任务使用该组件");
      }
      return state;
    case types.XAHC_UPDATE_RC_COMPONENT_SAGA:
      if (action.updateStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("updateStatus", 1);
      } else if (action.updateStatus.res.rtn_code == 84017) {
        return state.set("updateStatus", 2);
      } else if (action.updateStatus.res.rtn_code == 84020) {
        return state.set("updateStatus", 3);
      } else {
        return state.set("updateStatus", 4);
      }
    case types.XAHC_ENTER_RC_REPO_SAGA:
      if (action.ecList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("enterCodeList", action.ecList.res.data);
      } else if (action.ecList.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("enterCodeList", []);
      }
      return state;
    case types.XAHC_GET_FILE_CONTENT_SAGA:
      if (action.fileContent.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("fileContent", action.fileContent.res.data);
      } else if (action.ecList.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("fileContent", "");
      }
      return state;
    case types.XAHC_SEARCH_REP_SAGA:
      if (action.searchRep.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("rcComponents", action.searchRep.res.data);
      } else if (action.ecList.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("rcComponents", []);
      }
      return state;
    case types.XAHC_CODE_GET_TAG_LIST_SAGA:
      if (action.tagListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("tagListData", action.tagListData.res.data)
          .set("tagPageConfig", action.tagListData.res.pageBean)
          .set("tagAddFlag", 0)
          .set("deleteTagFlag", 0);
      } else if (action.tagListData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("tagListData", "");
      }
      return state;
    case types.XAHC_CODE_GET_TAG_ADD_SAGA:
      if (action.tagAddData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("添加成功！");
        return state.set("tagAddFlag", 1);
      } else if (action.tagListData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.info("添加失败！");
        return state.set("tagAddFlag", -1);
      }
      return state;
    case types.XAHC_CODE_GET_TAG_DELETE_SAGA:
      if (action.tagDeleteData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("删除成功！");
        return state.set("deleteTagFlag", 1);
      } else if (action.tagDeleteData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.info("删除失败！");
        return state.set("deleteTagFlag", -1);
      }
      return state;
    default:
      return state;
  }
};

export default CodeRelaction;
