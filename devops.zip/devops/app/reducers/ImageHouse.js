import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  collectsData: [],
  pageConfig: {},
  imageInfoData: [],
  houseimageData: [],
  houseimagePubData: [],
  housepageConfig: {},
  houseTagsData: [],
  houseTagspageConfig: {},
  ScanTagsData: {}
});

const ImageHouse = (state = initState, action) => {
  switch (action.type) {
    // 收藏列表
    case types.XAHC_CAAS_HOUSE_COLLECTS_LIST_SAGA:
      if (action.collectsData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("collectsData", action.collectsData.res.data)
          .set("pageConfig", action.collectsData.res.pageBean);
      }
      return state;
    // 收藏
    case types.XAHC_CAAS_HOUSE_COLLECT_SAGA:
      if (action.houseStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("houseStatus", 1);
      } else if (action.houseStatus.res.rtn_code == "1003") {
        return state.set("houseStatus", 2);
      } else {
        return state.set("houseStatus", 3);
      }
    // return state;
    // 镜像信息
    case types.XAHC_CAAS_HOUSE_IMAGEINFO_SAGA:
      if (action.imageInfoData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("imageInfoData", action.imageInfoData.res.data);
      }
      return state;
    // 镜像公有私有列表
    case types.XAHC_CAAS_HOUSE_IMAGES_LIST_SAGA:
      if (action.houseimageData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("houseimageData", action.houseimageData.res.list)
          .set("housepageConfig", action.houseimageData.res.pageBean);
      }
      return state;
    // 镜像公有列表
    case types.XAHC_CAAS_HOUSE_IMAGES_PUBLIC_LIST_SAGA:
      if (action.houseimagePubData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("houseimagePubData", action.houseimagePubData.res.list)
          .set("housePubpageConfig", action.houseimagePubData.res.pageBean);
      }
      return state;
    // 镜像同步
    case types.XAHC_CAAS_HOUSE_SYNC_SAGA:
      if (action.houseSyncStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("同步成功");
        return state.set("houseSyncStatus", 1);
      } else {
        message.success("同步失败");
        return state.set("houseSyncStatus", 2);
      }
    // return state;
    // 扫描镜像
    case types.XAHC_CAAS_HOUSE_SCAN_SAGA:
      if (action.houseScanStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("扫描成功");
        return state.set("houseScanStatus", 1);
      } else {
        message.info("扫描失败");
        return state.set("houseScanStatus", 2);
      }
    // 扫描镜像1
    case types.XAHC_CAAS_HOUSE_SCAN_TAG_SAGA:
      if (action.ScanTagStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state;
      }
      return state;
    // 扫描镜像2
    case types.XAHC_CAAS_HOUSE_SCAN_TAGS_SAGA:
      if (action.ScanTagsData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("ScanTagsData", action.ScanTagsData.res.data);
      } else if (action.ScanTagsData.res.rtn_code == "-1") {
        return state.set("ScanTagsData", "-1");
      }
      return state;
    // 扫描镜像3
    case types.XAHC_CAAS_HOUSE_SCAN_UPDATETAG_SAGA:
      if (action.ScanUpdateStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("扫描成功");
      } else {
        message.info("扫描失败");
      }
      return state;
    // 镜像(版本)
    case types.XAHC_CAAS_HOUSE_TAGS_SAGA:
      if (action.houseTagsData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("houseTagsData", action.houseTagsData.res.list)
          .set("houseTagspageConfig", action.houseTagsData.res.pageBean);
      }
      return state;
    // 镜像保存
    case types.XAHC_CAAS_HOUSE_UPDATE_SAGA:
      if (action.addStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("保存成功");
        return state.set("addStatus", 1);
      } else {
        message.error("保存失败");
        // return state.set("addStatus", 2);
      }
      return state;

    default:
      return state;
  }
};

export default ImageHouse;
