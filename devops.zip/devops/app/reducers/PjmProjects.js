import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  userallData: []
});

const PjmProjects = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_PJM_PROJECT_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        sessionStorage.setItem("projectsInfo", JSON.stringify(action.resData.res));
        return state
          .set("resData", action.resData.res.data)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_PJM_ADD_PROJECT_SAGA:
      if (action.appStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.appStatus.res.rtn_code == "84009") {
        return state.set("AddStatus", 3);
      } else {
        return state.set("AddStatus", 2);
      }
    // return state;
    case types.XAHC_PJM_DELETE_PROJECT_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      }
      return state;
    case types.XAHC_PJM_UPDATA_PROJECT_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        if (action.updataStatus.res.status == "1") {
          message.info("审核成功");
        } else if (action.updataStatus.res.status == "2") {
          message.info("驳回成功");
        }
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("项目名称已存在，审核失败");
        return state.set("UpdataStatus", 2);
      } else if (action.updataStatus.res.rtn_code == "84009") {
        return state.set("UpdataStatus", 3);
      } else if (action.updataStatus.res.rtn_code == "4008") {
        message.info("harbor异常");
        return state.set("UpdataStatus", 4);
      }
      return state;
    case types.XAHC_PJM_CODEORNAME_PROJECT_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfigs", action.resData.res.pageBean)
          .set("UpdataStatus", 0)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("codeornameStatus", 1);
      }
      if (
        action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED &&
        !action.resData.res.pageBean
      ) {
        return state.set("resData", action.resData.res.data).set("pageConfigs", {});
      }
      return state;
    case types.XAHC_PJM_PROJECT_USERALL_SAGA:
      if (action.userallData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("userallData", action.userallData.res.data);
      }
      return state;
    default:
      return state;
  }
};

export default PjmProjects;
