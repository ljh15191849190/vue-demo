import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  getAllData: [],
  selectData: [],
  userallData: []
});

const Role = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_ROLE_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_ROLE_ADD_SAGA:
      if (action.addStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.addStatus.res.rtn_code == "1003") {
        return state.set("AddStatus", 3);
      } else if (action.addStatus.res.rtn_code == "4003") {
        message.error("角色已存在");
      } else {
        return state.set("AddStatus", 2);
      }
    // return state;
    case types.XAHC_ROLE_DELETE_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      } else if (action.deleteStatus.res.rtn_code == "4004") {
        message.info("此角色被占用不能删除");
      } else {
        return state.set("delStatus", 2);
      }
      return state;
    case types.XAHC_ROLE_UPDATE_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == "1003") {
        return state.set("UpdataStatus", 3);
      } else {
        return state.set("UpdataStatus", 2);
      }
    // return state;
    case types.XAHC_ROLE_ALL_MENU_SAGA:
      if (action.getAllData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("getAllData", action.getAllData.res.data);
      }
      return state;
    case types.XAHC_ROLE_SELECT_MENU_SAGA:
      if (action.selectData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("selectData", action.selectData.res.data);
      }
      return state;
    case types.XAHC_ROLE_SAVE_SELECT_MENU_SAGA:
      if (action.selectStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("授权成功");
        return state.set("selectStatus", 1);
      } else {
        message.info("授权失败");
        return state.set("selectStatus", 2);
      }
    // return state;

    // 团队
    case types.XAHC_TEAM_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("teamresData", action.resData.res.data)
          .set("teamdelStatus", 0)
          .set("teamAddStatus", 0)
          .set("authorStatus", 0)
          .set("teampageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_TEAM_ADD_SAGA:
      if (action.addStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("teamAddStatus", 1);
      } else {
        return state.set("teamAddStatus", 2);
      }
    // return state;
    case types.XAHC_TEAM_DELETE_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("teamdelStatus", 1);
      } else {
        return state.set("teamdelStatus", 2);
      }
    // return state;
    case types.XAHC_TEAM_AUTHORIZE_SAGA:
      if (action.authorStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("authorStatus", 1);
      } else if (action.authorStatus.res.rtn_code == "4005") {
        message.info("授权失败，必须有项目经理");
      } else {
        return state.set("authorStatus", 2);
      }
      return state;
    case types.XAHC_TEAM_TEAM_USER_ALL_SAGA:
      if (action.userallData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("userallData", action.userallData.res.data);
      }
      return state;
    default:
      return state;
  }
};

export default Role;
