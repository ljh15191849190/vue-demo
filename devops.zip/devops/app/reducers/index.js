import { combineReducers } from "redux";
import login from "./login";
import SysInteRepertory from "./SysInteRepertory";
import PjmProjects from "./PjmProjects";
import PjmComponent from "./PjmComponent";
import Build from "./Build";
import Deploy from "./Deploy";
import SystemBulid from "./SystemBulid";
import listProjects from "./ListProjects";
import branch from "./Branch";
import MediumWarehouse from "./MediumWarehouse";
import codeRelation from "./CodeRelation";
import Environment from "./Environment";
import Resource from "./Resource";
import Role from "./Role";
import ImageHouse from "./ImageHouse";

import SystemManage from "./SystemManage";
import MaitananceManage from "./maitananceManage";

const rootReducer = combineReducers({
  login,
  SysInteRepertory,
  PjmProjects,
  PjmComponent,
  Build,
  Environment,
  Resource,
  ImageHouse,
  Role,
  SystemBulid,
  listProjects,
  MediumWarehouse,
  codeRelation,
  branch,
  SystemManage,
  Deploy,
  MaitananceManage
});

export default rootReducer;
