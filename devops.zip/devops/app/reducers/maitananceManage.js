import Immutable from "immutable";
import { message } from "antd";
import * as type from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.fromJS({
  allPartListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    allPartList: [],
    allPartListAction: [],
    pageConfig: {}
  },

  visualEventFindByCustomizedListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    visualEventFindByCustomizedList: [],
    allPartListAction: [],
    pageBean: {}
  },

  findInstancesByServiceIdListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    findInstancesByServiceIdList: [],
    allPartListAction: [],
    pageBean: {}
  },

  findInstanceByInstanceIdData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    findInstanceByInstanceIdInfo: [],
    allPartListAction: [],
    pageBean: {}
  },

  visualCheckLogListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    visualCheckLogList: null,
    allPartListAction: [],
    pageBean: {}
  },

  visualMonitorListDataCPU: {
    addStatusCPU: 0,
    delStatusCPU: 0,
    updateStatusCPU: 0,
    otherStatusCPU: 0,
    availableStatusCPU: 0,
    visualMonitorListCPU: [],
    allPartListAction: [],
    pageBean: {}
  },

  visualMonitorListDataMEM: {
    addStatusMEM: 0,
    delStatusMEM: 0,
    updateStatusMEM: 0,
    otherStatusMEM: 0,
    availableStatusMEM: 0,
    visualMonitorListMEM: [],
    allPartListAction: [],
    pageBean: {}
  },

  visualHighAvailableInfoListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    visualHighAvailableInfoList: [],
    allPartListAction: [],
    pageBean: {}
  },

  visualUpdateInstanceDisableListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    visualUpdateInstanceDisableList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesPodsCountListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesPodsCountList: null,
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesPodsListInfoListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesPodsListInfoList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasPodsInfoListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasPodsInfoList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasPodsInfoMonitorListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasPodsInfoMonitorList: [],
    allPartListAction: [],
    pageBean: {}
  },
  caasPodsEventsListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasPodsEventsList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasPodsLogsListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasPodsLogsList: null,
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesEventsListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServiesEventsList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesMetricsListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesMetricsList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesLivenessprobeListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesLivenessprobeList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesConfigListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesConfigListContainer: {},
    caasServicesConfigListPorts: [],
    caasServicesConfigListBasic: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesActionListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesActionList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesHorizontalScalingListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesHorizontalScalingList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesConfigSetListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesConfigSetList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesTagsListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesTagsList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesGrayReleaseListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesGrayReleaseList: [],
    allPartListAction: [],
    pageBean: {}
  },
  caasServicesDeploymentEnableHpaListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesDeploymentEnableHpaList: [],
    allPartListAction: [],
    pageBean: {}
  },

  caasServicesAutoScalingListData: {
    addStatus: 0,
    delStatus: 0,
    updateStatus: 0,
    otherStatus: 0,
    availableStatus: 0,
    caasServicesAutoScalingList: [],
    allPartListAction: [],
    pageBean: {}
  },

  resManageData: [],
  findresData: [],
  pageConfig: {}
});

const reduce = (state = initState, action) => {
  switch (action.type) {
    case type.SAGA_MAITANANCE_ADD:
      switch (action.param.from) {
        case "allPartList":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["allPartListData", "allPartList"], action.status.res.data)
              .setIn(["allPartListData", "pageBean"], action.status.res.pageBean)
              .setIn(["allPartListData", "delStatus"], 0)
              .setIn(["allPartListData", "addStatus"], 0)
              .setIn(["allPartListData", "updateStatus"], 0)
              .setIn(["allPartListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;
        case "visualEventFindByCustomized":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["visualEventFindByCustomizedListData", "visualEventFindByCustomizedList"],
                action.status.res.data
              )
              .setIn(
                ["visualEventFindByCustomizedListData", "pageBean"],
                action.status.res.pageBean
              )
              .setIn(["visualEventFindByCustomizedListData", "delStatus"], 0)
              .setIn(["visualEventFindByCustomizedListData", "addStatus"], 0)
              .setIn(["visualEventFindByCustomizedListData", "updateStatus"], 0)
              .setIn(["visualEventFindByCustomizedListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "userMenuAll":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("userMenuAllData", action.status.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_NOTEXIST) {
            // message.error("该用户名未定义任何角色，请联系管理员!");
          }
          return state;
        default:
          return state;
      }
    case type.SAGA_MAITANANCE_DEL:
      // TODO:
      // if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
      //   return state
      //     .set("delStatus", 1)
      //     .set("addStatus", 0)
      //     .set("updateStatus", 0)
      //     .set("otherStatus", 0);
      // } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLE_USED) {
      //   message.error("角色被使用无法删除!");
      // } else if (action.status.res.rtn_code === StatusCode.XAHC_PEMISSION_USED) {
      //   message.error("权限被使用无法删除!");
      // } else if (action.status.res.rtn_code === StatusCode.XAHC_MENUCHILD_EXIST) {
      //   message.error("此菜单有子菜单，无法删除!");
      // } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGCHILD_EXIST) {
      //   message.error("此机构有子机构，无法删除!");
      // } else {
      //   message.error("删除失败！");
      // }
      // return state;
      break;

    case type.SAGA_MAITANANCE_GET:
      switch (action.param.from) {
        case "allPartListAction":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["allPartListData", "allPartListAction"], action.data.res.data)
              .setIn(["allPartListData", "delStatus"], 0)
              .setIn(["allPartListData", "addStatus"], 0)
              .setIn(["allPartListData", "updateStatus"], 0)
              .setIn(["allPartListData", "otherStatus"], 1);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("操作失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("获取数据失败！");
          }
          return state;
        default:
          break;

        case "findInstancesByServiceId":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["findInstancesByServiceIdListData", "findInstancesByServiceIdList"],
                action.data.res.data
              )
              .setIn(["findInstancesByServiceIdListData", "delStatus"], 0)
              .setIn(["findInstancesByServiceIdListData", "addStatus"], 0)
              .setIn(["findInstancesByServiceIdListData", "updateStatus"], 0)
              .setIn(["findInstancesByServiceIdListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "findInstanceByInstanceId":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["findInstanceByInstanceIdData", "findInstanceByInstanceIdInfo"],
                action.data.res.data
              )
              .setIn(["findInstanceByInstanceIdData", "delStatus"], 0)
              .setIn(["findInstanceByInstanceIdData", "addStatus"], 0)
              .setIn(["findInstanceByInstanceIdData", "updateStatus"], 0)
              .setIn(["findInstanceByInstanceIdData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "visualCheckLog":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["visualCheckLogListData", "visualCheckLogList"], action.data.res.data)
              .setIn(["visualCheckLogListData", "delStatus"], 0)
              .setIn(["visualCheckLogListData", "addStatus"], 0)
              .setIn(["visualCheckLogListData", "updateStatus"], 0)
              .setIn(["visualCheckLogListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "visualMonitorCPU":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["visualMonitorListDataCPU", "visualMonitorListCPU"], action.data.res.data)
              .setIn(["visualMonitorListDataCPU", "delStatusCPU"], 0)
              .setIn(["visualMonitorListDataCPU", "addStatusCPU"], 0)
              .setIn(["visualMonitorListDataCPU", "updateStatusCPU"], 0)
              .setIn(["visualMonitorListDataCPU", "otherStatusCPU"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "visualMonitorMEM":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["visualMonitorListDataMEM", "visualMonitorListMEM"], action.data.res.data)
              .setIn(["visualMonitorListDataMEM", "delStatusMEM"], 0)
              .setIn(["visualMonitorListDataMEM", "addStatusMEM"], 0)
              .setIn(["visualMonitorListDataMEM", "updateStatusMEM"], 0)
              .setIn(["visualMonitorListDataMEM", "otherStatusMEM"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "visualHighAvailableInfo":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["visualHighAvailableInfoListData", "visualHighAvailableInfoList"],
                action.data.res.data
              )
              .setIn(["visualHighAvailableInfoListData", "delStatus"], 0)
              .setIn(["visualHighAvailableInfoListData", "addStatus"], 0)
              .setIn(["visualHighAvailableInfoListData", "updateStatus"], 0)
              .setIn(["visualHighAvailableInfoListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "visualUpdateInstanceDisable":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("设置成功！");
            return state
              .setIn(
                ["visualUpdateInstanceDisableListData", "visualUpdateInstanceDisableList"],
                action.data.res.data
              )
              .setIn(["visualUpdateInstanceDisableListData", "delStatus"], 0)
              .setIn(["visualUpdateInstanceDisableListData", "addStatus"], 0)
              .setIn(["visualUpdateInstanceDisableListData", "updateStatus"], 0)
              .setIn(["visualUpdateInstanceDisableListData", "otherStatus"], 0);
          } else {
            message.error("设置失败！");
          }
          return state;

        case "caasPodsInfo":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasPodsInfoListData", "caasPodsInfoList"], action.data.res.data)
              .setIn(["caasPodsInfoListData", "delStatus"], 0)
              .setIn(["caasPodsInfoListData", "addStatus"], 0)
              .setIn(["caasPodsInfoListData", "updateStatus"], 0)
              .setIn(["caasPodsInfoListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasPodsInfoMonitor":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["caasPodsInfoMonitorListData", "caasPodsInfoMonitorList"],
                action.data.res.data
              )
              .setIn(["caasPodsInfoMonitorListData", "delStatus"], 0)
              .setIn(["caasPodsInfoMonitorListData", "addStatus"], 0)
              .setIn(["caasPodsInfoMonitorListData", "updateStatus"], 0)
              .setIn(["caasPodsInfoMonitorListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasPodsEvents":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasPodsEventsListData", "caasPodsEventsList"], action.data.res.data)
              .setIn(["caasPodsEventsListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasPodsEventsListData", "delStatus"], 0)
              .setIn(["caasPodsEventsListData", "addStatus"], 0)
              .setIn(["caasPodsEventsListData", "updateStatus"], 0)
              .setIn(["caasPodsEventsListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasPodsLogs":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasPodsLogsListData", "caasPodsLogsList"], action.data.res.data)
              .setIn(["caasPodsLogsListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasPodsLogsListData", "delStatus"], 0)
              .setIn(["caasPodsLogsListData", "addStatus"], 0)
              .setIn(["caasPodsLogsListData", "updateStatus"], 0)
              .setIn(["caasPodsLogsListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
            return state
              .setIn(["caasPodsLogsListData", "caasPodsLogsList"], null)
              .setIn(["caasPodsLogsListData", "pageBean"], {
                total: 0,
                size: 15,
                totalPage: 0,
                page: 1
              })
              .setIn(["caasPodsLogsListData", "delStatus"], 0)
              .setIn(["caasPodsLogsListData", "addStatus"], 0)
              .setIn(["caasPodsLogsListData", "updateStatus"], 0)
              .setIn(["caasPodsLogsListData", "otherStatus"], 0);
          }

        case "caasServicesPodsCount":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["caasServicesPodsCountListData", "caasServicesPodsCountList"],
                action.data.res.data
              )
              .setIn(["caasServicesPodsCountListData", "delStatus"], 0)
              .setIn(["caasServicesPodsCountListData", "addStatus"], 0)
              .setIn(["caasServicesPodsCountListData", "updateStatus"], 0)
              .setIn(["caasServicesPodsCountListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasServicesPodsListInfo":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["caasServicesPodsListInfoListData", "caasServicesPodsListInfoList"],
                action.data.res.data
              )
              .setIn(["caasServicesPodsListInfoListData", "delStatus"], 0)
              .setIn(["caasServicesPodsListInfoListData", "addStatus"], 0)
              .setIn(["caasServicesPodsListInfoListData", "updateStatus"], 0)
              .setIn(["caasServicesPodsListInfoListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasServicesEvents":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasServicesEventsListData", "caasServicesEventsList"], action.data.res.data)
              .setIn(["caasServicesEventsListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasServicesEventsListData", "delStatus"], 0)
              .setIn(["caasServicesEventsListData", "addStatus"], 0)
              .setIn(["caasServicesEventsListData", "updateStatus"], 0)
              .setIn(["caasServicesEventsListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasServicesLogs":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasServicesLogsListData", "caasServicesLogsList"], action.data.res.data)
              .setIn(["caasServicesLogsListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasServicesLogsListData", "delStatus"], 0)
              .setIn(["caasServicesLogsListData", "addStatus"], 0)
              .setIn(["caasServicesLogsListData", "updateStatus"], 0)
              .setIn(["caasServicesLogsListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasServicesMetrics":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(
                ["caasServicesMetricsListData", "caasServicesMetricsList"],
                action.data.res.data
              )
              .setIn(["caasServicesMetricsListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasServicesMetricsListData", "delStatus"], 0)
              .setIn(["caasServicesMetricsListData", "addStatus"], 0)
              .setIn(["caasServicesMetricsListData", "updateStatus"], 0)
              .setIn(["caasServicesMetricsListData", "otherStatus"], 0);
          } else {
            message.error("获取数据失败！");
          }
          return state;

        case "caasServicesLivenessprobe":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("设置成功！");

            return state
              .setIn(
                ["caasServicesLivenessprobeListData", "caasServicesLivenessprobeList"],
                action.data.res.data
              )
              .setIn(["caasServicesLivenessprobeListData", "pageBean"], action.data.res.pageBean)
              .setIn(["caasServicesLivenessprobeListData", "delStatus"], 0)
              .setIn(["caasServicesLivenessprobeListData", "addStatus"], 0)
              .setIn(["caasServicesLivenessprobeListData", "updateStatus"], 0)
              .setIn(["caasServicesLivenessprobeListData", "otherStatus"], 0);
          } else {
            message.error("设置失败！");
          }
          return state;

        case "caasServicesConfig":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            if (action.data.res.container) {
              return state
                .setIn(
                  ["caasServicesConfigListData", "caasServicesConfigListContainer"],
                  action.data.res.container
                )
                .setIn(
                  ["caasServicesConfigListData", "caasServicesConfigListPorts"],
                  action.data.res.port
                )
                .setIn(
                  ["caasServicesConfigListData", "caasServicesConfigListBasic"],
                  action.data.res
                )
                .setIn(["caasServicesConfigListData", "pageBean"], action.data.res.pageBean)
                .setIn(["caasServicesConfigListData", "delStatus"], 0)
                .setIn(["caasServicesConfigListData", "addStatus"], 0)
                .setIn(["caasServicesConfigListData", "updateStatus"], 0)
                .setIn(["caasServicesConfigListData", "otherStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "delStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "addStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "updateStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "otherStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "delStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "addStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "updateStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "otherStatus"], 0);
            } else {
              return state
                .setIn(["caasServicesConfigListData", "caasServicesConfigListContainer"], {})
                .setIn(["caasServicesConfigListData", "caasServicesConfigListPorts"], [])
                .setIn(
                  ["caasServicesConfigListData", "caasServicesConfigListBasic"],
                  action.data.res
                )
                .setIn(["caasServicesConfigListData", "pageBean"], {})
                .setIn(["caasServicesConfigListData", "delStatus"], 0)
                .setIn(["caasServicesConfigListData", "addStatus"], 0)
                .setIn(["caasServicesConfigListData", "updateStatus"], 0)
                .setIn(["caasServicesConfigListData", "otherStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "delStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "addStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "updateStatus"], 0)
                .setIn(["caasServicesDeploymentEnableHpaListData", "otherStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "delStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "addStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "updateStatus"], 0)
                .setIn(["caasServicesAutoScalingListData", "otherStatus"], 0);
            }
          } else {
            message.error("获取数据失败！");
          }
          return state
            .setIn(["caasServicesDeploymentEnableHpaListData", "delStatus"], 0)
            .setIn(["caasServicesDeploymentEnableHpaListData", "addStatus"], 0)
            .setIn(["caasServicesDeploymentEnableHpaListData", "updateStatus"], 0)
            .setIn(["caasServicesDeploymentEnableHpaListData", "otherStatus"], 0)
            .setIn(["caasServicesAutoScalingListData", "delStatus"], 0)
            .setIn(["caasServicesAutoScalingListData", "addStatus"], 0)
            .setIn(["caasServicesAutoScalingListData", "updateStatus"], 0)
            .setIn(["caasServicesAutoScalingListData", "otherStatus"], 0);

        case "caasServicesAction":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["allPartListData", "allPartListAction"], action.data.res.data)
              .setIn(["allPartListData", "delStatus"], 0)
              .setIn(["allPartListData", "addStatus"], 0)
              .setIn(["allPartListData", "updateStatus"], 0)
              .setIn(["allPartListData", "otherStatus"], 1);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_STOP) {
            message.error("操作失败！请先关闭该服务的自动伸缩，才能停止该服务");
          } else {
            message.error("操作失败！");
          }
          return state;

        case "caasServicesHorizontalScaling":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("操作成功！");
            return state
              .setIn(
                ["caasServicesHorizontalScalingListData", "caasServicesHorizontalScalingList"],
                action.data.res.data
              )
              .setIn(["caasServicesHorizontalScalingListData", "delStatus"], 0)
              .setIn(["caasServicesHorizontalScalingListData", "addStatus"], 0)
              .setIn(["caasServicesHorizontalScalingListData", "updateStatus"], 0)
              .setIn(["caasServicesHorizontalScalingListData", "otherStatus"], 1);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_STOP) {
            message.error("操作失败！请先关闭该服务的自动伸缩，才能停止该服务");
          } else {
            message.error("操作失败！");
          }
          return state;

        case "caasServicesConfigSet":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("设置成功！");
            return state
              .setIn(
                ["caasServicesConfigSetListData", "caasServicesConfigSetList"],
                action.data.res.data
              )
              .setIn(["caasServicesConfigSetListData", "delStatus"], 0)
              .setIn(["caasServicesConfigSetListData", "addStatus"], 0)
              .setIn(["caasServicesConfigSetListData", "updateStatus"], 0)
              .setIn(["caasServicesConfigSetListData", "otherStatus"], 0);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("设置失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("设置失败！");
          }
          return state;

        case "caasServicesTags":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .setIn(["caasServicesTagsListData", "caasServicesTagsList"], action.data.res.data)
              .setIn(["caasServicesTagsListData", "delStatus"], 0)
              .setIn(["caasServicesTagsListData", "addStatus"], 0)
              .setIn(["caasServicesTagsListData", "updateStatus"], 0)
              .setIn(["caasServicesTagsListData", "otherStatus"], 0);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("设置失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("获取镜像信息数据失败！");
          }
          return state;

        case "caasServicesGrayRelease":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("设置成功！");
            return state
              .setIn(
                ["caasServicesGrayReleaseListData", "caasServicesGrayReleaseList"],
                action.data.res.data
              )
              .setIn(["caasServicesGrayReleaseListData", "delStatus"], 0)
              .setIn(["caasServicesGrayReleaseListData", "addStatus"], 0)
              .setIn(["caasServicesGrayReleaseListData", "updateStatus"], 0)
              .setIn(["caasServicesGrayReleaseListData", "otherStatus"], 0);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("设置失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("设置失败！");
          }
          return state;

        case "caasServicesDeploymentEnableHpa":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            // message.success("设置成功！");
            return state
              .setIn(
                ["caasServicesDeploymentEnableHpaListData", "caasServicesDeploymentEnableHpaList"],
                action.data.res.data
              )
              .setIn(["caasServicesDeploymentEnableHpaListData", "delStatus"], 0)
              .setIn(["caasServicesDeploymentEnableHpaListData", "addStatus"], 0)
              .setIn(["caasServicesDeploymentEnableHpaListData", "updateStatus"], 0)
              .setIn(["caasServicesDeploymentEnableHpaListData", "otherStatus"], 1);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("设置失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("设置失败！");
          }
          return state;

        case "caasServicesAutoScaling":
          if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            // message.success("设置成功！");
            return state
              .setIn(
                ["caasServicesAutoScalingListData", "caasServicesAutoScalingList"],
                action.data.res.data
              )
              .setIn(["caasServicesAutoScalingListData", "delStatus"], 0)
              .setIn(["caasServicesAutoScalingListData", "addStatus"], 0)
              .setIn(["caasServicesAutoScalingListData", "updateStatus"], 0)
              .setIn(["caasServicesAutoScalingListData", "otherStatus"], 1);
          } else if (action.data.res.rtn_code === StatusCode.XAHC_SERVICE_RUNNING) {
            message.error("操作失败！请先停止该服务，才能删除掉该服务");
          } else {
            message.error("操作失败！");
          }
          return state;
      }
      break;
    case type.SAGA_MAITANANCE_UPDATE:
      break;

    case type.SAGA_MAITANANCE_SEARCHGET:
      if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "allPartList":
            return state
              .setIn(["allPartListData", "allPartList"], action.data.res.data)
              .setIn(["allPartListData", "pageBean"], action.data.res.pageBean)

              .setIn(["allPartListData", "delStatus"], 0)
              .setIn(["allPartListData", "addStatus"], 0)
              .setIn(["allPartListData", "updateStatus"], 0)
              .setIn(["allPartListData", "otherStatus"], 0);

          case "userManage":
            return state
              .set("userManageData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          default:
            return state;
        }
      } else {
        message.error("查询数据失败！");
        return state;
      }

    default:
      return state;
  }
};

export default reduce;
