import Immutable from "immutable";
import { message } from "antd";
import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  baseUpdateData: {},
  baseSaveData: {},
  definationDetails: [],
  definationDetailsFlag: 0,
  deleteFlag: 0,
  cloneFlag: 0,
  stageListFlag: 0,
  templatesSaveFlag: 0,
  baseUpdateFlag: 0,
  baseSaveFlag: 0,
  uploadSoftFlag: 0,
  jobStatus: 0,
  emailData: [],
  missionBatchSaveFlag: 0,
  missionBatchSaveData: [],
  sonarQubeServerList: [],
  nexusList: [],
  imageServerList: [],
  currentPage: 1
});
const getDefinationList = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_BUILD_LIST_ALL_SAGA:
      if (action.definationListStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.definationListStatus.res.data)
          .set("pageConfig", action.definationListStatus.res.pageBean)
          .set("deleteFlag", 0)
          .set("baseSaveFlag", 0)
          .set("cloneFlag", 0);
      }
      return state;

    case types.XAHC_BUILD_CLONE_SAGA:
      if (action.definationCloneStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("克隆成功");
        return state.set("cloneFlag", 1);
      } else if (action.definationCloneStatus.res.rtn_code == 1004) {
        message.warning("构建名称重复");
        return state.set("cloneFlag", 2);
      } else if (action.definationCloneStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("克隆失败");
      } else if (action.definationCloneStatus.res.rtn_code == "1002") {
        message.error("组件没有关联代码克隆失败");
      }
      return state;
    case types.XAHC_BUILD_DELETE_SAGA:
      if (action.deleteDefinationStatus.res.rtn_code == "OK") {
        return state.set("deleteFlag", 1).set("stageListFlag", 0);
      } else if (action.deleteDefinationStatus.res.rtn_code == StatusCode.XAHC_SERVICE_EXIST) {
        message.warning("部署服务有服务实例，请先删除监控服务");
      }
      return state;
    case types.XAHC_BUILD_BASE_SAGA:
      if (action.baseDefinationStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("baseSaveData", action.baseDefinationStatus.res.data)
          .set("definationDetailsFlag", 0)
          .set("baseSaveFlag", 1);
      } else if (action.baseDefinationStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        // return state.set("baseSaveFlag", 2);
        message.warning("不能重复添加");
      } else if (action.baseDefinationStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        // return state.set("baseSaveFlag", -1);
        message.error("添加失败");
      } else if (action.baseDefinationStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        // return state.set("baseSaveFlag", -1);
        if (action.baseDefinationStatus.res.data) {
          message.error(action.baseDefinationStatus.res.data);
        } else {
          message.error("参数为空");
        }
      }
      return state;
    // 基本信息更新
    case types.XAHC_BUILD_BASE_UPDATE_SAGA:
      if (action.baseUpdateStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("baseUpdateData", action.baseUpdateStatus.res.data)
          .set("definationDetailsFlag", 0)
          .set("baseUpdateFlag", 1);
      } else if (action.baseUpdateStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        // return state.set("baseSaveFlag", 2);
        message.warning("不能重复添加");
      } else if (action.baseUpdateStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        // return state.set("baseSaveFlag", -1);
        message.error("添加失败");
      } else if (action.baseUpdateStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        // return state.set("baseSaveFlag", -1);
        if (action.baseUpdateStatus.res.data) {
          message.error(action.baseUpdateStatus.res.data);
        } else {
          message.error("参数为空");
        }
      } else if (action.baseUpdateStatus.res.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.error(action.baseUpdateStatus.res.data);
      }
      return state;
    case types.XAHC_BUILD_UPDATE_SAGA:
      if (action.updateDefinationStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("baseUpdateFlag", 1)
          .set("baseUpdateData", action.updateDefinationStatus.res.data);
      } else if (action.updateDefinationStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
        return state.set("baseUpdateFlag", 2);
      } else if (action.updateDefinationStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.warning("参数不正确");
      } else if (action.updateDefinationStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("添加失败");
        return state.set("baseUpdateFlag", -1);
      } else if (action.updateDefinationStatus.res.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.error(action.updateDefinationStatus.res.data);
        return state.set("baseUpdateFlag", -2);
      }
      return state;
    // 参数保存
    case types.XAHC_BUILD_PARAMS_SAVE_SAGA:
      if (action.saveParamsStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("paramsSaveFlag", 1)
          .set("paramsSaveData", action.saveParamsStatus.res.data);
      } else if (action.saveParamsStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
        return state.set("paramsSaveFlag", 2);
      } else if (action.saveParamsStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("添加失败");
        return state.set("paramsSaveFlag", -1);
      } else if (action.saveParamsStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.error("参数为空");
        return state.set("paramsSaveFlag", -1);
      }
      return state;
    // 参数更新
    case types.XAHC_BUILD_PARAMS_UPDATE_SAGA:
      if (action.updateParamsStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state.set("paramsUpdateFlag", 1);
      } else if (action.updateParamsStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
        return state.set("paramsUpdateFlag", 2);
      } else if (action.updateParamsStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("添加失败");
        return state.set("paramsUpdateFlag", -1);
      } else if (action.updateParamsStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.error("参数为空");
        return state.set("paramsUpdateFlag", -1);
      }
      return state;
    // 参数列表获取
    case types.XAHC_BUILD_PARAMS_LIST_SAGA:
      if (action.paramsListStatus.res.rtn_code == "0") {
        return state
          .set("paramsListFlag", 1)
          .set("paramsDeleteFlag", 0)
          .set("paramsSaveFlag", 0)
          .set("paramsUpdateFlag", 0)
          .set("paramsListData", action.paramsListStatus.res.data);
      } else if (action.paramsListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        return state
          .set("paramsListFlag", -1)
          .set("paramsDeleteFlag", -1)
          .set("paramsSaveFlag", -1)
          .set("paramsUpdateFlag", -1);
      } else if (action.paramsListStatus.res.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        return state
          .set("paramsListFlag", -2)
          .set("paramsDeleteFlag", -2)
          .set("paramsSaveFlag", -2)
          .set("paramsUpdateFlag", -2)
          .set("paramsListData", action.paramsListStatus.res.data);
      }
      return state;
    // 删除参数
    case types.XAHC_BUILD_PARAMS_DELETE_SAGA:
      if (action.paramsDeleteStatus.res.rtn_code == "OK") {
        message.success("删除成功");
        return state.set("paramsDeleteFlag", 1);
        // state.set("paramsListData", action.paramsDeleteStatus.res.data);
      } else if (action.paramsDeleteStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("删除失败");
        return state.set("paramsDeleteFlag", -1);
      }
      return state;
    // 构建模板获取
    case types.XAHC_BUILD_TEMPLATES_SAGA:
      if (action.templatesStatus.res.rtn_code == "0") {
        return state
          .set("templatesListData", action.templatesStatus.res.data)
          .set("deleteStageFlag", 0);
      }
      return state;
    // 介质下载
    case types.XAHC_BUILD_MEDIUM_DOWNLOAD_SAGA:
      if (action.downloadData.res.rtn_code == "0") {
        return state.set("downloadData", action.downloadData.res.data);
      }
      return state;
    // 构建计划模板获取
    case types.XAHC_BUILD_PIPELINE_TEMPLATE_SAGA:
      if (action.pipeTemplatesStatus.res.rtn_code == "0") {
        return state.set("pipeTemplatesListData", action.pipeTemplatesStatus.res.data);
      }
      return state;
    // 获取当前构建任务配置stage
    case types.XAHC_BUILD_STAGE_SAGA:
      if (action.stageStatus.res.rtn_code == "0") {
        return state
          .set("stageListData", action.stageStatus.res.data)
          .set("deleteStageFlag", 0)
          .set("templatesSaveFlag", 0)
          .set("stageListFlag", 1);
      }
      return state;
    // 构建任务保存
    case types.XAHC_BUILD_MISSION_SAVE_SAGA:
      if (action.buildTaskSaveStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("templatesSaveData", action.buildTaskSaveStatus.res)
          .set("templatesSaveFlag", 1);
      } else if (action.paramsListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        // return state.set("paramsListFlag", -1);
      } else if (action.saveParamsStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
      }
      return state;
    // 构建任务批量保存
    case types.XAHC_BUILD_MISSION_BATCH_SAVE_SAGA:
      if (action.buildTaskBatchSaveStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state
          .set("missionBatchSaveData", action.buildTaskBatchSaveStatus.res)
          .set("missionBatchSaveFlag", 1);
      } else if (action.buildTaskBatchSaveStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        // return state.set("paramsListFlag", -1);
      } else if (action.buildTaskBatchSaveStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
      }
      return state;
    /**
     * 查询构建任务详情
     */
    case types.XAHC_BUILD_MISSION_DETAILS_SAGA:
      if (action.getStageDetailsStatus.res.rtn_code == "0") {
        return state.set("stageDetailsData", action.getStageDetailsStatus.res.data);
      } else if (action.getStageDetailsStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        // return state.set("paramsListFlag", -1);
      }
      return state;
    /**
     * 构建任务更新
     */
    case types.XAHC_BUILD_MISSION_UPDATE_SAGA:
      if (action.buildTaskUpdateStatus.res.rtn_code == "0") {
        message.success("保存成功");
        return state.set("templatesUpdateData", action.buildTaskUpdateStatus.res.data);
      } else if (action.buildTaskUpdateStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        // return state.set("paramsListFlag", -1);
      } else if (action.buildTaskUpdateStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("不能重复添加");
      }
      return state;
    case types.XAHC_BUILD_GET_DEFINATION_BY_ID_SAGA:
      if (action.getDefinationDetailsStatus.res.rtn_code == "0") {
        return state
          .set("definationDetails", action.getDefinationDetailsStatus.res.data)
          .set("emailData", action.getDefinationDetailsStatus.res.email)
          .set("definationDetailsFlag", 1)
          .set("baseUpdateData", {})
          .set("baseUpdateFlag", 0)
          .set("baseSaveFlag", 0);
      }
      return state;
    // console
    case types.XAHC_BUILD_PERFORME_CONSOLE_SAGA:
      if (action.consoleListStatus.res) {
        return state.set("consoleData", action.consoleListStatus.res.data);
      } else if (action.consoleListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
      }
      return state;
    // 概要
    case types.XAHC_BUILD_PERFORME_STATUS_SAGA:
      if (action.StatusListStatus.res) {
        return state.set("statusData", JSON.parse(action.StatusListStatus.res.data));
      } else if (action.StatusListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
      }
      return state;
    // 概要清空
    case types.XAHC_BUILD_PERFORME_STATUS_EMPTY_SAGA:
      return state.set("statusData", []);
    // 概要日志
    case types.XAHC_BUILD_PERFORME_LOGS_SAGA:
      if (action.LogsListStatus.res) {
        return state.set("logsData", action.LogsListStatus.res.data);
      } else if (action.LogsListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
      }
      return state;
    // 点击执行
    case types.XAHC_BUILD_PERFORME_FLAG_SAGA:
      if (action.FlagListStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("flagData", action.FlagListStatus.res);
      } else if (action.FlagListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error(action.FlagListStatus.res.data);
      }
      return state;
    // 下载
    case types.XAHC_BUILD_PERFORME_FINDJAR_SAGA:
      if (action.JarListStatus.res) {
        return state.set("findJarData", action.JarListStatus.res.data);
      } else if (action.JarListStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
      }
      return state;
    case types.XAHC_BUILD_HISTORY_SAGA:
      if (action.historyData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        // message.success("保存成功");
        let resData = [];
        try {
          resData = action.historyData.res.data;
        } catch (e) {
          resData = [];
        }
        return state
          .set("historyData", resData)
          .set("hispageConfig", action.historyData.res.pageBean);
      } else if (action.historyData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        // message.error("请求失败");
        // return state.set("paramsListFlag", -1);
      } else if (action.historyData.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        // message.warning("不能重复添加");
      }
      return state;
    case types.XAHC_BUILD_STAGE_DELETE_SAGA:
      if (action.deleteStageStatus.res.rtn_code == "OK") {
        message.success("删除成功");
        return state.set("deleteStageFlag", 1);
      } else if (action.deleteStageStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("请求失败");
        return state.set("deleteStageFlag", 0);
      }
      return state;

    // 构建计划模板data获取
    case types.XAHC_BUILD_STAGENAME_PLAN_SAGA:
      if (action.StageNameStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("StageNameListData", action.StageNameStatus.res.data);
      }
      return state;
    // 质量展示
    case types.XAHC_BUILD_QUALITY_MEASURES_SAGA:
      if (action.MeasuresStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("MeasuresData", action.MeasuresStatus.res);
      } else if (
        action.MeasuresStatus.res.rtn_code == "3002" ||
        action.MeasuresStatus.res.rtn_code == "3003" ||
        action.MeasuresStatus.res.rtn_code == "3004"
      ) {
        message.error("该组件未执行过代码质量检查");
      }
      return state;
    // 质量树
    case types.XAHC_BUILD_QUALITY_TREE_SAGA:
      if (action.TreeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("TreeData", action.TreeStatus.res);
      }
      return state;
    // 质量树代码
    case types.XAHC_BUILD_QUALITY_SOURCE_SAGA:
      if (action.SourceStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("SourceData", action.SourceStatus.res);
      }
      return state;
    // 质量树代码bug
    case types.XAHC_BUILD_QUALITY_RULE_SAGA:
      if (action.RuleStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("RuleData", action.RuleStatus.res);
      }
      return state;
    // 参数配置
    case types.XAHC_BUILD_ATTR_PARAMS_SAGA:
      if (action.ParamsStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("ParamsData", action.ParamsStatus.res.data);
      }
      return state;
    // 构建计划模板data获取
    case types.XAHC_BUILD_RESETSTATE_SAGA:
      return (
        state
          .set("baseUpdateFlag", 0)
          .set("baseSaveFlag", 0)
          // .set("baseUpdateData", [])
          // .set("baseSaveData", [])
          .set("paramsDeleteFlag", 0)
          .set("paramsSaveFlag", 0)
          .set("paramsUpdateFlag", 0)
          .set("stageListFlag", 0)
      );
    // 重置构建表单
    case types.XAHC_BUILD_RESET_IMAGE_SAGA:
      return state.set("stageDetailsData", []).set("jobStatus", 0);
    // 重置通知选择邮件列表
    case types.XAHC_BUILD_RESET_EMAIL_SAGA:
      return state.set("emailData", []);
    case types.XAHC_BUILD_RESETDATA_SAGA:
      return state
        .set("baseUpdateData", {})
        .set("baseSaveData", {})
        .set("definationDetails", []);
    // 清除初次保存数据
    case types.XAHC_BUILD_RESET_SAVE_DATA_SAGA:
      return state.set("baseSaveData", {});
    case types.XAHC_BUILD_UPDATE_STATUS_SAGA:
      if (action.jobStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("jobStatus", 1);
      } else if (action.jobStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("jobStatus", 0);
      }
      return state;
    // SonarQube服务器
    case types.XAHC_BUILD_SONAR_SERVER_LIST_SAGA:
      if (action.sonarQubeServerList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("sonarQubeServerList", action.sonarQubeServerList.res.data);
      }
      return state;
    // nexus地址
    case types.XAHC_BUILD_NEXUS_LIST_SAGA:
      if (action.nexusList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("nexusList", action.nexusList.res.data);
      }
      return state;
    // 镜像服务器
    case types.XAHC_BUILD_IMAGE_SERVER_LIST_SAGA:
      if (action.imageServerList.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("imageServerList", action.imageServerList.res.data);
      }
      return state;
    // 设置构建分页当前页
    case types.XAHC_BUILD_SET_CURRENT_PAGE_SAGA:
      return state.set("currentPage", action.currentPage);
    default:
      return state;
  }
};
export default getDefinationList;
