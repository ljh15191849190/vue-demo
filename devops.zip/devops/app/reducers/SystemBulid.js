import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  categoryData: [],
  pageConfig: {}
});

const SystemBulid = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_SYSTEM_SEARCH_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("TestStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_ADD_SYSTEM_SEARCH_LIST_SAGA:
      if (action.appStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.appStatus.res.rtn_code == 1001) {
        return state.set("AddStatus", 2);
      }
      return state;
    case types.XAHC_DELETE_SYSTEM_SEARCH_LIST_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      }
      return state;
    case types.XAHC_UPDATE_SYSTEM_SEARCH_LIST_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == 1001) {
        return state.set("UpdataStatus", 2);
      }
      return state;
    case types.XAHC_SYSTEMTYPE_SEARCHBYNAME_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("resData", action.resData.res.data).set("systemByNameStatus", 1);
      }
      return state;

    case types.XAHC_SYSTEMTYPE_CATEGORY_SAGA:
      if (action.categoryData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("categoryData", action.categoryData.res.data).set("categoryStatus", 1);
      }
      return state;

    case types.XAHC_TESE_SYSTEM_SEARCH_LIST_SAGA:
      if (action.testStatus.res.data == true) {
        return state.set("TestStatus", 1);
      } else if (action.testStatus.res.data == false) {
        return state.set("TestStatus", 2);
      } else if (action.testStatus.res.status == "500") {
        return state.set("TestStatus", 3);
      }
      return state;
    case types.XAHC_RESET_SYSTEM_FIELDS_SAGA:
      return state.set("categoryData", []);
    default:
      return state;
  }
};

export default SystemBulid;
