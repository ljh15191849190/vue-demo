import Immutable from "immutable";
import { message } from "antd";
import history from "../routes/history";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  loginStatus: {},
  logoutStatus: {},
  userInfo: {},
  projectName: ""
});

const login = (state = initState, action) => {
  switch (action.type) {
    case types.LOGIN_SAGA:
      if (action.loginStatus.res.rtn_code == 0) {
        sessionStorage.setItem("loginStatue", 1);
        sessionStorage.setItem("userInfo", JSON.stringify(action.loginStatus.res));
        return state
          .set("loginStatue", 1)
          .set("logoutStatus", 0)
          .set("userInfo", action.loginStatus.res);
      } else if (
        action.loginStatus.res.rtn_code == "1003" ||
        action.loginStatus.res.rtn_code == "1010"
      ) {
        message.info("用户名或密码错误！");
      } else {
        message.info("登录失败！");
        sessionStorage.setItem("loginStatue", 0);
        return state.set("loginStatue", 0).set("logoutStatus", 0);
      }
      // return state.set("loginStatus", action.loginStatus.res.login);
      // sessionStorage.setItem("loginStatue", 1);
      // return state.set("logininfo", 1);
      return state;
    case types.LOGOUT_SAGA:
      if (action.logoutStatus.res.rtn_code == 0) {
        sessionStorage.setItem("loginStatue", 0);
        sessionStorage.clear();
        history.push("/devops/login");
        return state.set("logoutStatus", 1).set("loginStatue", 3);
      }
      return state.set("logoutStatus", 0).set("loginStatue", 3);
    case types.XAHC_UPDATE_PROJECT_NAME_SAGA:
      return state.set("projectName", action.projectName);
    default:
      return state;
  }
};

export default login;
