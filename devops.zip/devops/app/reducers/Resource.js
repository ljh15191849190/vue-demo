import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  testData: [],
  nameData: [],
  nodeListData: [],
  nameSpaceListData: [],
  appListData: [],
  appDetailData: [],
  clusterInfoData: {},
  podInfoData: [],
  podNumData: {},
  clusterData: [],
  podBasicData: [],
  podLogData: [],
  podMonitorData: [],
  nameSpacePodData: [],
  buildnum: ""
});

const Resource = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_RESOURCE_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.list)
          .set("delStatus", 0)
          .set("testData", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_RESOURCE_ADD_SAGA:
      if (action.addStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.addStatus.res.rtn_code == "1004") {
        return state.set("AddStatus", 3);
      } else if (action.addStatus.res.rtn_code == "5003") {
        return state.set("AddStatus", 4);
      } else if (action.addStatus.res.rtn_code == "5001") {
        message.error("新增失败,IP已占用");
      } else {
        return state.set("AddStatus", 2);
      }
      return state;
    case types.XAHC_RESOURCE_UPDATE_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == "1004") {
        return state.set("UpdataStatus", 3);
      } else {
        return state.set("UpdataStatus", 2);
      }
    // return state;
    case types.XAHC_RESOURCE_DELETE_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      } else if (action.deleteStatus.res.rtn_code == "5004") {
        return state.set("delStatus", 2);
      } else if (action.deleteStatus.res.rtn_code == "5005") {
        message.info("该虚拟机资源有任务不能删除");
      }
      return state;
    case types.XAHC_RESOURCE_TEST_SAGA:
      if (action.testData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("testData", 1);
      } else if (action.testData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("testData", 2);
      } else if (action.testData.res.rtn_code == "6020") {
        message.error("连接失败");
      } else {
        message.error("连接失败");
      }
      return state;
    case types.XAHC_ENVIRONMENT_NAME_SAGA:
      if (action.nameData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("nameData", action.nameData.res.data);
      }
      return state;
    // 容器云
    case types.XAHC_RESOURCE_CLUSTER_ADD_SAGA:
      if (action.addClusterStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.addClusterStatus.res.rtn_code == "6006") {
        return state.set("AddStatus", 5);
      } else if (action.addClusterStatus.res.rtn_code == "6010") {
        message.error("集群IP已存在");
      } else {
        return state.set("AddStatus", 2);
      }
      return state;
    // 容器信息
    case types.XAHC_RESOURCE_FIND_CLUSTER_INFO_SAGA:
      if (action.clusterInfoData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("clusterInfoData", action.clusterInfoData.res);
      }
      return state;
    //  testClusterStatus
    case types.XAHC_RESOURCE_CLUSTER_TEST_SAGA:
      if (action.testClusterStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("测试成功");
        return state.set("testClusterStatus", 1);
      } else if (action.testClusterStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.error("测试失败");
        return state.set("testClusterStatus", 2);
      } else if (action.testClusterStatus.res.rtn_code == "6020") {
        message.error("集群连接失败");
      }
      return state;
    case types.XAHC_RESOURCE_CAAS_NODE_ADD_SAGA:
      if (action.addNodeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("addNodeStatus", 1);
      } else if (action.addNodeStatus.res.rtn_code == "6007") {
        return state.set("addNodeStatus", 3);
      } else if (action.addNodeStatus.res.rtn_code == "6008") {
        message.error("主机Ip已存在");
      } else {
        return state.set("addNodeStatus", 2);
      }
      return state;
    // 主机删除
    case types.XAHC_RESOURCE_CAAS_NODE_DELETE_SAGA:
      if (action.deleteNodeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("deleteNodeStatus", 1);
      } else if (action.deleteNodeStatus.res.rtn_code == "6036") {
        message.info("该主机有pod存在不能删除");
      } else {
        return state.set("deleteNodeStatus", 2);
      }
      return state;
    // 主机修改
    case types.XAHC_RESOURCE_CAAS_NODE_UPDATE_SAGA:
      if (action.updateNodeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("updateNodeStatus", 1);
      } else if (action.updateNodeStatus.res.rtn_code == "1004") {
        return state.set("updateNodeStatus", 3);
      } else if (action.updateNodeStatus.res.rtn_code == "6007") {
        message.error("主机已存在");
      } else {
        return state.set("updateNodeStatus", 2);
      }
      return state;
    // 主机信息
    case types.XAHC_RESOURCE_FIND_POD_INFO_SAGA:
      if (action.podInfoData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("podNumData", action.podInfoData.res.data.listMeta)
          .set("podInfoData", action.podInfoData.res.data.pods);
      }
      return state;
    //  主机测试测试
    case types.XAHC_RESOURCE_CAAS_NODE_TEST_SAGA:
      if (action.testNodeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.success("测试成功");
        return state.set("testNodeStatus", 1);
      } else {
        message.error("测试失败");
        return state.set("testNodeStatus", 2);
      }
    // return state;
    case types.XAHC_RESOURCE_CAAS_NODE_LIST_SAGA:
      if (action.nodeListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("nodeListData", action.nodeListData.res.data)
          .set("addNodeStatus", 0)
          .set("updateNodeStatus", 0)
          .set("deleteNodeStatus", 0)
          .set("nodepageConfig", action.nodeListData.res.pageBean);
      }
      return state;

    case types.XAHC_RESOURCE_CAAS_NAMESPACE_ADD_SAGA:
      if (action.addNameSpaceStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("addNameSpaceStatus", 1);
      } else if (action.addNameSpaceStatus.res.rtn_code == "6009") {
        return state.set("addNameSpaceStatus", 3);
      } else {
        return state.set("addNameSpaceStatus", 2);
      }
    // return state;
    case types.XAHC_RESOURCE_CAAS_NAMESPACE_LIST_SAGA:
      if (action.nameSpaceListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("nameSpaceListData", action.nameSpaceListData.res.data)
          .set("addNameSpaceStatus", 0)
          .set("deleteNameSpaceStatus", 0)
          .set("updateNameSpaceStatus", 0)
          .set("nameSpacepageConfig", action.nameSpaceListData.res.pageBean);
      }
      return state;
    case types.XAHC_RESOURCE_CAAS_NAMESPACE_SEARCH_SAGA:
      if (action.searchnameSpaceListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("nameSpaceListData", action.searchnameSpaceListData.res.data)
          .set("addNameSpaceStatus", 0)
          .set("nameSpacepageConfig", action.searchnameSpaceListData.res.pageBean);
      }
      return state;
    // 工作区删除
    case types.XAHC_RESOURCE_CAAS_NAMESPACE_DELETE_SAGA:
      if (action.deleteNameSpaceStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("deleteNameSpaceStatus", 1);
      } else if (action.deleteNameSpaceStatus.res.rtn_code == "5002") {
        return state.set("deleteNameSpaceStatus", 2);
      } else if (action.deleteNameSpaceStatus.res.rtn_code == "6039") {
        message.error("此工作区有服务不能删除");
      }
      return state;
    // 工作区修改
    case types.XAHC_RESOURCE_CAAS_NAMESPACE_UPDATE_SAGA:
      if (action.updateNameSpaceStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("updateNameSpaceStatus", 1);
      } else if (action.updateNameSpaceStatus.res.rtn_code == "1004") {
        return state.set("updateNameSpaceStatus", 3);
      } else {
        return state.set("updateNameSpaceStatus", 2);
      }
    // return state;

    // 应用市场
    case types.XAHC_CAAS_MARKETAPPS_LIST_SAGA:
      if (action.appListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("appListData", action.appListData.res.data)
          .set("appListpageConfig", action.appListData.res.pageBean);
      }
      return state;
    case types.XAHC_CAAS_MARKETAPPS_DETAIL_SAGA:
      if (action.appDetailData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("appDetailData", action.appDetailData.res.data)
          .set("appDetailpageConfig", action.appDetailData.res.pageBean);
      }
      return state;
    // 部署
    case types.XAHC_DEPLOY_MARKETAPPS_DEPLOY_SAGA:
      if (action.deployData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("deployData", action.deployData.res.data)
          .set("buildnum", action.deployData.res.buildnum);
      } else if (action.deployData.res.rtn_code == "1004") {
        message.info("数据已存在");
      }
      return state;
    //  根据projectId查找集群信息
    case types.XAHC_FIND_CLUSTER_BY_ID_SAGA:
      if (action.clusterData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("clusterData", action.clusterData.res.data);
      }
      return state;
    //  根据clusterId查询命名空间
    case types.XAHC_FIND_NAMESPACE_BY_CLUSTER_ID_SAGA:
      if (action.nameSpacePodData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("nameSpacePodData", action.nameSpacePodData.res.data);
      }
      return state;
    // pod 操作
    // 主机信息
    case types.XAHC_RESOURCE_POD_BASIC_INFO_SAGA:
      if (action.podBasicData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("podBasicData", action.podBasicData.res.data);
        //  .set("podInfoData", action.podBasicData.res.data.pods);
      }
      return state;
    case types.XAHC_RESOURCE_POD_EVENT_INFO_SAGA:
      if (action.podEventData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("podEventData", action.podEventData.res.data);
      }
      return state;
    case types.XAHC_RESOURCE_POD_LOG_INFO_SAGA:
      if (action.podLogData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("podLogData", action.podLogData.res.data);
      }
      return state;
    case types.XAHC_RESOURCE_POD_MONITOR_INFO_SAGA:
      if (action.podMonitorData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("podMonitorData", action.podMonitorData.res.data);
      }
      return state;
    //  重置所在集群下拉数据
    case types.XAHC_RESET_CLUSTER_SAGA:
      return state.set("clusterData", []);
    //  重置命名空间下拉数据
    case types.XAHC_RESET_NAMESPACE_SAGA:
      return state.set("nameSpacePodData", []);
    default:
      return state;
  }
};

export default Resource;
