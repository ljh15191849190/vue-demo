import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  uploadStatus: 0,
  uploadSoftFlag: 0
});

const MediumWarehouse = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_BUILD_MEDIUM_WH_FIND_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("pageConfig", action.resData.res.pageBean)
          .set("uploadStatus", 0)
          .set("uploadSoftFlag", 0)
          .set("searchStatus", 0);
      }
      return state;
    case types.XAHC_BUILD_MEDIUM_WH_UPLOAD_SAGA:
      if (action.uploadStatus.res.rtn_code == "OK") {
        return state.set("uploadStatus", 1);
      } else if (action.uploadStatus.res.rtn_code == "-1") {
        return state.set("uploadStatus", 2);
      }
      return state;
    case types.XAHC_BUILD_SEARCH_WH_FIND_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("resData", action.resData.res.data).set("searchStatus", 1);
      }
      return state;
    case types.XAHC_BUILD_SEARCH_NAME_SYSTEM_TYPE_SAGA:
      if (action.systemTypeData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("systemTypeData", action.systemTypeData.res.data);
      }
      return state;
    case types.XAHC_BUILD_REP_LIST_BYNAME_SAGA:
      if (action.repListData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("repListData", action.repListData.res.data);
      }
      return state;
    // 上传软件包
    case types.XAHC_BUILD_UPLOAD_SOFT_SAGA:
      if (action.uploadStatus.res.rtn_code == "OK") {
        message.info("上传成功");
        return state.set("uploadSoftFlag", 1);
      }else if (action.uploadStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.warning(action.uploadStatus.res.data);
        return state.set("uploadSoftFlag", -1);
      }
      return state;
    default:
      return state;
  }
};

export default MediumWarehouse;
