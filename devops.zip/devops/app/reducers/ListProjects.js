import Immutable from "immutable";
import { message } from "antd";
import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  projects: [],
  resData: {},
  topData: [],
  topbuildData: [],
  rateData: {},
  buildData: [],
  deployData: [],
  qualityData: [],
  commitData: [],
  buildcode: "",
  deploycode: "",
  commitcode: "",
  qualitycode: ""
});

const listProjects = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_GET_ALL_PROJECTS_SAGA:
      if (action.projects.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("projects", action.projects.res.data)
          .set("pageConfig", action.projects.res.pageBean);
      }
      return state.set("projects", []);
    case types.XAHC_PROJECT_OVERVIEW_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("resData", action.resData.res.data);
      }
      return state;
    case types.XAHC_PROJECT_DEPLOYTOP_SAGA:
      if (action.topData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("topData", action.topData.res.deployDuration.top5);
      }
      return state;
    case types.XAHC_PROJECT_BUILD_DEPLOYTOP_SAGA:
      if (action.topbuildData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("topbuildData", action.topbuildData.res.buildDuration.top5);
      }
      return state;
    case types.XAHC_PROJECT_RATE_SAGA:
      if (action.rateData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("rateData", action.rateData.res.data);
      }
      return state;
    // 报表
    case types.XAHC_PROJECT_BUILDSTATEMENT_SAGA:
      if (action.buildData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("buildData", action.buildData.res.data)
          .set("buildcode", action.buildData.res.code);
      }
      return state;
    case types.XAHC_PROJECT_DEPLOYSTATEMENT_SAGA:
      if (action.deployData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("deployData", action.deployData.res.data)
          .set("deploycode", action.deployData.res.code);
      }
      return state;
    case types.XAHC_PROJECT_CODEQUALITY_SAGA:
      if (action.qualityData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("qualityData", action.qualityData.res.data)
          .set("qualitycode", action.qualityData.res.code);
      }
      return state;
    case types.XAHC_PROJECT_CODECOMMIT_SAGA:
      if (action.commitData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("commitData", action.commitData.res.data)
          .set("commitcode", action.commitData.res.code);
      }
      return state;
    default:
      return state;
  }
};

export default listProjects;
