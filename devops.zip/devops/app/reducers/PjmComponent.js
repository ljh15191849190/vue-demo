import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  detailData: [],
  lastBuildInfo: {},
  lastDeployReleaseInfo: [],
  deployDefInfo: [],
  buildDef: []
});

const PjmComponent = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_PJM_COMPONENT_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.data)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_PJM_ADD_COMPONENT_SAGA:
      if (action.appStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.appStatus.res.rtn_code == "84013") {
        message.error("组件编号已存在");
      } else {
        return state.set("AddStatus", 2);
      }
      return state;
    case types.XAHC_PJM_UPDATE_COMPONENT_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("UpdataStatus", 2);
      }
      return state;
    case types.XAHC_PJM_DELETE_COMPONENT_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      } else if (action.deleteStatus.res.rtn_code == 84014) {
        return state.set("delStatus", 2);
      } else if (
        action.deleteStatus.res.rtn_code == 5002 ||
        action.deleteStatus.res.rtn_code == 4001
      ) {
        message.error("删除失败当前组件有任务");
      } else {
        message.info("删除失败");
      }
      return state;
    case types.XAHC_PJM_COMPONENT_MODULE_DETAIL_SAGA:
      if (action.detailData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("lastBuildInfo", action.detailData.res.lastBuildInfo)
          .set("lastDeployReleaseInfo", action.detailData.res.lastDeployReleaseInfo.data)
          .set("deployDefInfo", action.detailData.res.deployDefInfo.data)
          .set("buildDef", action.detailData.res.buildDef.data);
      }
      return state;
    case types.XAHC_PJM_COMPONENT_ADDRESS_SAGA:
      if (action.addressStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("addressData", action.addressStatus.res.data);
      }
      return state;
    default:
      return state;
  }
};

export default PjmComponent;
