import Immutable from "immutable";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {}
});

const SysInteRepertory = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_SYS_INTE_REPERTORY_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.list)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;

    default:
      return state;
  }
};

export default SysInteRepertory;
