import Immutable from "immutable";
import { message } from "antd";
import * as type from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  addStatus: 0,
  delStatus: 0,
  updateStatus: 0,
  otherStatus: 0,
  availableStatus: 0,

  pjmMenuListData: [],
  userMenuAllData: [],
  organizationAllData: [],
  userManageData: [],
  userFindData: [],
  roleAllData: [],
  userFindoneData: [],
  roleManageData: [],
  sysroleFindData: [],
  menuTreeData: [],
  menuTreeManageData: [],
  roleMenusData: [],
  operationLogData: [],
  operationLogDetailData: [],

  introduceMenuData: [],
  childMenusData: [],
  menuFindData: [],

  introduceOrgData: [],
  childOrgsData: [],
  orgFindData: [],

  resManageData: [],
  findresData: [],
  pageConfig: {}
});

const reduce = (state = initState, action) => {
  switch (action.type) {
    case type.SAGA_ADD:
      switch (action.param.from) {
        case "pjmMenuList":
          return state
            .set("pjmMenuListData", action.status.res)
            .set("delStatus", 0)
            .set("addStatus", 0)
            .set("updateStatus", 0)
            .set("otherStatus", 0);

        case "userMenuAll":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("userMenuAllData", action.status.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_NOTEXIST) {
            // message.error("该用户名未定义任何角色，请联系管理员!");
          }
          return state;
        case "userManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 1)
              .set("updateStatus", 0);
            // message.success("添加成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_USERNAME_EXIST) {
            message.error("该用户名或邮箱或手机号已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;
        case "addrole":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("配置成功！");
            return state
              .set("delStatus", 0)
              .set("addStatus", 1)
              .set("updateStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该角色已存在!");
          } else {
            message.error("配置失败！");
          }
          return state;
        case "roleManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 1)
              .set("updateStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该角色已存在!");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLENAME_EXIST) {
            message.error("该角色名称已存在!");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLECODE_EXIST) {
            message.error("该角色编码已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;

        case "menuManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            // message.success("添加成功！");
            return state
              .set("delStatus", 0)
              .set("addStatus", 1)
              .set("updateStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_MENUCODE_EXIST) {
            message.error("该菜单编号或菜单名称已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;

        case "orgManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            // message.success("添加成功！");
            return state
              .set("delStatus", 0)
              .set("addStatus", 1)
              .set("updateStatus", 0);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGNAME_EXIST) {
            message.error("该机构名称已存在!");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGCODE_EXIST) {
            message.error("该机构编号已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;

        case "roleAuthorize":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state.set("otherStatus", 1);

            // message.success("添加成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该权限已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;

        case "authorityManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("添加成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该权限已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;

        case "addResource":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("添加成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该权限已存在!");
          } else {
            message.error("添加失败！");
          }
          return state;
        default:
          return state;
      }

    case type.SAGA_DEL:
      if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
        return state
          .set("delStatus", 1)
          .set("addStatus", 0)
          .set("updateStatus", 0)
          .set("otherStatus", 0);
      } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLE_USED) {
        message.error("角色被使用无法删除!");
      } else if (action.status.res.rtn_code === StatusCode.XAHC_PEMISSION_USED) {
        message.error("权限被使用无法删除!");
      } else if (action.status.res.rtn_code === StatusCode.XAHC_MENUCHILD_EXIST) {
        message.error("此菜单有子菜单，无法删除!");
      } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGCHILD_EXIST) {
        message.error("此机构有子机构，无法删除!");
      } else {
        message.error("删除失败！");
      }
      return state;

    case type.SAGA_GET:
      if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "organizationAll":
            return state
              .set("organizationAllData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "userManage":
            return state
              .set("userManageData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "userFind":
            return state.set("userFindData", action.data.res);

          case "roleAll":
            return state.set("roleAllData", action.data.res);

          case "userFindone":
            return state.set("userFindoneData", action.data.res);

          case "roleManage":
            return state
              .set("roleManageData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "menuTree":
            return state
              .set("menuTreeData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "menuTreeManage":
            return state.set("menuTreeManageData", action.data.res);

          case "introduceMenu":
            return state
              .set("introduceMenuData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "childMenus":
            return state
              .set("childMenusData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "menuFind":
            return state.set("menuFindData", action.data.res);

          case "roleMenus":
            return state.set("roleMenusData", action.data.res);

          case "sysroleFind":
            return state.set("sysroleFindData", action.data.res);

          case "introduceOrg":
            return state
              .set("introduceOrgData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "childOrgs":
            return state
              .set("childOrgsData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);

          case "orgFind":
            return state.set("orgFindData", action.data.res);

          case "operationLog":
            return state.set("operationLogData", action.data.res);

          case "operationLogDetail":
            return state.set("operationLogDetailData", action.data.res);

          default:
            return state;
        }
      } else {
        message.error("获取数据失败！");
        return state;
      }

    case type.SAGA_UPDATE:
      switch (action.param.from) {
        case "userManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 1);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_USERNAME_EXIST) {
            message.error("该用户名或邮箱或手机号已存在！");
          } else {
            message.error("修改失败！");
          }
          return state;
        case "forbidden":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state.set("otherStatus", 1);
          } else {
            message.error("修改失败！");
          }
          return state;

        case "roleManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 1);
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLENAME_EXIST) {
            message.error("该角色名称已存在！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ROLECODE_EXIST) {
            message.error("该角色编码已存在！");
          } else {
            message.error("修改失败！");
          }
          return state;

        case "menuManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 1);
            // message.success("修改成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_MENUCODE_EXIST) {
            message.error("该菜单编号或菜单名称已存在!");
          } else {
            message.error("修改失败！");
          }
          return state;

        case "orgManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            return state
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 1);
            // message.success("修改成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGNAME_EXIST) {
            message.error("该机构名称已存在!");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_ORGCODE_EXIST) {
            message.error("该机构编码已存在!");
          } else {
            message.error("修改失败！");
          }
          return state;
        case "authorityManage":
          if (action.status.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
            message.success("修改成功！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_DATA_EXIST) {
            message.error("该权限已存在！");
          } else if (action.status.res.rtn_code === StatusCode.XAHC_PERMISSION_EXITST) {
            message.error("该权限名称已存在！");
          } else {
            message.error("修改失败！");
          }
          return state;
        default:
          return state;
      }

    case type.SAGA_SEARCH:
      if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "userManage":
            return state
              .set("userManageData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          case "roleManage":
            return state
              .set("roleManageData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          case "operationLog":
            return state
              .set("operationLogData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          case "findres":
            return state
              .set("findresData", action.data.res)
              .set("delStatus", 0)
              .set("addStatus", 0)
              .set("updateStatus", 0)
              .set("otherStatus", 0);
          default:
            return state;
        }
      } else {
        message.error("获取数据失败！");
        return state;
      }

    case type.SAGA_UPDATE_COMPANY_INFO:
      if (action.data.res.rtn_code === StatusCode.XAHC_SUCCESSED) {
        switch (action.param.from) {
          case "companyInfo":
            message.info("修改用户数据成功！");
            return state.set("companyInfo", action.data.res);
          default:
            return state;
        }
      } else {
        message.error("修改用户数据失败！");
        return state;
      }

    default:
      return state;
  }
};

export default reduce;
