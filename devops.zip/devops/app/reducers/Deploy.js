import Immutable from "immutable";
import { message } from "antd";
import * as types from "../constants/ActionTypes";
import * as StatusCode from "../constants/StatusCode";

const initState = Immutable.Map({
  defiantionListData: [],
  pageConfig: [],
  deleteFlag: 0,
  hostListData: [],
  runningEnvList: [],
  saveFlag: 0,
  hostPageConfig: [],
  cloneFlag: 0,
  updateFlag: 0,
  deployStatus: 0,
  ipsData: [],
  ipsList: [],
  historyData: [],
  historyDetails: [],
  executeFlag: 0,
  executeData: "",
  exception: "",
  deployStatusCode: "",
  time: "",
  detailsData: {},
  selectedHosts: [],
  hisConsoleData: {},
  podData: [],
  podLog: "",
  ymlTmpData: "",
  imageList: [],
  envFlag: 0,
  currentPage: 1,
  duratime: ""
});
const deploymentManage = (state = initState, action) => {
  switch (action.type) {
    // 获取部署任务列表
    case types.XAHC_DEPLOY_LIST_ALL_SAGA:
      if (action.deploymentPageListStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("defiantionListData", action.deploymentPageListStatus.res.data)
          .set("pageConfig", action.deploymentPageListStatus.res.pageBean)
          .set("saveFlag", 0)
          .set("deleteFlag", 0)
          .set("cloneFlag", 0)
          .set("updateFlag", 0);
      }
      return state;
    // 保存部署实例
    case types.XAHC_DEPLOY_SAVE_SAGA:
      if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("新增成功");
        return state.set("saveFlag", 1);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("定义名称重复");
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.warning("参数为空");
        return state.set("saveFlag", 2);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_DEP_PARAMS_EXIST) {
        message.warning("参数为空");
        return state.set("saveFlag", 2);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_NAMESPACE_EXIST) {
        message.warning("该组件已在当前命名空间中部署");
        return state.set("envFlag", 2);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.warning("服务异常");
        return state.set("envFlag", 1);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_ENV_EXIST) {
        message.warning(action.deploymentSaveStatus.res.data);
        return state.set("envFlag", 1);
      } else if (action.deploymentSaveStatus.res.rtn_code == StatusCode.XAHC_DEP_NAME_EXIST) {
        message.warning(action.deploymentSaveStatus.res.data);
        return state.set("envFlag", 1);
      }
      return state;
    // 获取运行环境
    case types.XAHC_DEPLOY_RUNNINGENV_LIST_SAGA:
      if (action.getRuningEnvListStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("runningEnvList", action.getRuningEnvListStatus.res.data);
      }
      return state;
    // 获取主机列表
    case types.XAHC_DEPLOY_HOST_LIST_SAGA:
      if (action.hostStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("hostListData", action.hostStatus.res.list)
          .set("hostPageConfig", action.hostStatus.res.pageBean);
      }
      return state;
    // 获取shell脚本
    case types.XAHC_DEPLOY_SHELL_SAGA:
      if (action.shellStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("shellContent", action.shellStatus.res.data);
      }
      return state;
    // 删除
    case types.XAHC_DEPLOY_DELETE_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("删除成功");
        return state.set("deleteFlag", 1);
      } else if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SERVICE_EXIST) {
        message.info("部署服务有服务实例，请先删除监控服务");
        return state.set("deleteFlag", 0);
      } else if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.warning("参数为空");
      } else if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.warning("服务异常");
      }
      return state;
    // 克隆
    case types.XAHC_DEPLOY_CLONE_SAGA:
      if (action.cloneDeployStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("克隆成功");
        return state.set("cloneFlag", 1);
      }
      return state;
    // 查找定义
    case types.XAHC_DEPLOY_FIND_BY_ID_SAGA:
      if (action.detailsStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("detailsData", action.detailsStatus.res)
          .set("ipsData", action.detailsStatus.res.ips)
          .set("attr", action.detailsStatus.res.attr);
      }
      return state;
    // 更新定义
    case types.XAHC_DEPLOY_UPDATE_SAGA:
      if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        message.info("更新成功");
        return state.set("updateFlag", 1).set("detailsData", {});
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_USER_EXIST) {
        message.warning("定义名称重复");
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        message.warning("参数为空");
        return state.set("updateFlag", 2);
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_DEP_PARAMS_EXIST) {
        message.warning("参数为空");
        return state.set("updateFlag", 2);
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.warning("服务异常");
        return state.set("envFlag", 1);
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_NAMESPACE_EXIST) {
        message.warning("该组件已在当前命名空间中部署");
        return state.set("envFlag", 2);
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_ENV_EXIST) {
        message.warning(action.deployUpdateStatus.res.data);
        return state.set("envFlag", 1);
      } else if (action.deployUpdateStatus.res.rtn_code == StatusCode.XAHC_DEP_NAME_EXIST) {
        message.warning(action.deployUpdateStatus.res.data);
        return state.set("envFlag", 1);
      }
      return state;
    // 更新实例状态
    case types.XAHC_DEPLOY_UPDATE_STATUS_SAGA:
      if (action.deployStatusData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("deployStatus", 1);
      } else if (action.deployStatusData.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        return state.set("deployStatus", 0);
      }
      return state;
    // 根据id查询主机列表
    case types.XAHC_DEPLOY_FIND_IPSLIST_BY_ID_SAGA:
      if (action.ipsData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("ipsList", action.ipsData.res);
      }
      return state;
    // 查询日志
    case types.XAHC_DEPLOY_CONSOLE_SAGA:
      if (action.consoleData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("consoleData", action.consoleData.res.data);
      }
      return state;
    // pod组信息
    case types.XAHC_DEPLOY_POD_LIST_SAGA:
      if (action.podData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("podData", action.podData.res.data);
      }
      return state;
    // pod日志
    case types.XAHC_DEPLOY_POD_LOG_SAGA:
      if (action.podLog.res) {
        return state.set("podLog", action.podLog.res.data);
      }
      return state;
    // 查询历史日志
    case types.XAHC_DEPLOY_HIS_CONSOLE_SAGA:
      if (action.hisConsoleData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("hisConsoleData", action.hisConsoleData.res.data);
      }
      return state;
    // 部署历史
    case types.XAHC_DEPLOY_HISTORY_SAGA:
      if (action.historyData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("historyData", action.historyData.res.data)
          .set("pageConfig", action.historyData.res.pageBean);
      }
      return state;
    // 部署历史详情
    case types.XAHC_DEPLOY_HISTORY_DETAILS_SAGA:
      if (action.historyDetails.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("historyDetails", action.historyDetails.res);
      }
      return state;
    // 部署执行
    case types.XAHC_DEPLOY_EXECUTE_SAGA:
      if (action.executeStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("executeFlag", 1).set("executeData", action.executeStatus.res.buildnum);
      } else if (action.executeStatus.res.rtn_code == StatusCode.XAHC_NONE_PARAM) {
        // message.info(action.executeStatus.res.exception);
        return state.set("executeFlag", 0).set("exception", action.executeStatus.res.exception);
      } else if (action.executeStatus.res.rtn_code == StatusCode.XAHC_EXCEPTION) {
        message.warning("执行失败");
        return state.set("executeFlag", 0).set("exception", "执行失败");
      }
      return state;
    // 重置状态
    case types.XAHC_DEPLOY_RESETSTATE_SAGA:
      return state
        .set("executeFlag", 0)
        .set("executeData", "")
        .set("exception", "")
        .set("deployStatusCode", "");
    // 重置部署状态
    case types.XAHC_RESET_DEPLOY_STATE_SAGA:
      return state.set("deployStatusCode", "");
    // 重置详情
    case types.XAHC_RESET_DETAIL_SAGA:
      return state.set("detailsData", {}).set("historyDetails", {});
    // 重置错误标志
    case types.XAHC_RESET_ENV_SAGA:
      return state.set("envFlag", 0);
    case types.XAHC_RESET_CONSOLE_SAGA:
      return state
        .set("consoleData", "")
        .set("duratime", "")
        .set("time", "");
    // 部署状态查询
    case types.XAHC_DEPLOY_FIND_STATUS_SAGA:
      if (action.deployStatusCode.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("deployStatusCode", action.deployStatusCode.res.status)
          .set("time", action.deployStatusCode.res.time)
          .set("duratime", action.deployStatusCode.res.duratime);
      }
      return state;
    // 根据项目Id查询用户信息列表
    case types.XAHC_TEAM_USER_LIST_BY_PROJECTID_SAGA:
      if (action.getUserlistByIdStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("getUserDataListById", action.getUserlistByIdStatus.res.data);
      }
      return state;
    // 更新部署主机
    case types.XAHC_DEPLOY_UPDATE_HOSTS_SAGA:
      if (action.updateHostStatusList.data) {
        return state.set("selectedHosts", action.updateHostStatusList.data);
      }
      return state;
    // 获取yml文件
    case types.XAHC_DEPLOY_YML_TMP_SAGA:
      if (action.ymlTmpData.res) {
        return state.set("ymlTmpData", action.ymlTmpData.res.data);
      }
      break;
    // 获取镜像仓库
    case types.XAHC_DEPLOY_IMAGE_SAGA:
      if (action.imageList.res) {
        return state.set("imageList", action.imageList.res.data);
      }
      break;
    // 设置部署分页当前页
    case types.XAHC_SET_CURRENT_PAGE_SAGA:
      return state.set("currentPage", action.currentPage);
    default:
      return state;
  }
};
export default deploymentManage;
