import Immutable from "immutable";
import { message } from "antd";
import * as StatusCode from "../constants/StatusCode";
import * as types from "../constants/ActionTypes";

const initState = Immutable.Map({
  resData: [],
  pageConfig: {},
  typeData: []
});

const Environment = (state = initState, action) => {
  switch (action.type) {
    case types.XAHC_ENVIRONMENT_LIST_SAGA:
      if (action.resData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state
          .set("resData", action.resData.res.list)
          .set("delStatus", 0)
          .set("AddStatus", 0)
          .set("UpdataStatus", 0)
          .set("pageConfig", action.resData.res.pageBean);
      }
      return state;
    case types.XAHC_ENVIRONMENT_ADD_SAGA:
      if (action.addStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("AddStatus", 1);
      } else if (action.addStatus.res.rtn_code == "1004") {
        return state.set("AddStatus", 3);
      } else {
        return state.set("AddStatus", 2);
      }
    // return state;
    case types.XAHC_ENVIRONMENT_DELETE_SAGA:
      if (action.deleteStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("delStatus", 1);
      } else if (action.deleteStatus.res.rtn_code == "5001") {
        return state.set("delStatus", 2);
      } else if (action.deleteStatus.res.rtn_code == "5007") {
        message.error("环境已被虚拟机使用不能删除");
      } else if (action.deleteStatus.res.rtn_code == "5006") {
        message.error("环境下有容器命名空间不能删除");
      }
      return state;
    case types.XAHC_ENVIRONMENT_UPDATE_SAGA:
      if (action.updataStatus.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("UpdataStatus", 1);
      } else if (action.updataStatus.res.rtn_code == "1004") {
        return state.set("UpdataStatus", 3);
      } else {
        return state.set("UpdataStatus", 2);
      }
    // return state;
    case types.XAHC_ENVIRONMENT_TYPE_SAGA:
      if (action.typeData.res.rtn_code == StatusCode.XAHC_SUCCESSED) {
        return state.set("typeData", action.typeData.res.data);
      }
      return state;
    default:
      return state;
  }
};

export default Environment;
