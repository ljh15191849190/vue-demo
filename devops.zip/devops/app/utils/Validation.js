// 验证
export default {
  // 名称
  Rule_name: [
    {
      required: true,
      pattern: /^(?!_)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
      message: "请输入中文、字母、数字、下划线，不能以下划线开头"
    }
  ],
  // 编号
  Rule_code: [
    {
      required: true,
      message: "请输入字母、数字、下划线，不能以下划线开头",
      pattern: /^(?!_)[a-zA-Z0-9_]+$/
    }
  ],
  // 组件编号
  Rule_Componentcode: [
    {
      required: true,
      message: "请输入小写字母、数字、下划线，不能以下划线开头",
      pattern: /^(?!_)[a-z0-9_]+$/
    }
  ],
  // ip
  Rule_ip: [
    {
      required: true,
      message: "请输入正确ip地址",
      pattern: /^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$/
    }
  ],
  // 编号,镜像名
  Rule_projectCode: [
    {
      required: true,
      message: "请输入小写字母、数字、下划线，点，-，以字母或者数字开头",
      pattern: /^[0-9a-z][0-9a-z\-_.]*$/
    },
    {
      min: 2,
      message: "长度至少为两个字符"
    }
  ],
  // 下拉选择框非空验证
  Rule_select: [{ required: true, message: "内容不能为空" }],
  Rule_falseselect: [{ required: false, message: "内容不能为空" }],
  // groupId
  Rule_groupId: [
    {
      required: true,
      message: "请输入字母、数字、下划线、点，以字母或者数字开头",
      pattern: /^[0-9a-zA-Z][0-9a-zA-Z\_.]*$/
    }
  ],
  // artifactId
  Rule_artifactId: [
    {
      required: true,
      message: "请输入字母、数字、-，以字母或者数字开头",
      pattern: /^[0-9a-zA-Z][0-9a-zA-Z\-]*$/
    }
  ],
  // nodeName
  Rule_nodeName: [
    {
      required: true,
      message: "请输入字母、数字、-，以字母开头",
      pattern: /^[a-zA-Z][0-9a-zA-Z\-]*$/
    }
  ],
  // nameSpace
  Rule_nameSpace: [
    {
      required: true,
      message: "请输入小写字母、数字、-，以小写字母开头",
      pattern: /^[a-z][0-9a-z\-]*$/
    }
  ],

  // numLetter
  Rule_NumLetter: [
    {
      required: true,
      message: "请输入字母、数字",
      pattern: /^[0-9a-zA-Z]*$/
    }
  ],
  // version&classifier&版本
  Rule_params: [
    {
      required: true,
      message: "请输入字母、数字、点、下划线、-，以字母或者数字开头",
      pattern: /^[0-9a-zA-Z][0-9a-zA-Z\-._]*$/
    }
  ],
  //  AutoComplete_Version
  Rule_AutoComplete_params: [
    {
      required: true,
      message: "请输入字母、数字、点、下划线、-，以字母或者数字开头",
      pattern: /^[0-9a-zA-Z][0-9a-zA-Z\-._]*$/
    },
    {
      max: 32,
      message: "最大长度不超过32位"
    }
  ],

  // branch
  Rule_branch: [
    {
      required: true,
      message: "请输入字母、数字、下划线、$、{}，以字母、数字或$开头",
      pattern: /^[0-9a-zA-Z$][0-9a-zA-Z\${}_]*$/
    }
  ],
  // Maven参数
  Rule_Maven: [
    {
      required: true,
      message: "请输入字母、空格、$、{}，-，以字母或$开头",
      pattern: /^[a-zA-Z$][a-zA-Z\$ -{}]*$/
    },
    {
      max: 128,
      message: "最大长度不超过128位"
    }
  ],
  // PoM文件
  Rule_PoM: [
    {
      required: true,
      message: "请输入字母、数字、/_.，，不能以点开头",
      pattern: /^[0-9a-zA-Z/_][a-z0-9A-Z\_/.]*$/
    }
  ],
  // 数字
  Rule_number: [
    {
      required: true,
      message: "请输入数字",
      pattern: /^[0-9]+$/
    }
  ],
  // 数字
  Rule_falsenumber: [
    {
      required: false,
      message: "请输入数字",
      pattern: /^[0-9]+$/
    }
  ],
  // 英文
  Rule_English: [
    {
      required: true,
      message: "请输入英文字母",
      pattern: /^[a-zA-Z]+$/
    }
  ],
  // 非中文
  Rule_nochinese: [
    {
      required: true,
      message: "请输入非中文",
      pattern: /^[^\u4e00-\u9fa5]+$/
    }
  ],
  // 非中文
  Rule_falsechinese: [
    {
      required: false,
      message: "请输入非中文",
      pattern: /^[^\u4e00-\u9fa5]+$/
    }
  ],
  // url/http
  Rule_url: [
    {
      required: true,
      pattern: /^(http|ftp|https):\/\/?[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?/,
      message: "请输入正确url地址"
    }
  ],
  //    手机号码
  Rule_tel: [
    {
      required: true,
      message: "请输入正确的手机号码",
      pattern: /^1[3|4|5|6|7|8|9][0-9]\d{8}$/
    }
  ],
  //    邮箱
  Rule_mail: [
    {
      required: true,
      message: "请输入正确的邮箱地址",
      pattern: /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/
    }
  ],
  // password
  Rule_password: [
    {
      required: true,
      message: "密码应为6到16位，非中文",
      pattern: /^[^\u4e00-\u9fa5]{6,16}$/gm
    }
  ],
  // 非必选项，但是不能输入空格
  Rule_not_required_whitespace: [
    {
      required: false,
      message: "内容不能有空格",
      whitespace: true
    }
  ],
  // buildManage
  Rule_perform_params: [
    {
      required: true,
      message: "请输入字母、数字、空格或者-_.:",
      pattern: /^[a-zA-Z0-9-_ .:/\u4e00-\u9fa5]+$/
    }
  ],
  // build参数
  Rule_build_params: [
    {
      required: true,
      message: "请输入字母、数字、空格或者-_.:",
      pattern: /^[a-zA-Z0-9-_ .:/\u4e00-\u9fa5]+$/
    }
  ],
  // 小数点两位
  Rule_NumberPoint: [
    {
      required: true,
      message: "请输入数字，可保留两位小数",
      // pattern: /^[0-9][0-9\.]*$/
      pattern: /^\d+(\.\d{1,2})?$/
    }
  ],
  // 环境类型
  Rule_envType: [
    {
      required: true,
      message: "请选择环境类型",
      pattern: /^[^\u4e00-\u9fa5]+$/
    }
  ],
  // command
  Rule_command: [
    {
      required: false,
      message: "请输入字母，数字，下划线",
      pattern: /^[a-zA-Z0-9_ ]+$/
    }
  ],
  // path路径
  Rule_path: [
    {
      required: false,
      message: "请输入非中文，必须以/开头",
      pattern: /^\/[^\u4e00-\u9fa5]+$/
    }
  ],
  // 验证路径
  Rule_routePath: [
    {
      required: true,
      message: "请输入非中文，必须以/开头",
      pattern: /^\/[^\u4e00-\u9fa5]*$/
    }
  ],
  // 服务名称
  Rule_routeProtocol: [
    {
      required: true,
      message: "请输入字母、下划线，不能以下划线开头",
      pattern: /^(?!_)[a-zA-Z_]+$/
    }
  ],
  // 端口
  Rule_resHostIp: [
    {
      required: false,
      message: "请输入正确的端口号",
      pattern: /^[1-9]$|(^[1-9][0-9]$)|(^[1-9][0-9][0-9]$)|(^[1-9][0-9][0-9][0-9]$)|(^[1-6][0-5][0-5][0-3][0-5]$)/
    }
  ]
};
