// 对字符串进行加密
function compileStr(code) {
  let c = "";
  c = String.fromCharCode(code.charCodeAt(0) + code.length * 10);
  for (let i = 1; i < code.length; i++) {
    c += String.fromCharCode(code.charCodeAt(i) + code.charCodeAt(i - 1));
  }
  return encodeURIComponent(c);
}
// 字符串进行解密
function uncompileStr(code) {
  code = decodeURIComponent(code);
  let c = "";
  c = String.fromCharCode(code.charCodeAt(0) - code.length * 10);
  for (let i = 1; i < code.length; i++) {
    c += String.fromCharCode(code.charCodeAt(i) - c.charCodeAt(i - 1));
  }
  return c;
}

export { compileStr, uncompileStr };
