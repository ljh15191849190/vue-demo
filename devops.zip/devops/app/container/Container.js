import React from "react";

import Header from "../components/home/Header";
import "../assets/css/app.css";
import history from "../routes/history";

class Container extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fresh: false,
      shouldFlush: false
    };
    this.projectName = sessionStorage.getItem("projectName");
    this.shouldFresh = this.shouldFresh.bind(this);
    // this.localStorageUpdated = this.localStorageUpdated.bind(this);
  }

  componentDidMount() {
    // let that = this;
    // history.listen( (location, that) => {
    //   let urlLinkArr = location.pathname.split("/");
    //   let projectName = "", linkName = "" ;
    //   for(let i = 1; i < urlLinkArr.length; i++){
    //     linkName = urlLinkArr[i-2]
    //     projectName = urlLinkArr[i]
    //   }
    //   if(linkName === "project"){
    //     that.shouldFresh();
    //   }
    // });
    // window.addEventListener("storage", function() {
    //   alert("storage changed");
    // });
  }

  // localStorageUpdated() {
  //   let projectName = sessionStorage.getItem("projectName");
  //   if (!projectName || !this.projectName) {
  //     return;
  //   }
  //   if (this.state.shouldFlush && projectName != this.projectName) {
  //     this.setState({
  //       shouldFlush: false
  //     });
  //   }
  // }

  shouldFresh() {
    this.setState({
      fresh: true
    });
  }

  render() {
    const { children } = this.props;
    return (
      <div>
        <Header shouldFresh={this.shouldFresh} />
        <div className="main-layout" ref="content">
          {children}
        </div>
      </div>
    );
  }
}

export default Container;
