export default {
  /**
   * 登陆相关
   */
  login: "/user/login",
  logout: "/user/logout",
  /**
   * 项目管理相关
   */
  getProjectsOvewview: "/webpjm/pjm/project/overview", // 概览
  getProjectsdeploytop: "/webpjm/pjm/project/deploytopfive", // 概览
  getProjectsbuildtop: "/webpjm/pjm/project/buildtopfive", // 概览
  getProjectsRate: "/webpjm/pjm/project/rate", // 概览
  getBuildstatement: "/webpjm/pjm/project/buildstatement", // 报表
  getdeploystatement: "/webpjm/pjm/project/deploystatement", // 报表
  getcodequality: "/webpjm/pjm/project/codequality", // 报表
  getcodeCommit: "/webpjm/code/analyzerCodeCommit", // 报表(提交)
  listProjects: "/webpjm/pjm/project/listbyuser", // 首页获取全部审核项目
  repoTypes: "/webpjm/code/repoType",
  getCRConponent: "/webpjm/pjm/app/list",
  getCRRepositoryList: "/webpjm/code/repository/list",
  repository: "/webpjm/code/repository",
  enterRepo: "/webpjm/code/repository/enterCode",
  fileContent: "/webpjm/code/repository/getContent",
  searchRep: "/webpjm/code/repository/search",
  branchList: "/webpjm/code/branch/list",
  branchDel: "/webpjm/code/branch", // 创建或删除branch
  branchUnprotect: "/webpjm/code/branch/unprotect",
  branchProtect: "/webpjm/code/branch/protect",
  getTagList: "/webpjm/code/tag/list", // 获取tag列表
  editTag: "/webpjm/code/tag", // 创建或删除tag
  downloadFile: "/webpjm/code/download", // 下载文件
  getSysInteRepertory: "/websystem/system/type/list",
  getPjmProjects: "/webpjm/pjm/project/listProjects",
  addProjects: "/webpjm/pjm/project/save",
  deleteProjects: "/webpjm/pjm/project/delete",
  updataProjects: "/webpjm/pjm/project/update",
  codenameProjects: "/webpjm/pjm/project/searchByCodeOrName",
  getPjmComponent: "/webpjm/pjm/app/list", // 组件查询
  addPjmComponent: "/webpjm/pjm/app/save", // 组件保存
  updatePjmComponent: "/webpjm/pjm/app/update", // 组件跟新
  deletePjmComponent: "/webpjm/pjm/app/delete", // 组件删除
  getModuleDetail: "/webpjm/pjm/module/details",
  /**
   * 构建部分
   */
  addressPjmComponent: "/webpjm/code/repository", // 组件详情下载
  getAllDefinationList: "/webbuildapplication/build/definition/all", // 查找构建定义列表
  cloneDefinition: "/webbuildapplication/build/definition/clone", // 克隆构建定义
  deleteDefinition: "/webbuildapplication/build/definition/delete", // 删除构建定义
  baseSave: "/webbuildapplication/build/definition/save", // 定义构建实例基本信息保存
  baseUpdate: "/webbuildapplication/build/definition/update", // 定义构建实例基本信息更新
  getDefinationById: "/webbuildapplication/build/definition/findById", // 根据ID查询定义实例
  updateDefination: "/webbuildapplication/build/definition/update", // 定义构建实例更新
  parmasSave: "/webbuildapplication/build/definition/param/save", // 参数配置保存
  parmasUpdate: "/webbuildapplication/build/definition/param/update", // 参数配置修改
  getParmasList: "/webbuildapplication/build/definition/param/findByDefId", // 参数列表查询
  paramsDelete: "/webbuildapplication/build/definition/param/delete", // 删除参数配置
  getAllTemplates: "/webbuildapplication/build/stage/template/findAll", // 配置模板查询
  getAllStage: "/webbuildapplication/build/pipeLine/stage/findByPlineId", // 配置stage查询
  stageBatchSave: "/webbuildapplication/build/pipeLine/stage/updatebatch", // 构建任务参数批量保存
  buildConsole: "/webbuildapplication/build/jenkins/consolehtml", // 构建执行console
  buildStatus: "/webbuildapplication/build/instance/findstatus", // 构建执行概要
  buildLogs: "/webbuildapplication/build/instance/findlogs", // 构建执行概要
  updateJobStatus: "/webbuildapplication/build/definition/status/update", // 更新job状态

  buildFindjar: "/webbuildapplication/build/instance/findjar", // 下载
  buildFlag: "/webbuildapplication/build/instance/save", // 点击构建执行
  // buildHistory: "/webbuildapplication/build/jenkins/instance", // 构建历史
  buildHistory: "/webbuildapplication/build/instance/all", // 构建历史
  getSystemList: "/websystem/system/3rd/systemType", // 查询系统集成
  addSystem: "/websystem/system/3rd", // 新增系统集成
  updateSystem: "/websystem/system/3rd", // 修改系统集成
  deleteSystem: "/websystem/system/3rd", // 删除系统集成
  searchByNameSystem: "/websystem/system/3rd/systemType", // 搜素补全系统集成
  categorySystem: "/websystem/system/3rd/categroys/systemType", // 类别下拉单选系统集成
  testSystem: "/websystem/system/3rd/test", // 测试系统集成
  buildTaskSave: "/webbuildapplication/build/pipeLine/stage/save", // 构建任务参数保存
  buildTaskUpdate: "/webbuildapplication/build/pipeLine/stage/update", // 构建任务参数更新
  getStageDetails: "/webbuildapplication/build/stage/attr/findByStageId", // 查询构建任务详情
  deleteStage: "/webbuildapplication/build/pipeLine/stage/delete", // 删除stage
  buildStagenameplan: "/webbuildapplication/build/stage/attr/findBypLineId", // 构建计划概要
  getcomponentMeasures: "/webbuildapplication/build/componentMeasures", // 构建质量展示
  getcomponentTree: "/webbuildapplication/build/componentTree", // 构建质量树
  getcomponentSource: "/webbuildapplication/build/source", // 构建质量树
  getcomponentRule: "/webbuildapplication/build/rule", // 构建质量树查看bug
  getattrParams: "/webbuildapplication/build/stage/attr/Params/findBypLineId", // 构建参数配置
  Mediumdownload: "/webbuildapplication/build/artifact/update/find/all", // 查找介质

  // 上传介质
  uploadMedium: "/webbuildapplication/build/nexus/upload", // 上传介质
  findMedium: "/webbuildapplication/build/artifact/all", // 查找介质
  getSearchMedium: "/webbuildapplication/build/nexus/list/asset", // 搜索介质
  // deleteStage: "/webbuildapplication/build/pipeLine/stage/delete", // 删除stage
  findPipeLineTmp: "/webbuildapplication/build/pipeline/template", // 查询构建计划模板
  searchNameSystemType: "/websystem/system/3rd/systemType/", // 通过系统type查找nexus
  repList: "/webbuildapplication/build/nexus/list/rep", // 通过name查找rep

  // systemManage
  getSystemMenuAll: "/websystem/system/menu/allMenuListByUserId", // ?userId=10
  getPjmMenuList: "/webpjm/pjm/menu/list",

  // personManage
  getSystemUser: "/websystem/system/user",
  addSystemUser: "/websystem/system/user",
  updateSystemUser: "/websystem/system/user",
  deleteSystemUser: "/websystem/system/user/",
  searchSystemUserAll: "/websystem/system/user/all",
  userFind: "/websystem/system/user/userId/",
  userStatusChange: "/websystem/system/user",

  // roleManage
  getSystemRole: "/websystem/system/role",
  addSystemRole: "/websystem/system/role",
  updateSystemRole: "/websystem/system/role",
  deleteSystemRole: "/websystem/system/role",
  searchSystemRole: "/websystem/system/role/all",
  sysroleFind: "/websystem/system/role/roleId/",
  roleMenus: "/websystem/system/role/menus/", // get
  roleAuthorize: "/websystem/system/role/authorize", // POST

  // menuManage
  getSystemMenu: "/websystem/system/menu",
  addSystemMenu: "/websystem/system/menu",
  updateSystemMenu: "/websystem/system/menu",
  deleteSystemMenu: "/websystem/system/menu",
  searchSystemMenu: "/websystem/system/menu/all", // 所有
  searchSystemMenuManage: "/websystem/system/menu/manager/all", // 所有管理

  introduceMenu: "/websystem/system/menu/menuId/", // headInformatiion
  childMenus: "/websystem/system/menu/childMenus", // {menuId}
  childMenusMenuId: "/websystem/system/menu/childMenus/menuId/", // {menuId}
  menuFind: "/websystem/system/menu/menuId/",

  // organization
  getSystemOrgId: "/websystem/system/org/childOrgs/orgId/", // ALL
  getSystemOrgChild: "/websystem/system/org/childOrgs", // page
  getSystemOrg: "/websystem/system/org/orgId/", // orgMessage
  addSystemOrg: "/websystem/system/org",
  updateSystemOrg: "/websystem/system/org",
  deleteSystemOrg: "/websystem/system/org",
  searchSystemOrg: "/websystem/system/org",

  introduceOrg: "/websystem/system/org/orgId/", // headInformatiion
  childOrgs: "/websystem/system/org/childOrgs", // {orgId}
  childOrgsOrgId: "/websystem/system/org/childOrgs/orgId/", // {orgId}
  orgFind: "/websystem/system/org/orgId/",

  // oprationLog
  getSystemLog: "/websystem/system/log",
  getSystemLogDetail: "/websystem/system/log/logId/",

  // 环境
  getEnvironment: "/webdeployapplication/deploy/env/list",
  addEnvironment: "/webdeployapplication/deploy/env/save",
  deleteEnvironment: "/webdeployapplication/deploy/env/delete",
  updateEnvironment: "/webdeployapplication/deploy/env/update",
  getEnvironmentType: "/webdeployapplication/deploy/env/envtypes",
  // 角色
  getRole: "/webpjm/project/role",
  addRole: "/webpjm/project/role",
  deleteRole: "/webpjm/project/role",
  updateRole: "/webpjm/project/role",
  getRoleAllMenu: "/websystem/system/menu/project/all",
  getRoleSelectMenu: "/webpjm/project/role/menus",
  saveRoleSelectMenu: "/webpjm/project/role/authorize",
  // 团队
  getTeam: "/webpjm/project/team",
  addTeam: "/webpjm/project/team",
  deleteTeam: "/webpjm/project/team",
  authorizeTeam: "/webpjm/project/team",
  userallTeam: "/websystem/system/user/all",

  // 资源
  getResource: "/webdeployapplication/deploy/res/list",
  addResource: "/webdeployapplication/deploy/res/save",
  updateResource: "/webdeployapplication/deploy/res/save",
  deleteResource: "/webdeployapplication/deploy/res/delete",
  getEnvironmentName: "/webdeployapplication/deploy/env/envnameid",
  testResource: "/webdeployapplication/deploy/res/test",

  addCluster: "/webcaasapplication/caas/cluster/save",
  testCluster: "/webcaasapplication/caas/cluster/validateClusterInfo",
  findClusterInfo: "/webcaasapplication/caas/cluster/findClusterInfoByClusterId",
  addCaasNode: "/webcaasapplication/caas/node/save",
  getCaasNodeList: "/webcaasapplication/caas/node/findByCustomized",
  deleteCaasNode: "/webcaasapplication/caas/node/delete",
  updateCaasNode: "/webcaasapplication/caas/node/update",
  testCaasNode: "/webcaasapplication/caas/node/validateNodeInfo",
  findPodInfo: "/webcaasapplication/caas/node/findPodInfo",

  addCaasNamespace: "/webcaasapplication/caas/namespace/save",
  deleteCaasNamespace: "/webcaasapplication/caas/namespace/delete",
  searchCaasNamespace: "/webcaasapplication/caas/namespace/search",
  updateCaasNamespace: "/webcaasapplication/caas/namespace/update",
  getCaasNamespaceList: "/webcaasapplication/caas/namespace/findNamespaceByClusterId",
  getSpacePodListByClusterId: "/webcaasapplication/caas/namespace/findNamespacePodByClusterId", // 根据集群id查询命名空间pod资源限制值
  getCaasClusterListsByProjectId: "/webcaasapplication/caas/cluster/findClusterByProjectId", // 根据projectId查找集群信息
  // 应用市场
  getmarketAppList: "/webcaasapplication/caas/market/apps",
  getmarketAppDetail: "/webcaasapplication/caas/market/apps",
  findMarketdeploy: "/webdeployapplication/deploy/definition/market/deploy", // 市场部署
  // 镜像仓库
  houseCollect: "/webcaasapplication/caas/house/collect",
  gethouseCollectList: "/webcaasapplication/caas/house/collects",
  gethouseImageInfoList: "/webcaasapplication/caas/house/imageInfo",
  gethouseImagesList: "/webcaasapplication/caas/house/images", // 镜像列表
  gethouseImagesPublicList: "/webcaasapplication/caas/house/images", // 镜像列表
  gethouseScan: "/webcaasapplication/caas/house/scan",
  gethouseSync: "/webcaasapplication/caas/house/sync",
  gethouseTags: "/webcaasapplication/caas/house/tags",
  gethouseUpdate: "/webcaasapplication/caas/house/update",
  gethouseScanTag: "/webcaasapplication/caas/house/scantag", // 扫描1
  gethouseSyncTag: "/webcaasapplication/caas/house/synctag", // 扫描1
  gethouseScanUpdateTag: "/webcaasapplication/caas/house/updatetag", // 扫描2
  // 部署相关
  deploymentPageList: "/webdeployapplication/deploy/definition/all", // 分页查找部署实例定义
  deploymentSave: "/webdeployapplication/deploy/definition/save", // 部署定义保存
  deploymentUpdate: "/webdeployapplication/deploy/definition/update", // 部署定义更新
  deploymentDelete: "/webdeployapplication/deploy/definition/delete", // 新增部署定义删除
  getRuningEnvList: "/webdeployapplication/deploy/comp/all", // 分页查找部署运行环境模板
  uploadSoft: "/webbuildapplication/build/deploy/nexus/upload", // 上传软件包
  getHostList: "/webdeployapplication/deploy/res/list", // 获取主机列表
  getShell: "/webdeployapplication/deploy/shelltmp/find", // 获取shell脚本
  findDefination: "/webdeployapplication/deploy/definition/findone", // 查询部署定义
  cloneDefination: "/webdeployapplication/deploy/definition/clone", // 克隆
  updateDeployStatus: "/webdeployapplication/deploy/definition/status/update", // 部署实例更新
  getDeployLog: "/webdeployapplication/deploy/jenkins/console", // 查询部署日志
  findIpListById: "/webdeployapplication/deploy/definition/ips/find", // 根据id查询主机列表
  getHistoryList: "/webdeployapplication/deploy/instance/all", // 查询部署历史
  getHistoryListDetails: "/webdeployapplication/deploy/instance/findone", // 查询部署历史详情
  executeDeployment: "/webdeployapplication/deploy/definition/execute", // 部署实例执行
  findDeployStatus: "/webdeployapplication/deploy/definition/status/find", // 部署实例状态查询
  findDeployYmlTmp: "/webdeployapplication/deploy/ymltmp/find", // 获取yml文件
  kbrsLogFind: "/webdeployapplication/deploy/kbrs/log/find", // 容器部署日志
  getPodList: "/webdeployapplication/deploy/kbrs/pod/instance", // pod组数据
  findPodLog: "/webdeployapplication/deploy/kbrs/pod/log", // pod组日志
  imagestags: "/webcaasapplication/caas/house/imagestags", // 新增/编辑部署任务选择的镜像仓库

  // 团队成员
  getUserlistById: "/webpjm/project/team/projectId", // 根据项目Id查询用户信息列表

  // maitanance
  findByCustomized: "/webmonitorapplication/monitor/service/findByCustomized", // 根据projectId查询容器信息
  execute: "/webmonitorapplication/monitor/instance/execute", // 操作服务
  findInstancesByServiceId: "/webmonitorapplication/monitor/instance/findInstancesByServiceId", // 根据deployServiceId查询instance列表
  findInstanceByInstanceId: "/webmonitorapplication/monitor/instance/findInstanceByInstanceId", // 根据instanceId查询instance
  visualCheckLog: "/webmonitorapplication/monitor/instance/checkLog", // 查看日志

  visualMonitor: "/webmonitorapplication/monitor/monitor/findByCustomized", // 8小时监控
  visualHighAvailableInfo: "/webmonitorapplication/monitor/instance/highAvailableInfo", // 高可用
  visualUpdateInstanceDisable: "/webmonitorapplication/monitor/instance/updateInstanceDisable", // 高可用是否开启，0关，1开
  visualEventFindByCustomized: "/webmonitorapplication/monitor/event/findByCustomized", // 分页查询事件

  caasPodsInfo: "/webmonitorapplication/monitor/caas/pods/", // 根据podName查询容器pod的详细信息
  caasPodsEvents: "/webmonitorapplication/monitor/caas/pods/", // 根据podName查询容器pod的详细信息
  caasPodsLogs: "/webmonitorapplication/monitor/caas/pods/", // 根据podName查询容器pod的日志信息
  caasPodsMetrics: "/webmonitorapplication/monitor/caas/pods/", // 根据podName查询容器pod的监控指标信息

  caasServicesPodsCount: "/webmonitorapplication/monitor/caas/services/pods/", // 根据serviceName查询该service下所有pod的数量  GET
  caasServicesPodsInfo: "/webmonitorapplication/monitor/caas/services/pods/", // 根据serviceName查询该service下所有pod的监控指标信息
  caasServicesDelete: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id删除容器服务
  caasServicesInfo: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id查询容器服务的详细信息
  caasServicesAutoScaling: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id自动伸缩容器服务
  caasServicesGrayRelease: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id灰度升级容器服务
  caasServicesHorizontalScaling: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id手动水平扩展容器服务

  caasServicesRestart: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id重启容器服务
  caasServicesStart: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id启动容器服务
  caasServicesStop: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id停止容器服务
  caasServicesEvents: "/webmonitorapplication/monitor/caas/services/", // 根据serviceName查询容器服务的事件信息
  caasServicesLogs: "/webmonitorapplication/monitor/caas/services/", // 根据serviceName查询容器服务的日志信息
  caasServicesMetrics: "/webmonitorapplication/monitor/caas/services/pods/", // 根据serviceName查询该service下所有pod的监控指标信息
  caasServicesConfig: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id获取其部署配置 高可用的初始状态
  caasServicesLivenessprobe: "/webmonitorapplication/monitor/caas/services/", // 开启或者关闭高可用
  caasServicesAction: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id动作状态
  caasServicesConfigSet: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id更改容器服务配置
  caasServicesTags: "/webmonitorapplication/monitor/caas/services/tags", // 根据容器服务Id获取其镜像tag信息
  // caasServicesGrayRelease: "/webmonitorapplication/monitor/caas/services/", // 根据容器服务Id手动水平扩展容器服务
  caasServicesDeploymentEnableHpa: "/webmonitorapplication/monitor/caas/services/" // 根据容器服务Id手动水平扩展容器服务
  // caasServicesAutoScaling: "/webmonitorapplication/monitor/caas/services/" // 根据容器服务Id自动伸缩容器服务
};
