import "whatwg-fetch";
import { message } from "antd";
import history from "../routes/history";
import URL from "./urlConfig";
import * as StatusCode from "../constants/StatusCode";

const fetchApi = function(postData, url, resolve, obj) {
  const options = {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(postData)
  };
  fetch(url, options)
    .then(res => {
      return res.json();
    })
    .then(data => {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login", { key: "logout" });
        sessionStorage.clear();
      }
      //   else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
      //     message.info("数据不存在");
      //   }
      else {
        resolve({ res: data, param: obj });
      }
    });
};
const fetchApiPUT = function(postData, url, resolve, obj) {
  const options = {
    method: "PUT",
    credentials: "include",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(postData)
  };
  fetch(url, options)
    .then(res => {
      return res.json();
    })
    .then(data => {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login", { key: "logout" });
        sessionStorage.clear();
      }
      //    else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
      //     message.info("数据不存在");
      //   }
      else {
        resolve({ res: data, param: obj });
      }
    });
};
const fetchApiDELETE = function(postData, url, resolve, obj) {
  const options = {
    method: "DELETE",
    credentials: "include",
    body: JSON.stringify(postData)
  };
  fetch(url, options)
    .then(res => {
      return res.json();
    })
    .then(data => {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login", { key: "logout" });
        sessionStorage.clear();
      } else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.info("数据不存在");
      } else {
        resolve({ res: data, param: obj });
      }
    });
};
const fetchApiGET = function(url, resolve, obj) {
  const options = {
    method: "GET",
    credentials: "include"
  };

  if (url.indexOf("?") > -1) {
    url = `${url}&time=${new Date().getTime()}`;
  } else {
    url = `${url}?time=${new Date().getTime()}`;
  }

  fetch(url, options)
    .then(res => {
      return res.json();
    })
    .then(data => {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login", { key: "logout" });
        sessionStorage.clear();
      }
      //   else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
      //     message.info("数据不存在");
      //   }
      else {
        resolve({ res: data, param: obj });
      }
    });
};
const fetchApiFORM = function(postData, url, resolve, obj) {
  const options = {
    method: "POST",
    credentials: "include",
    body: postData,
    headers: {
      processData: false, //  用于对data参数进行序列化处理，这里必须false；如果是true，就会将FormData转换为String类型
      contentType: false //   "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    }
  };
  fetch(url, options)
    .then(res => {
      return res.json();
    })
    .then(data => {
      if (data.rtn_code == StatusCode.XAHC_NOT_LOGIN) {
        history.push("/devops/login", { key: "logout" });
        sessionStorage.clear();
      } else if (data.rtn_code == StatusCode.XAHC_DATA_NOTEXIST) {
        message.info("fetchApiForm-->error");
      } else {
        resolve({ res: data, param: obj });
      }
    });
};

class ServiceApi {
  static login(payload) {
    return new Promise(resolve => {
      const url = URL.login;
      const postdata = {
        userName: payload.name,
        password: payload.pass
      };
      fetchApi(postdata, url, resolve);
    });
  }

  static logout(payload) {
    return new Promise(resolve => {
      const url = URL.logout;
      const postdata = {};
      fetchApi(postdata, url, resolve);
    });
  }

  static getRepoType() {
    return new Promise(resolve => {
      const url = URL.repoTypes;
      fetchApiGET(url, resolve);
    });
  }

  //  code relaction
  static getConponents(payload) {
    return new Promise(resolve => {
      const url = URL.getCRConponent;
      const postdata = {
        projectId: payload.projectId,
        page: 1,
        size: 50
      };
      fetchApi(postdata, url, resolve);
    });
  }

  static getCRConponentsList(payload) {
    return new Promise(resolve => {
      const url = URL.getCRRepositoryList;
      const postdata = {
        projectId: payload.projectId,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc"
      };
      fetchApi(postdata, url, resolve);
    });
  }

  static saveCRConponent(payload) {
    return new Promise(resolve => {
      const url = URL.repository;
      const postdata = {};
      fetchApi(payload, url, resolve);
    });
  }

  static updateCRRelation(payload) {
    return new Promise(resolve => {
      const url = URL.repository;
      const postdata = {};
      fetchApiPUT(payload, url, resolve);
    });
  }

  static delCRRelation(payload) {
    return new Promise(resolve => {
      const url = `${URL.repository}?repoId=${payload}`;
      const postdata = {};
      fetchApiDELETE(postdata, url, resolve);
    });
  }

  static enterCRRepo(payload) {
    return new Promise(resolve => {
      const url = URL.enterRepo;
      fetchApi(payload, url, resolve);
    });
  }

  static getCRFileContent(payload) {
    return new Promise(resolve => {
      const url = URL.fileContent;
      const postdata = {};
      fetchApi(payload, url, resolve);
    });
  }

  static searchRep(payload) {
    return new Promise(resolve => {
      const url = URL.searchRep;
      const postdata = {
        projectId: payload.projectId,
        searchValue: payload.searchValue,
        page: 1,
        size: 10,
        sortid: "id",
        sortvalue: "desc"
      };
      fetchApi(postdata, url, resolve);
    });
  }

  static getBranchList(payload) {
    return new Promise(resolve => {
      const url = URL.branchList;
      fetchApi(payload, url, resolve);
    });
  }

  static createBranch(payload) {
    return new Promise(resolve => {
      const url = URL.branchDel;
      fetchApi(payload, url, resolve);
    });
  }

  static getBranchDel(payload) {
    return new Promise(resolve => {
      const url = URL.branchDel;
      fetchApiDELETE(payload, url, resolve);
    });
  }

  static getBranchUnprotect(payload) {
    return new Promise(resolve => {
      const url = URL.branchUnprotect;
      fetchApiPUT(payload, url, resolve);
    });
  }

  static getBranchProtect(payload) {
    return new Promise(resolve => {
      const url = URL.branchProtect;
      fetchApiPUT(payload, url, resolve);
    });
  }

  // code relaction end
  static listAllProjects(payload) {
    return new Promise(resolve => {
      const url = URL.listProjects;
      const postdata = {
        searchValue: payload.data.searchValue,
        page: payload.data.page,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: payload.data.conditions
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 概览
  static getProjectsOvewviewRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getProjectsOvewview;
      const postdata = {
        projectId: payload.data.projectId,
        date: payload.data.date,
        sDate: payload.data.sDate,
        dataJson: payload.data.dataJson
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 概览
  static getProjectsdeploytopRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getProjectsdeploytop;
      const postdata = {
        projectId: payload.data.projectId,
        date: payload.data.date,
        sDate: payload.data.sDate,
        dataJson: payload.data.dataJson
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 概览
  static getProjectsbuildtopRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getProjectsbuildtop;
      const postdata = {
        projectId: payload.data.projectId,
        date: payload.data.date,
        sDate: payload.data.sDate,
        dataJson: payload.data.dataJson
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 概览
  static getProjectsRateRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getProjectsRate;
      const postdata = {
        projectId: payload.data.projectId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 报表
  static getBuildstatementRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getBuildstatement}?projectId=${payload.data.projectId}&code=${
        payload.data.code
      }`;

      fetchApiGET(url, resolve);
    });
  }

  // 报表
  static getdeploystatementRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getdeploystatement}?projectId=${payload.data.projectId}&code=${
        payload.data.code
      }`;
      fetchApiGET(url, resolve);
    });
  }

  // 报表
  static getcodequalityRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getcodequality;
      const postdata = {
        projectId: payload.data.projectId,
        sign: "",
        page: "1",
        size: "100"
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 报表（提交代码）
  static getcodeCommitRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getcodeCommit}?projectId=${payload.data.projectId}&code=${
        payload.data.code
      }`;
      fetchApiGET(url, resolve);
    });
  }

  static getSysInteRepertory(payload) {
    return new Promise(resolve => {
      const url = `${URL.getSysInteRepertory}?page=${payload.currentPage}&size=10`;
      const reqParam = {
        page: payload.currentPage,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        conditions: []
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  //   项目查询
  static getAllProjects(payload) {
    return new Promise(resolve => {
      const url = URL.getPjmProjects;
      const reqParam = {
        page: payload.data.page,
        size: 10,
        sortid: "id",
        sortvalue: "desc"
      };
      if (payload.condition) {
        reqParam["conditions"] = [payload.data.conditions];
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  //   项目新增
  static addProjectsRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addProjects;
      const postdata = {
        projectCode: payload.projectCode,
        projectStatus: payload.projectStatus,
        projectName: payload.projectName,
        projectDesc: payload.projectDesc,
        projectOwner: payload.projectOwner,
        projectPermission: payload.projectPermission
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //   项目删除
  static deleteEquip(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteProjects}?projectId=${payload.deviceId}`;
      const reqParam = {
        conditions: []
      };
      fetchApiDELETE(reqParam, url, resolve);
    });
  }

  //   项目修改
  static updataProjectsRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updataProjects;
      const postdata = {
        projectId: payload.projectId,
        projectCode: payload.projectCode,
        projectStatus: payload.projectStatus,
        projectName: payload.projectName,
        projectDesc: payload.projectDesc,
        projectOwner: payload.projectOwner,
        approvingDesc: payload.approvingDesc,
        projectPermission: payload.projectPermission
      };
      fetchApiPUT(postdata, url, resolve);
    });
  }

  // 项目搜索不全查询
  static codeornameProjectsRequest(payload) {
    return new Promise(resolve => {
      const url = URL.codenameProjects;
      const reqParam = {
        page: payload.data.page,
        size: 10,
        sortid: "id",
        sortvalue: "desc",
        searchValue: payload.data.searchValue,
        projectStatus: payload.data.projectStatus,
        projectOwner: payload.data.projectOwner
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  // 项目经理
  static searchSystemUserAllRequest(payload) {
    return new Promise(resolve => {
      const url = URL.searchSystemUserAll;
      fetchApiGET(url, resolve);
    });
  }

  // 组件
  static getComponentList(payload) {
    return new Promise(resolve => {
      const url = URL.getPjmComponent;
      const reqParam = {};
      if (payload.data.conditions) {
        reqParam["projectId"] = payload.data.projectId;
        reqParam["page"] = payload.data.page;
        reqParam["size"] = payload.data.size;
        reqParam["sign"] = payload.data.sign;
        reqParam["sortid"] = payload.data.sortid;
        reqParam["sortvalue"] = payload.data.sortvalue;
        reqParam["applicationCode"] = payload.data.applicationCode;
        reqParam["applicationName"] = payload.data.applicationName;
        reqParam["conditions"] = payload.data.conditions;
      } else {
        reqParam["projectId"] = payload.data.projectId;
        reqParam["page"] = payload.data.page;
        reqParam["size"] = payload.data.size;
        reqParam["sign"] = payload.data.sign;
        reqParam["sortid"] = payload.data.sortid;
        reqParam["sortvalue"] = payload.data.sortvalue;
        reqParam["applicationCode"] = payload.data.applicationCode;
        reqParam["applicationName"] = payload.data.applicationName;
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  //   组件保存
  static addComponentRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addPjmComponent;
      const postdata = {
        projectId: payload.projectId,
        versionCode: payload.versionCode,
        applicationCode: payload.applicationCode,
        applicationName: payload.applicationName,
        applicationDesc: payload.applicationDesc
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //   组件修改
  static updateComponentRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updatePjmComponent;
      const postdata = {
        projectId: payload.projectId,
        versionCode: payload.versionCode,
        applicationId: payload.applicationId,
        applicationCode: payload.applicationCode,
        applicationName: payload.applicationName,
        applicationDesc: payload.applicationDesc
      };
      fetchApiPUT(postdata, url, resolve);
    });
  }

  // 组件删除
  static deleteComponentRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deletePjmComponent}?applicationId=${payload.deviceId}`;
      const reqParam = {
        conditions: []
      };
      fetchApiDELETE(reqParam, url, resolve);
    });
  }

  //   组件详情下载
  static addressComponentRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.addressPjmComponent}?projectId=${payload.data.projectId}&applicationId=${
        payload.data.applicationId
      }`;
      fetchApiGET(url, resolve);
    });
  }

  //   组件详情
  static getModuleDetailRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getModuleDetail;
      const postdata = {
        projectId: payload.data.projectId,
        applicationId: payload.data.applicationId,
        applicationName: payload.data.applicationName
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //   系统集成保存
  static addSystemRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addSystem;
      const postdata = {
        category: payload.category,
        alias: payload.alias,
        username: payload.username,
        password: payload.password,
        address: payload.address,
        systemDesc: payload.systemDesc,
        extend: payload.extend,
        systemType: payload.systemType
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 系统集成删除
  static deleteSystemRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteSystem}/${payload.deviceId}`;
      const reqParam = {};
      fetchApiDELETE(reqParam, url, resolve);
    });
  }

  //  集成修改
  static updateSystemRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateSystem;
      const postdata = {
        category: payload.category,
        alias: payload.alias,
        username: payload.username,
        password: payload.password,
        address: payload.address,
        systemDesc: payload.systemDesc,
        systemId: payload.systemId,
        extend: payload.extend,
        id: payload.id,
        systemType: payload.systemType
      };
      fetchApiPUT(postdata, url, resolve);
    });
  }

  // 系统集成查询
  static getAllSystemList(payload) {
    return new Promise(resolve => {
      const url = `${URL.getSystemList}/${payload.systemType}`;
      fetchApiGET(url, resolve);
    });
  }

  // 集成搜索补全
  static searchByNameSystemRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.searchByNameSystem}/${payload.systemType}/category/${
        payload.category
      }?alias=${payload.alias}`;
      fetchApiGET(url, resolve);
    });
  }

  // 集成搜索类别下拉单选
  static categorySystemRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.categorySystem}/${payload.deviceId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  系统集成测试
  static testSystemRequest(payload) {
    return new Promise(resolve => {
      const url = URL.testSystem;
      const postdata = {
        category: payload.category,
        alias: payload.alias,
        username: payload.username,
        password: payload.password,
        address: payload.address,
        extend: payload.extend,
        systemDesc: payload.systemDesc,
        systemType: payload.systemType
      };
      fetchApi(postdata, url, resolve);
    });
  }

  static getAllDefinationList(payload) {
    return new Promise(resolve => {
      const url = `${URL.getAllDefinationList}?page=${payload.data.page}&size=${payload.data.size}`;
      const reqParam = {};
      if (payload.data.conditions) {
        reqParam["page"] = payload.data.page;
        reqParam["size"] = payload.data.size;
        reqParam["sortid"] = payload.data.sortid;
        reqParam["sortvalue"] = payload.data.sortvalue;
        reqParam["conditions"] = payload.data.conditions.filter(v => v.value);
      } else {
        reqParam["page"] = payload.data.page;
        reqParam["size"] = payload.data.size;
        reqParam["sortid"] = payload.data.sortid;
        reqParam["sortvalue"] = payload.data.sortvalue;
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  static cloneDefination(payload) {
    return new Promise(resolve => {
      const url = `${URL.cloneDefinition}?defName=${payload.data.defName}&id=${
        payload.data.id
      }&applicationId=${payload.data.applicationId}&applicationName=${
        payload.data.applicationName
      }&repository=${payload.data.repository}&definitionDesc=${payload.data.definitionDesc}`;
      const postdata = payload.data.jsonObject;
      fetchApi(postdata, url, resolve);
    });
  }

  static deleteDefination(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteDefinition}?id=${payload.data.id}`;
      const reqParam = {};
      fetchApiDELETE(reqParam, url, resolve);
    });
  }

  static baseDefination(payload) {
    return new Promise(resolve => {
      const url = URL.baseSave;
      const reqParam = payload.data;
      reqParam["applicationName"] = payload.data.applicationName;
      reqParam["definitionDesc"] = payload.data.definitionDesc;
      reqParam["definitionName"] = payload.data.definitionName;
      reqParam["timeOutScope"] = payload.data.timeOutScope;
      reqParam["maxFailBackBuild"] = payload.data.maxFailBackBuild
        ? payload.data.maxFailBackBuild
        : 5;
      reqParam["maxFailBackBuild"] = payload.data.maxFailBackBuild
        ? payload.data.maxFailBackBuild
        : 10;
      reqParam["conditions"] = payload.data.condition;
      reqParam["pLineTpId"] = payload.data.pLineTpId;
      fetchApi(reqParam, url, resolve);
    });
  }

  static updateDefination(payload) {
    return new Promise(resolve => {
      const url = URL.updateDefination;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static saveParams(payload) {
    return new Promise(resolve => {
      const url = URL.parmasSave;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static updateParams(payload) {
    return new Promise(resolve => {
      const url = URL.parmasUpdate;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static getParmasList(payload) {
    return new Promise(resolve => {
      const url = `${URL.getParmasList}?defId=${payload.data.defId}`;
      const reqParam = {};
      fetchApi(reqParam, url, resolve);
    });
  }

  static deleteParmas(payload) {
    return new Promise(resolve => {
      const url = `${URL.paramsDelete}?id=${payload.data.id}`;
      const reqParam = {};
      fetchApi(reqParam, url, resolve);
    });
  }

  static getAllTemplates(payload) {
    return new Promise(resolve => {
      const url = `${URL.getAllTemplates}?sortid=id&sortvalue=asc`;
      const reqParam = payload.data;
      delete reqParam.editType;
      fetchApi(reqParam, url, resolve);
    });
  }

  static getPipeTemplates(payload) {
    return new Promise(resolve => {
      const url = URL.findPipeLineTmp;
      fetchApiGET(url, resolve);
    });
  }

  static getCurrentStage(payload) {
    return new Promise(resolve => {
      const url = `${URL.getAllStage}?pLineId=${payload.data.pLineId}`;
      fetchApiGET(url, resolve);
    });
  }

  // 构建计划模板
  static getStageNameplan(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildStagenameplan}?pLineId=${payload.data.pLineId}`;
      fetchApiGET(url, resolve);
    });
  }

  static buildTaskSave(payload) {
    return new Promise(resolve => {
      const url = URL.buildTaskSave;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  //  构建任务批量保存
  static buildTaskBatchSave(payload) {
    return new Promise(resolve => {
      const url = `${URL.stageBatchSave}?pLineId=${payload.data.pLineId}`;
      const reqParam = { list: payload.data.list };
      fetchApi(reqParam, url, resolve);
    });
  }

  static buildTaskUpdate(payload) {
    return new Promise(resolve => {
      const url = URL.buildTaskUpdate;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static getDefinationById(payload) {
    return new Promise(resolve => {
      const url = `${URL.getDefinationById}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  // console
  static getPerformeConsole(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildConsole}?jobName=${payload.data.jobName}&buildNum=${
        payload.data.buildNum
      }&projectId=${payload.data.projectId}`;
      fetchApiGET(url, resolve);
    });
  }

  // 下载
  static getPerformeFindjar(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildFindjar}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  // 概要
  static getPerformeStatus(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildStatus}?jobName=${payload.data.jobName}&id=${
        payload.data.id
      }&buildnum=${payload.data.buildnum}&projectId=${payload.data.projectId}`;
      const reqParam = {};
      fetchApi(reqParam, url, resolve);
    });
  }

  // 概要日志
  static getPerformeLogs(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildLogs}?jobName=${payload.data.jobName}&nodeId=${
        payload.data.nodeId
      }&buildnum=${payload.data.buildnum}&projectId=${payload.data.projectId}`;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  // 质量展示
  static buildcomponentMeasures(payload) {
    return new Promise(resolve => {
      const url = `${URL.getcomponentMeasures}?projectId=${payload.data.projectId}&repoUrl=${
        payload.data.repoUrl
      }`;
      fetchApiGET(url, resolve);
    });
  }

  // 质量树
  static buildcomponentTree(payload) {
    return new Promise(resolve => {
      const url = `${URL.getcomponentTree}?component=${payload.data.component}&page=1&size=20`;
      fetchApiGET(url, resolve);
    });
  }

  // 质量树daima
  static buildcomponentSource(payload) {
    return new Promise(resolve => {
      const url = `${URL.getcomponentSource}?key=${payload.data.key}&from=1&to=20`;
      fetchApiGET(url, resolve);
    });
  }

  // 质量树查看bug
  static buildcomponentRule(payload) {
    return new Promise(resolve => {
      const url = `${URL.getcomponentRule}?key=${payload.data.key}`;
      fetchApiGET(url, resolve);
    });
  }

  // 参数配置
  static buildattrParams(payload) {
    return new Promise(resolve => {
      const url = `${URL.getattrParams}?pLineId=${payload.data.pLineId}`;
      fetchApiGET(url, resolve);
    });
  }

  // 点击执行
  static getPerformeFlag(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildFlag}?jobName=${payload.data.jobName}`;
      const reqParam = payload.data.jsonObject;
      fetchApi(reqParam, url, resolve);
    });
  }

  //  基本信息更新
  static baseUpdate(payload) {
    return new Promise(resolve => {
      const url = URL.baseUpdate;
      const reqParam = payload;
      fetchApi(reqParam, url, resolve);
    });
  }

  static buildHistory(payload) {
    return new Promise(resolve => {
      const url = `${URL.buildHistory}?page=${payload.page}&size=10&sortid=id&sortvalue=desc`;
      const reqParam = {
        conditions: payload.conditions
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  // 介质上传
  static uploadMediumWH(payload) {
    return new Promise(resolve => {
      const url = `${URL.uploadMedium}?nexusId=${payload.nexusId}&nexusName=${
        payload.nexusName
      }&alliasName=${payload.alliasName}&pojectId=${payload.projectId}&componentId=${
        payload.componentId
      }&componentName=${payload.componentName}&repName=${payload.repName}&groupId=${
        payload.groupId
      }&artifactId=${payload.artifactId}&version=${payload.version}&classfier=${
        payload.classfier
      }&extension=${payload.extension}`;
      fetchApiFORM(payload.file, url, resolve);
    });
  }
  //  介质下载
  static getMediumdownload(payload) {
    return new Promise(resolve => {
      const url = `${URL.Mediumdownload}?page=${payload.data.page}&id=${payload.data.id}&defName=${
        payload.data.defName
      }&buildNum=${payload.data.buildNum}&size=10&sortid=id&sortvalue=desc`;
      const reqParam = {
        conditions: payload.data.conditions
      };

      fetchApi(reqParam, url, resolve);
    });
  }
  //  介质查找
  static findMediumWH(payload) {
    return new Promise(resolve => {
      const url = `${URL.findMedium}?page=${payload.page}&size=10&sortid=id&sortvalue=desc`;
      const reqParam = {
        conditions: payload.conditions
      };

      fetchApi(reqParam, url, resolve);
    });
  }

  //  介质搜索
  static getMediumMethod(payload) {
    return new Promise(resolve => {
      const url = `${URL.getSearchMedium}?repName=${payload.repName}&groupId=${
        payload.groupId
      }&artifactId=${payload.artifactId}&version=${
        payload.version
      }&extension=jar&continuationToken=${payload.continuationToken}`;
      fetchApiGET(url, resolve);
    });
  }

  //  查找nexus
  static searchNameSystemType(payload) {
    return new Promise(resolve => {
      const url = `${URL.searchNameSystemType}${payload.systemType}`;
      fetchApiGET(url, resolve);
    });
  }

  //  repList
  static repListByName(payload) {
    return new Promise(resolve => {
      const url = `${URL.repList}?aliasName=${payload.aliasName}`;
      fetchApiGET(url, resolve);
    });
  }

  //  查询构建任务详情
  static getStageDetails(payload) {
    return new Promise(resolve => {
      const url = `${URL.getStageDetails}?stageId=${payload.data.stageTpId}`;
      const reqParam = {};
      fetchApi(reqParam, url, resolve);
    });
  }

  static getTagList(payload) {
    return new Promise(resolve => {
      const url = URL.getTagList;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static addTag(payload) {
    return new Promise(resolve => {
      const url = URL.editTag;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static deleteTag(payload) {
    return new Promise(resolve => {
      const url = URL.editTag;
      const reqParam = payload.data;
      fetchApiDELETE(reqParam, url, resolve);
    });
  }

  static downloadFile(payload) {
    return new Promise(resolve => {
      const url = `${URL.downloadFile}?repoId=
       ${payload.data.repoId}&ref=${payload.data.ref}&fileFormat=
        ${payload.data.fileFormat}`;
      fetchApiGET(url, resolve);
    });
  }

  static deleteStage(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteStage}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  static updateJobStatus(payload) {
    return new Promise(resolve => {
      const url = `${URL.updateJobStatus}?id=${payload.data.id}&defName=${
        payload.data.defName
      }&buildNum=${payload.data.buildNum}`;
      fetchApiGET(url, resolve);
    });
  }

  // system
  static add(param) {
    const postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "pjmMenuList":
          url = `${URL.getPjmMenuList}?projectId=${param.params.projectId}`;
          break;
        case "userMenuAll":
          url = URL.getSystemMenuAll;
          break;
        case "userManage":
          url = URL.addSystemUser;
          break;
        case "roleManage":
          url = URL.addSystemRole;
          break;
        case "roleAuthorize":
          url = URL.roleAuthorize;
          break;
        case "menuManage":
          url = URL.addSystemMenu;
          break;
        case "orgManage":
          url = URL.addSystemOrg;
          break;
        default:
          break;
      }

      if (param.from === "userMenuAll" || param.from === "pjmMenuList") {
        fetchApi({}, url, resolve);
      }

      fetchApi(postdata, url, resolve);
    });
  }

  static del(param) {
    let url = "";
    const postdata = {};
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = `${URL.deleteSystemUser}${param.id}`;
          break;

        case "roleManage":
          url = `${URL.deleteSystemRole}/${param.id}`;
          break;

        case "menuManage":
          url = `${URL.deleteSystemMenu}/${param.id}`;
          break;
        case "orgManage":
          url = `${URL.deleteSystemOrg}/${param.id}`;
          break;
        case "authorityManage":
          url = `${URL.syspermissionDelete}?permissionId=${param.id}`;
          break;
        default:
          break;
      }
      fetchApiDELETE(postdata, url, resolve);
    });
  }

  static get(param) {
    let url = "";
    const postdata = { conditions: [] };
    return new Promise(resolve => {
      switch (param.from) {
        case "organizationAll":
          if (param.page === null) {
            url = `${URL.getSystemOrgId}${param.params.orgId}`;
          } else {
            url = `${URL.getSystemOrgId}?size=10&page=${param.page}&userStatus=${
              param.params.userStatus
            }`;
          }
          break;
        case "userManage":
          if (param.page === null) {
            url = URL.getSystemUser;
          } else {
            url = `${URL.getSystemUser}?size=10&page=${param.page}`;
          }
          break;
        case "userFind":
          if (param.page === null) {
            url = `${URL.userFind}${param.params.id}`;
          } else {
            url = `${URL.userFind}${param.params.id}`;
          }
          break;
        case "roleAll":
          if (param.page === null) {
            url = `${URL.searchSystemRole}?roleName=${param.params.roleName}`;
          } else {
            url = `${URL.searchSystemRole}?size=1&page=${param.page}&userStatus=${
              param.params.userStatus
            }`;
          }
          break;
        case "userFindone":
          url = `${URL.userFindone}?userId=${param.page}`;
          break;
        case "roleManage":
          if (param.page === null) {
            url = URL.getSystemRole;
          } else {
            url = `${URL.getSystemRole}?size=10&page=${param.page}`;
          }
          break;
        case "sysroleFind":
          url = `${URL.sysroleFind}${param.page}`;
          break;
        case "roleMenus":
          url = `${URL.roleMenus}${param.page}`;
          break;
        case "menuTree":
          url = URL.searchSystemMenu;
          break;

        case "menuTreeManage":
          url = URL.searchSystemMenuManage;
          break;
        case "introduceMenu":
          url = `${URL.introduceMenu}${param.params.id}`;
          break;
        case "childMenus":
          if (param.page === null) {
            url = `${URL.childMenus}&menuId=${param.params.id}`;
          } else {
            url = `${URL.childMenus}?size=10&page=${param.page}&menuId=${param.params.id}`;
          }
          break;
        case "menuFind":
          url = `${URL.menuFind}${param.page}`;
          break;
        case "introduceOrg":
          url = `${URL.introduceOrg}${param.params.id}`;
          break;
        case "childOrgs":
          if (param.page === null) {
            url = `${URL.childOrgs}&orgId=${param.params.id}`;
          } else {
            url = `${URL.childOrgs}?size=10&page=${param.page}&orgId=${param.params.id}`;
          }
          break;
        case "orgFind":
          url = `${URL.orgFind}${param.page}`;
          break;
        case "operationLog":
          if (param.page === null) {
            //  无分页查询
            url = `${URL.getSystemLog}&menuId=${param.params.id}`;
          } else if (param.params) {
            url = `${URL.getSystemLog}?queryStr=${param.params.id}&actionType=${
              param.params.id
            }&startTime=${param.params.id}&endTime=${param.params.id}?size=10&page=${param.page}`;
          } else {
            url = `${URL.getSystemLog}?size=10&page=${param.page}`;
          }

          break;
        case "operationLogDetail":
          url = `${URL.getSystemLogDetail}${param.page}`;
          break;
        default:
          break;
      }
      fetchApiGET(url, resolve);
    });
  }

  static update(param) {
    const postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.updateSystemUser;
          break;
        case "forbidden":
          url = `${URL.userStatusChange}/userId/${param.data.id}/userStatus/${
            param.data.userStatus
          }`;
          break;
        case "roleManage":
          url = URL.updateSystemRole;
          break;
        case "menuManage":
          url = URL.updateSystemMenu;
          break;
        case "orgManage":
          url = URL.updateSystemOrg;
          break;
        case "authorityManage":
          url = URL.syspermissionUpdate;
          break;
        default:
          break;
      }

      if (param.from === "forbidden") {
        fetchApiPUT({}, url, resolve);
      } else {
        fetchApiPUT(postdata, url, resolve);
      }
    });
  }

  static search(param) {
    let url = "";
    const postdata = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          if (param.page === null) {
            //  无分页查询
            url = encodeURI(
              `${URL.getSystemUser}?queryStr=${param.params.name}&page=${param.page}`
            );
          } else {
            url = encodeURI(
              `${URL.getSystemUser}?queryStr=${param.params.name}&userStatus=${
                param.params.userStatus
              }&size=10&page=${param.page}`
            );
          }
          break;
        case "roleManage":
          if (param.page === null) {
            //  无分页查询
            url = encodeURI(`${URL.getSystemRole}?roleName=${param.params.roleName}`);
          } else {
            //  有分页查询
            url = encodeURI(
              `${URL.getSystemRole}?roleName=${param.params.roleName}&page=${param.page}`
            );
          }
          break;
        case "operationLog":
          if (param.page === null) {
            //  无分页查询
            url = encodeURI(URL.getSystemLog);
          } else {
            url = encodeURI(
              `${URL.getSystemLog}?queryStr=${param.params.queryStr}&actionType=${
                param.params.actionType
              }&startTime=${param.params.startTime}&endTime=${param.params.endTime}&size=10&page=${
                param.page
              }`
            );
          }
          break;
        default:
          break;
      }
      fetchApiGET(url, resolve);
    });
  }

  //  环境查询
  static getEnvironmentRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getEnvironment;
      const reqParam = {
        page: payload.data.page,
        size: 10,
        sortid: "id",
        sortvalue: "desc"
      };
      if (payload.data.conditions) {
        reqParam["conditions"] = payload.data.conditions;
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  //  环境新增
  static addEnvironmentRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addEnvironment;
      const postdata = {
        envName: payload.data.envName,
        projectId: payload.data.projectId,
        envType: payload.data.envType
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  环境删除
  static deleteEnvironmentRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteEnvironment}?envId=${payload.data}`;
      fetchApiDELETE(payload, url, resolve);
    });
  }

  //  环境修改
  static updateEnvironmentRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateEnvironment;
      const postdata = {
        envName: payload.data.envName,
        projectId: payload.data.projectId,
        envType: payload.data.envType,
        envId: payload.data.envId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 环境类型
  static getEnvironmentTypeRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getEnvironmentType;
      fetchApiGET(url, resolve);
    });
  }

  //  角色查询
  static getRoleRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getRole}?projectId=${payload.data.projectId}&roleName=${
        payload.data.roleName
      }&page=${payload.data.page}&size=${payload.data.size}`;
      fetchApiGET(url, resolve);
    });
  }

  //  角色新增
  static addRoleRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addRole;
      const postdata = {
        projectId: payload.data.projectId,
        roleName: payload.data.roleName,
        roleDesc: payload.data.roleDesc
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  角色删除
  static deleteRoleRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteRole}/${payload.data.id}`;
      fetchApiDELETE(payload, url, resolve);
    });
  }

  //  角色修改
  static updateRoleRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateRole;
      const postdata = {
        projectId: payload.data.projectId,
        id: payload.data.id,
        roleName: payload.data.roleName,
        roleDesc: payload.data.roleDesc
      };
      fetchApiPUT(postdata, url, resolve);
    });
  }

  //  角色授权
  static getAllMenuRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getRoleAllMenu;
      fetchApiGET(url, resolve);
    });
  }

  static getSelectMenuRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getRoleSelectMenu}/${payload.data.roleId}`;
      fetchApiGET(url, resolve);
    });
  }

  static saveSelectMenuRequest(payload) {
    return new Promise(resolve => {
      const url = URL.saveRoleSelectMenu;
      const postdata = {
        menuIds: payload.data.menuIds,
        roleId: payload.data.roleId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 团队
  //  团队查询
  static getTeamRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getTeam}?projectId=${payload.data.projectId}&realName=${
        payload.data.realName
      }&page=${payload.data.page}&size=10`;
      fetchApiGET(url, resolve);
    });
  }

  //  团队新增
  static addTeamRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.addTeam}/projectId/${payload.data.projectId}/roleId${payload.data.roleId}`;
      const postdata = { userIds: payload.data.userIds };
      fetchApi(postdata, url, resolve);
    });
  }

  //  团队删除
  static deleteTeamRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteTeam}/teamId/${payload.data.teamId}`;
      fetchApiDELETE(payload, url, resolve);
    });
  }

  //  团队授权
  static authorizeTeamRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.authorizeTeam}/teamId/${payload.data.teamId}`;
      const postdata = { roleIds: payload.data.roleIds };
      fetchApi(postdata, url, resolve);
    });
  }

  //  团队chengyuan
  static userAllTeamRequest(payload) {
    return new Promise(resolve => {
      const url = URL.userallTeam;
      fetchApiGET(url, resolve);
    });
  }

  //  资源查询
  static getResourceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.getResource;
      const reqParam = {
        page: payload.data.page,
        size: 10,
        sortid: "id",
        sortvalue: "desc"
      };
      if (payload.data.conditions) {
        reqParam["conditions"] = payload.data.conditions;
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  //  资源新增
  static addResourceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addResource;
      const postdata = {
        resName: payload.data.resName,
        resType: payload.data.resType,
        envId: payload.data.envId,
        resHostUser: payload.data.resHostUser,
        resHostPwd: payload.data.resHostPwd,
        resHostPort: payload.data.resHostPort,
        resHostIp: payload.data.resHostIp,
        id: payload.data.id,
        projectId: payload.data.projectId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  资源修改
  static updateResourceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateResource;
      const postdata = {
        resName: payload.data.resName,
        resType: payload.data.resType,
        envId: payload.data.envId,
        resHostUser: payload.data.resHostUser,
        resHostPwd: payload.data.resHostPwd,
        resHostPort: payload.data.resHostPort,
        resHostIp: payload.data.resHostIp,
        id: payload.data.id,
        projectId: payload.data.projectId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  资源删除
  static deleteResourceRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteResource}?resId=${payload.data}`;
      fetchApiDELETE(payload, url, resolve);
    });
  }

  //  测试
  static testResourceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.testResource;
      const postdata = {
        resName: payload.data.resName,
        resType: payload.data.resType,
        envId: payload.data.envId,
        resHostUser: payload.data.resHostUser,
        resHostPwd: payload.data.resHostPwd,
        resHostPort: payload.data.resHostPort,
        resHostIp: payload.data.resHostIp,
        id: payload.data.id
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 资源类型
  static getEnvironmentNameRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getEnvironmentName}/${payload.data.projectId}`;
      fetchApiGET(url, resolve);
    });
  }

  // 容器云
  //  容器新增
  static addClusterRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addCluster;
      const postdata = {
        clusterResType: payload.data.clusterResType,
        clusterName: payload.data.clusterName,
        clusterVipPort: payload.data.clusterVipPort,
        clusterIngressVipIp: payload.data.clusterIngressVipIp,
        clusterVipIp: payload.data.clusterVipIp,
        clusterCerType: payload.data.clusterCerType,
        clusterCa: payload.data.clusterCa,
        clusterClientCa: payload.data.clusterClientCa,
        clusterClientKey: payload.data.clusterClientKey,
        dashboardToken: payload.data.dashboardToken,
        projectId: payload.data.projectId,
        zoneId: payload.data.zoneId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 容器信息
  static findClusterInfoRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.findClusterInfo}?clusterId=${payload.data.clusterId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  容器新增测试
  static testClusterRequest(payload) {
    return new Promise(resolve => {
      const url = URL.testCluster;
      const postdata = {
        clusterName: payload.data.clusterName,
        clusterVipPort: payload.data.clusterVipPort,
        clusterVipIp: payload.data.clusterVipIp,
        clusterCerType: payload.data.clusterCerType,
        clusterCa: payload.data.clusterCa,
        clusterClientCa: payload.data.clusterClientCa,
        clusterClientKey: payload.data.clusterClientKey,
        dashboardToken: payload.data.dashboardToken,
        clusterIngressVipIp: payload.data.clusterIngressVipIp,
        projectId: payload.data.projectId,
        zoneId: payload.data.zoneId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  主机新增
  static addCaasNodeRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addCaasNode;
      const postdata = {
        nodeName: payload.data.nodeName,
        nodeHostRole: payload.data.nodeHostRole,
        nodeHostIp: payload.data.nodeHostIp,
        nodeHostPort: payload.data.nodeHostPort,
        nodeHostUser: payload.data.nodeHostUser,
        nodeHostPwd: payload.data.nodeHostPwd,
        nodeCerType: payload.data.nodeCerType,
        clusterId: payload.data.clusterId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  主机查询
  static getCaasNodeListRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getCaasNodeList}?page=${payload.data.page}&size=10`;
      const reqParam = {};
      if (payload.data.conditions) {
        reqParam["conditions"] = payload.data.conditions;
      } else {
        reqParam["conditions"] = [];
      }
      fetchApi(reqParam, url, resolve);
    });
  }

  static deleteCaasNodeRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteCaasNode}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  // 主机信息
  static findPodInfoRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.findPodInfo}?page=${payload.data.page}&size=10&clusterId=${
        payload.data.clusterId
      }&nodeNames=${payload.data.nodeNames}&podeName=${payload.data.podeName}`;
      fetchApiGET(url, resolve);
    });
  }

  //  主机修改
  static updateCaasNodeRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateCaasNode;
      const postdata = {
        id: payload.data.id,
        nodeId: payload.data.nodeId,
        nodeName: payload.data.nodeName,
        nodeHostRole: payload.data.nodeHostRole,
        nodeHostIp: payload.data.nodeHostIp,
        nodeHostPort: payload.data.nodeHostPort,
        nodeHostUser: payload.data.nodeHostUser,
        nodeHostPwd: payload.data.nodeHostPwd,
        nodeCerType: payload.data.nodeCerType,
        clusterId: payload.data.clusterId,
        createTime: payload.data.createTime,
        createUser: payload.data.createUser
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  主机测试
  static testCaasNodeRequest(payload) {
    return new Promise(resolve => {
      const url = URL.testCaasNode;
      const postdata = {
        nodeName: payload.data.nodeName,
        nodeHostRole: payload.data.nodeHostRole,
        nodeHostIp: payload.data.nodeHostIp,
        nodeHostPort: payload.data.nodeHostPort,
        nodeHostUser: payload.data.nodeHostUser,
        nodeHostPwd: payload.data.nodeHostPwd,
        nodeCerType: payload.data.nodeCerType,
        clusterId: payload.data.clusterId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // pod基本信息
  static getmonitorPodBasicRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.caasPodsInfo}${payload.data.podName}/clusterId/${
        payload.data.clusterId
      }?namespace=${payload.data.namespace}`;
      fetchApiGET(url, resolve);
    });
  }

  // pod事件
  static getmonitorPodEventRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.caasPodsEvents}${payload.data.podName}/events/clusterId/${
        payload.data.clusterId
      }?namespace=${payload.data.namespace}&page=${payload.data.page}&size=${payload.data.size}`;
      fetchApiGET(url, resolve);
    });
  }

  // pod-log
  static getmonitorPodLogRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.caasPodsLogs}${payload.data.podName}/logs/clusterId/${
        payload.data.clusterId
      }?namespace=${payload.data.namespace}&timestamp=${payload.data.timestamp}&page=${
        payload.data.page
      }&size=${payload.data.size}`;
      fetchApiGET(url, resolve);
    });
  }

  // pod监控
  static getmonitorInfoRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.caasPodsMetrics}${payload.data.podName}/metrics/clusterId/${
        payload.data.clusterId
      }?namespace=${payload.data.namespace}`;
      fetchApiGET(url, resolve);
    });
  }

  //  工作区新增
  static addCaasNamespaceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.addCaasNamespace;
      const postdata = {
        namespaceName: payload.data.namespaceName,
        envId: payload.data.envId,
        deploymentDefaultLimitCpu: payload.data.deploymentDefaultLimitCpu,
        deploymentDefaultRequestCpu: payload.data.deploymentDefaultRequestCpu,
        deploymentDefaultLimitMem: payload.data.deploymentDefaultLimitMem,
        deploymentDefaultRequestMem: payload.data.deploymentDefaultRequestMem,
        quotaLimitCpu: payload.data.quotaLimitCpu,
        quotaRequestCpu: payload.data.quotaRequestCpu,
        quotaLimitMem: payload.data.quotaLimitMem,
        quotaRequestMem: payload.data.quotaRequestMem,
        clusterId: payload.data.clusterId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  工作区修改
  static updateCaasNamespaceRequest(payload) {
    return new Promise(resolve => {
      const url = URL.updateCaasNamespace;
      const postdata = {
        id: payload.data.id,
        namespaceId: payload.data.namespaceId,
        namespaceName: payload.data.namespaceName,
        envId: payload.data.envId,
        deploymentDefaultLimitCpu: payload.data.deploymentDefaultLimitCpu,
        deploymentDefaultRequestCpu: payload.data.deploymentDefaultRequestCpu,
        deploymentDefaultLimitMem: payload.data.deploymentDefaultLimitMem,
        deploymentDefaultRequestMem: payload.data.deploymentDefaultRequestMem,
        quotaLimitCpu: payload.data.quotaLimitCpu,
        quotaRequestCpu: payload.data.quotaRequestCpu,
        quotaLimitMem: payload.data.quotaLimitMem,
        quotaRequestMem: payload.data.quotaRequestMem,
        clusterId: payload.data.clusterId
      };
      fetchApi(postdata, url, resolve);
    });
  }

  // 工作区name查询
  static searchCaasNamespaceListRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.searchCaasNamespace}?page=${payload.data.page}&size=10&clusterId=${
        payload.data.clusterId
      }&namespaceName=${payload.data.namespaceName}`;
      fetchApiGET(url, resolve);
    });
  }

  //  工作区
  static getCaasNamespaceListRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getCaasNamespaceList}?page=${payload.data.page}&size=10&clusterId=${
        payload.data.clusterId
      }`;
      fetchApiGET(url, resolve);
    });
  }

  static deleteCaasNamespaceRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.deleteCaasNamespace}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（收藏）
  static houseCollectRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.houseCollect}?imageId=${payload.data.imageId}&flag=${payload.data.flag}`;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（收藏列表）
  static gethouseCollectListRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseCollectList;
      const postdata = {
        page: payload.data.page,
        size: 5,
        projectCode: payload.data.projectCode
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  镜像仓库（镜像信息）
  static gethouseImageInfoRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.gethouseImageInfoList}?id=${payload.data.id}&projectId=${
        payload.data.projectId
      }`;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（公私列表）
  static gethouseImageListRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseImagesList;
      const postdata = {
        page: payload.data.page,
        size: payload.data.size || 5,
        sortid: "updateTime",
        sortvalue: "desc"
      };
      if (payload.data.conditions) {
        postdata["conditions"] = payload.data.conditions;
      } else {
        postdata["conditions"] = [];
      }
      fetchApi(postdata, url, resolve);
    });
  }

  //  镜像仓库（公私列表）
  static gethouseImagePublicListRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseImagesPublicList;
      const postdata = {
        page: payload.data.page,
        size: 5,
        sortid: "updateTime",
        sortvalue: "desc"
      };
      if (payload.data.conditions) {
        postdata["conditions"] = payload.data.conditions;
      } else {
        postdata["conditions"] = [];
      }
      fetchApi(postdata, url, resolve);
    });
  }

  //  镜像仓库（镜像同步）
  static houseImageSyncRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseSync;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（镜像扫描）
  static houseImageScanRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.gethouseScan}?imageName=${payload.data.imageName}&tag=${
        payload.data.tagName
      }&imageId=${payload.data.imageId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（镜像扫描1）
  static houseImageScanTagRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.gethouseScanTag}?imageName=${payload.data.imageName}&tag=${
        payload.data.tagName
      }&imageId=${payload.data.imageId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（镜像扫描2）
  static houseImageScanTagsRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.gethouseSyncTag}?imageName=${payload.data.imageName}&tag=${
        payload.data.tagName
      }`;

      fetchApiGET(url, resolve);
    });
  }

  //  镜像仓库（镜像扫描3）
  static houseImageUpdateScanRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseScanUpdateTag;
      const postdata = payload.data.data;
      fetchApi(postdata, url, resolve);
    });
  }

  //  镜像仓库（版本）
  static houseImageTagsRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseTags;
      const postdata = {
        page: payload.data.page,
        size: payload.data.size,
        sortid: payload.data.sortid,
        sortvalue: payload.data.sortvalue
      };
      if (payload.data.conditions) {
        postdata["conditions"] = payload.data.conditions;
      } else {
        postdata["conditions"] = [];
      }
      fetchApi(postdata, url, resolve);
    });
  }

  //  镜像仓库（保存）
  static houseImageUpdateRequest(payload) {
    return new Promise(resolve => {
      const url = URL.gethouseUpdate;
      const postdata = {
        id: payload.data.id,
        imageInfo: payload.data.imageInfo,
        dockerfile: payload.data.dockerfile
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  应用市场
  static getmarketAppListRequest(payload) {
    return new Promise(resolve => {
      const url = encodeURI(
        `${URL.getmarketAppList}?marketAppType=${payload.data.marketAppType}&page=${
          payload.data.page
        }&size=12`
      );

      fetchApiGET(url, resolve);
    });
  }

  //  应用市场detail
  static getmarketAppDetailRequest(payload) {
    return new Promise(resolve => {
      const url = `${URL.getmarketAppDetail}/${payload.data.marketAppId}`;
      fetchApiGET(url, resolve);
    });
  }

  // 市场部署
  static findMarketdeployRequest(payload) {
    return new Promise(resolve => {
      const url = URL.findMarketdeploy;
      const postdata = {
        data: payload.data.data,
        container: payload.data.container
      };
      fetchApi(postdata, url, resolve);
    });
  }

  //  分页查找部署实例定义
  static deploymentPageList(payload) {
    return new Promise(resolve => {
      const url = `${URL.deploymentPageList}?page=${payload.data.page}&size=10`;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static deploymentSave(payload) {
    return new Promise(resolve => {
      const url = URL.deploymentSave;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static deploymentUpdate(payload) {
    return new Promise(resolve => {
      const url = URL.deploymentUpdate;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static findDefination(payload) {
    return new Promise(resolve => {
      const url = `${URL.findDefination}?id=${payload.data}`;
      fetchApiGET(url, resolve);
    });
  }

  static cloneDeployMent(payload) {
    return new Promise(resolve => {
      const url = URL.cloneDefination;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static deploymentDelete(payload) {
    return new Promise(resolve => {
      const url = `${URL.deploymentDelete}?id=${payload.data}`;
      fetchApiDELETE({}, url, resolve);
    });
  }

  static deployImageList(payload) {
    return new Promise(resolve => {
      const url = `${URL.imagestags}?projectCode=${payload.data.projectCode}`;
      fetchApiGET(url, resolve);
    });
  }

  static getRuningEnvList(payload) {
    return new Promise(resolve => {
      const url = URL.getRuningEnvList;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static uploadSoft(payload) {
    return new Promise(resolve => {
      const url = `${URL.uploadSoft}?repName=${payload.data.repName}&groupId=${
        payload.data.projectId
      }&artifactId=${payload.data.artifactId}&alliasName=${payload.data.alliasName}&extension=${
        payload.data.extension
      }&pojectId=${payload.data.projectId}`;

      fetchApiFORM(payload.data.file, url, resolve);
    });
  }

  static getHostList(payload) {
    return new Promise(resolve => {
      const url = URL.getHostList;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static getShell(payload) {
    return new Promise(resolve => {
      const url = URL.getShell;
      const reqParam = payload.data;
      fetchApiGET(url, resolve);
    });
  }

  static getYmlTmp(payload) {
    return new Promise(resolve => {
      const url = `${URL.findDeployYmlTmp}?type=${payload.data.type}`;
      fetchApiGET(url, resolve);
    });
  }

  static updateDeployStatus(payload) {
    return new Promise(resolve => {
      const url = `${URL.updateDeployStatus}?id=${payload.data.id}&defName=${
        payload.data.defName
      }&buildNum=${payload.data.buildNum}&instanceId=${payload.data.instanceId}`;
      fetchApiGET(url, resolve);
    });
  }

  static getDeployLog(payload) {
    return new Promise(resolve => {
      let url;
      if (payload.data.deployType == "1") {
        url = `${URL.getDeployLog}?jobName=${payload.data.jobName}&buildNum=${
          payload.data.buildNum
        }&pojectId=${payload.data.pojectId}`;
      } else if (payload.data.deployType == "2") {
        url = `${URL.kbrsLogFind}?deployDfId=${payload.data.deployDfId}`;
      }
      fetchApiGET(url, resolve);
    });
  }

  static getPodList(payload) {
    return new Promise(resolve => {
      const url = `${URL.getPodList}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  static findPodLog(payload) {
    return new Promise(resolve => {
      const url = `${URL.findPodLog}?id=${payload.data.id}&podName=${payload.data.podName}`;
      fetchApiGET(url, resolve);
    });
  }

  static getDeployHisLog(payload) {
    return new Promise(resolve => {
      const url = `${URL.getDeployLog}?jobName=${payload.data.jobName}&buildNum=${
        payload.data.buildNum
      }&pojectId=${payload.data.pojectId}`;
      fetchApiGET(url, resolve);
    });
  }

  static findIpListById(payload) {
    return new Promise(resolve => {
      const url = `${URL.findIpListById}?id=${payload.data.id}&param=${
        payload.data.param ? payload.data.param : ""
      }`;
      fetchApiGET(url, resolve);
    });
  }

  static getHistoryList(payload) {
    return new Promise(resolve => {
      const url = `${URL.getHistoryList}?sortid=${payload.data.sortid}&sortvalue=${
        payload.data.sortvalue
      }&page=${payload.data.page}&size=${payload.data.size}`;
      const reqParam = payload.data;
      fetchApi(reqParam, url, resolve);
    });
  }

  static getHistoryListDetails(payload) {
    return new Promise(resolve => {
      const url = `${URL.getHistoryListDetails}?id=${payload.data.id}`;
      fetchApiGET(url, resolve);
    });
  }

  static executeDeployment(payload) {
    return new Promise(resolve => {
      const url = `${URL.executeDeployment}?id=${payload.data.id}&opsType=${payload.data.opsType}`;
      const reqParam = {
        packageUrl: payload.data.packageUrl,
        resIds: payload.data.resIds,
        deployOps: payload.data.deployOps
      };
      fetchApi(reqParam, url, resolve);
    });
  }

  static findDeployStatus(payload) {
    return new Promise(resolve => {
      const url = `${URL.findDeployStatus}?id=${payload.data.id}&defName=${
        payload.data.defName
      }&buildNum=${payload.data.buildNum}`;
      fetchApiGET(url, resolve);
    });
  }

  static getUserlistById(payload) {
    return new Promise(resolve => {
      const url = `${URL.getUserlistById}/${payload.data.projectId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  根据projectId查找集群信息
  static getClusterListsByProjectId(payload) {
    return new Promise(resolve => {
      const url = `${URL.getCaasClusterListsByProjectId}?projectId=${payload.data.projectId}`;
      fetchApiGET(url, resolve);
    });
  }

  //  根据集群id查询命名空间pod资源限制值
  static getCaasNamespacePodListByClusterId(payload) {
    return new Promise(resolve => {
      const url = `${URL.getSpacePodListByClusterId}?clusterId=${payload.data.clusterId}&envId=${
        payload.data.envId
      }`;
      fetchApiGET(url, resolve);
    });
  }

  // Maitanance
  static maitananceAdd(param) {
    let postdata = {};
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "allPartList":
          postdata = {
            conditions: [
              {
                name: "projectId",
                sopt: "eq",
                value: param.params.projectId //  正常情况/虚拟机时用
              }
            ]
          };
          if (param.data === null) {
            url = `${URL.findByCustomized}?size=10&sortid=id&sortvalue=desc&page=1`;
          } else {
            url = `${URL.findByCustomized}?size=10&sortid=id&sortvalue=desc&page=${param.data}`;
          }

          break;

        case "visualEventFindByCustomized":
          postdata = {
            conditions: [
              {
                name: "instanceId",
                sopt: "eq",
                value: `${param.params.instanceId}`
              }
            ]
          };
          if (param.data === null) {
            url = `${URL.visualEventFindByCustomized}?size=10&sortid=id&sortvalue=desc&page=1`;
          } else {
            url = `${URL.visualEventFindByCustomized}?size=10&sortid=id&sortvalue=desc&page=${
              param.data
            }`;
          }
          break;
        default:
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }

  static maitananceDel(param) {
    let url = "";
    const postdata = {};
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = `${URL.deleteSystemUser}${param.id}`;
          break;
        case "roleManage":
          url = `${URL.deleteSystemRole}/${param.id}`;
          break;
        case "menuManage":
          url = `${URL.deleteSystemMenu}/${param.id}`;
          break;
        case "orgManage":
          url = `${URL.deleteSystemOrg}/${param.id}`;
          break;
        case "authorityManage":
          url = `${URL.syspermissionDelete}?permissionId=${param.id}`;
          break;
        default:
          break;
      }
      fetchApiDELETE(postdata, url, resolve);
    });
  }

  static maitananceGet(param) {
    let url = "";
    let postdata = { conditions: [] };
    return new Promise(resolve => {
      switch (param.from) {
        case "allPartListAction":
          url = `${URL.execute}?deployServiceId=${param.params.deployServiceId}&execType=${
            param.params.execType
          }`;
          break;
        case "findInstancesByServiceId":
          url = `${URL.findInstancesByServiceId}?deployServiceId=${param.params.deployServiceId}`;
          break;
        case "findInstanceByInstanceId":
          url = `${URL.findInstanceByInstanceId}?instanceId=${param.params.instanceId}`;
          break;
        case "visualCheckLog":
          url = `${URL.visualCheckLog}?instanceId=${param.params.instanceId}&logPath=${
            param.params.logPath
          }&size=${param.params.sizeNumber}`;
          break;
        case "visualMonitorCPU":
          url = `${URL.visualMonitor}?code= ${param.params.code}&hostIp=${param.params.hostIp}`;
          break;
        case "visualMonitorMEM":
          url = `${URL.visualMonitor}?code=${param.params.code}&hostIp=${param.params.hostIp}`;
          break;
        case "visualHighAvailableInfo":
          url = `${URL.visualHighAvailableInfo}?instanceId=${param.params.instanceId}`;
          break;
        case "visualUpdateInstanceDisable":
          url = `${URL.visualUpdateInstanceDisable}?instanceId=${param.params.instanceId}&code=${
            param.params.code
          }`;
          break;
        case "caasPodsInfo":
          url = `${URL.caasPodsInfo}${param.params.podName}?namespaceId=${
            param.params.namespaceId
          }`;
          break;
        case "caasPodsInfoMonitor":
          url = `${URL.caasPodsMetrics}${param.params.podName}/metrics?namespaceId=${
            param.params.namespaceId
          }`;
          break;
        case "caasPodsEvents":
          if (param.page === null) {
            url = `${URL.caasPodsEvents}${param.params.podName}/events?namespaceId=${
              param.params.namespaceId
            }`;
          } else {
            url = `${URL.caasPodsEvents}${param.params.podName}
              /events?namespaceId=${param.params.namespaceId}&size=10&page=${param.page}`;
          }
          break;
        case "caasPodsLogs":
          if (param.page === null) {
            url = `${URL.caasPodsLogs}${param.params.podName}/logs?namespaceId=${
              param.params.namespaceId
            }&timestamp=${param.params.timestamp}`;
          } else {
            url = `${URL.caasPodsEvents}${param.params.podName}/logs?namespaceId=${
              param.params.namespaceId
            }&timestamp=${param.params.timestamp}&page=1&size=${param.page}`;
          }
          break;
        case "caasServicesPodsCount":
          url = `${URL.caasServicesPodsCount}${param.params.serviceName}/count?namespaceId=${
            param.params.namespaceId
          }`;
          break;
        case "caasServicesPodsListInfo":
          url = `${URL.caasServicesPodsInfo}${param.params.serviceName}/metrics?namespaceId=${
            param.params.namespaceId
          }`;
          break;
        case "caasServicesEvents":
          if (param.page === null) {
            url = `${URL.caasServicesEvents}${param.params.serviceName}/events?namespaceId=${
              param.params.namespaceId
            }`;
          } else {
            url = `${URL.caasServicesEvents}${param.params.serviceName}
              /events?namespaceId=${param.params.namespaceId}&size=10&page=${param.page}`;
          }
          break;
        case "caasServicesLogs":
          if (param.page === null) {
            url = `${URL.caasServicesLogs}${param.params.serviceName}/logs?namespaceId=${
              param.params.namespaceId
            }&timestamp=${param.params.timestamp}`;
          } else {
            url = `${URL.caasServicesLogs}${param.params.serviceName}/logs?namespaceId=${
              param.params.namespaceId
            }&timestamp=${param.params.timestamp}&size=15&page=${param.page}`;
          }
          break;

        case "caasServicesMetrics":
          url = `${URL.caasServicesMetrics}${param.params.serviceName}/metrics?namespaceId=${
            param.params.namespaceId
          }`;
          break;

        case "caasServicesLivenessprobe":
          url = `${URL.caasServicesLivenessprobe}${
            param.params.serviceId
          }/livenessprobe?livenessprobe=${param.params.livenessprobe}`;
          break;
        case "caasServicesConfig":
          url = `${URL.caasServicesConfig}${param.params.serviceId}/config`;
          break;
        case "caasServicesAction":
          if (param.page === "restart") {
            url = `${URL.caasServicesAction}${param.params.serviceId}/restart?rc=${
              param.params.serviceName
            }&namespaceId=${param.params.namespaceId}`;
          } else if (param.page === "start") {
            url = `${URL.caasServicesAction}${param.params.serviceId}/start?rc=${
              param.params.serviceName
            }&namespaceId=${param.params.namespaceId}`;
          } else if (param.page === "stop") {
            url = `${URL.caasServicesAction}${param.params.serviceId}/stop?rc=${
              param.params.serviceName
            }&namespaceId=${param.params.namespaceId}`;
          } else if (param.page === "del") {
            url = `${URL.caasServicesAction}${param.params.serviceId}?rc=${
              param.params.serviceName
            }&namespaceId=${param.params.namespaceId}`;
          }
          break;
        case "caasServicesHorizontalScaling":
          postdata = {
            expectCount: `${param.params.expectCount}`,
            namespaceId: param.params.namespaceId,
            serviceName: param.params.serviceName
          };
          url = `${URL.caasServicesHorizontalScaling}${param.params.serviceId}/horizontalScaling`;
          break;
        case "caasServicesConfigSet":
          postdata = {
            deployment: param.params.serviceName,
            namespaceId: param.params.namespaceId,
            requestCpu: param.params.requestCpu,
            requestMem: param.params.requestMem
          };
          url = `${URL.caasServicesHorizontalScaling}${param.params.serviceId}/config`;
          break;
        case "caasServicesTags":
          url = `${URL.caasServicesTags}?imageUrl=${param.params.imageUrl}`;
          break;
        case "caasServicesGrayRelease":
          postdata = {
            deployment: param.params.serviceName,
            namespaceId: param.params.namespaceId,
            image: param.params.image
          };
          url = `${URL.caasServicesGrayRelease}${param.params.serviceId}/grayRelease`;
          break;
        case "caasServicesDeploymentEnableHpa":
          url = `${URL.caasServicesDeploymentEnableHpa}${
            param.params.serviceId
          }/deploymentEnableHpa?namespaceId=${param.params.namespaceId}`;
          break;
        case "caasServicesAutoScaling":
          postdata = {
            deploymentHpaTrigger: param.params.deploymentHpaTrigger,
            maxreplicas: param.params.maxreplicas,
            minreplicas: param.params.minreplicas,
            strategyMaxunavailable: param.params.strategyMaxunavailable,
            namespaceId: param.params.namespaceId
          };
          url = `${URL.caasServicesAutoScaling}${param.params.serviceId}/autoScaling`;
          break;
        default:
          break;
      }
      if (
        param.from === "caasServicesLivenessprobe" ||
        param.from === "caasServicesAction" ||
        param.from === "caasServicesDeploymentEnableHpa"
      ) {
        if (param.page === "del") {
          fetchApiDELETE({}, url, resolve);
          return;
        } else if (param.page === "changeStatus") {
          fetchApiPUT({}, {}, resolve);
          return;
        }
        fetchApiPUT({}, url, resolve);
        return;
      }
      if (
        param.from === "caasServicesHorizontalScaling" ||
        param.from === "caasServicesConfigSet" ||
        param.from === "caasServicesGrayRelease" ||
        param.from === "caasServicesAutoScaling"
      ) {
        fetchApiPUT(postdata, url, resolve);
        return;
      }
      fetchApiGET(url, resolve);
    });
  }

  static maitananceUpdate(param) {
    const postdata = param.data;
    let url = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "userManage":
          url = URL.updateSystemUser;
          break;
        case "forbidden":
          url = `${URL.userStatusChange}/userId/${param.data.id}/userStatus/${
            param.data.userStatus
          }`;
          break;
        case "roleManage":
          url = URL.updateSystemRole;
          break;
        case "menuManage":
          url = URL.updateSystemMenu;
          break;
        case "orgManage":
          url = URL.updateSystemOrg;
          break;
        case "authorityManage":
          url = URL.syspermissionUpdate;
          break;
        default:
          break;
      }

      if (param.from === "forbidden") {
        fetchApiPUT({}, url, resolve);
      } else {
        fetchApiPUT(postdata, url, resolve);
      }
    });
  }

  static maitananceSearch(param) {
    let url = "";
    let postdata = "";
    return new Promise(resolve => {
      switch (param.from) {
        case "allPartList":
          if (param.params.inputType && param.params.inputName) {
            postdata = {
              conditions: [
                {
                  name: "projectId",
                  sopt: "eq",
                  value: param.params.projectId
                },
                {
                  name: "applicationName",
                  sopt: "like",
                  value: param.params.inputName
                },
                {
                  name: "serviceType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            };
          } else if (param.params.inputType) {
            postdata = {
              conditions: [
                {
                  name: "projectId",
                  sopt: "eq",
                  value: param.params.projectId
                },
                {
                  name: "serviceType",
                  sopt: "eq",
                  value: param.params.inputType
                }
              ]
            };
          } else if (param.params.inputName) {
            postdata = {
              conditions: [
                {
                  name: "projectId",
                  sopt: "eq",
                  value: param.params.projectId
                },
                {
                  name: "applicationName",
                  sopt: "like",
                  value: param.params.inputName
                }
              ]
            };
          } else {
            postdata = {
              conditions: [
                {
                  name: "projectId",
                  sopt: "eq",
                  value: param.params.projectId
                }
              ]
            };
          }
          if (param.page === null) {
            url = `${URL.findByCustomized}?size=10&sortid=id&sortvalue=desc&page=1`;
          } else {
            url = `${URL.findByCustomized}?size=10&sortid=id&sortvalue=desc&page=${param.page}`;
          }
          break;
        default:
          break;
      }
      fetchApi(postdata, url, resolve);
    });
  }
}

export default ServiceApi;
